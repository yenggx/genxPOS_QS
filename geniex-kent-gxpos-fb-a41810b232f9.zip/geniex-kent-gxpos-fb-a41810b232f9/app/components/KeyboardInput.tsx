'use client';
import React, { InputHTMLAttributes, useEffect, useRef } from 'react';
import { useKeyboard } from './GlobalKeyboard';

interface KeyboardInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'onChange'> {
  keyboardLayout?: 'default' | 'email' | 'numeric';
  value: string;
  onChange: (val: string) => void;
}

export function KeyboardInput({ 
  keyboardLayout = 'default', 
  value, 
  onChange, 
  onFocus,
  onClick,
  placeholder,
  ...props 
}: KeyboardInputProps) {
  const { openKeyboard, setInputValue } = useKeyboard();
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync external value changes down to the keyboard state safely
  useEffect(() => {
    setInputValue(value || '');
  }, [value, setInputValue]);

  const handleOpen = () => {
    // Pass the placeholder up so the keyboard Preview Bar knows what you are typing!
    openKeyboard(keyboardLayout, value || '', onChange, placeholder || 'Text Input', props.type === 'password');
  };

  return (
    <input
      ref={inputRef}
      value={value}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
      onFocus={(e) => {
        e.stopPropagation();
        handleOpen();
        if (onFocus) onFocus(e);
      }}
      onClick={(e) => {
        e.stopPropagation();
        handleOpen();
        if (onClick) onClick(e);
      }}
      onPointerDown={(e) => {
        e.stopPropagation();
      }}
      {...props}
    />
  );
}