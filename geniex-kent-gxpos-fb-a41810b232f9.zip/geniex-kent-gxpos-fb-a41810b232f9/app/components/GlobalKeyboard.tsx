'use client';
import React, { createContext, useContext, useState, useRef, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import Keyboard from 'react-simple-keyboard';
import 'react-simple-keyboard/build/css/index.css';

interface KeyboardContextType {
  openKeyboard: (layout: 'default' | 'email' | 'numeric', initialValue: string, onChange: (val: string) => void, label?: string, isPassword?: boolean) => void;
  closeKeyboard: () => void;
  setInputValue: (val: string) => void;
}

const KeyboardContext = createContext<KeyboardContextType | null>(null);

export const useKeyboard = () => {
  const ctx = useContext(KeyboardContext);
  if (!ctx) throw new Error('useKeyboard must be used within a GlobalKeyboardProvider');
  return ctx;
};

export function GlobalKeyboardProvider({ children }: { children: React.ReactNode }) {
  const [mounted, setMounted] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [baseLayout, setBaseLayout] = useState<'default' | 'email' | 'numeric'>('default');
  const [shiftState, setShiftState] = useState<'default' | 'shift'>('default');
  const [input, setInput] = useState('');
  const [inputLabel, setInputLabel] = useState('');
  const [isPassword, setIsPassword] = useState(false);
  
  const keyboardRef = useRef<any>(null);
  const keyboardWrapperRef = useRef<HTMLDivElement>(null);
  const onChangeCallback = useRef<((val: string) => void) | null>(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  const openKeyboard = (layout: 'default' | 'email' | 'numeric', initialValue: string, onChange: (val: string) => void, label = '', isPwd = false) => {
    setBaseLayout(layout);
    setShiftState('default');
    setInput(initialValue);
    setInputLabel(label);
    setIsPassword(isPwd);
    onChangeCallback.current = onChange;
    if (keyboardRef.current) {
      keyboardRef.current.setInput(initialValue);
    }
    setIsOpen(true);
  };

  const closeKeyboard = () => setIsOpen(false);

  // BUG FIX: The Feedback Loop killer
  const setInputValue = useCallback((val: string) => {
    setInput((prevInput) => {
      // Stops the execution if the value hasn't actually changed
      if (prevInput === val) return prevInput; 
      
      // Syncs the physical keyboard instance if it differs
      if (keyboardRef.current && keyboardRef.current.getInput() !== val) {
        keyboardRef.current.setInput(val);
      }
      
      return val;
    });
  }, []);

  const onKeyPress = (button: string) => {
    if (button === "{shift}" || button === "{lock}") {
      setShiftState(shiftState === "default" ? "shift" : "default");
    }
    if (button === "{enter}" || button === "{close}") {
      closeKeyboard();
    }
  };

  const onChange = (inputVal: string) => {
    setInput(inputVal);
    if (onChangeCallback.current) {
      onChangeCallback.current(inputVal);
    }
  };

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent | TouchEvent) => {
      if (keyboardWrapperRef.current && keyboardWrapperRef.current.contains(e.target as Node)) {
        return;
      }
      if ((e.target as HTMLElement).tagName === 'INPUT' || (e.target as HTMLElement).tagName === 'TEXTAREA') {
        return;
      }
      closeKeyboard();
    };

    if (isOpen) {
      const timer = setTimeout(() => {
        window.addEventListener('mousedown', handleClickOutside);
        window.addEventListener('touchstart', handleClickOutside);
      }, 100);
      return () => {
        clearTimeout(timer);
        window.removeEventListener('mousedown', handleClickOutside);
        window.removeEventListener('touchstart', handleClickOutside);
      };
    }
  }, [isOpen]);

  const currentLayoutName = baseLayout === 'default' ? shiftState : baseLayout;

  const keyboardUI = (
    <div 
      id="global-keyboard-wrapper"
      ref={keyboardWrapperRef}
      onMouseDown={(e) => e.preventDefault()}
      className="fixed bg-gray-200 bottom-0 left-0 w-full z-[999999] transition-transform duration-300 ease-out"
      style={{ transform: isOpen ? 'translateY(0)' : 'translateY(100%)' }}
    >
      <div className="bg-[#e2e8f0]/95 backdrop-blur-2xl border-t border-white/50 shadow-[0_-10px_40px_rgba(0,0,0,0.15)] p-4 sm:p-6 rounded-t-3xl">
        
        <div className="flex justify-center mb-4">
          <button onClick={closeKeyboard} className="w-16 h-2 rounded-full bg-gray-400 hover:bg-orange-500 transition-colors" />
        </div>

        {/* ─── NEW PREVIEW BAR ─── */}
        <div className="mb-4 bg-white/70 border border-white rounded-2xl px-5 py-3 shadow-inner flex flex-col justify-center min-h-[70px]">
          <p className="text-[10px] font-bold text-orange-500 uppercase tracking-widest mb-0.5" style={{ fontFamily: "Poppins" }}>
            {inputLabel || 'Current Input'}
          </p>
          <p className="text-2xl font-black text-gray-900 truncate tracking-wide" style={{ fontFamily: "Poppins" }}>
            {input ? (isPassword ? '•'.repeat(input.length) : input) : <span className="text-gray-400 font-normal italic">Type here...</span>}
          </p>
        </div>

        <Keyboard
          keyboardRef={r => (keyboardRef.current = r)}
          layoutName={currentLayoutName}
          onChange={onChange}
          onKeyPress={onKeyPress}
          display={{
            "{bksp}": "⌫ Backspace",
            "{enter}": "Enter ↵",
            "{shift}": "⇧ Shift",
            "{lock}": "⇪ Caps",
            "{tab}": "Tab ⇥",
            "{space}": "Space",
            "{close}": "⬇ Hide Keyboard"
          }}
          layout={{
            default: [
              "` 1 2 3 4 5 6 7 8 9 0 - = {bksp}",
              "{tab} q w e r t y u i o p [ ] \\",
              "{lock} a s d f g h j k l ; ' {enter}",
              "{shift} z x c v b n m , . / {shift}",
              "{close} {space}"
            ],
            shift: [
              "~ ! @ # $ % ^ & * () _ + {bksp}",
              "{tab} Q W E R T Y U I O P { } |",
              "{lock} A S D F G H J K L : \" {enter}",
              "{shift} Z X C V B N M < > ? {shift}",
              "{close} {space}"
            ],
            email: [
              "1 2 3 4 5 6 7 8 9 0 - _ {bksp}",
              "q w e r t y u i o p @ .com",
              "a s d f g h j k l {enter}",
              "{shift} z x c v b n m . {shift}",
              "{close} {space}"
            ],
            numeric: ["1 2 3", "4 5 6", "7 8 9", "{close} 0 {bksp}"]
          }}
          theme="hg-theme-default geniex-keyboard-theme"
        />
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        .geniex-keyboard-theme { background: transparent !important; font-family: 'Poppins', sans-serif !important; }
        .geniex-keyboard-theme .hg-button { background: rgba(255, 255, 255, 0.9) !important; border: 1px solid rgba(0,0,0,0.05) !important; border-radius: 12px !important; box-shadow: 0 4px 10px rgba(0,0,0,0.04), inset 0 -2px 0 rgba(0,0,0,0.05) !important; font-weight: 700 !important; color: #334155 !important; height: 60px !important; transition: all 0.1s !important; }
        .geniex-keyboard-theme .hg-button:active { transform: scale(0.95) !important; background: #f97316 !important; color: white !important; }
        .geniex-keyboard-theme .hg-button-bksp, .geniex-keyboard-theme .hg-button-enter, .geniex-keyboard-theme .hg-button-shift, .geniex-keyboard-theme .hg-button-lock, .geniex-keyboard-theme .hg-button-close { background: #f1f5f9 !important; color: #64748b !important; font-size: 14px !important; }
        .geniex-keyboard-theme .hg-button-enter { background: linear-gradient(135deg, #f97316 0%, #ea580c 100%) !important; color: white !important; box-shadow: 0 4px 15px rgba(249,115,22,0.3) !important; }
      `}} />
    </div>
  );

  return (
    <KeyboardContext.Provider value={{ openKeyboard, closeKeyboard, setInputValue }}>
      {children}
      {mounted ? createPortal(keyboardUI, document.body) : null}
    </KeyboardContext.Provider>
  );
}