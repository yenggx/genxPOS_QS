// app/components/WorkstationInit.tsx
'use client';
import { useEffect } from 'react';
import { useSearchParams } from 'next/navigation';

export function WorkstationInit() {
  const searchParams = useSearchParams();
  useEffect(() => {
    const ws = searchParams.get('ws');
    if (ws) localStorage.setItem('workstationId', ws);
  }, []);
  return null;
}