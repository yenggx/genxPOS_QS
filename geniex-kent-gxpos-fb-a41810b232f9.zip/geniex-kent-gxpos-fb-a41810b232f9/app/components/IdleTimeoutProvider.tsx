"use client";

import { useIdleTimeout } from "@/app/hooks/useIdleTimeout";

export function IdleTimeoutProvider({ children }: { children: React.ReactNode }) {
  useIdleTimeout();
  return <>{children}</>;
}
