import { SimpleDiscount } from "@/src/api/discounts";
import { formatMoney } from "./ProductCard";
import { DiscountType } from "./constants";
import { useState } from "react";

function DiscountModal({ subtotal, appliedDiscount, onApply, onClose, availableDiscounts = [], cart = [] }: { subtotal: number; appliedDiscount: DiscountType | number | null; onApply: (type: DiscountType | number | null) => void; onClose: () => void; availableDiscounts?: SimpleDiscount[]; cart?: any[]; }) {
  const [selected, setSelected] = useState<DiscountType | number | null>(appliedDiscount);

  const COLOR_PALETTE = [
    { color: "#2563eb", bg: "rgba(37,99,235,0.07)", border: "rgba(37,99,235,0.20)", activeBg: "rgba(37,99,235,0.12)", activeBorder: "#2563eb" },
    { color: "#f97316", bg: "rgba(249,115,22,0.07)", border: "rgba(249,115,22,0.20)", activeBg: "rgba(249,115,22,0.12)", activeBorder: "#f97316" },
    { color: "#dc2626", bg: "rgba(220,38,38,0.07)", border: "rgba(220,38,38,0.20)", activeBg: "rgba(220,38,38,0.12)", activeBorder: "#dc2626" },
    { color: "#8b5cf6", bg: "rgba(139,92,246,0.07)", border: "rgba(139,92,246,0.20)", activeBg: "rgba(139,92,246,0.12)", activeBorder: "#8b5cf6" },
    { color: "#06b6d4", bg: "rgba(6,182,212,0.07)", border: "rgba(6,182,212,0.20)", activeBg: "rgba(6,182,212,0.12)", activeBorder: "#06b6d4" },
    { color: "#ec4899", bg: "rgba(236,72,153,0.07)", border: "rgba(236,72,153,0.20)", activeBg: "rgba(236,72,153,0.12)", activeBorder: "#ec4899" },
  ];

  const discounts = availableDiscounts || [];
  const cartItemCount = cart.reduce((sum, item) => sum + (item.qty || 0), 0);

  const checkRestrictions = (discount: SimpleDiscount) => {
    const violations: string[] = [];
    const minBasket = discount.restrictions?.minAmountBasket || 0;
    const itemCount = discount.restrictions?.numberofItems || 0;
    if (subtotal < minBasket) violations.push(`Min. amount: ${formatMoney(minBasket)}`);
    if (cartItemCount < itemCount) violations.push(`Min. ${itemCount} item(s)`);
    return { isValid: violations.length === 0, violations };
  };

  const calculatePreviewDiscountAmount = (discount: any) => {
    let amount = 0;
    if (discount.rate) {
      amount = subtotal * discount.rate;
    } else {
      if (discount.discount_type === 'percentage') {
        amount = subtotal * (parseFloat(discount.discount_value) / 100);
      } else {
        amount = Math.min(parseFloat(discount.discount_value), subtotal);
      }
    }
    const cap = discount.discount_cap || 0;
    if (cap > 0) amount = Math.min(amount, cap);
    return amount;
  };

  const getDiscountRate = (discount: any) => {
    if (discount.rate) return (discount.rate * 100).toFixed(0);
    if (discount.discount_type === 'percentage') return discount.discount_value;
    return `${parseFloat(discount.discount_value).toFixed(0)}`;
  };

  const getDiscountLabel = (discount: any) => discount.label || discount.campaign_name || `Discount ${discount.id}`;

  const selectedDiscount = discounts.find((d: any) => d.id === selected);
  const discountAmount = selected && selectedDiscount ? calculatePreviewDiscountAmount(selectedDiscount) : 0;

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 animate-fade-in" style={{ background: "rgba(160,150,145,0.40)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)" }} onClick={onClose}>
      <div className="rounded-3xl w-full max-w-lg mx-4 relative overflow-hidden animate-scale-in flex flex-col max-h-[90vh] bg-white shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div style={{ height: 6, background: "linear-gradient(90deg, #f97316 0%, #fb923c 60%, #fed7aa 100%)", flexShrink: 0 }} />
        
        {/* HEADER */}
        <div className="p-7 pb-4 flex-shrink-0">
          <button onClick={onClose} className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-base transition-all hover:bg-gray-100 text-gray-400">✕</button>
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0 bg-orange-50 border border-orange-100 shadow-sm text-2xl">
              🏷️
            </div>
            <div>
              <p className="text-[10px] font-bold text-orange-400 uppercase tracking-widest mb-0.5" style={{ fontFamily: "Poppins" }}>Available Campaigns</p>
              <h2 className="text-2xl font-black text-gray-900 leading-none" style={{ fontFamily: "Poppins" }}>Select <span className="text-orange-500">Offer</span></h2>
            </div>
          </div>
        </div>

        {/* SCROLLABLE LIST */}
        <div className="px-7 py-2 flex-1 overflow-y-auto hide-scroll flex flex-col gap-3">
          {discounts.length > 0 ? (
            discounts.map((discount: any, idx: number) => {
              const isSelected = selected === discount.id;
              const palette = COLOR_PALETTE[idx % COLOR_PALETTE.length];
              const colors = discount.color ? { color: discount.color, bg: discount.bg, border: discount.border, activeBg: discount.activeBg, activeBorder: discount.activeBorder } : palette;
              const checkResult = checkRestrictions(discount);
              const isDisabled = !checkResult.isValid;
              
              return (
                <button key={discount.id} onClick={() => !isDisabled && setSelected(isSelected ? null : discount.id)} className="flex items-center gap-4 rounded-2xl p-4 text-left w-full transition-all duration-200 focus:outline-none" disabled={isDisabled}
                  style={{ background: isSelected ? colors.activeBg : colors.bg, border: `2px solid ${isSelected ? colors.activeBorder : colors.border}`, boxShadow: isSelected ? `0 4px 16px ${colors.color}22` : "none", transform: isSelected ? "scale(1.01)" : "scale(1)", opacity: isDisabled ? 0.5 : 1, cursor: isDisabled ? "not-allowed" : "pointer" }}>
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 text-2xl" style={{ background: isSelected ? `${colors.color}18` : "rgba(255,255,255,0.6)", fontFamily: "Poppins", border: `1px solid ${colors.border}` }}>
                    {isDisabled ? "🚫" : discount.icon || "🏷️"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="truncate text-sm font-black tracking-wide" style={{ color: isSelected ? colors.color : isDisabled ? "#ccc" : "#1a1a1a", fontFamily: "Poppins" }}>{getDiscountLabel(discount)}</p>
                    <p className="truncate text-[11px]" style={{ color: isDisabled ? "#ddd" : "#aaa", marginTop: 2, fontFamily: "Poppins" }}>{isDisabled && checkResult.violations.length > 0 ? `• ${checkResult.violations.join(" • ")}` : discount.sublabel || (discount.campaign_name ? "Campaign Discount" : "Limited Time Offer")}</p>
                  </div>
                  <div className="flex flex-col items-end gap-2 flex-shrink-0 pl-2">
                    <span className="px-3 py-1 rounded-full text-[10px] font-black whitespace-nowrap tracking-wider shadow-sm" style={{ fontFamily: "Poppins", background: isSelected ? colors.color : isDisabled ? "rgba(0,0,0,0.03)" : "rgba(0,0,0,0.06)", color: isSelected ? "#fff" : isDisabled ? "#ddd" : "#999", transition: "all 0.2s" }}>
                      {getDiscountRate(discount)}{discount.discount_type === 'percentage' && !discount.rate ? '%' : ''} OFF
                    </span>
                    <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: isSelected ? colors.color : isDisabled ? "rgba(0,0,0,0.04)" : "rgba(0,0,0,0.08)", border: `2px solid ${isSelected ? colors.color : isDisabled ? "rgba(0,0,0,0.08)" : "rgba(0,0,0,0.12)"}`, transition: "all 0.2s" }}>
                      {isSelected && <span style={{ color: "#fff", fontSize: 11, fontWeight: 900, lineHeight: 1 }}>✓</span>}
                    </div>
                  </div>
                </button>
              );
            })
          ) : (
            <div className="text-center py-10 text-gray-400 font-medium" style={{ fontFamily: "Poppins" }}>No discounts currently available</div>
          )}
        </div>

        {/* FOOTER */}
        <div className="p-7 pt-4 flex-shrink-0 bg-white border-t border-gray-50 z-10">
          {selected && (
            <div className="rounded-2xl px-5 py-3 mb-4 flex items-center justify-between bg-orange-50 border border-orange-100 shadow-sm animate-fade-in">
              <div>
                <p className="text-[10px] font-bold text-orange-500 uppercase tracking-widest mb-0.5" style={{ fontFamily: "Poppins" }}>Discount Preview</p>
                <p className="text-xs text-orange-400 font-medium truncate max-w-[200px]" style={{ fontFamily: "Poppins" }}>{getDiscountLabel(discounts.find((d: any) => d.id === selected))} · {formatMoney(subtotal)}</p>
              </div>
              <span className="text-2xl font-black text-orange-600" style={{ fontFamily: "Poppins" }}>−{formatMoney(discountAmount)}</span>
            </div>
          )}
          <div className="flex gap-3">
            <button onClick={() => { onApply(null); onClose(); }} className="flex-1 rounded-xl py-3.5 text-sm font-bold text-gray-500 bg-gray-100 hover:bg-gray-200 transition-colors" style={{ fontFamily: "Poppins" }}>Remove Campaign</button>
            <button onClick={() => { onApply(selected); onClose(); }} className="flex-1 rounded-xl py-3.5 text-sm font-bold text-white transition-all hover:brightness-110 active:scale-95 shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ fontFamily: "Poppins", background: selected ? "linear-gradient(135deg, #f97316 0%, #ea580c 100%)" : "#cbd5e1" }}
              disabled={!selected && !appliedDiscount}>Apply Campaign →</button>
          </div>
        </div>
      </div>
    </div>
  );
}