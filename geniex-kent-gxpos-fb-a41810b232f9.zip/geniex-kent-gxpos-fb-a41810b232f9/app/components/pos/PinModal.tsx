'use client';
import { useState } from 'react';

export function PinModal({
  title = "Enter PIN",
  subtitle,
  onConfirm,
  onClose,
  accentColor = "#f97316",
  stripColor  = "linear-gradient(90deg, #f97316 0%, #fb923c 60%, #fdba74 100%)",
}: {
  title?:       string;
  subtitle:     string;
  onConfirm:    (pin: string) => void;
  onClose?:     () => void;
  accentColor?: string;
  stripColor?:  string;
}) {
  const [pin, setPin] = useState('');

  return (
    <div
      className="fixed inset-0 flex items-center justify-center z-[200] animate-fade-in"
      style={{ background: 'rgba(15,23,42,0.82)', backdropFilter: 'blur(14px)', WebkitBackdropFilter: 'blur(14px)' }}
      onClick={onClose}
    >
      <div
        className="rounded-3xl w-full max-w-sm mx-4 relative overflow-hidden shadow-2xl"
        style={{ background: '#ffffff', animation: 'scaleIn 0.3s cubic-bezier(0.16,1,0.3,1) forwards' }}
        onClick={e => e.stopPropagation()}
      >
        <div style={{ height: 6, background: stripColor }} />

        <div className="p-7">
          {onClose && (
            <button
              onClick={onClose}
              className="absolute top-7 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-base transition-all hover:bg-black/5"
              style={{ background: 'rgba(0,0,0,0.05)', color: '#bbb', border: '1px solid rgba(0,0,0,0.07)' }}
            >
              ✕
            </button>
          )}

          <div className="flex items-center gap-3 mb-4">
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
              style={{ background: `${accentColor}15`, border: `1.5px solid ${accentColor}30` }}
            >
              <span style={{ fontSize: 22 }}>🔐</span>
            </div>
            <div>
              <p style={{ fontFamily: 'Poppins', fontSize: 10, color: '#ccc', fontWeight: 700, letterSpacing: 1.2, textTransform: 'uppercase', marginBottom: 2 }}>
                Identity Verification
              </p>
              <h2 style={{ fontFamily: 'Poppins', fontSize: 18, fontWeight: 900, color: '#1a1a1a', lineHeight: 1 }}>
                {title.split('PIN')[0]}
                <span style={{ color: accentColor }}>PIN</span>
              </h2>
            </div>
          </div>

          <p style={{ fontFamily: 'Poppins', fontSize: 13, color: '#666', marginBottom: 12, textAlign: 'center' }}>
            {subtitle}
          </p>

          {/* PIN display */}
          <div
            className="rounded-xl px-6 py-4 mb-5"
            style={{
              fontFamily: 'Poppins', background: `${accentColor}10`,
              border: `1.5px solid ${accentColor}30`, color: accentColor,
              minHeight: 72, display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            {pin.length > 0 ? (
              <span style={{ fontSize: 24, fontWeight: 900, letterSpacing: 6 }}>{'•'.repeat(pin.length)}</span>
            ) : (
              <span style={{ color: '#ddd', fontSize: 14, fontWeight: 500 }}>Enter 4-digit PIN</span>
            )}
          </div>

          {/* Keypad */}
          <div className="flex gap-4 items-start">
            <div className="grid grid-cols-3 gap-2.5 flex-1">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                <button
                  key={num}
                  onClick={() => { if (pin.length < 4) setPin(p => p + String(num)); }}
                  className="h-14 rounded-xl text-xl font-bold transition-all hover:bg-gray-100 active:scale-95"
                  style={{ background: 'rgba(0,0,0,0.04)', fontFamily: 'Poppins', color: '#1a1a1a', border: '1px solid rgba(0,0,0,0.07)' }}
                >
                  {num}
                </button>
              ))}
              <button
                onClick={() => { if (pin.length < 4) setPin(p => p + '0'); }}
                className="col-span-2 h-14 rounded-xl text-xl font-bold transition-all hover:bg-gray-100 active:scale-95"
                style={{ background: 'rgba(0,0,0,0.04)', fontFamily: 'Poppins', color: '#1a1a1a', border: '1px solid rgba(0,0,0,0.07)' }}
              >
                0
              </button>
              <button
                onClick={() => setPin(p => p.slice(0, -1))}
                className="h-14 rounded-xl text-xl font-bold transition-all hover:bg-red-50 active:scale-95"
                style={{ background: `${accentColor}15`, color: accentColor, fontFamily: 'Poppins', border: `1px solid ${accentColor}30` }}
              >
                ⌫
              </button>
            </div>

            {/* Confirm + Cancel stacked */}
            <div className="flex flex-col gap-2.5">
              <button
                onClick={() => onConfirm(pin)}
                className="w-16 rounded-xl font-bold transition-all hover:brightness-110 active:scale-95 flex items-center justify-center"
                style={{ height: 122, background: '#4ade80', border: '1px solid rgba(255,255,255,0.5)', color: '#fff', fontSize: 32 }}
              >
                ✓
              </button>
              {onClose && (
                <button
                  onClick={onClose}
                  className="w-16 h-12 rounded-xl text-sm font-bold transition-all hover:bg-gray-100"
                  style={{ background: 'rgba(0,0,0,0.04)', color: '#666', fontFamily: 'Poppins', border: '1px solid rgba(0,0,0,0.07)' }}
                >
                  Cancel
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}