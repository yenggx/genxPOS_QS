import { useEffect, useState } from "react";
import { FiLock, FiAlertTriangle } from "react-icons/fi";
import { sileo } from "sileo";
import { formatMoney } from "./ProductCard";
import { useRouter } from "next/navigation";

export default function OpenRegisterModal({ onOpenShift, openDrawer, fundLimit = 1000, businessDate }: { 
  onOpenShift: (floatAmount: number, breakdown: Record<number, number>) => void, 
  openDrawer: () => void,
  fundLimit?: number,
  businessDate?: string | null
}) {
  
  const token = localStorage.getItem('sessionToken');
  const user  = localStorage.getItem('currentUser');
  if (!token || !user) return

  const router = useRouter();
  useEffect(() => {
    openDrawer();
  }, []);

  const [mode, setMode] = useState<'add' | 'subtract'>('add');
  const [manualEntry, setManualEntry] = useState('');
  const [denominations, setDenominations] = useState<Record<number, number>>({
    1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0
  });

  const handleNumpad = (val: string) => {
    if (val === '⌫') {
      setManualEntry(prev => prev.slice(0, -1));
    } else if (val === '.') {
      if (!manualEntry.includes('.')) setManualEntry(prev => prev + val);
    } else {
      const nextVal = manualEntry + val;
      if (parseFloat(nextVal) > fundLimit) {
        sileo.error({ title: "Limit Exceeded", description: `Maximum allowed cash fund is ${formatMoney(fundLimit)}.`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
      } else {
        setManualEntry(nextVal);
      }
    }
  };

  const handleTap = (value: number) => {
    setManualEntry('');

    const current = denominations[value] || 0;
    const next = mode === 'add' ? current + 1 : Math.max(0, current - 1);
    const newDenominations = { ...denominations, [value]: next };
    const newTotal = Object.entries(newDenominations).reduce(
      (sum, [val, count]) => sum + (parseFloat(val) * count), 0
    );

    if (newTotal > fundLimit) {
      sileo.error({
        title: "Limit Exceeded",
        description: `Maximum allowed cash fund is ${formatMoney(fundLimit)}.`,
        fill: "#171717",
        styles: { title: "text-white!", description: "text-white/75!" },
      });
      return;
    }

    setDenominations(newDenominations);
  };

  const clearCount = () => {
    setManualEntry('');
    setDenominations({ 1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0 });
  };

  const tappedTotal = Object.entries(denominations).reduce((sum, [val, count]) => sum + (parseFloat(val) * count), 0);
  const displayTotal = manualEntry ? parseFloat(manualEntry) : tappedTotal;
  const now = new Date();
  const dateBadge = now.toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase();

  let isBusinessWeekend = false;
  let businessDateFormatted = "";
  if (businessDate) {
    const [year, month, day] = businessDate.split('-').map(Number);
    const bDate = new Date(year, month - 1, day);
    isBusinessWeekend = bDate.getDay() === 0 || bDate.getDay() === 6;
    businessDateFormatted = bDate.toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase();
  }
  
  const systemDateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  const isDateMismatch = businessDate && businessDate !== systemDateStr;

  const getBillColor = (val: number) => {
    switch (val) {
      case 1000: return { border: "rgba(59, 130, 246, 0.3)", text: "#2563eb" };
      case 500:  return { border: "rgba(234, 179, 8, 0.3)",  text: "#ca8a04" };
      case 200:  return { border: "rgba(34, 197, 94, 0.3)",  text: "#16a34a" };
      case 100:  return { border: "rgba(168, 85, 247, 0.3)", text: "#9333ea" };
      case 50:   return { border: "rgba(239, 68, 68, 0.3)",  text: "#dc2626" };
      default:   return { border: "rgba(148, 163, 184, 0.4)", text: "#475569" };
    }
  };

  const handleSignOut = () => {
    localStorage.removeItem("currentUser");
    localStorage.removeItem("sessionToken");
    localStorage.removeItem("managerBypass");
    router.push("/logs");
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center z-[100] animate-fade-in" style={{ background: "rgba(15, 23, 42, 0.75)", backdropFilter: "blur(16px)", WebkitBackdropFilter: "blur(16px)" }}>
      <div className="rounded-3xl w-full max-w-3xl mx-4 relative overflow-hidden flex flex-col animate-scale-in shadow-2xl" style={{ background: "#ffffff" }}>
        <div className="px-7 py-4 flex items-center justify-between border-b border-gray-100">
          <div>
            <div className="flex items-center gap-3 mb-0.5">
              <h2 className="text-2xl font-black text-gray-900" style={{ fontFamily: "Poppins" }}>Open Register</h2>
              <span className="px-2.5 py-0.5 rounded-md text-[10px] font-bold tracking-wider" style={{ background: "rgba(168, 85, 247, 0.15)", color: "#F5821F" }}>{dateBadge}</span>
            </div>
            <p className="text-xs text-gray-500 font-medium" style={{ fontFamily: "Poppins" }}>Declare your starting cash funds by tapping bills and coins.</p>
          </div>
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(168, 85, 247, 0.1)", color: "#F5821F" }}>
            <FiLock size={18} />
          </div>
        </div>
        <div className="flex flex-col p-7 gap-5 bg-gray-50">
          {(isDateMismatch || isBusinessWeekend) && (
            <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4 flex gap-3 items-start shadow-sm">
              <div className="text-orange-500 mt-0.5">
                <FiAlertTriangle size={20} />
              </div>
              <div>
                <p className="text-xs font-black text-orange-800 uppercase tracking-widest mb-1" style={{ fontFamily: "Poppins" }}>
                  Date Notice
                </p>
                <p className="text-[11px] font-medium text-orange-700 leading-relaxed" style={{ fontFamily: "Poppins" }}>
                  {isDateMismatch && <span>The active business date (<strong>{businessDateFormatted || businessDate}</strong>) differs from today's system date. </span>}
                  {isBusinessWeekend && <span>The active business date falls on a weekend. </span>}
                  <br/>If there are no sales today, simply open and close the register to advance the business day.
                </p>
              </div>
            </div>
          )}
          <div className="flex items-center gap-4">
            <div className="flex-1 h-14 rounded-2xl flex items-center px-5 justify-between bg-white border-2 border-orange-200 shadow-sm">
              <span className="text-orange-400 font-bold text-lg" style={{ fontFamily: "Poppins" }}></span>
              <span className="text-2xl font-black text-gray-900" style={{ fontFamily: "Poppins" }}>
                {displayTotal > 0 ? formatMoney(displayTotal) : "0.00"}
              </span>
            </div>
            <div className="flex bg-gray-200 p-1 rounded-xl shrink-0">
              <button onClick={() => setMode('add')} className="px-5 py-2 rounded-lg text-sm font-bold transition-all shadow-sm" style={{ background: mode === 'add' ? "#ffffff" : "transparent", color: mode === 'add' ? "#1a1a1a" : "#64748b", fontFamily: "Poppins" }}>+ Add</button>
              <button onClick={() => setMode('subtract')} className="px-5 py-2 rounded-lg text-sm font-bold transition-all" style={{ background: mode === 'subtract' ? "#ffffff" : "transparent", color: mode === 'subtract' ? "#1a1a1a" : "#64748b", fontFamily: "Poppins" }}>− Subtract</button>
            </div>
          </div>
          <div>
            <h4 className="text-[10px] font-bold text-gray-400 tracking-widest uppercase mb-2.5" style={{ fontFamily: "Poppins" }}>Paper Bills</h4>
            <div className="grid grid-cols-5 gap-3">
              {[1000, 500, 200, 100, 50].map(val => {
                const colors = getBillColor(val);
                const count = denominations[val] || 0;
                return (
                  <button key={val} onClick={() => handleTap(val)} className="relative h-16 rounded-2xl flex items-center justify-center font-black text-base transition-transform active:scale-95 bg-white shadow-sm hover:shadow-md" style={{ border: `2px solid ${colors.border}`, color: colors.text, fontFamily: "Poppins" }}>
                    {formatMoney(val)}
                    {count > 0 && <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-gray-900 text-white text-[10px] flex items-center justify-center border-2 border-white shadow-sm" style={{ fontFamily: "Poppins" }}>{count}</span>}
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <h4 className="text-[10px] font-bold text-gray-400 tracking-widest uppercase mb-2.5" style={{ fontFamily: "Poppins" }}>Coins</h4>
            <div className="flex gap-3">
              {[20, 10, 5, 1, 0.25].map(val => {
                const colors = getBillColor(val);
                const count = denominations[val] || 0;
                return (
                  <button key={val} onClick={() => handleTap(val)} className="relative w-14 h-14 rounded-full flex items-center justify-center font-bold text-xs transition-transform active:scale-95 bg-white shadow-sm hover:shadow-md" style={{ border: `2px solid ${colors.border}`, color: colors.text, fontFamily: "Poppins" }}>
                    {formatMoney(val)}
                    {count > 0 && <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-gray-900 text-white text-[9px] flex items-center justify-center border-2 border-white" style={{ fontFamily: "Poppins" }}>{count}</span>}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
        <div className="px-7 py-4 border-t border-gray-100 flex items-center justify-between bg-white">
          <button onClick={clearCount} className="px-5 py-2.5 rounded-xl bg-gray-100 text-gray-500 font-bold text-sm transition-colors hover:bg-gray-200" style={{ fontFamily: "Poppins" }}>
            Clear All
          </button>
          <div className="flex gap-2">
            <button
              onClick={() => router.push('/logs')}
              className="px-8 py-2.5 rounded-xl font-bold text-white transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ background: "#25272C", fontFamily: "Poppins" }}
            >
             ← Back
            </button>
            <button
              onClick={() => onOpenShift(displayTotal, denominations)}
              disabled={displayTotal <= 0}
              className="px-8 py-2.5 rounded-xl font-bold text-white transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ background: "#111827", fontFamily: "Poppins" }}
            >
              Open Register →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}