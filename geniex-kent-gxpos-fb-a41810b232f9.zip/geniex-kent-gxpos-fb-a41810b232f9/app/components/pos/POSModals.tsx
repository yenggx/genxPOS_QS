import React, { useState, useRef } from 'react';
import { FiLock, FiDownload, FiAlertTriangle, FiX, FiUser } from 'react-icons/fi';
import { sileo } from 'sileo';
import { glass, TRANSACTION_TYPES, type DiscountType, type TransactionType } from './constants';
import type { SimpleDiscount } from '../../../src/api/discounts';

export function CashLimitWarningModal({ currentCash, onUnderstood, onDropCash }: { currentCash: number, onUnderstood: () => void, onDropCash: () => void }) {
  return (
    <div className="fixed inset-0 flex items-center justify-center z-[250] animate-fade-in" style={{ background: "rgba(15, 23, 42, 0.8)", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)" }}>
      <div className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden flex flex-col p-8 animate-scale-in shadow-2xl" style={{ background: "#ffffff" }}>
        <div className="w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto" style={{ background: "rgba(234, 179, 8, 0.1)", color: "#ca8a04" }}>
          <FiAlertTriangle size={32} />
        </div>
        <h2 className="text-2xl font-black text-gray-900 mb-2 text-center font-poppins">Nearing Cash Limit</h2>
        <p className="text-sm text-gray-500 font-medium mb-8 text-center leading-relaxed">
          Your drawer cash is currently at <strong>{currentCash.toFixed(2)}</strong>, which is nearing your maximum limit. Consider performing a cash drop soon to secure the funds.
        </p>
        <div className="flex gap-3">
          <button onClick={onUnderstood} className="flex-1 py-3 rounded-xl font-bold text-gray-700 bg-gray-100 hover:bg-gray-200 transition-colors shadow-sm">Understood</button>
          <button onClick={onDropCash} className="flex-1 py-3 rounded-xl font-bold text-white transition-colors shadow-md" style={{ background: "#f97316" }}>Drop Cash</button>
        </div>
      </div>
    </div>
  );
}

export function CashDropModal({ currentCash, onConfirm, onClose, isForced }: { currentCash: number; onConfirm: (amount: number) => void; onClose: () => void; isForced: boolean; }) {
  const [amountStr, setAmountStr] = useState("");

  const handleNumpad = (val: string) => {
    if (val === '⌫') setAmountStr(prev => prev.slice(0, -1));
    else if (val === '.') { if (!amountStr.includes('.')) setAmountStr(prev => prev + val); }
    else {
      const nextVal = amountStr + val;
      if (parseFloat(nextVal) > currentCash) {
        sileo.error({ title: "Exceeds Drawer Cash", description: `You only have ${currentCash.toFixed(2)} in cash.`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
      } else {
        setAmountStr(nextVal);
      }
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center z-[200] animate-fade-in" style={{ background: "rgba(15, 23, 42, 0.8)", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)" }}>
      <div className="rounded-3xl w-full max-w-4xl mx-4 relative overflow-hidden flex animate-scale-in shadow-2xl" style={{ background: "#ffffff" }}>
        
        <div className="w-1/2 p-8 bg-gray-50 border-r border-gray-100 flex flex-col justify-center">
          {!isForced && <button onClick={onClose} className="absolute top-6 left-6 w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg hover:bg-gray-200 transition-colors" style={{ color: "#666" }}>✕</button>}
          
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6" style={{ background: "rgba(249,115,22,0.1)", color: "#f97316" }}>
            <FiDownload size={32} />
          </div>
          <h2 className="text-3xl font-black text-gray-900 mb-2 font-poppins">Cash Drop</h2>
          <p className="text-sm text-gray-500 font-medium mb-8">
            {isForced ? "Your drawer limit of 20,000 has been reached. You must drop cash before accepting more transactions." : "Transfer physical cash from your drawer into the safe."}
          </p>

          <div className="rounded-2xl bg-white border border-gray-200 overflow-hidden shadow-sm">
            <div className="p-4 flex justify-between items-center border-b border-gray-100">
              <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Current Drawer Cash</span>
              <span className="text-lg font-black text-gray-900"> {currentCash.toFixed(2)}</span>
            </div>
            <div className="p-4 flex justify-between items-center bg-orange-50 border-b-2 border-orange-100">
              <span className="text-xs font-bold text-[#F5821F] uppercase tracking-widest">Drop Amount</span>
              <span className="text-xl font-black text-[#F5821F]">—  {amountStr ? parseFloat(amountStr).toFixed(2) : "0.00"}</span>
            </div>
            <div className="p-4 flex justify-between items-center bg-white">
              <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Remaining Drawer</span>
              <span className="text-lg font-black text-gray-900"> {(currentCash - (parseFloat(amountStr) || 0)).toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="w-1/2 p-8 flex flex-col justify-center bg-white">
          <div className="w-full h-16 rounded-2xl flex items-center px-4 justify-between bg-white border-2 border-orange-200 mb-6 shadow-sm">
            <span className="text-gray-400 font-bold"></span>
            <span className="text-3xl font-black text-gray-900">{amountStr || "0"}</span>
          </div>
          
          <div className="grid grid-cols-3 gap-4 mb-6">
            {['1','2','3','4','5','6','7','8','9','.','0','⌫'].map((key) => (
              <button
                key={key}
                onClick={() => handleNumpad(key)}
                className="h-16 rounded-2xl bg-gray-50 border border-gray-200 text-2xl font-black text-gray-700 shadow-sm active:scale-95 transition-transform flex items-center justify-center hover:bg-gray-100"
                style={key === '⌫' ? { color: "#ef4444", background: "rgba(239, 68, 68, 0.05)", borderColor: "rgba(239,68,68,0.2)" } : { fontFamily: "Poppins" }}
              >
                {key}
              </button>
            ))}
          </div>

          <button 
            onClick={() => onConfirm(parseFloat(amountStr))}
            disabled={!amountStr || parseFloat(amountStr) <= 0}
            className="w-full py-4 rounded-xl font-black text-white uppercase tracking-widest transition-all hover:brightness-110 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
            style={{ background: "#111827", fontFamily: "Poppins" }}
          >
            Confirm Drop →
          </button>
        </div>
      </div>
    </div>
  );
}

export function OpenRegisterModal({ onOpenShift }: { onOpenShift: (floatAmount: number, breakdown: Record<number, number>) => void }) {
  const [mode, setMode] = useState<'add' | 'subtract'>('add');
  const [manualEntry, setManualEntry] = useState('');
  const [denominations, setDenominations] = useState<Record<number, number>>({
    1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0
  });

  const handleNumpad = (val: string) => {
    if (val === '⌫') {
      setManualEntry(prev => prev.slice(0, -1));
    } else if (val === '.') {
      if (!manualEntry.includes('.')) setManualEntry(prev => prev + val);
    } else {
      const nextVal = manualEntry + val;
      if (parseFloat(nextVal) > 1000) {
        sileo.error({
          title: "Limit Exceeded",
          description: "Maximum allowed cash fund is 1,000.00",
          fill: "#171717",
          styles: { title: "text-white!", description: "text-white/75!" }
        });
      } else {
        setManualEntry(nextVal);
      }
    }
  };

  const handleTap = (value: number) => {
    setManualEntry('');
    setDenominations(prev => {
      const current = prev[value] || 0;
      const next = mode === 'add' ? current + 1 : Math.max(0, current - 1);
      const newDenominations = { ...prev, [value]: next };
      const newTotal = Object.entries(newDenominations).reduce((sum, [val, count]) => sum + (parseFloat(val) * count), 0);
      if (newTotal > 1000) {
        sileo.error({
          title: "Limit Exceeded",
          description: "Maximum allowed cash fund is 1,000.00",
          fill: "#171717",
          styles: { title: "text-white!", description: "text-white/75!" }
        });
        return prev;
      }
      return newDenominations;
    });
  };

  const clearCount = () => {
    setManualEntry('');
    setDenominations({ 1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0 });
  };

  const tappedTotal = Object.entries(denominations).reduce((sum, [val, count]) => sum + (parseFloat(val) * count), 0);
  const displayTotal = manualEntry ? parseFloat(manualEntry) : tappedTotal;

  const now = new Date();
  const dateBadge = now.toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase();

  const getBillColor = (val: number) => {
    switch (val) {
      case 1000: return { border: "rgba(59, 130, 246, 0.3)", text: "#2563eb" };
      case 500:  return { border: "rgba(234, 179, 8, 0.3)",  text: "#ca8a04" };
      case 200:  return { border: "rgba(34, 197, 94, 0.3)",  text: "#16a34a" };
      case 100:  return { border: "rgba(168, 85, 247, 0.3)", text: "#9333ea" };
      case 50:   return { border: "rgba(239, 68, 68, 0.3)",  text: "#dc2626" };
      default:   return { border: "rgba(148, 163, 184, 0.4)", text: "#475569" };
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center z-[100] animate-fade-in" style={{ background: "rgba(15, 23, 42, 0.75)", backdropFilter: "blur(16px)", WebkitBackdropFilter: "blur(16px)" }}>
      <div className="rounded-3xl w-full max-w-3xl mx-4 relative overflow-hidden flex flex-col animate-scale-in shadow-2xl" style={{ background: "#ffffff" }}>
        <div className="px-7 py-4 flex items-center justify-between border-b border-gray-100">
          <div>
            <div className="flex items-center gap-3 mb-0.5">
              <h2 className="text-2xl font-black text-gray-900" style={{ fontFamily: "Poppins" }}>Open Register</h2>
              <span className="px-2.5 py-0.5 rounded-md text-[10px] font-bold tracking-wider" style={{ background: "rgba(168, 85, 247, 0.15)", color: "#F5821F" }}>{dateBadge}</span>
            </div>
            <p className="text-xs text-gray-500 font-medium" style={{ fontFamily: "Poppins" }}>Declare your starting cash funds by tapping bills and coins.</p>
          </div>
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(168, 85, 247, 0.1)", color: "#F5821F" }}>
            <FiLock size={18} />
          </div>
        </div>
        <div className="flex flex-col p-7 gap-5 bg-gray-50">
          <div className="flex items-center gap-4">
            <div className="flex-1 h-14 rounded-2xl flex items-center px-5 justify-between bg-white border-2 border-orange-200 shadow-sm">
              <span className="text-orange-400 font-bold text-lg" style={{ fontFamily: "Poppins" }}></span>
              <span className="text-2xl font-black text-gray-900" style={{ fontFamily: "Poppins" }}>
                {displayTotal > 0 ? displayTotal.toFixed(2) : "0.00"}
              </span>
            </div>
            <div className="flex bg-gray-200 p-1 rounded-xl shrink-0">
              <button onClick={() => setMode('add')} className="px-5 py-2 rounded-lg text-sm font-bold transition-all shadow-sm" style={{ background: mode === 'add' ? "#ffffff" : "transparent", color: mode === 'add' ? "#1a1a1a" : "#64748b", fontFamily: "Poppins" }}>+ Add</button>
              <button onClick={() => setMode('subtract')} className="px-5 py-2 rounded-lg text-sm font-bold transition-all" style={{ background: mode === 'subtract' ? "#ffffff" : "transparent", color: mode === 'subtract' ? "#1a1a1a" : "#64748b", fontFamily: "Poppins" }}>− Subtract</button>
            </div>
          </div>
          <div>
            <h4 className="text-[10px] font-bold text-gray-400 tracking-widest uppercase mb-2.5" style={{ fontFamily: "Poppins" }}>Paper Bills</h4>
            <div className="grid grid-cols-5 gap-3">
              {[1000, 500, 200, 100, 50].map(val => {
                const colors = getBillColor(val);
                const count = denominations[val] || 0;
                return (
                  <button key={val} onClick={() => handleTap(val)} className="relative h-16 rounded-2xl flex items-center justify-center font-black text-base transition-transform active:scale-95 bg-white shadow-sm hover:shadow-md" style={{ border: `2px solid ${colors.border}`, color: colors.text, fontFamily: "Poppins" }}>
                    {val}
                    {count > 0 && <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-gray-900 text-white text-[10px] flex items-center justify-center border-2 border-white shadow-sm" style={{ fontFamily: "Poppins" }}>{count}</span>}
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <h4 className="text-[10px] font-bold text-gray-400 tracking-widest uppercase mb-2.5" style={{ fontFamily: "Poppins" }}>Coins</h4>
            <div className="flex gap-3">
              {[20, 10, 5, 1, 0.25].map(val => {
                const colors = getBillColor(val);
                const count = denominations[val] || 0;
                return (
                  <button key={val} onClick={() => handleTap(val)} className="relative w-14 h-14 rounded-full flex items-center justify-center font-bold text-xs transition-transform active:scale-95 bg-white shadow-sm hover:shadow-md" style={{ border: `2px solid ${colors.border}`, color: colors.text, fontFamily: "Poppins" }}>
                    {val}
                    {count > 0 && <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-gray-900 text-white text-[9px] flex items-center justify-center border-2 border-white" style={{ fontFamily: "Poppins" }}>{count}</span>}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
        <div className="px-7 py-4 border-t border-gray-100 flex items-center justify-between bg-white">
          <button onClick={clearCount} className="px-5 py-2.5 rounded-xl bg-gray-100 text-gray-500 font-bold text-sm transition-colors hover:bg-gray-200" style={{ fontFamily: "Poppins" }}>
            Clear All
          </button>
          <button
            onClick={() => onOpenShift(displayTotal, denominations)}
            disabled={displayTotal <= 0}
            className="px-8 py-2.5 rounded-xl font-bold text-white transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            style={{ background: "#111827", fontFamily: "Poppins" }}
          >
            Open Register →
          </button>
        </div>
      </div>
    </div>
  );
}

export function DiscountModal({ subtotal, appliedDiscount, onApply, onClose, availableDiscounts = [], cart = [] }: { subtotal: number; appliedDiscount: DiscountType | number | null; onApply: (type: DiscountType | number | null) => void; onClose: () => void; availableDiscounts?: SimpleDiscount[]; cart?: any[]; }) {
  const [selected, setSelected] = useState<DiscountType | number | null>(appliedDiscount);

  const COLOR_PALETTE = [
    { color: "#2563eb", bg: "rgba(37,99,235,0.07)", border: "rgba(37,99,235,0.20)", activeBg: "rgba(37,99,235,0.12)", activeBorder: "#2563eb" },
    { color: "#f97316", bg: "rgba(249,115,22,0.07)", border: "rgba(249,115,22,0.20)", activeBg: "rgba(249,115,22,0.12)", activeBorder: "#f97316" },
    { color: "#dc2626", bg: "rgba(220,38,38,0.07)", border: "rgba(220,38,38,0.20)", activeBg: "rgba(220,38,38,0.12)", activeBorder: "#dc2626" },
    { color: "#8b5cf6", bg: "rgba(139,92,246,0.07)", border: "rgba(139,92,246,0.20)", activeBg: "rgba(139,92,246,0.12)", activeBorder: "#8b5cf6" },
    { color: "#06b6d4", bg: "rgba(6,182,212,0.07)", border: "rgba(6,182,212,0.20)", activeBg: "rgba(6,182,212,0.12)", activeBorder: "#06b6d4" },
    { color: "#ec4899", bg: "rgba(236,72,153,0.07)", border: "rgba(236,72,153,0.20)", activeBg: "rgba(236,72,153,0.12)", activeBorder: "#ec4899" },
  ];

  const discounts = availableDiscounts || [];
  const cartItemCount = cart.reduce((sum, item) => sum + (item.qty || 0), 0);

  const checkRestrictions = (discount: SimpleDiscount) => {
    const violations: string[] = [];
    const minBasket = discount.restrictions?.minAmountBasket || 0;
    const itemCount = discount.restrictions?.numberofItems || 0;
    if (subtotal < minBasket) violations.push(`Min. amount: ${minBasket}`);
    if (cartItemCount < itemCount) violations.push(`Min. ${itemCount} item(s)`);
    return { isValid: violations.length === 0, violations };
  };

  const calculatePreviewDiscountAmount = (discount: any) => {
    let amount = 0;
    if (discount.rate) {
      amount = subtotal * discount.rate;
    } else {
      if (discount.discount_type === 'percentage') {
        amount = subtotal * (parseFloat(discount.discount_value) / 100);
      } else {
        amount = Math.min(parseFloat(discount.discount_value), subtotal);
      }
    }
    const cap = discount.discount_cap || 0;
    if (cap > 0) amount = Math.min(amount, cap);
    return amount;
  };

  const getDiscountRate = (discount: any) => {
    if (discount.rate) return (discount.rate * 100).toFixed(0);
    if (discount.discount_type === 'percentage') return discount.discount_value;
    return `${parseFloat(discount.discount_value).toFixed(0)}`;
  };

  const getDiscountLabel = (discount: any) => discount.label || discount.campaign_name || `Discount ${discount.id}`;

  const selectedDiscount = discounts.find((d: any) => d.id === selected);
  const discountAmount = selected && selectedDiscount ? calculatePreviewDiscountAmount(selectedDiscount) : 0;

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 animate-fade-in" style={{ background: "rgba(160,150,145,0.30)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)" }} onClick={onClose}>
      <div className="rounded-3xl w-full max-w-lg mx-4 relative overflow-hidden animate-scale-in" style={glass.modal} onClick={(e) => e.stopPropagation()}>
        <div style={{ height: 5, background: "linear-gradient(90deg, #f97316 0%, #fb923c 60%, #fed7aa 100%)" }} />
        <div className="p-7">
          <button onClick={onClose} className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-base transition-all hover:bg-black/5" style={{ background: "rgba(0,0,0,0.05)", color: "#bbb", border: "1px solid rgba(0,0,0,0.07)" }}>✕</button>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: "linear-gradient(135deg, #fff7ed, #ffedd5)", border: "1.5px solid rgba(249,115,22,0.18)", boxShadow: "0 2px 10px rgba(249,115,22,0.10)" }}>
              <span style={{ fontSize: 22 }}>🏷️</span>
            </div>
            <div>
              <p style={{ fontSize: 10, color: "#ccc", fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 2, fontFamily: "Poppins" }}>Available Campaigns</p>
              <h2 style={{ fontFamily: "Poppins", fontSize: 22, fontWeight: 900, color: "#1a1a1a", lineHeight: 1 }}>Select <span style={{ color: "#f97316", fontFamily: "Poppins" }}>Offer</span></h2>
            </div>
          </div>
          <div className="flex flex-col gap-3 mb-6 max-h-64 overflow-y-auto">
            {discounts.length > 0 ? (
              discounts.map((discount: any, idx: number) => {
                const isSelected = selected === discount.id;
                const palette = COLOR_PALETTE[idx % COLOR_PALETTE.length];
                const colors = discount.color ? { color: discount.color, bg: discount.bg, border: discount.border, activeBg: discount.activeBg, activeBorder: discount.activeBorder } : palette;
                const checkResult = checkRestrictions(discount);
                const isDisabled = !checkResult.isValid;
                return (
                  <div key={discount.id}>
                    <button onClick={() => !isDisabled && setSelected(isSelected ? null : discount.id)} className="flex items-center gap-4 rounded-2xl p-4 text-left w-full transition-all duration-200 focus:outline-none" disabled={isDisabled}
                      style={{ background: isSelected ? colors.activeBg : colors.bg, border: `2px solid ${isSelected ? colors.activeBorder : colors.border}`, boxShadow: isSelected ? `0 4px 16px ${colors.color}22` : "none", transform: isSelected ? "scale(1.01)" : "scale(1)", opacity: isDisabled ? 0.5 : 1, cursor: isDisabled ? "not-allowed" : "pointer" }}>
                      <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 text-2xl" style={{ background: isSelected ? `${colors.color}18` : "rgba(255,255,255,0.6)", fontFamily: "Poppins", border: `1px solid ${colors.border}` }}>
                        {isDisabled ? "🚫" : discount.icon || "🏷️"}
                      </div>
                      <div className="flex-1">
                        <p style={{ fontSize: 13, fontWeight: 900, color: isSelected ? colors.color : isDisabled ? "#ccc" : "#1a1a1a", fontFamily: "Poppins", letterSpacing: 0.3 }}>{getDiscountLabel(discount)}</p>
                        <p style={{ fontSize: 11, color: isDisabled ? "#ddd" : "#aaa", marginTop: 2, fontFamily: "Poppins" }}>{isDisabled && checkResult.violations.length > 0 ? `• ${checkResult.violations.join(" • ")}` : discount.sublabel || (discount.campaign_name ? "Campaign Discount" : "Limited Time Offer")}</p>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <span className="px-3 py-1 rounded-full text-sm font-black whitespace-nowrap" style={{ fontFamily: "Poppins", background: isSelected ? colors.color : isDisabled ? "rgba(0,0,0,0.03)" : "rgba(0,0,0,0.06)", color: isSelected ? "#fff" : isDisabled ? "#ddd" : "#999", transition: "all 0.2s", fontSize: 11 }}>
                          {getDiscountRate(discount)}{discount.discount_type === 'percentage' && !discount.rate ? '%' : ''} OFF
                        </span>
                        <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: isSelected ? colors.color : isDisabled ? "rgba(0,0,0,0.04)" : "rgba(0,0,0,0.08)", border: `2px solid ${isSelected ? colors.color : isDisabled ? "rgba(0,0,0,0.08)" : "rgba(0,0,0,0.12)"}`, transition: "all 0.2s" }}>
                          {isSelected && <span style={{ color: "#fff", fontSize: 11, fontWeight: 900, lineHeight: 1 }}>✓</span>}
                        </div>
                      </div>
                    </button>
                  </div>
                );
              })
            ) : (
              <div style={{ textAlign: "center", padding: "20px", color: "#999", fontFamily: "Poppins" }}>No discounts available</div>
            )}
          </div>
          {selected && (
            <div className="rounded-2xl px-5 py-3 mb-5 flex items-center justify-between" style={{ background: "linear-gradient(135deg, rgba(249,115,22,0.07), rgba(253,186,116,0.09))", border: "1.5px solid rgba(249,115,22,0.16)" }}>
              <div>
                <p style={{ fontFamily: "Poppins", fontSize: 10, color: "#f97316", fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", opacity: 0.8 }}>Discount Preview</p>
                <p style={{ fontFamily: "Poppins", fontSize: 12, color: "#aaa", marginTop: 1 }}>{getDiscountLabel(discounts.find((d: any) => d.id === selected))} · {subtotal.toFixed(2)}</p>
              </div>
              <span style={{ fontFamily: "Poppins", fontSize: 22, fontWeight: 900, color: "#f97316" }}>−{discountAmount.toFixed(2)}</span>
            </div>
          )}
          <div className="flex gap-3">
            <button onClick={() => { onApply(null); onClose(); }} className="flex-1 rounded-full py-3 text-sm font-bold transition-all hover:brightness-95" style={{ fontFamily: "Poppins", background: "rgba(0,0,0,0.05)", color: "#888", border: "1px solid rgba(0,0,0,0.08)" }}>Remove Discount</button>
            <button onClick={() => { onApply(selected); onClose(); }} className="flex-1 rounded-full py-3 text-sm font-bold text-white transition-all hover:brightness-110 active:scale-95"
              style={{  fontFamily: "Poppins", background: selected ? "linear-gradient(135deg, #f97316 0%, #ea580c 100%)" : "rgba(0,0,0,0.15)", color: selected ? "#fff" : "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.25)", boxShadow: selected ? "0 4px 18px rgba(249,115,22,0.35)" : "none" }}
              disabled={!selected && !appliedDiscount}>Apply Discount</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function DiplomatPromptModal({ onClose, onNext }: { onClose: () => void, onNext: (name: string, id: string) => void }) {
  const [name, setName] = useState('');
  const [idNum, setIdNum] = useState('');

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 animate-fade-in" style={{ background: "rgba(160,150,145,0.30)", backdropFilter: "blur(14px)" }} onClick={onClose}>
      <div className="rounded-3xl w-full max-w-sm mx-4 relative overflow-hidden animate-scale-in" style={glass.modal} onClick={e => e.stopPropagation()}>
        <div style={{ height: 5, background: "linear-gradient(90deg, #8b5cf6 0%, #a78bfa 100%)" }} />
        <div className="p-7">
          <button onClick={onClose} className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-gray-400 hover:bg-gray-100 transition-colors">✕</button>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center bg-purple-50 border border-purple-100 text-2xl shadow-sm">
              🏛️
            </div>
            <div>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-0.5" style={{ fontFamily: "Poppins" }}>Diplomat Exemption</p>
              <h2 className="text-lg font-black text-gray-900 leading-none" style={{ fontFamily: "Poppins" }}>Customer Details</h2>
            </div>
          </div>
          <div className="flex flex-col gap-4 mb-6">
            <div>
              <label className="text-xs font-bold text-gray-500 mb-1.5 block" style={{ fontFamily: "Poppins" }}>Diplomat Name</label>
              <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold text-gray-900 outline-none focus:border-purple-500 transition-colors" placeholder="Enter Full Name" style={{ fontFamily: "Poppins" }} />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 mb-1.5 block" style={{ fontFamily: "Poppins" }}>ID Number</label>
              <input type="text" value={idNum} onChange={e => setIdNum(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold text-gray-900 outline-none focus:border-purple-500 transition-colors" placeholder="Enter ID Number" style={{ fontFamily: "Poppins" }} />
            </div>
          </div>
          <button onClick={() => onNext(name, idNum)} disabled={!name || !idNum} className="w-full py-3.5 rounded-xl font-bold text-white bg-purple-600 hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95 shadow-md" style={{ fontFamily: "Poppins" }}>
            Proceed to Verification →
          </button>
        </div>
      </div>
    </div>
  );
}

export const findAlaCartePrice = (itemName: string, remoteProducts: any) => {
  if (!remoteProducts) return 0;
  for (const catKey in remoteProducts) {
    const cat = remoteProducts[catKey];
    for (const sec of cat.sections || []) {
       const found = sec.items?.find((i:any) => i.name.toLowerCase() === itemName.toLowerCase());
       if (found) return found.price;
    }
    for (const sub of cat.subcategories || []) {
       const found = sub.items?.find((i:any) => i.name.toLowerCase() === itemName.toLowerCase());
       if (found) return found.price;
    }
  }
  return 0;
};

export const getSelectableLines = (currentCart: any[], remoteProducts: any) => {
  const lines: any[] = [];
  currentCart.forEach((c, cIdx) => {
    const itemTotal = c.price * c.qty;
    const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
    const hasMods = mods.length > 0;

    lines.push({
      key: `base-${cIdx}`,
      name: c.name,
      qty: c.qty,
      price: c.price,
      total: itemTotal,
      img: c.imgReal || '',
      isMod: false,
      selectable: !hasMods 
    });
    
    mods.forEach((m: any, mIdx: number) => {
      let mPrice = (m.price || 0) / 100;
      
      if (mPrice === 0) {
         mPrice = findAlaCartePrice(m.name, remoteProducts);
      }
      
      const mTotal = mPrice * (m.qty * c.qty);
      lines.push({
        key: `mod-${cIdx}-${mIdx}`,
        name: `↳ ${m.qty * c.qty}x ${m.name}`,
        rawName: m.name,
        qty: m.qty * c.qty,
        price: mPrice,
        total: mTotal,
        img: m.imgReal || c.imgReal || '', 
        isMod: true,
        selectable: true
      });
    });
  });
  return lines;
};

export function LineItemDiscountModal({ cart, type, remoteProducts, onClose, onApply }: { cart: any[], type: string, remoteProducts: any, onClose: () => void, onApply: (slots: number, keys: string[]) => void }) {
  const [slots, setSlots] = useState(1);
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
  
  const lines = useRef(getSelectableLines(cart, remoteProducts)).current;

  const toggleKey = (key: string) => {
    if (selectedKeys.includes(key)) {
      setSelectedKeys(selectedKeys.filter(k => k !== key));
    } else if (selectedKeys.length < slots) {
      setSelectedKeys([...selectedKeys, key]);
    }
  };

  const discountPercent = 0.20 / slots;
  const previewAmount = lines.filter(l => selectedKeys.includes(l.key)).reduce((sum, l) => sum + (l.total * discountPercent), 0);

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 animate-fade-in" style={{ background: "rgba(160,150,145,0.40)", backdropFilter: "blur(14px)" }} onClick={onClose}>
      <div className="rounded-3xl w-full max-w-5xl mx-4 relative overflow-hidden flex flex-col bg-white shadow-2xl animate-scale-in" style={{ maxHeight: '90vh' }} onClick={e => e.stopPropagation()}>
        <div className="px-8 py-6 border-b border-gray-100 flex justify-between items-center bg-gray-50 flex-shrink-0">
          <div>
            <h2 className="text-xl font-black text-gray-900 uppercase tracking-tight" style={{ fontFamily: "Poppins" }}>
              {TRANSACTION_TYPES.find(t => t.id === type)?.label} Assignment
            </h2>
            <p className="text-xs text-gray-500 font-medium mt-1" style={{ fontFamily: "Poppins" }}>Allocate discount slots to specific items in the cart</p>
          </div>
          <button onClick={onClose} className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-gray-400 hover:bg-gray-200 transition-colors text-lg">✕</button>
        </div>
        <div className="flex overflow-hidden" style={{ height: '65vh', minHeight: 500 }}>
          <div className="border-r border-gray-100 p-8 flex flex-col bg-gray-50/50 overflow-y-auto hide-scroll w-5/12">
            <div className="flex justify-between items-end mb-4">
              <h3 className="text-sm font-black text-gray-600 uppercase tracking-widest" style={{ fontFamily: "Poppins" }}>ID Slots</h3>
              <span className="text-xs font-bold text-orange-600 bg-orange-100 px-3 py-1 rounded-md" style={{ fontFamily: "Poppins" }}>Total: {slots}</span>
            </div>
            <div className="flex-1 space-y-4">
              {Array.from({length: slots}).map((_, i) => {
                const assignedKey = selectedKeys[i];
                const assignedLine = assignedKey ? lines.find(l => l.key === assignedKey) : null;
                const itemDiscount = assignedLine ? (assignedLine.total * discountPercent) : 0;
                return (
                  <div key={i} className={`p-4 bg-white border rounded-2xl shadow-sm transition-all ${assignedLine ? 'border-orange-400 ring-2 ring-orange-100' : 'border-gray-200'}`}>
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-xs font-black text-gray-400 uppercase tracking-widest" style={{ fontFamily: "Poppins" }}>Slot {i+1}</span>
                      {slots > 1 && !assignedLine && (
                        <button onClick={() => setSlots(slots - 1)} className="text-red-500 hover:text-red-700 text-xs font-bold uppercase transition-colors" style={{ fontFamily: "Poppins" }}>Remove</button>
                      )}
                      {assignedLine && (
                        <button onClick={() => toggleKey(assignedLine.key)} className="text-gray-400 hover:text-gray-700 text-xs font-bold uppercase transition-colors" style={{ fontFamily: "Poppins" }}>Clear</button>
                      )}
                    </div>
                    {assignedLine ? (
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 rounded-xl bg-gray-100 flex items-center justify-center overflow-hidden border border-gray-200 flex-shrink-0 p-1">
                          {assignedLine.img ? <img src={assignedLine.img} className="w-full h-full object-contain" alt={assignedLine.name} /> : <span className="text-2xl">🍩</span>}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-gray-900 truncate" style={{ fontFamily: "Poppins" }}>{assignedLine.rawName || assignedLine.name}</p>
                          <div className="flex justify-between items-center mt-1.5">
                            <span className="text-xs text-gray-500 font-medium" style={{ fontFamily: "Poppins" }}>{assignedLine.total.toFixed(2)}</span>
                            <span className="text-xs font-black text-orange-600 bg-orange-100 px-2 py-1 rounded" style={{ fontFamily: "Poppins" }}>− {itemDiscount.toFixed(2)}</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center gap-4 opacity-40 py-1">
                        <div className="w-14 h-14 rounded-xl bg-gray-100 border-2 border-dashed border-gray-300 flex-shrink-0" />
                        <p className="text-xs text-gray-500 font-medium italic" style={{ fontFamily: "Poppins" }}>Select an item from the right...</p>
                      </div>
                    )}
                  </div>
                );
              })}
              <button onClick={() => setSlots(slots + 1)} className="w-full mt-2 py-4 bg-white border-2 border-dashed border-gray-300 text-gray-600 rounded-2xl font-bold uppercase tracking-widest text-xs hover:border-gray-400 hover:bg-gray-50 transition-colors active:scale-95" style={{ fontFamily: "Poppins" }}>
                + Add Another ID
              </button>
            </div>
            <div className="mt-6 p-5 bg-gray-100 border border-gray-200 rounded-2xl flex-shrink-0">
              <p className="text-xs font-black uppercase tracking-widest mb-2 text-gray-900" style={{ fontFamily: "Poppins" }}>Discount Breakdown</p>
              <p className="text-sm font-medium text-gray-600 leading-relaxed" style={{ fontFamily: "Poppins" }}>
                You have <strong>{slots} slot{slots > 1 ? 's' : ''}</strong>. The 20% discount is divided equally.
              </p>
              <p className="text-2xl font-black text-gray-900 mt-2" style={{ fontFamily: "Poppins" }}>
                {(discountPercent * 100).toFixed(2)}% <span className="text-xs font-bold text-gray-500 uppercase tracking-widest ml-1">per assigned item</span>
              </p>
            </div>
          </div>
          <div className="w-7/12 p-8 flex flex-col bg-white overflow-y-auto hide-scroll">
            <div className="flex justify-between items-end mb-6">
              <div>
                <h3 className="text-sm font-black text-gray-800 uppercase tracking-widest" style={{ fontFamily: "Poppins" }}>Select Cart Items</h3>
                <p className="text-xs text-gray-500 font-medium mt-1" style={{ fontFamily: "Poppins" }}>Check the items consumed by the cardholders.</p>
              </div>
              <span className="text-xs font-bold text-gray-500 bg-gray-100 px-3 py-1 rounded-md" style={{ fontFamily: "Poppins" }}>{selectedKeys.length} / {slots} Selected</span>
            </div>
            <div className="space-y-3">
              {lines.map(l => {
                if (!l.selectable) {
                  return (
                    <div key={l.key} className="pt-5 pb-2 px-2 border-b border-gray-200 flex items-center gap-3">
                      <span className="text-xl">📦</span>
                      <span className="text-sm font-black text-gray-900 uppercase tracking-wider" style={{ fontFamily: "Poppins" }}>{l.name} (Combo)</span>
                    </div>
                  );
                }
                const isSelected = selectedKeys.includes(l.key);
                const isDisabled = !isSelected && selectedKeys.length >= slots;
                return (
                  <button 
                    key={l.key} 
                    onClick={() => toggleKey(l.key)} 
                    disabled={isDisabled}
                    className={`w-full text-left px-5 py-4 rounded-2xl border flex items-center gap-4 transition-all ${isSelected ? 'border-orange-500 bg-orange-50 shadow-md ring-1 ring-orange-500' : isDisabled ? 'border-gray-100 bg-gray-50 opacity-40 cursor-not-allowed' : 'border-gray-200 bg-white hover:border-orange-300 hover:shadow-sm'}`}
                  >
                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${isSelected ? 'border-orange-500 bg-orange-500 text-white' : 'border-gray-300 bg-white'}`}>
                      {isSelected && <svg viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>}
                    </div>
                    <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center overflow-hidden border border-gray-200 flex-shrink-0 p-1">
                      {l.img ? <img src={l.img} className="w-full h-full object-contain" alt={l.name} /> : <span className="text-2xl">🍩</span>}
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className={`block text-sm font-bold truncate ${isSelected ? 'text-orange-900' : 'text-gray-800'}`} style={{ fontFamily: "Poppins" }}>{l.name}</span>
                      {l.isMod && <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1 block" style={{ fontFamily: "Poppins" }}>Combo Inclusion</span>}
                    </div>
                    <div className="text-right flex-shrink-0">
                      <span className={`block text-sm font-black ${isSelected ? 'text-orange-700' : 'text-gray-900'}`} style={{ fontFamily: "Poppins" }}> {l.total.toFixed(2)}</span>
                      {isSelected && <span className="text-[10px] font-black text-orange-600 block mt-1" style={{ fontFamily: "Poppins" }}>− {(l.total * discountPercent).toFixed(2)}</span>}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
        <div className="px-8 py-5 border-t border-gray-100 bg-white flex justify-between items-center shadow-[0_-4px_20px_rgba(0,0,0,0.03)] flex-shrink-0 z-10">
          <div>
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest block mb-1" style={{ fontFamily: "Poppins" }}>Total Discount Amount</span>
            <span className="text-3xl font-black text-orange-600" style={{ fontFamily: "Poppins" }}>− {previewAmount.toFixed(2)}</span>
          </div>
          <div className="flex gap-4">
            <button onClick={onClose} className="px-8 py-4 rounded-xl font-bold text-gray-600 bg-gray-100 hover:bg-gray-200 transition-colors text-sm" style={{ fontFamily: "Poppins" }}>Cancel</button>
            <button onClick={() => onApply(slots, selectedKeys)} disabled={selectedKeys.length === 0} className="px-10 py-4 rounded-xl font-bold text-white bg-gray-900 hover:bg-black transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-xl active:scale-95 text-sm" style={{ fontFamily: "Poppins" }}>
              Apply Configuration →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function TransactionTypeModal({ selectedType, onSelect, onClose }: { selectedType: TransactionType; onSelect: (type: TransactionType) => void; onClose: () => void; }) {
  const [selected, setSelected] = useState<TransactionType>(selectedType);
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 animate-fade-in" style={{ background: "rgba(160,150,145,0.30)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)" }} onClick={onClose}>
      <div className="rounded-3xl w-full max-w-sm mx-4 relative overflow-hidden animate-scale-in" style={glass.modal} onClick={(e) => e.stopPropagation()}>
        <div style={{ height: 5, background: "linear-gradient(90deg, #f97316 0%, #fb923c 60%, #fed7aa 100%)" }} />
        <div className="p-7">
          <button onClick={onClose} className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-base transition-all hover:bg-black/5" style={{ background: "rgba(0,0,0,0.05)", color: "#bbb", border: "1px solid rgba(0,0,0,0.07)" }}>✕</button>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: "linear-gradient(135deg, #fef2f2, #fee2e2)", border: "1.5px solid rgba(220,38,38,0.18)", boxShadow: "0 2px 10px rgba(220,38,38,0.10)" }}>
              <span style={{ fontSize: 22 }}>🏷️</span>
            </div>
            <div>
              <p style={{ fontFamily: "Poppins", fontSize: 10, color: "#ccc", fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 2 }}>Customer Type</p>
              <h2 style={{ fontFamily: "Poppins", fontSize: 16, fontWeight: 900, color: "#1a1a1a", lineHeight: 1 }}>Select <span style={{ color: "#f97316" }}>Transaction Type</span></h2>
            </div>
          </div>
          <div className="flex flex-col gap-3 mb-6">
            {TRANSACTION_TYPES.map((opt) => {
              const isSelected = selected === opt.id;
              return (
                <button key={opt.id} onClick={() => { setSelected(opt.id); onSelect(opt.id); }} className="flex items-center gap-4 rounded-2xl p-4 text-left w-full transition-all duration-200 focus:outline-none"
                  style={{ background: isSelected ? opt.activeBg : opt.bg, border: `2px solid ${isSelected ? opt.activeBorder : opt.border}`, boxShadow: isSelected ? `0 4px 16px ${opt.color}22` : "none", transform: isSelected ? "scale(1.01)" : "scale(1)" }}>
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 text-2xl" style={{ fontFamily: "Poppins", background: isSelected ? `${opt.color}18` : "rgba(255,255,255,0.6)", border: `1px solid ${opt.border}` }}>{opt.icon}</div>
                  <div className="flex-1">
                    <p style={{ fontSize: 16, fontWeight: 900, color: isSelected ? opt.color : "#1a1a1a", fontFamily: "Poppins", letterSpacing: 0.5 }}>{opt.label}</p>
                    <p style={{ fontFamily: "Poppins", fontSize: 11, color: "#aaa", marginTop: 1 }}>{opt.sublabel}</p>
                  </div>
                  {opt.autoDiscount && opt.autoDiscount !== "VAT_EXEMPT_ONLY" && (
                    <div className="flex flex-col items-end gap-1">
                      <span className="px-3 py-1 rounded-full text-xs font-black" style={{ fontFamily: "Poppins", background: isSelected ? opt.color : "rgba(0,0,0,0.06)", color: isSelected ? "#fff" : "#999", transition: "all 0.2s" }}>
                        20% OFF
                      </span>
                      {isSelected && <span style={{ fontFamily: "Poppins", color: opt.color, fontSize: 11, fontWeight: 900, lineHeight: 1 }}>✓</span>}
                    </div>
                  )}
                  {opt.autoDiscount === "VAT_EXEMPT_ONLY" && (
                    <div className="flex flex-col items-end gap-1">
                      <span className="px-3 py-1 rounded-full text-xs font-black" style={{ fontFamily: "Poppins", background: isSelected ? opt.color : "rgba(0,0,0,0.06)", color: isSelected ? "#fff" : "#999", transition: "all 0.2s" }}>
                        12% OFF
                      </span>
                      {isSelected && <span style={{ fontFamily: "Poppins", color: opt.color, fontSize: 11, fontWeight: 900, lineHeight: 1 }}>✓</span>}
                    </div>
                  )}
                  {!opt.autoDiscount && (
                    <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: isSelected ? opt.color : "rgba(0,0,0,0.08)", border: `2px solid ${isSelected ? opt.color : "rgba(0,0,0,0.12)"}`, transition: "all 0.2s" }}>
                      {isSelected && <span style={{ fontFamily: "Poppins", color: "#fff", fontSize: 11, fontWeight: 900, lineHeight: 1 }}>✓</span>}
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

export function ManagerPinModal({ title, subtitle, onConfirm, onClose, accentColor = "#f97316", stripColor = "linear-gradient(90deg, #ef4444 0%, #f87171 60%, #fca5a5 100%)" }: { title: string; subtitle: string; onConfirm: (pin: string) => void; onClose: () => void; accentColor?: string; stripColor?: string; }) {
  const [pin, setPin] = useState("");
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 animate-fade-in" style={{ background: "rgba(160,150,145,0.30)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)" }} onClick={onClose}>
      <div className="rounded-3xl w-full max-w-sm mx-4 relative overflow-hidden animate-scale-in" style={glass.modal} onClick={(e) => e.stopPropagation()}>
        <div style={{ height: 5, background: stripColor }} />
        <div className="p-7">
          <button onClick={onClose} className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-base transition-all hover:bg-black/5" style={{ background: "rgba(0,0,0,0.05)", color: "#bbb", border: "1px solid rgba(0,0,0,0.07)" }}>✕</button>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: "linear-gradient(135deg, #fee2e2, #fecaca)", border: "1.5px solid rgba(239,68,68,0.18)", boxShadow: "0 2px 10px rgba(239,68,68,0.10)" }}>
              <span style={{ fontSize: 22 }}>🔐</span>
            </div>
            <div>
              <p style={{ fontFamily: "Poppins", fontSize: 10, color: "#ccc", fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 2 }}>Manager Verification</p>
              <h2 style={{ fontFamily: "Poppins", fontSize: 18, fontWeight: 900, color: "#1a1a1a", lineHeight: 1 }}>Enter Manager <span style={{ color: "#f97316" }}>PIN</span></h2>
            </div>
          </div>
          <p style={{ fontFamily: "Poppins", fontSize: 13, color: "#666", marginBottom: 6, textAlign: "center" }}>{subtitle}</p>
          <div style={{ fontFamily: "Poppins" }} className="text-2xl font-bold tracking-widest text-center rounded-lg px-6 py-4 mb-6" style={{ background: "rgba(255,255,255,0.2)", backdropFilter: "blur(12px)", border: "1px solid rgba(255,255,255,0.4)", color: accentColor, minHeight: 80, display: "flex", alignItems: "center", justifyContent: "center" }}>
            {"•".repeat(pin.length) || "Enter PIN"}
          </div>
          <div className="flex gap-6 items-start">
            <div className="grid grid-cols-3 gap-3">
              {[1,2,3,4,5,6,7,8,9].map((num) => (
                <button key={num} onClick={() => { if (pin.length < 4) setPin((p) => p + String(num)); }} className="rounded-lg py-3 text-xl font-bold transition-all duration-100 hover:brightness-110 active:scale-95"
                  style={{ fontFamily: "Poppins", width: 70, height: 70, background: "rgba(255,255,255,0.3)", backdropFilter: "blur(12px)", border: "1px solid rgba(255,255,255,0.5)", color: accentColor }}>{num}</button>
              ))}
              <button onClick={() => { if (pin.length < 4) setPin((p) => p + "0"); }} className="col-span-2 rounded-lg py-3 text-xl font-bold transition-all duration-100 hover:brightness-110 active:scale-95"
                style={{ fontFamily: "Poppins", background: "rgba(255,255,255,0.3)", backdropFilter: "blur(12px)", border: "1px solid rgba(255,255,255,0.5)", color: accentColor }}>0</button>
              <button onClick={() => setPin((p) => p.slice(0, -1))} className="rounded-lg py-3 text-xl font-bold transition-all duration-100 hover:brightness-110 active:scale-95"
                style={{ fontFamily: "Poppins", background: "rgba(255,255,255,0.3)", backdropFilter: "blur(12px)", border: "1px solid rgba(255,255,255,0.5)", color: "#ff6b6b" }}>⌫</button>
            </div>
            <div className="flex flex-col gap-3">
              <button onClick={() => onConfirm(pin)} className="rounded-lg font-bold transition-all duration-100 hover:brightness-110 active:scale-95"
                style={{ width: 70, height: 156, background: "#4ade80", backdropFilter: "blur(12px)", border: "1px solid rgba(255,255,255,0.5)", color: "#fff", fontSize: "36px" }}>✓</button>
              <button onClick={onClose} className="px-4 py-2 text-sm font-bold tracking-wide transition-all duration-200 hover:brightness-105 rounded-lg"
                style={{ fontFamily: "Poppins", color: "#333", background: "rgba(255,255,255,0.4)", backdropFilter: "blur(12px)", border: "1px solid rgba(255,255,255,0.6)" }}>Cancel</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
