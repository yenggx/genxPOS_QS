import React from 'react';

export type DiscountType = number | "SR_PWD" | "VIP" | "ATHLETE" | null;

export const DISCOUNT_OPTIONS = [
  { id: "SR_PWD" as DiscountType, label: "SR / PWD", sublabel: "Senior Citizen & Person with Disability", icon: "♿", rate: 0.20, color: "#2563eb", bg: "rgba(37,99,235,0.07)", border: "rgba(37,99,235,0.20)", activeBg: "rgba(37,99,235,0.12)", activeBorder: "#2563eb" },
  { id: "ATHLETE" as DiscountType, label: "ATHLETE", sublabel: "Registered Athlete", icon: "🏅", rate: 0.20, color: "#dc2626", bg: "rgba(220,38,38,0.07)", border: "rgba(220,38,38,0.20)", activeBg: "rgba(220,38,38,0.12)", activeBorder: "#dc2626" },
  { id: "VIP" as DiscountType, label: "VIP", sublabel: "VIP Member Discount", icon: "⭐", rate: 0.20, color: "#f97316", bg: "rgba(249,115,22,0.07)", border: "rgba(249,115,22,0.20)", activeBg: "rgba(249,115,22,0.12)", activeBorder: "#f97316" },
];

export type TransactionType = "REGULAR" | "SRPWD" | "ATHLETE" | "VIP" | "DIPLOMAT" | "PEZA";

export const TRANSACTION_TYPES = [
  { id: "REGULAR" as TransactionType, label: "Regular", sublabel: "Regular Customer", icon: "👤", autoDiscount: null, color: "#6b7280", bg: "rgba(107,113,128,0.07)", border: "rgba(107,113,128,0.20)", activeBg: "rgba(107,113,128,0.12)", activeBorder: "#6b7280" },
  { id: "SRPWD" as TransactionType, label: "PWD/SR", sublabel: "Person with Disability & Senior Citizen", icon: "♿", autoDiscount: "SR_PWD", color: "#2563eb", bg: "rgba(37,99,235,0.07)", border: "rgba(37,99,235,0.20)", activeBg: "rgba(37,99,235,0.12)", activeBorder: "#2563eb" },
  { id: "ATHLETE" as TransactionType, label: "Athlete", sublabel: "Registered Athlete", icon: "🏅", autoDiscount: "ATHLETE", color: "#dc2626", bg: "rgba(220,38,38,0.07)", border: "rgba(220,38,38,0.20)", activeBg: "rgba(220,38,38,0.12)", activeBorder: "#dc2626" },
  { id: "DIPLOMAT" as TransactionType, label: "Diplomat", sublabel: "VAT Exemption (Zero Rated)", icon: "🏛️", autoDiscount: "VAT_EXEMPT_ONLY", color: "#8b5cf6", bg: "rgba(139,92,246,0.07)", border: "rgba(139,92,246,0.20)", activeBg: "rgba(139,92,246,0.12)", activeBorder: "#8b5cf6" },
  { id: "PEZA" as TransactionType, label: "PEZA Zone", sublabel: "VAT Exemption (No VAT)", icon: "🏢", autoDiscount: "VAT_EXEMPT_ONLY", color: "#0ea5e9", bg: "rgba(14,165,233,0.07)", border: "rgba(14,165,233,0.20)", activeBg: "rgba(14,165,233,0.12)", activeBorder: "#0ea5e9" },
];


export const glass = {
  card: { background: "#e0e0e0", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)", border: "1px solid rgba(255,255,255,0.45)", boxShadow: "0 4px 20px rgba(0,0,0,0.10), inset 0 1px 0 rgba(255,255,255,0.6)" } as React.CSSProperties,
  cardHover: { background: "rgba(255,255,255,0.38)", border: "1px solid rgba(249,115,22,0.55)", boxShadow: "0 8px 28px rgba(249,115,22,0.18), inset 0 1px 0 rgba(255,255,255,0.7)" } as React.CSSProperties,
  panel: { background: "rgba(255,255,255,0.18)", backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)", border: "1px solid rgba(255,255,255,0.35)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.5), 0 8px 32px rgba(0,0,0,0.12)" } as React.CSSProperties,
  cartItem: { background: "rgba(255,255,255,0.30)", backdropFilter: "blur(10px)", WebkitBackdropFilter: "blur(10px)", border: "1px solid rgba(255,255,255,0.50)", boxShadow: "0 2px 8px rgba(0,0,0,0.06), inset 0 1px 0 rgba(255,255,255,0.6)" } as React.CSSProperties,
  modal: { background: "rgba(255,255,255,0.85)", backdropFilter: "blur(32px)", WebkitBackdropFilter: "blur(32px)", border: "1.5px solid rgba(255,255,255,0.95)", boxShadow: "0 32px 80px rgba(0,0,0,0.16), inset 0 1px 0 rgba(255,255,255,1)" } as React.CSSProperties,
};