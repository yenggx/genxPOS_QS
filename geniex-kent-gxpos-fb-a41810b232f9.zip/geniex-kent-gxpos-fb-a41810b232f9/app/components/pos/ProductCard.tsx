import { resolveMenuImageUrl } from "@/src/utils/menuImages";
import { useRef, useState } from "react";

export const DonutPlaceholder = ({ size = 100 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
    <circle cx="50" cy="50" r="45" fill="rgba(245,197,163,0.7)" />
    <circle cx="50" cy="50" r="18" fill="rgba(243,243,243,0.8)" />
    <circle cx="50" cy="50" r="45" stroke="rgba(232,168,124,0.8)" strokeWidth="2" fill="none" />
  </svg>
);

export const formatMoney = (val: number) =>
  val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });


export function ProductCard({ item, onAdd, onLongPress, stock, showStock }: { item: any; onAdd: (item: any) => void; onLongPress: (item: any) => void; stock?: number, showStock: boolean }) {
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const isLongPress = useRef(false);
  
  // Drag detection refs
  const touchStartPos = useRef<{ x: number, y: number } | null>(null);
  const hasDragged = useRef(false);

  const [imgSrc, setImgSrc] = useState<string | undefined>(
    () => resolveMenuImageUrl(item.imgReal) || undefined
  );
  const [imgLoaded, setImgLoaded] = useState(false);
  const [imgErr, setImgErr]     = useState(false);
  const fallbackStage           = useRef<'local' | 'remote' | 'dead'>('local');

  const currentStock = stock ?? 0;
  const isOutOfStock = currentStock <= 0;

  const handleError = () => {
    if (fallbackStage.current === 'local' && item.imgReal) {
      fallbackStage.current = 'remote';
      setImgSrc(item.imgReal || undefined);
    } else {
      fallbackStage.current = 'dead';
      setImgErr(true);               // show placeholder
    }
  };

  const startPress = (e: React.TouchEvent | React.MouseEvent) => {
    if (isOutOfStock) return;
    
    // Record starting coordinates
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    touchStartPos.current = { x: clientX, y: clientY };
    hasDragged.current = false;
    isLongPress.current = false;

    timerRef.current = setTimeout(() => {
      // Only fire long press if the user hasn't dragged
      if (!hasDragged.current) {
        onLongPress(item);
        isLongPress.current = true;
      }
    }, 600);
  };

  const handleMove = (e: React.TouchEvent | React.MouseEvent) => {
    if (!touchStartPos.current || hasDragged.current || isOutOfStock) return;
    
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    const dx = clientX - touchStartPos.current.x;
    const dy = clientY - touchStartPos.current.y;
    
    // If movement exceeds 10px, flag it as a drag and kill the timer
    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
      hasDragged.current = true;
      cancelPress();
    }
  };

  const handleRelease = (e: React.TouchEvent | React.MouseEvent) => {
    if (isOutOfStock) return;
    cancelPress();
    
    // Stop synthetic mouse events from firing after a touch sequence
    if (e.type === 'touchend' && e.cancelable) {
      e.preventDefault(); 
    }
    
    // Only trigger add if it wasn't a long press AND wasn't a scroll/drag
    if (!isLongPress.current && !hasDragged.current) {
      onAdd(item);
    }
    
    touchStartPos.current = null;
  };

  const cancelPress = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
  };

  return (
    <>
      {isOutOfStock && (
        <div className="absolute top-3 left-3 bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-full z-10 shadow-sm"  style={{ fontFamily: "Poppins" }}>
          Unavailable
        </div>
      )}
      {(stock ?? 0) > 0 && showStock && (
        <div className="absolute top-3 left-3 bg-green-700 text-white text-[10px] font-bold px-2 py-1 rounded-full z-10 shadow-sm" style={{ fontFamily: "Poppins" }}>
          {formatMoney(stock ?? 0).replace(/\.00$/, '')}
        </div>
      )}
      <button
        onMouseDown={startPress}
        onMouseMove={handleMove}
        onMouseUp={handleRelease}
        onMouseLeave={(e) => { handleMove(e); cancelPress(); }}
        onTouchStart={startPress}
        onTouchMove={handleMove}
        onTouchEnd={handleRelease}
        disabled={isOutOfStock}
        className={`flex flex-col items-center p-3 sm:p-4 rounded-3xl w-full relative focus:outline-none transition-transform duration-200 ${!isOutOfStock ? 'active:scale-95' : ''}`}
        style={{ height: "220px", backgroundColor: "#e4e4e4", boxShadow: "inset 2px 2px 4px rgba(255,255,255,0.8), inset -2px -2px 4px rgba(0,0,0,0.05), 0 4px 8px rgba(0,0,0,0.05)", opacity: isOutOfStock ? 0.5 : 1, cursor: isOutOfStock ? 'not-allowed' : 'pointer' }}
      >
        <div className="relative w-24 h-24 sm:w-28 sm:h-28 shrink-0 flex items-center justify-center mt-1">
          {!imgErr ? (
            <>
              {!imgLoaded && <div className="absolute inset-0 rounded-full bg-black/5 animate-pulse" />}
              <img
                src={imgSrc}
                alt={item.name}
                className={`w-full h-full object-contain transition-opacity duration-300 ${imgLoaded ? 'opacity-100' : 'opacity-0'}`}
                onLoad={() => setImgLoaded(true)}
                onError={handleError}
              />
            </>
          ) : (
            <DonutPlaceholder size={96} />
          )}
        </div>
        <div className="flex flex-col items-center justify-end grow w-full pb-1">
          <span className="text-center uppercase leading-tight line-clamp-2 w-full wrap-break-word" style={{ fontFamily: "'DunkinSans Display', 'DunkinSans Book', Impact, Arial, sans-serif", fontSize: 14, color: "#4a4a4a", fontWeight: 900 }}>
            {item.name}
          </span>
          <span className="font-bold mt-1" style={{ fontSize: 13, color: "#ff5800", fontFamily: "Poppins" }}>
             {formatMoney(item.price)}
          </span>
        </div>
      </button>
    </>
  );
}