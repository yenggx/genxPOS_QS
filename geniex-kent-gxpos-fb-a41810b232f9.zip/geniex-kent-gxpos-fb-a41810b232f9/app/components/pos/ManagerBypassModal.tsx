import { FiUser } from "react-icons/fi";

export function ManagerBypassModal({ 
  onOpenDrawer, 
  onBypass 
}: { 
  onOpenDrawer: () => void; 
  onBypass: () => void; 
}) {
  return (
    <div className="fixed inset-0 flex items-center justify-center z-[300] animate-fade-in" style={{ background: "rgba(15, 23, 42, 0.8)", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)" }}>
      <div className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden flex flex-col p-8 animate-scale-in shadow-2xl" style={{ background: "#ffffff" }}>
        
        <div className="w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto" style={{ background: "rgba(249, 115, 22, 0.1)", color: "#f97316" }}>
          <FiUser size={32} />
        </div>
        
        <h2 className="text-2xl font-black text-gray-900 mb-2 text-center" style={{ fontFamily: "Poppins" }}>
          Manager Access
        </h2>
        
        <p className="text-gray-500 text-sm text-center mb-8 font-medium">
          No active shift detected for your account. Would you like to open a cash drawer for transactions, or bypass to access reports?
        </p>

        <div className="flex flex-col gap-3">
          <button 
            onClick={onOpenDrawer}
            className="w-full rounded-2xl py-3.5 text-sm font-bold text-white transition-all hover:brightness-110 active:scale-95 shadow-md"
            style={{ background: "linear-gradient(135deg, #f97316 0%, #ea580c 100%)", fontFamily: "Poppins" }}
          >
            Open Cash Drawer
          </button>
          
          <button 
            onClick={onBypass}
            className="w-full rounded-2xl py-3.5 text-sm font-bold transition-all hover:bg-gray-50 active:scale-95"
            style={{ background: "#f3f4f6", color: "#4b5563", fontFamily: "Poppins", border: "2px solid #e5e7eb" }}
          >
            Bypass to Reports
          </button>
        </div>
      </div>
    </div>
  );
}