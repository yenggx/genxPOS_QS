'use client';

import Image from 'next/image';
import styles from './loader.module.css';

export default function LoaderPage() {
  return (
    <div className={styles.loaderContainer}>
      <div className={styles.loaderContent}>
        {/* Rotating Product Image */}
        <div className={styles.rotatingWrapper}>
          <Image
            src="/images/classic-nutty-choco.png"
            alt="Classic Nutty Choco"
            width={120}
            height={120}
            className={styles.rotatingImage}
            priority
          />
        </div>

        {/* Dunkin Logo in center */}
        <div className={styles.logoWrapper}>
          <Image
            src="/images/dunkinlogo.svg"
            alt="Dunkin Logo"
            width={100}
            height={100}
            priority
          />
        </div>

        {/* Loading text */}
        <p className={styles.loadingText}>Loading...</p>
      </div>
    </div>
  );
}
