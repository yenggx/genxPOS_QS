'use client';
import {
  createContext, useContext, useEffect, useRef, useState, useCallback,
  type ReactNode, type MutableRefObject,
} from 'react';

// ─── Types ────────────────────────────────────────────────────────────────────

export type MediaType = 'image' | 'video';

export interface MediaItem {
  id: string;
  url: string;
  type: MediaType;
  duration: number;
  name: string;
}

export interface DisplayModeConfig {
  mode: 'static' | 'carousel';
  items: MediaItem[];
}

export interface CfdConfig {
  idle: DisplayModeConfig;
  ongoing: DisplayModeConfig;
}

interface CfdContextValue {
  /** Current CFD configuration (idle + ongoing screens) */
  cfdConfig: CfdConfig;
  /** Update config, persist to localStorage, and broadcast to the CFD window */
  updateCfdConfig: (config: CfdConfig) => void;
  /** Whether the CFD popup window is currently open */
  cfdOpen: boolean;
  /** Ref to the CFD popup window (for focus / close polling) */
  cfdWindowRef: MutableRefObject<Window | null>;
  /** Open (or refocus + resync) the CFD popup window */
  launchCfd: (selectedScreenId?: string) => Promise<void>;
}

// ─── Defaults ─────────────────────────────────────────────────────────────────

const DEFAULT_CFD_CONFIG: CfdConfig = {
  idle:    { mode: 'static', items: [] },
  ongoing: { mode: 'static', items: [] },
};

// ─── Context ──────────────────────────────────────────────────────────────────

const CfdContext = createContext<CfdContextValue | null>(null);

export function CfdProvider({ children }: { children: ReactNode }) {
  const [cfdConfig, setCfdConfigState] = useState<CfdConfig>(DEFAULT_CFD_CONFIG);
  const [cfdOpen, setCfdOpen]          = useState(false);

  // Stable refs — avoids stale-closure issues inside the BroadcastChannel handler
  const cfdConfigRef  = useRef<CfdConfig>(DEFAULT_CFD_CONFIG);
  const cfdChannel    = useRef<BroadcastChannel | null>(null);
  const cfdWindowRef  = useRef<Window | null>(null);
  const pollRef       = useRef<ReturnType<typeof setInterval> | null>(null);

  // Keep ref in sync with state
  useEffect(() => { cfdConfigRef.current = cfdConfig; }, [cfdConfig]);

  // ── Load persisted config on mount ─────────────────────────────────────────
  useEffect(() => {
    try {
      const saved = localStorage.getItem('cfd_config');
      if (saved) {
        const parsed = JSON.parse(saved) as CfdConfig;
        setCfdConfigState(parsed);
        cfdConfigRef.current = parsed;
      }
    } catch { /* corrupt storage — ignore */ }
  }, []);

  // ── BroadcastChannel — lives for the entire app lifetime ───────────────────
  useEffect(() => {
    const channel = new BroadcastChannel('cfd_channel');
    cfdChannel.current = channel;

    channel.onmessage = ({ data }) => {
      if (data.type === 'CFD_READY') {
        // CFD window just (re)loaded — push the latest config immediately
        setCfdOpen(true);
        channel.postMessage({
          type: 'CFD_CONFIG_UPDATE',
          payload: cfdConfigRef.current,
        });
      }
    };

    // Ping in case the CFD window is already open from a previous session
    channel.postMessage({ type: 'PING' });

    return () => {
      channel.close();
      cfdChannel.current = null;
    };
  }, []);

  // ── updateCfdConfig ────────────────────────────────────────────────────────
  const updateCfdConfig = useCallback((newConfig: CfdConfig) => {
    setCfdConfigState(newConfig);
    cfdConfigRef.current = newConfig;
    localStorage.setItem('cfd_config', JSON.stringify(newConfig));
    cfdChannel.current?.postMessage({ type: 'CFD_CONFIG_UPDATE', payload: newConfig });
  }, []);

  // ── launchCfd ─────────────────────────────────────────────────────────────
  const launchCfd = useCallback(async (selectedScreenId?: string) => {
    // If window is already open — focus and resync
    if (cfdWindowRef.current && !cfdWindowRef.current.closed) {
      cfdWindowRef.current.focus();
      cfdChannel.current?.postMessage({
        type: 'CFD_CONFIG_UPDATE',
        payload: cfdConfigRef.current,
      });
      return;
    }

    let features = 'popup=1,width=1024,height=768';

    try {
      if ('getScreenDetails' in window && selectedScreenId !== undefined) {
        const screenDetails = await (window as any).getScreenDetails();
        const idx = parseInt(selectedScreenId, 10);
        const target = !isNaN(idx) ? screenDetails.screens[idx] : null;

        if (target) {
          const left   = target.availLeft  ?? target.left  ?? 0;
          const top    = target.availTop   ?? target.top   ?? 0;
          const width  = target.availWidth ?? target.width ?? 1920;
          const height = target.availHeight ?? target.height ?? 1080;
          features = `popup=1,left=${left},top=${top},width=${width},height=${height}`;
        }
      }
    } catch { /* API unavailable or permission denied — fall back to default */ }

    const win = window.open('/cfd', 'CustomerDisplay', features);
    if (!win) return;

    cfdWindowRef.current = win;
    setCfdOpen(true);

    // Attempt fullscreen on the popup
    const tryFullscreen = () => {
      try {
        win.document.documentElement
          .requestFullscreen({ navigationUI: 'hide' })
          .catch(() => {});
      } catch { /* cross-origin / gesture required */ }
    };
    tryFullscreen();
    win.addEventListener('load', tryFullscreen);

    // Poll to detect when the popup closes
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(() => {
      if (win.closed) {
        setCfdOpen(false);
        cfdWindowRef.current = null;
        clearInterval(pollRef.current!);
      }
    }, 1000);
  }, []);

  // Cleanup poll on unmount (shouldn't happen in root layout, but good practice)
  useEffect(() => () => { if (pollRef.current) clearInterval(pollRef.current); }, []);

  return (
    <CfdContext.Provider value={{ cfdConfig, updateCfdConfig, cfdOpen, cfdWindowRef, launchCfd }}>
      {children}
    </CfdContext.Provider>
  );
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useCfd() {
  const ctx = useContext(CfdContext);
  if (!ctx) throw new Error('useCfd must be used within <CfdProvider>');
  return ctx;
}