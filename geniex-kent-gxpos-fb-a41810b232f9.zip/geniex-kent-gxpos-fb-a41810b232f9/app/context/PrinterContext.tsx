// printerContext.tsx
"use client";

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
} from "react";
import { sileo } from "sileo";

// ─────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────

const POLL_INTERVAL          = 1000;
const STATUS_READ_DELAY      = 80;
const TRANSFER_TIMEOUT       = 4000;
const DRAWER_SETTLE_DELAY    = 800;
const MAX_RECONNECT_ATTEMPTS = 3;
const RECONNECT_BACKOFF_MS   = 3000;

// BroadcastChannel used to delegate print jobs across tabs.
// The tab that owns the USB claim listens and executes; other tabs post.
const PRINT_CHANNEL_NAME = "pos_printer_bus";

// ─────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────

type TillStatus = "OPEN" | "CLOSED" | "UNKNOWN" | "ERROR";

type PrintJob = {
  type: "PRINT_JOB";
  id: string;
  text: string;
  kickDrawer: boolean;
};

type PrintAck = {
  type: "PRINT_ACK";
  id: string;
  ok: boolean;
  error?: string;
};

type PrinterBusMessage = PrintJob | PrintAck | { type: "PRINTER_AVAILABLE" } | { type: "PRINTER_GONE" };

interface PrinterContextType {
  usbPrinter: any | null;
  tillStatus: TillStatus;
  pairPrinter: () => Promise<void>;
  unpairPrinter: () => Promise<void>;
  openDrawer: () => Promise<void>;
  printDirect: (text: string, kickDrawer?: boolean) => Promise<void>;
  checkStatusNow: () => Promise<void>;
}

// ─────────────────────────────────────────
// USB QUEUE
// ─────────────────────────────────────────

class UsbQueue {
  private queue = Promise.resolve();

  add<T>(task: () => Promise<T>): Promise<T> {
    return new Promise((resolve, reject) => {
      this.queue = this.queue.then(async () => {
        try { resolve(await task()); }
        catch (err) { reject(err); }
      });
    });
  }
}

// ─────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

const withTimeout = <T,>(promise: Promise<T>, ms: number): Promise<T> =>
  Promise.race([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(() => reject(new Error(`USB timeout after ${ms}ms`)), ms)
    ),
  ]);

const randomId = () => Math.random().toString(36).slice(2);

// ─────────────────────────────────────────
// CONTEXT
// ─────────────────────────────────────────

const PrinterContext = createContext<PrinterContextType | null>(null);

export function PrinterProvider({ children }: { children: React.ReactNode }) {
  const [usbPrinter, setUsbPrinter] = useState<any | null>(null);
  const [tillStatus, setTillStatus] = useState<TillStatus>("UNKNOWN");

  const usbQueue             = useRef(new UsbQueue()).current;
  const pollingRef           = useRef(false);
  const busyRef              = useRef(false);
  const mountedRef           = useRef(true);
  const consecutiveErrorsRef = useRef(0);
  const lastReconnectAttempt = useRef(0);
  const pendingPrintQueue    = useRef<Array<{ text: string; kickDrawer: boolean }>>([]);

  // Tracks whether THIS tab owns the USB claim.
  const isUsbOwnerRef = useRef(false);

  // Pending cross-tab print job resolvers: id -> { resolve, reject }
  const pendingDelegatedJobs = useRef<
    Map<string, { resolve: () => void; reject: (e: Error) => void }>
  >(new Map());

  const channelRef = useRef<BroadcastChannel | null>(null);

  // ─── BROADCAST CHANNEL SETUP ──────────────────────────────────────
  // NOTE: This effect captures usbPrinter via closure. We re-run it
  // whenever usbPrinter changes so the message handler always has the
  // latest device reference.

  useEffect(() => {
    if (typeof window === "undefined" || !("BroadcastChannel" in window)) return;

    // Close previous channel instance before creating a new one
    if (channelRef.current) {
      channelRef.current.close();
    }

    const channel = new BroadcastChannel(PRINT_CHANNEL_NAME);
    channelRef.current = channel;

    channel.onmessage = async (event: MessageEvent<PrinterBusMessage>) => {
      const msg = event.data;

      if (msg.type === "PRINT_JOB" && isUsbOwnerRef.current && usbPrinter) {
        let ok = true;
        let error: string | undefined;
        try {
          await printDirectWithDevice(usbPrinter, msg.text, msg.kickDrawer);
        } catch (err: any) {
          ok = false;
          error = err?.message ?? "Unknown error";
        }
        const ack: PrintAck = { type: "PRINT_ACK", id: msg.id, ok, error };
        channel.postMessage(ack);
        return;
      }

      if (msg.type === "PRINT_ACK") {
        const pending = pendingDelegatedJobs.current.get(msg.id);
        if (pending) {
          pendingDelegatedJobs.current.delete(msg.id);
          if (msg.ok) {
            pending.resolve();
          } else {
            pending.reject(new Error(msg.error ?? "Remote print failed"));
          }
        }
        return;
      }
    };

    return () => {
      channel.close();
      if (channelRef.current === channel) {
        channelRef.current = null;
      }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [usbPrinter]);

  const announceOwnership = (owned: boolean) => {
    isUsbOwnerRef.current = owned;
    channelRef.current?.postMessage(
      owned ? { type: "PRINTER_AVAILABLE" } : { type: "PRINTER_GONE" }
    );
  };

  const delegatePrintJob = (text: string, kickDrawer: boolean): Promise<void> => {
    return new Promise<void>((resolve, reject) => {
      const id = randomId();
      const timeout = setTimeout(() => {
        pendingDelegatedJobs.current.delete(id);
        reject(new Error("Cross-tab print timed out — is the Settings/POS tab open?"));
      }, 8000);

      pendingDelegatedJobs.current.set(id, {
        resolve: () => { clearTimeout(timeout); resolve(); },
        reject:  (e) => { clearTimeout(timeout); reject(e); },
      });

      const job: PrintJob = { type: "PRINT_JOB", id, text, kickDrawer };
      channelRef.current?.postMessage(job);
    });
  };

  // ─── DEVICE HELPERS ───────────────────

  const ensurePrinterReady = async (device: any): Promise<void> => {
    if (!device.opened) await device.open();
    if (device.configuration === null) await device.selectConfiguration(1);

    // Use a flag on the device object itself to track whether we've
    // already fully set up this session. Reset in reconnectPrinter.
    if (device.__interfaceReady) return;

    try {
      await device.claimInterface(0);
    } catch (err: any) {
      if (!err?.message?.toLowerCase().includes("claimed")) throw err;
      // Already claimed by this tab from a prior call — still need to
      // set the flag so we don't loop, but don't call selectAlternate.
      device.__interfaceReady = true;
      return;
    }

    await device.selectAlternateInterface(0, 0);
    device.__interfaceReady = true;
  };


  const getEndpoints = (device: any) => {
    const endpoints: any[] =
      device.configuration?.interfaces?.[0]?.alternate?.endpoints ?? [];
    return {
      inEndpoint:  endpoints.find((e) => e.direction === "in"),
      outEndpoint: endpoints.find((e) => e.direction === "out"),
    };
  };

  const reconnectPrinter = async (device: any): Promise<boolean> => {
    try {
      try { await device.releaseInterface(0); } catch {}
      try { await device.close(); }            catch {}
      device.__interfaceReady = false; //
      await sleep(1000);
      await device.open();
      if (device.configuration === null) await device.selectConfiguration(1);
      await device.claimInterface(0);
      await device.selectAlternateInterface(0, 0);
      device.__interfaceReady = true; // ← and this
      console.log("[Printer] Reconnect succeeded.");
      return true;
    } catch (err) {
      console.warn("[Printer] Reconnect failed:", err);
      return false;
    }
  };

  const waitForPrinterIdle = async (
    device: any,
    inEndpoint: any,
    outEndpoint: any,
    maxWaitMs = 8000,
  ): Promise<void> => {
    const started   = Date.now();
    const statusCmd = new Uint8Array([0x10, 0x04, 0x01]);

    while (Date.now() - started < maxWaitMs) {
      await sleep(100);
      try {
        await withTimeout(device.transferOut(outEndpoint.endpointNumber, statusCmd), TRANSFER_TIMEOUT);
        await sleep(STATUS_READ_DELAY);
        const result = await withTimeout(device.transferIn(inEndpoint.endpointNumber, 1), TRANSFER_TIMEOUT);
        if (result?.status !== "ok" || !result.data?.byteLength) break;
        const byte = result.data.getUint8(0);
        if ((byte & 0x90) !== 0x10) break;
        if ((byte & 0x08) === 0) {
          console.log(`[Printer] Idle after ${Date.now() - started}ms`);
          return;
        }
      } catch { break; }
    }
  };

  // ─── AUTO-CONNECT ─────────────────────

  useEffect(() => {
    mountedRef.current = true;

    const initPrinter = async () => {
      if (typeof navigator === "undefined" || !("usb" in navigator)) return;
      try {
        const pairedDevices: any[] = await (navigator as any).usb.getDevices();
        const savedVendorId  = localStorage.getItem("defaultPrinter_vendorId");
        const savedProductId = localStorage.getItem("defaultPrinter_productId");
        const device =
          savedVendorId && savedProductId
            ? pairedDevices.find(
                (d) =>
                  d.vendorId  === Number(savedVendorId) &&
                  d.productId === Number(savedProductId)
              )
            : null;
        if (!device) return;

        try {
          await ensurePrinterReady(device);
          if (mountedRef.current) {
            setUsbPrinter(device);
            announceOwnership(true);
            console.log("[Printer] Auto-connected and claimed:", device.productName);
            drainPrintQueue(device).catch(err =>
              console.warn("[Printer] Drain after auto-connect failed:", err)
            );
          }
        } catch (claimErr: any) {
          // Another tab already owns the claim — store device ref anyway
          // so printDirect can delegate
          console.warn("[Printer] Claim failed on auto-connect (another tab owns it):", claimErr?.message);
          if (mountedRef.current) {
            setUsbPrinter(device);
            isUsbOwnerRef.current = false;
          }
        }
      } catch (err) {
        console.warn("[Printer] Auto-connect failed:", err);
      }
    };

    initPrinter();
    return () => { mountedRef.current = false; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ─── TILL STATUS POLLING ───────────────

  useEffect(() => {
    if (!usbPrinter || !isUsbOwnerRef.current) {
      if (!usbPrinter) {
        setTillStatus("UNKNOWN");
        consecutiveErrorsRef.current = 0;
      }
      return;
    }

    let stopped = false;
    let timeoutId: ReturnType<typeof setTimeout>;

    const pollStatus = async () => {
      if (stopped) return;

      if (pollingRef.current || busyRef.current) {
        timeoutId = setTimeout(pollStatus, POLL_INTERVAL);
        return;
      }

      const errorCount = consecutiveErrorsRef.current;
      if (errorCount > 0) {
        const elapsed = Date.now() - lastReconnectAttempt.current;
        if (elapsed < RECONNECT_BACKOFF_MS) {
          timeoutId = setTimeout(pollStatus, RECONNECT_BACKOFF_MS - elapsed);
          return;
        }
      }

      pollingRef.current = true;

      try {
        await usbQueue.add(async () => {
          try {
            await ensurePrinterReady(usbPrinter);
            const { inEndpoint, outEndpoint } = getEndpoints(usbPrinter);

            if (!inEndpoint || !outEndpoint) throw new Error("Missing USB endpoints");

            const statusRequestCmd = new Uint8Array([0x10, 0x04, 0x01]);

            await withTimeout(
              usbPrinter.transferOut(outEndpoint.endpointNumber, statusRequestCmd),
              TRANSFER_TIMEOUT
            );
            await sleep(STATUS_READ_DELAY);

            const result = await withTimeout(
              usbPrinter.transferIn(inEndpoint.endpointNumber, 1),
              TRANSFER_TIMEOUT
            );

            if (result?.status === "ok" && result.data?.byteLength >= 1) {
              const statusByte  = result.data.getUint8(0);
              const isValidByte = (statusByte & 0x90) === 0x10;

              if (isValidByte) {
                const isOpen = (statusByte & 0x04) === 0;
                setTillStatus(isOpen ? "OPEN" : "CLOSED");
                consecutiveErrorsRef.current = 0;
              } else {
                console.warn(`[Printer] Unexpected status byte: 0x${statusByte.toString(16).toUpperCase()}`);
                setTillStatus("UNKNOWN");
                consecutiveErrorsRef.current = 0;
              }
            } else {
              console.warn("[Printer] Poll returned no data:", result?.status);
              setTillStatus("ERROR");
              throw new Error("No data from transferIn");
            }

          } catch (err) {
            console.warn("[Printer] Poll error:", err);
            setTillStatus("ERROR");

            consecutiveErrorsRef.current++;
            lastReconnectAttempt.current = Date.now();

            if (consecutiveErrorsRef.current >= MAX_RECONNECT_ATTEMPTS) {
              console.warn("[Printer] Max reconnect attempts reached. Forcing unpair.");
              consecutiveErrorsRef.current = 0;

              try { await usbPrinter.releaseInterface(0); } catch {}
              try { await usbPrinter.close(); }            catch {}

              if (mountedRef.current) {
                announceOwnership(false);
                setUsbPrinter(null);
                setTillStatus("UNKNOWN");
                localStorage.removeItem("defaultPrinter_vendorId");
                localStorage.removeItem("defaultPrinter_productId");
                localStorage.removeItem("defaultPrinter_name");

                sileo.error({
                  title: "Printer Disconnected",
                  description: "USB connection lost. Please re-pair your printer.",
                  fill: "#171717",
                  styles: { title: "text-white!", description: "text-white/75!" },
                });
              }
            } else {
              const recovered = await reconnectPrinter(usbPrinter);
              if (recovered) {
                drainPrintQueue(usbPrinter).catch(err =>
                  console.warn("[Printer] Drain after recovery failed:", err)
                );
              }
            }
          }
        });
      } finally {
        pollingRef.current = false;
        if (!stopped) {
          const nextDelay = consecutiveErrorsRef.current > 0
            ? RECONNECT_BACKOFF_MS
            : POLL_INTERVAL;
          timeoutId = setTimeout(pollStatus, nextDelay);
        }
      }
    };

    timeoutId = setTimeout(pollStatus, POLL_INTERVAL);

    return () => {
      stopped = true;
      clearTimeout(timeoutId);
    };
  }, [usbPrinter, usbQueue]);

  // ─── DRAIN QUEUE ──────────────────────

  const drainPrintQueue = async (device: any) => {
    while (pendingPrintQueue.current.length > 0) {
      const job = pendingPrintQueue.current.shift()!;
      try {
        await printDirectWithDevice(device, job.text, job.kickDrawer);
      } catch (err) {
        console.warn("[Printer] Drain job failed — re-queuing:", err);
        pendingPrintQueue.current.unshift(job);
        break;
      }
    }
  };

  // ─── INTERNAL: actual USB write ────────

  const printDirectWithDevice = async (device: any, text: string, kickDrawer = false) => {
    await usbQueue.add(async () => {
      busyRef.current = true;
      try {
        await ensurePrinterReady(device);

        const { inEndpoint, outEndpoint } = getEndpoints(device);
        if (!outEndpoint) throw new Error("No output endpoint found — check printer USB descriptor");

        const encoder   = new TextEncoder();
        const initCmd   = new Uint8Array([0x1b, 0x40]);
        const cutCmd    = new Uint8Array([0x1d, 0x56, 0x41, 0x10]);
        const textBytes = encoder.encode(text + "\n\n\n\n\n");

        await withTimeout(device.transferOut(outEndpoint.endpointNumber, initCmd), TRANSFER_TIMEOUT);

        const CHUNK = 512;
        for (let i = 0; i < textBytes.length; i += CHUNK) {
          await withTimeout(
            device.transferOut(outEndpoint.endpointNumber, textBytes.slice(i, i + CHUNK)),
            TRANSFER_TIMEOUT
          );
        }

        await withTimeout(device.transferOut(outEndpoint.endpointNumber, cutCmd), TRANSFER_TIMEOUT);

        if (kickDrawer) {
          const drawerCmd = new Uint8Array([0x1b, 0x70, 0x00, 0x19, 0xfa]);
          await withTimeout(device.transferOut(outEndpoint.endpointNumber, drawerCmd), TRANSFER_TIMEOUT);
        }

        if (inEndpoint) {
          await waitForPrinterIdle(device, inEndpoint, outEndpoint);
        } else {
          await sleep(Math.min(1500, 800 + text.length * 2));
        }
      } catch (err) {
        console.warn("[Printer] printDirectWithDevice failed:", err);
        await reconnectPrinter(device);
        throw err;
      } finally {
        busyRef.current = false;
      }
    });
  };

  // ─── PAIR ─────────────────────────────

  const pairPrinter = async () => {
    try {
      const device = await (navigator as any).usb.requestDevice({ filters: [] });
      await ensurePrinterReady(device);

      localStorage.setItem("defaultPrinter_vendorId",  String(device.vendorId));
      localStorage.setItem("defaultPrinter_productId", String(device.productId));
      localStorage.setItem("defaultPrinter_name",      device.productName || "POS Printer");

      consecutiveErrorsRef.current = 0;
      setUsbPrinter(device);
      announceOwnership(true);
      drainPrintQueue(device).catch(err =>
        console.warn("[Printer] Drain after pair failed:", err)
      );

      sileo.success({
        title: "Printer Paired!",
        description: device.productName,
        fill: "#171717",
        styles: { title: "text-white!", description: "text-white/75!" },
        duration: 1000
      });
    } catch (err) {
      console.warn("[Printer] Pairing error:", err);
      sileo.error({
        title: "Pairing Cancelled",
        fill: "#171717",
        styles: { title: "text-white!", description: "text-white/75!" },
      });
    }
  };

  // ─── UNPAIR ───────────────────────────

  const unpairPrinter = async () => {
    if (usbPrinter) {
      try { await usbPrinter.releaseInterface(0); } catch {}
      try { await usbPrinter.close(); }            catch {}
    }
    consecutiveErrorsRef.current = 0;
    announceOwnership(false);
    setUsbPrinter(null);
    setTillStatus("UNKNOWN");
    localStorage.removeItem("defaultPrinter_vendorId");
    localStorage.removeItem("defaultPrinter_productId");
    localStorage.removeItem("defaultPrinter_name");
  };

  // ─── OPEN DRAWER ──────────────────────

  const openDrawer = async () => {
    if (!usbPrinter) return;

    if (!isUsbOwnerRef.current) {
      try {
        await delegatePrintJob("", true);
      } catch (err) {
        console.warn("[Printer] Delegated drawer open failed:", err);
      }
      return;
    }

    await usbQueue.add(async () => {
      busyRef.current = true;
      try {
        await ensurePrinterReady(usbPrinter);
        const { outEndpoint } = getEndpoints(usbPrinter);
        if (!outEndpoint) throw new Error("No output endpoint for drawer kick");
        const drawerCmd = new Uint8Array([0x1b, 0x70, 0x00, 0x19, 0xfa]);
        await withTimeout(
          usbPrinter.transferOut(outEndpoint.endpointNumber, drawerCmd),
          TRANSFER_TIMEOUT
        );
        await sleep(DRAWER_SETTLE_DELAY);
      } catch (err) {
        console.warn("[Printer] openDrawer failed:", err);
        await reconnectPrinter(usbPrinter);
      } finally {
        busyRef.current = false;
      }
    });
  };

  // ─── PRINT ────────────────────────────

  const printDirect = async (text: string, kickDrawer = false) => {
    if (!usbPrinter) {
      pendingPrintQueue.current.push({ text, kickDrawer });
      const { previewReceiptText } = await import("@/src/libs/ReceiptPrinting");
      previewReceiptText(text);
      return;
    }

    if (isUsbOwnerRef.current) {
      await printDirectWithDevice(usbPrinter, text, kickDrawer);
      return;
    }

    // Delegate to the tab that owns the USB claim
    try {
      await delegatePrintJob(text, kickDrawer);
      console.log("[Printer] Print delegated to owning tab successfully.");
    } catch (delegateErr) {
      console.warn("[Printer] Delegation failed, falling back to preview:", delegateErr);
      const { previewReceiptText } = await import("@/src/libs/ReceiptPrinting");
      previewReceiptText(text);
    }
  };

  // ─── MANUAL STATUS CHECK ──────────────

  const checkStatusNow = async () => {
    sileo.promise(
      new Promise<void>((resolve) => setTimeout(resolve, 800)),
      {
        loading: {
          title: "Checking Till Status...",
          fill: "#171717",
          styles: { title: "text-white!", description: "text-white/75!" },
        },
        success: {
          title: `Till is ${tillStatus}`,
          fill: "#171717",
          styles: { title: "text-white!", description: "text-white/75!" },
        },
        error: {
          title: "Status check failed",
          fill: "#171717",
          styles: { title: "text-white!", description: "text-white/75!" },
        },
      }
    );
  };

  // ─── PROVIDER ─────────────────────────

  return (
    <PrinterContext.Provider
      value={{ usbPrinter, tillStatus, pairPrinter, unpairPrinter, openDrawer, printDirect, checkStatusNow }}
    >
      {children}
    </PrinterContext.Provider>
  );
}

export function usePrinter() {
  const context = useContext(PrinterContext);
  if (!context) throw new Error("usePrinter must be used within PrinterProvider");
  return context;
}