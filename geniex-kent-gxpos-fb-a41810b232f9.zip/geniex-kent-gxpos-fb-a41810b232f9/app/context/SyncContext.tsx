'use client';
import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';

type SyncStatus = 'idle' | 'syncing' | 'error';

interface SyncContextValue {
  syncNow: () => void;
  status: SyncStatus;
  lastSyncedAt: Date | null;
  pendingCount: number | null;
}

const SyncContext = createContext<SyncContextValue>({
  syncNow: () => {},
  status: 'idle',
  lastSyncedAt: null,
  pendingCount: null,
});

export const useSyncContext = () => useContext(SyncContext);

const SYNC_INTERVAL_MS = 2 * 60 * 1000; // 2 min polling as safety net

export function SyncProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus]           = useState<SyncStatus>('idle');
  const [lastSyncedAt, setLastSyncedAt] = useState<Date | null>(null);
  const [pendingCount, setPendingCount] = useState<number | null>(null);
  const isSyncingRef = useRef(false);

  const syncNow = useCallback(async () => {
    if (isSyncingRef.current) return; // prevent overlapping calls
    isSyncingRef.current = true;
    setStatus('syncing');

    try {
      const res  = await fetch('/api/cms-sync', { method: 'POST' });
      const data = await res.json();

      setStatus('idle');
      setLastSyncedAt(new Date());

      // track how many are still waiting
      if (typeof data.total === 'number' && typeof data.synced === 'number') {
        setPendingCount(data.failed ?? 0);
      }
    } catch {
      setStatus('error');
    } finally {
      isSyncingRef.current = false;
    }
  }, []);

  // safety-net polling
  useEffect(() => {
    const interval = setInterval(syncNow, SYNC_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [syncNow]);

  // sync immediately when internet comes back
  useEffect(() => {
    window.addEventListener('online', syncNow);
    return () => window.removeEventListener('online', syncNow);
  }, [syncNow]);

  return (
    <SyncContext.Provider value={{ syncNow, status, lastSyncedAt, pendingCount }}>
      {children}
    </SyncContext.Provider>
  );
}