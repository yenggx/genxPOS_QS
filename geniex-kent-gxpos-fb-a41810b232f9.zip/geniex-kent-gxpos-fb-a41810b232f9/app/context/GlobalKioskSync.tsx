// src/components/GlobalKioskSync.tsx
'use client';
import { useEffect, useRef } from 'react';
import { getWorkstationId } from "@/src/lib/workstation";
import { formatTransactionPayload, saveTransaction } from '@/src/api/transactions';
import { getMenuFromCache } from '@/src/api/menu';

export default function GlobalKioskSync() {
  const processingRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    let isMounted = true;

    const processNonCashOrder = async (order: any, paymentType: string, sessionData: any, businessDate?: string) => {
      if (processingRef.current.has(order.order_id)) return;
      processingRef.current.add(order.order_id);

      try {
        let detail: any = {};
        try {
          detail = typeof order.orderDetailJSON === 'string' 
            ? JSON.parse(order.orderDetailJSON) 
            : (order.orderDetailJSON || {});
        } catch (e) {}

        const itemsList = detail.items || order.items || [];

        // Fetch menu to enrich missing names from the Kiosk payload
        let flatMenu: any[] = [];
        try {
          const menuRecord = await getMenuFromCache();
          if (menuRecord?.categories) {
            menuRecord.categories.forEach((cat: any) => {
              flatMenu = flatMenu.concat(cat.items || []);
              (cat.subcategories || []).forEach((sub: any) => { flatMenu = flatMenu.concat(sub.items || []); });
            });
          }
        } catch (e) {
          console.warn('Could not fetch menu for enrichment:', e);
        }
        
        const workstationId = getWorkstationId() || '001';
        let storeData: any = {};
        try { storeData = JSON.parse(localStorage.getItem("store_data") || "{}"); } catch {}
        const seriesType = storeData?.series_type || 'WS';

        const countersRes = await fetch('/api/numbers?type=generateAll', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ workstationId, seriesType, skipOrderNumber: true })
        });
        
        if (!countersRes.ok) throw new Error("Failed to fetch counters");
        const counters = await countersRes.json();

        let rawTotal = Number(order.total_amount || detail.price?.eaterPayment || 0) / 100;
        if (rawTotal === 0) rawTotal = Number(order.subtotal_amount || detail.price?.subtotal || 0) / 100;
        const netPrice = rawTotal / 1.12;
        const vatAmount = rawTotal - netPrice;

        const cart = itemsList.map((item: any) => {
          const itemPrice = (typeof item.price === 'number' ? item.price : Number(item.price || 0)) / 100;
          const blueprint = flatMenu.find(m => m.id === (item.id || item.itemId)) || {};
          const itemName = item.itemName || item.name || blueprint.name || 'Unknown Item';

          return {
            id: item.id || item.itemId,
            name: itemName,
            price: itemPrice > 0 ? itemPrice : 0,
            qty: item.quantity || item.qty || 1,
            modifiers: Array.isArray(item.modifiers) ? item.modifiers.map((m: any) => {
              let exactMod = null;
              const cleanModId = String(m.id || '').split('|').pop() || ''; // Extract 'CLASSIC-5' from 'MD-0|CLASSIC-5'

              if (blueprint.modifierGroups) {
                for (const group of blueprint.modifierGroups) {
                  if (group.modifiers) {
                    for (const gm of group.modifiers) {
                      if (gm.id === m.id || gm.id === cleanModId || gm.name === m.name) {
                        exactMod = gm;
                        break;
                      }
                    }
                  }
                  if (exactMod) break;
                }
              }

              // Fallback to searching the entire flat menu if not found in modifier groups
              if (!exactMod && cleanModId) {
                exactMod = flatMenu.find(menuItem => menuItem.id === cleanModId || menuItem.id === `IT-${cleanModId}`);
              }

              const modName = m.modifiersName || m.modifierName || (m.name ? m.name : null) || exactMod?.name || 'Unknown Modifier';

              return {
                ...m,
                name: modName,
                price: (typeof m.price === 'number' ? m.price : Number(m.price || 0)) / 100,
                qty: m.quantity || m.qty || 1
              };
            }) : []
          };
        });

        const payments = [{ method: paymentType, amount: rawTotal, refCode: 'KIOSK-AUTO' }];

        const orderType = detail.ordertype || detail.orderType || order.order_type || 'TakeOut';
        const kioskOrderNo = (detail.KioskNo && detail.OrderNo) 
          ? `${String(detail.KioskNo).padEnd(2, '0')}${String(detail.OrderNo).padStart(2, '0')}` 
          : String(order.order_number || detail.OrderNo || order.short_order_number || order.order_id);

        const txnPayload = formatTransactionPayload({
          orderNumber: kioskOrderNo, 
          salesNumber: counters.salesNumber,
          transactionNumber: counters.transactionNumber,          
          cart,
          payments,
          subtotal: rawTotal, 
          tax: vatAmount, 
          vatableSales: netPrice, 
          vatExemptSales: 0, 
          zeroRatedSales: 0,
          transactionType: 'REGULAR', 
          appliedDiscount: null, 
          discountInfo: null, 
          discountAmount: 0,
          staffId: sessionData?.staffId || 'KIOSK', 
          sessionId: sessionData?.sessionId, 
          guests: [], 
          shiftNo: parseInt(sessionData?.shiftNumber || '1'), 
          cashierName: sessionData?.staffName || 'AUTO-KIOSK',
          kioskOrderId: order.order_id
        });
        txnPayload.featureFlags = { ...(txnPayload.featureFlags || {}), orderType };

        await saveTransaction(txnPayload);

        await fetch('/api/kiosk-orders', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderId: order.order_id, salesNumber: counters.salesNumber, businessDate })
        });

        console.log(`[Auto-Process] Successfully processed non-cash kiosk order: ${order.order_id}`);
      } catch (err) {
        console.error(`[Auto-Process] Failed to process order ${order.order_id}:`, err);
        processingRef.current.delete(order.order_id); 
      }
    };

    const runSyncCycle = async () => {
      if (!isMounted) return;

      try {
        // 1. Ask the Database gatekeeper if we are allowed to sync
        const lockRes = await fetch('/api/sync-lock', { method: 'POST' });
        const lockData = await lockRes.json();
        
        // If another terminal just synced, quietly stop and wait for the next tick
        if (!lockData.canFetch) {
          return; 
        }

        // 2. We got the green light! Fetch the orders.
        const res = await fetch('/api/kiosk-orders');
        if (res.ok) {
          const json = await res.json();
          
          let ordersData: any[] = [];
          if (Array.isArray(json.data)) {
            ordersData = json.data;
          } else if (json.data && typeof json.data === 'object') {
            ordersData = [json.data];
          }

          const ordersToProcess = ordersData.filter(order => {
            let detail: any = {};
            try {
              detail = typeof order.orderDetailJSON === 'string' 
                ? JSON.parse(order.orderDetailJSON) 
                : (order.orderDetailJSON || {});
            } catch (e) {}
            const paymentType = (order.payment_type || detail.paymentType || 'CASH').toUpperCase();
            return order.status === 'ACTIVE' && paymentType !== 'CASH';
          });

          if (ordersToProcess.length > 0) {
            let sessionData: any = null;
            let businessDate: string | undefined = undefined;
            const sessionRes = await fetch('/api/cashier-session');
            
            if (sessionRes.ok) {
               const parsedSession = await sessionRes.json();
               if (parsedSession.active && parsedSession.session) {
                 sessionData = parsedSession.session;
               }
               businessDate = parsedSession.businessDayDate || parsedSession.businessDate;
            }

            for (const order of ordersToProcess) {
              let detail: any = {};
              try {
                detail = typeof order.orderDetailJSON === 'string' 
                  ? JSON.parse(order.orderDetailJSON) 
                  : (order.orderDetailJSON || {});
              } catch (e) {}
              
              const paymentType = (order.payment_type || detail.paymentType || 'CASH').toUpperCase();
              await processNonCashOrder(order, paymentType, sessionData, businessDate);
            }
          }
          
          window.dispatchEvent(new CustomEvent('kiosk-orders-updated'));
        }
      } catch (error) {
        console.warn('Background sync error:', error);
      } finally {
        // Schedule the next execution exactly 10s after this one finishes
        if (isMounted) {
          timeoutId = setTimeout(runSyncCycle, 10000);
        }
      }
    };

    runSyncCycle();

    return () => {
      isMounted = false;
      clearTimeout(timeoutId);
    };
  }, []);

  return null;
}