'use client';
import { createContext, useContext, useEffect, useState } from 'react';
import { checkConnection } from '@/src/api/connectionCheck';

const ConnectionContext = createContext(true);

// ---- Module-level singleton (shared across the whole tab/POS) ----
let isOnline = true;
let intervalId: ReturnType<typeof setInterval> | null = null;
let inFlightCheck: Promise<boolean> | null = null;
let refCount = 0;
const subscribers = new Set<(online: boolean) => void>();

async function runCheck() {
  // If a check is already in progress, don't start another —
  // just let everyone piggyback on the same result.
  if (inFlightCheck) return inFlightCheck;

  inFlightCheck = checkConnection()
    .then((online) => {
      isOnline = online;
      subscribers.forEach((cb) => cb(online));
      return online;
    })
    .finally(() => {
      inFlightCheck = null;
    });

  return inFlightCheck;
}

function subscribe(cb: (online: boolean) => void) {
  subscribers.add(cb);
  refCount++;

  // Only the FIRST mount on this POS starts the loop.
  if (refCount === 1) {
    runCheck();
    intervalId = setInterval(runCheck, 600000);
  }

  return () => {
    subscribers.delete(cb);
    refCount--;

    // Only the LAST unmount tears the loop down.
    if (refCount === 0 && intervalId) {
      clearInterval(intervalId);
      intervalId = null;
    }
  };
}
// --------------------------------------------------------------

export function ConnectionProvider({ children }: { children: React.ReactNode }) {
  const [online, setOnline] = useState(isOnline);

  useEffect(() => {
    setOnline(isOnline); // sync in case a check already ran before this mount
    const unsubscribe = subscribe(setOnline);
    return unsubscribe;
  }, []);

  return (
    <ConnectionContext.Provider value={online}>
      {children}
    </ConnectionContext.Provider>
  );
}

export const useConnection = () => useContext(ConnectionContext);