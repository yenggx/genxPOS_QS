'use client';
import { useEffect, useState, useRef } from 'react';
import { Utensils, CheckCircle, ShoppingBag, Bell } from 'lucide-react';
import { FiClock } from 'react-icons/fi';

type Order = {
  _id: string;
  OrderNo: string;
  orderTime: string;
  kitchenState: 'PREPARING' | 'READY';
  updatedAt?: string;
};

function LiveClock() {
  const [time, setTime] = useState('');
  useEffect(() => {
    const tick = () => setTime(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 18, fontWeight: 800, color: '#64748b', fontFamily: 'Poppins', letterSpacing: 1, background: 'rgba(0,0,0,0.03)', padding: '6px 12px', borderRadius: 10 }}>
      <FiClock size={14} />
      <span>{time}</span>
    </div>
  );
}

export default function CDSPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const prevReadyOrdersRef = useRef<Set<string>>(new Set());
  const [latestReadyId, setLatestReadyId] = useState<string | null>(null);

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/kds');
      const data = await res.json();
      if (data.success) {
        setOrders(data.orders);
      }
    } catch (err) {
      console.error('Failed to fetch CDS orders:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
    const interval = setInterval(fetchOrders, 3000);
    return () => clearInterval(interval);
  }, []);

  const preparingOrders = orders.filter(o => o.kitchenState === 'PREPARING').slice(0, 30);
  
  const readyOrders = orders
    .filter(o => o.kitchenState === 'READY')
    .sort((a, b) => new Date(b.updatedAt || b.orderTime).getTime() - new Date(a.updatedAt || a.orderTime).getTime())
    .slice(0, 30);

  useEffect(() => {
    const currentReadyIds = new Set(readyOrders.map(o => o._id));
    const newlyReady = readyOrders.filter(o => !prevReadyOrdersRef.current.has(o._id));
    
    if (newlyReady.length > 0) {
      setLatestReadyId(newlyReady[0]._id);
      setTimeout(() => setLatestReadyId(null), 8000);
    }
    
    prevReadyOrdersRef.current = currentReadyIds;
  }, [readyOrders]);

  if (loading && orders.length === 0) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
          <div className="text-lg font-black text-slate-800 tracking-widest uppercase font-poppins">
            Loading Display...
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes popIn {
          0% { opacity: 0; transform: scale(0.8) translateY(20px); }
          70% { transform: scale(1.05) translateY(-5px); }
          100% { opacity: 1; transform: scale(1) translateY(0); }
        }
        @keyframes pulseGlow {
          0% { box-shadow: 0 0 0 0 rgba(255, 255, 255, 0.7), inset 0 0 15px rgba(249, 115, 22, 0.2); }
          70% { box-shadow: 0 0 0 15px rgba(255, 255, 255, 0), inset 0 0 8px rgba(249, 115, 22, 0); }
          100% { box-shadow: 0 0 0 0 rgba(255, 255, 255, 0), inset 0 0 0 rgba(249, 115, 22, 0); }
        }
        @keyframes float {
          0% { transform: translateY(0px); }
          50% { transform: translateY(-8px); }
          100% { transform: translateY(0px); }
        }
        .animate-pop-in {
          animation: popIn 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          opacity: 0;
        }
        .animate-float {
          animation: float 4s ease-in-out infinite;
        }
        .animate-pulse-glow {
          animation: pulseGlow 2s infinite;
        }
        .hide-scroll::-webkit-scrollbar { display: none; }
        .hide-scroll { -ms-overflow-style: none; scrollbar-width: none; }
      `}} />

      <div className="min-h-screen h-screen flex flex-col bg-white overflow-hidden select-none font-poppins">
        
        <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 24px', background: 'rgba(255,255,255,0.8)', backdropFilter: 'blur(20px)', borderBottom: `1px solid rgba(255, 255, 255, 0.8)`, flexShrink: 0, gap: 16, zIndex: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <img src="/images/logo.svg" alt="Brand Logo" style={{ height: 36, width: 'auto', objectFit: 'contain' }} />
            <div style={{ width: 2, height: 24, background: 'rgba(0,0,0,0.1)', borderRadius: 1 }} />
            <span style={{ fontSize: 15, fontWeight: 900, color: '#64748b', letterSpacing: 1.5, textTransform: 'uppercase', fontFamily: 'Poppins', marginTop: 2 }}>
              Customer Display
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <LiveClock />
          </div>
        </header>

        <div className="flex-1 flex overflow-hidden bg-slate-50">
          
          <div className="w-1/3 h-full flex flex-col border-r border-slate-200 relative bg-white">
            <div className="py-4 text-center bg-slate-50 border-b border-slate-200 shadow-sm z-10 flex-shrink-0">
              <div className="flex items-center justify-center gap-2">
                <Utensils size={20} className="text-slate-400" />
                <h2 className="text-xl font-black text-slate-700 uppercase tracking-widest">
                  Preparing
                </h2>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 hide-scroll relative">
              {preparingOrders.length > 0 ? (
                <div className="grid grid-cols-4 2xl:grid-cols-5 gap-3 auto-rows-max">
                  {preparingOrders.map((order, idx) => (
                    <div 
                      key={order._id} 
                      className="bg-slate-100 rounded-xl py-4 flex items-center justify-center border border-slate-200 animate-pop-in"
                      style={{ animationDelay: `${idx * 0.03}s` }}
                    >
                      <span className="text-2xl lg:text-3xl font-black text-slate-600 tracking-tighter" style={{ fontFamily: "Impact, Arial Black, sans-serif" }}>
                        {order.OrderNo}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center opacity-30 animate-float text-slate-400">
                  <ShoppingBag size={48} strokeWidth={1.5} className="mb-3" />
                  <span className="text-base font-bold tracking-widest uppercase">Awaiting Orders</span>
                </div>
              )}
            </div>
          </div>

          <div className="w-2/3 h-full flex flex-col relative" style={{ background: "linear-gradient(135deg, #f97316 0%, #ea580c 100%)" }}>
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 mix-blend-overlay pointer-events-none"></div>
            
            <div className="py-4 text-center bg-black/10 shadow-[0_4px_20px_rgba(0,0,0,0.1)] z-10 backdrop-blur-sm border-b border-white/10 flex-shrink-0">
              <div className="flex items-center justify-center gap-2">
                <CheckCircle size={24} className="text-white drop-shadow-md" />
                <h2 className="text-2xl font-black text-white uppercase tracking-widest drop-shadow-md">
                  Please Collect
                </h2>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-5 hide-scroll relative z-10 flex flex-col">
              {readyOrders.length > 0 ? (
                <div className="grid grid-cols-5 2xl:grid-cols-6 gap-4 auto-rows-max">
                  {readyOrders.map((order, idx) => (
                    <div 
                      key={order._id} 
                      className={`bg-white rounded-2xl py-6 flex items-center justify-center shadow-lg relative overflow-hidden border-[3px] border-white
                        ${latestReadyId === order._id ? 'animate-pulse-glow' : 'animate-pop-in'}`}
                      style={{ boxShadow: "0 10px 25px rgba(0,0,0,0.15)", animationDelay: `${idx * 0.05}s` }}
                    >
                      <div className="absolute inset-0 bg-gradient-to-tr from-orange-50 to-transparent opacity-80"></div>
                      <span className="font-black text-orange-600 tracking-tighter drop-shadow-sm relative z-10 text-4xl md:text-5xl" style={{ fontFamily: "Impact, Arial Black, sans-serif", lineHeight: 1 }}>
                        {order.OrderNo}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center opacity-60 animate-float text-white">
                  <Bell size={56} strokeWidth={1.5} className="mb-4 drop-shadow-md" />
                  <span className="text-xl font-black tracking-widest uppercase drop-shadow-md">Ready orders will appear here</span>
                </div>
              )}
            </div>
          </div>

        </div>
      </div>
    </>
  );
}