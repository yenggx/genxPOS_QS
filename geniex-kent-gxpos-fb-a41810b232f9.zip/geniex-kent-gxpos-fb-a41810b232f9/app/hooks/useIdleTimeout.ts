import { useEffect, useRef } from "react";
import { useRouter } from "next/navigation";

const IDLE_TIMEOUT = 300000; // 5 minutes in milliseconds

export function useIdleTimeout() {
  const router = useRouter();
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const resetTimeout = () => {
    // Clear existing timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    // Set new timeout for idle screen
    timeoutRef.current = setTimeout(() => {
      // Clear session/logout
      localStorage.removeItem("authToken");
      localStorage.removeItem("userSession");
      localStorage.removeItem("cashierInfo");
      
      // Navigate to idle screen
      window.dispatchEvent(new Event('trigger-lock')); // to show the lock
    }, IDLE_TIMEOUT);
  };

  useEffect(() => {
    // Reset timeout on user activity
    const handleActivity = () => {
      resetTimeout();
    };

    // Track various user interactions
    window.addEventListener("click", handleActivity);
    window.addEventListener("keydown", handleActivity);
    window.addEventListener("mousemove", handleActivity);
    window.addEventListener("touchstart", handleActivity);

    // Initial timeout
    resetTimeout();

    return () => {
      // Cleanup
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      window.removeEventListener("click", handleActivity);
      window.removeEventListener("keydown", handleActivity);
      window.removeEventListener("mousemove", handleActivity);
      window.removeEventListener("touchstart", handleActivity);
    };
  }, [router]);
}
