//solo-discount-tracker
import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';

export const dynamic = 'force-dynamic';

// ── helpers ──────────────────────────────────────────────────────────────────

function getWindowBounds(resetTiming: 'weekly' | 'monthly'): { start: Date; end: Date } {
  const now = new Date();

  if (resetTiming === 'weekly') {
    // Window: last Sunday 00:00:00 → next Saturday 23:59:59
    const day = now.getDay(); // 0 = Sun
    const sunday = new Date(now);
    sunday.setDate(now.getDate() - day);
    sunday.setHours(0, 0, 0, 0);

    const saturday = new Date(sunday);
    saturday.setDate(sunday.getDate() + 6);
    saturday.setHours(23, 59, 59, 999);

    return { start: sunday, end: saturday };
  }

  // monthly — 1st of this month → last ms of last day
  const start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
  const end   = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
  return { start, end };
}

// ── GET /api/solo-discount-tracker?idNum=XXX ─────────────────────────────────
// Returns { totalDiscountUsed, limit, remaining, resetTiming, windowStart, windowEnd }
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const idNum = (searchParams.get('idNum') || '').trim();

    if (!idNum) {
      return NextResponse.json({ error: 'idNum is required' }, { status: 400 });
    }

    const db  = await getDatabase();

    // Pull settings for limit + reset timing
    const settings = await db.collection('workstation_config')
      .findOne({ settingsId: 'global' });

    const limit        = Number(settings?.soloParentLimit  ?? 0);
    const resetTiming  = (settings?.soloParentReset === 'weekly' ? 'weekly' : 'monthly') as 'weekly' | 'monthly';

    const { start, end } = getWindowBounds(resetTiming);

    // Sum all SOLO discount amounts for this ID within the current window
    const records = await db.collection('solo_discount_tracker')
      .find({
        idNum,
        usedAt: { $gte: start, $lte: end },
      })
      .toArray();

    const totalDiscountUsed = records.reduce((s: number, r: any) => s + (r.discountAmount || 0), 0);
    const remaining = limit > 0 ? Math.max(0, limit - totalDiscountUsed) : Infinity;

    return NextResponse.json({
      idNum,
      totalDiscountUsed,
      limit,
      remaining,
      resetTiming,
      windowStart: start.toISOString(),
      windowEnd:   end.toISOString(),
    });
  } catch (err) {
    console.error('[SoloTracker] GET error:', err);
    return NextResponse.json({ error: 'Failed to fetch tracker' }, { status: 500 });
  }
}

// ── POST /api/solo-discount-tracker ──────────────────────────────────────────
// Body: { idNum, customerName, discountAmount }
// Saves a new usage record. Call this AFTER the transaction is confirmed.
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const idNum          = (body.idNum          || '').trim();
    const customerName   = (body.customerName   || '').trim();
    const discountAmount = Number(body.discountAmount ?? 0);

    if (!idNum || discountAmount <= 0) {
      return NextResponse.json({ error: 'idNum and discountAmount are required' }, { status: 400 });
    }

    const db  = await getDatabase();

    await db.collection('solo_discount_tracker').insertOne({
      idNum,
      customerName,
      discountAmount,
      usedAt: new Date(),
    });

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error('[SoloTracker] POST error:', err);
    return NextResponse.json({ error: 'Failed to record usage' }, { status: 500 });
  }
}