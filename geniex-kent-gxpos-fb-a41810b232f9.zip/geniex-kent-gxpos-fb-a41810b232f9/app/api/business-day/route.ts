// app/api/business-day/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase } from '@/src/lib/mongodb-utils';

export const dynamic = 'force-dynamic';

// ─── GET: return business day by date (or current open one) ───────────────────
export async function GET(request: NextRequest) {
  await initializeDatabase().catch((err: unknown) => console.error('DB init error:', err));

  try {
    const db = await getDatabase();
    const businessDaysCollection = db.collection('businessDays');

    const { searchParams } = new URL(request.url);
    const dateParam = searchParams.get('date'); // e.g. "2026-06-09"

    if (dateParam) {
      // Find the business day whose `date` field matches, regardless of status.
      // Also try matching by the calendar date of openedAt as a fallback for
      // older records that may not have a `date` field stored.
      const byDate = await businessDaysCollection.findOne(
        { date: dateParam },
        { projection: { _id: 0, businessDayId: 1, status: 1, openedAt: 1, date: 1, eodLocked: 1, lockedBy: 1, completedTerminals: 1 } }
      );

      if (byDate) {
        return NextResponse.json({ businessDay: byDate }, { status: 200 });
      }

      // Fallback: match by openedAt calendar date (handles legacy docs without `date` field)
      const dayStart = `${dateParam}T00:00:00.000Z`;
      const dayEnd   = `${dateParam}T23:59:59.999Z`;
      const byOpenedAt = await businessDaysCollection.findOne(
        { openedAt: { $gte: dayStart, $lte: dayEnd } },
        { projection: { _id: 0, businessDayId: 1, status: 1, openedAt: 1, date: 1, eodLocked: 1, lockedBy: 1, completedTerminals: 1 } }
      );

      return NextResponse.json({ businessDay: byOpenedAt || null }, { status: 200 });
    }

    // No date param → return current open business day (original behaviour)
    const activeBusinessDay = await businessDaysCollection.findOne(
      { status: 'open' },
      { projection: { _id: 0, businessDayId: 1, status: 1, openedAt: 1, date: 1, eodLocked: 1, lockedBy: 1, lockedAt: 1, completedTerminals: 1 } }
    );

    return NextResponse.json({ businessDay: activeBusinessDay || null }, { status: 200 });
  } catch (error) {
    console.error('Business Day GET error:', error);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

// ─── PATCH: acquireLock | releaseLock | close ──────────────────────────────
export async function PATCH(request: NextRequest) {
  await initializeDatabase().catch((err: unknown) => console.error('DB init error:', err));

  try {
    const db = await getDatabase();
    const businessDaysCollection = db.collection('businessDays');
    const body = await request.json().catch(() => ({}));
    const action = body?.action as string | undefined;

    // ── Atomically acquire the EOD lock ──────────────────────────────────
    if (action === 'acquireLock') {
      const { terminalId } = body;
      if (!terminalId) {
        return NextResponse.json({ error: 'terminalId required' }, { status: 400 });
      }

      const LOCK_TTL_MS = 5 * 60 * 1000;
      const staleThreshold = new Date(Date.now() - LOCK_TTL_MS).toISOString();

      const result = await businessDaysCollection.findOneAndUpdate(
        {
          status: 'open',
          $or: [
            { eodLocked: { $ne: true } },
            { eodLocked: true, lockedAt: { $lt: staleThreshold } },
          ],
        },
        {
          $set: {
            eodLocked: true,
            lockedBy: terminalId,
            lockedAt: new Date().toISOString(),
          },
        },
        { returnDocument: 'after' }
      );

      if (!result) {
        const current = await businessDaysCollection.findOne({ status: 'open' });
        return NextResponse.json(
          { acquired: false, lockedBy: current?.lockedBy || 'another terminal' },
          { status: 409 }
        );
      }

      return NextResponse.json({ acquired: true, businessDayId: result.businessDayId }, { status: 200 });
    }

    // ── Release the EOD lock ─────────────────────────────────────────────
    if (action === 'releaseLock') {
      const { terminalId } = body;
      await businessDaysCollection.updateOne(
        { status: 'open', lockedBy: terminalId },
        { $set: { eodLocked: false }, $unset: { lockedBy: '', lockedAt: '' } }
      );
      return NextResponse.json({ released: true }, { status: 200 });
    }

    // ── Mark Terminal EOD Complete ──────────────────────────────────────
    if (action === 'completeTerminalEOD') {
      const { terminalId } = body;
      if (!terminalId) return NextResponse.json({ error: 'terminalId required' }, { status: 400 });

      const activeBusinessDay = await businessDaysCollection.findOne({ status: 'open' });
      if (!activeBusinessDay) return NextResponse.json({ error: 'No active business day' }, { status: 404 });

      await businessDaysCollection.updateOne(
        { _id: activeBusinessDay._id },
        { $addToSet: { completedTerminals: terminalId } }
      );
      return NextResponse.json({ success: true }, { status: 200 });
    }

    // ── Close the business day ──────────────────────────────────────────
    const activeBusinessDay = await businessDaysCollection.findOne({ status: 'open' });

    if (!activeBusinessDay) {
      return NextResponse.json({ error: 'No active business day to close' }, { status: 404 });
    }

    const closedAt = new Date().toISOString();

    await businessDaysCollection.updateOne(
      { _id: activeBusinessDay._id },
      {
        $set: { status: 'closed', closedAt, eodLocked: false },
        $unset: { lockedBy: '', lockedAt: '' },
      }
    );

    const closedDayDate = new Date(activeBusinessDay.openedAt ?? closedAt);
    const nextDayDate   = new Date(closedDayDate);
    nextDayDate.setDate(nextDayDate.getDate() + 1);
    nextDayDate.setHours(0, 0, 0, 0);

    const localDateStr = `${nextDayDate.getFullYear()}-${String(nextDayDate.getMonth() + 1).padStart(2, '0')}-${String(nextDayDate.getDate()).padStart(2, '0')}`;

    await businessDaysCollection.insertOne({
      businessDayId: `BD_${nextDayDate.getTime()}`,
      status:        'open',
      openedAt:      nextDayDate.toISOString(),
      date:          localDateStr,
      completedTerminals: [],
    });

    return NextResponse.json(
      { success: true, businessDayId: activeBusinessDay.businessDayId },
      { status: 200 }
    );

  } catch (error) {
    console.error('Business Day PATCH error:', error);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}