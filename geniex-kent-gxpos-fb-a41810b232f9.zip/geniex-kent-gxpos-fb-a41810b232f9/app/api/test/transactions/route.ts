import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { COLLECTIONS } from '@/src/lib/mongodb-utils';

export const dynamic = 'force-dynamic';

/**
 * GET /api/test/transactions
 * Test endpoint - shows all transactions in database
 */
export async function GET(request: NextRequest) {
  try {
    const db = await getDatabase();
    const transactionsCollection = db.collection(COLLECTIONS.TRANSACTIONS);

    const allTransactions = await transactionsCollection
      .find({})
      .sort({ createdAt: -1 })
      .limit(20)
      .toArray();

    const total = await transactionsCollection.countDocuments();

    console.log('[TEST] Found', total, 'transactions total,', allTransactions.length, 'recent');

    return NextResponse.json({
      success: true,
      total,
      recent: allTransactions.length,
      transactions: allTransactions.map(t => ({
        _id: t._id,
        OrderNo: t.OrderNo,
        orderNumber: t.orderNumber,
        items: Array.isArray(t.items) ? t.items.length : 0,
        total: t.price?.eaterPayment ? t.price.eaterPayment / 100 : 0,
        createdAt: t.createdAt,
        isSynced: t.isSynced,
      })),
    });
  } catch (error) {
    console.error('[TEST] Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Server error',
      },
      { status: 500 }
    );
  }
}
