import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { exec } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import puppeteer from 'puppeteer';
import { getWorkstationId } from '@/src/lib/workstation';

const execAsync = promisify(exec);

/**
 * POST /api/print - Send receipt directly to printer
 * Uses system print commands (lp on macOS/Linux, print on Windows)
 */

export async function POST(request: NextRequest) {
  let tempFile: string | null = null;
  
  try {
    const body = await request.json();
    const { html, workstationId = getWorkstationId() || '001', printerName } = body;
    
    if (!html) {
      return NextResponse.json({
        success: false,
        error: 'Missing receipt HTML'
      }, { status: 400 });
    }
    
    if (!printerName) {
      return NextResponse.json({
        success: false,
        error: 'Missing printer name'
      }, { status: 400 });
    }
    
    const db = await getDatabase();
    
    console.log(`[Print API] Printing to ${printerName} (WS: ${workstationId})`);
    
    // Create temporary file (HTML for macOS/Linux, plain text for Windows)
    const tmpDir = os.tmpdir();
    const timestamp = Date.now();
    const platform = process.platform;
    let printCommand = '';
    let tempContent = '';
    let tempExt = '.txt';

    if (platform === 'win32') {
      // Windows - use Puppeteer to generate PDF, then print via PowerShell
      console.log(`[Print API] Using Puppeteer for Windows PDF printing`);
      tempContent = `\n<!DOCTYPE html>\n<html>\n<head>\n  <style>\n    @media print { body { margin: 0; padding: 0; } * { margin: 0; padding: 0; } }\n    body { font-family: 'Courier New', monospace; }\n  </style>\n</head>\n<body>\n${html}\n</body>\n</html>\n`;
      const pdfPath = path.join(tmpDir, `receipt-${timestamp}.pdf`);
      const browser = await puppeteer.launch({ headless: "new" });
      const page = await browser.newPage();
      await page.setContent(tempContent, { waitUntil: 'networkidle0' });
      await page.pdf({ path: pdfPath, format: 'A4', printBackground: true, margin: { top: '10mm', bottom: '10mm', left: '5mm', right: '5mm' } });
      await browser.close();
      printCommand = `powershell.exe Start-Process -FilePath "${pdfPath}" -Verb Print -Wait`;
      console.log(`[Print API] Printing PDF via PowerShell: ${printCommand}`);
      const { stdout, stderr } = await execAsync(printCommand, { timeout: 10000 });
      const output = stdout + stderr;
      console.log(`[Print API] ✓ Print command succeeded`);
      console.log(`[Print API] Output: ${output}`);
      // Log successful print
      await db.collection('print_jobs').insertOne({
        workstationId,
        printerName,
        status: 'printed',
        platform,
        command: printCommand,
        timestamp: new Date(),
        createdAt: new Date()
      });
      return NextResponse.json({
        success: true,
        message: `Receipt sent to printer: ${printerName}`,
        printer: printerName,
        workstationId
      });
    } else {
      // Use HTML for macOS/Linux
      tempContent = `\n<!DOCTYPE html>\n<html>\n<head>\n  <style>\n    @media print { body { margin: 0; padding: 0; } * { margin: 0; padding: 0; } }\n    body { font-family: 'Courier New', monospace; }\n  </style>\n</head>\n<body>\n${html}\n</body>\n</html>\n`;
      tempFile = path.join(tmpDir, `receipt-${timestamp}.html`);
      await fs.promises.writeFile(tempFile, tempContent, 'utf-8');
      console.log(`[Print API] Created temporary file: ${tempFile}`);

      try {
        if (platform === 'darwin') {
          // macOS - use lp command with localhost
          printCommand = `lp -d "${printerName}" "${tempFile}"`;
          console.log(`[Print API] Executing macOS print: ${printCommand}`);
        } else if (platform === 'linux') {
          // Linux - use lp command
          printCommand = `lp -d "${printerName}" "${tempFile}"`;
          console.log(`[Print API] Executing Linux print: ${printCommand}`);
        } else if (platform === 'win32') {
          // Windows - use Puppeteer for fully automatic HTML printing
          console.log(`[Print API] Using Puppeteer for Windows HTML printing`);
          const browser = await puppeteer.launch({ headless: "new" });
          const page = await browser.newPage();
          await page.setContent(tempContent, { waitUntil: 'networkidle0' });
          await page.evaluate(() => window.print());
          await browser.close();
          printCommand = 'puppeteer.print';
          console.log(`[Print API] Puppeteer print command executed`);
        }

        // Execute print command
        const { stdout, stderr } = await execAsync(printCommand, { timeout: 5000 });
        const output = stdout + stderr;

        console.log(`[Print API] ✓ Print command succeeded`);
        console.log(`[Print API] Output: ${output}`);

        // Log successful print
        await db.collection('print_jobs').insertOne({
          workstationId,
          printerName,
          status: 'printed',
          platform,
          command: printCommand,
          timestamp: new Date(),
          createdAt: new Date()
        });

        return NextResponse.json({
          success: true,
          message: `Receipt sent to printer: ${printerName}`,
          printer: printerName,
          workstationId
        });

      } catch (execError) {
        const errorMsg = execError instanceof Error ? execError.message : String(execError);
        console.error(`[Print API] ✗ Print command failed: ${printCommand}`);
        console.error(`[Print API] Error: ${errorMsg}`);

        // Log failed print
        await db.collection('print_jobs').insertOne({
          workstationId,
          printerName,
          status: 'failed',
          error: errorMsg,
          platform,
          command: printCommand,
          timestamp: new Date(),
          createdAt: new Date()
        });

        return NextResponse.json({
          success: false,
          error: `Printer "${printerName}" not available or offline`,
          details: errorMsg,
          troubleshooting: [
            `1. Verify printer "${printerName}" is powered on`,
            `2. Check printer connection (USB, Network, etc)`,
            `3. On macOS: lpstat -p -d (to list printers)`,
            `4. Printer name must match system printer name exactly`,
            `5. Check printer queue: lpstat -o`
          ]
        }, { status: 500 });
      }
    }
    
  } catch (error) {
    console.error('[Print API] Fatal error:', error);
    
    // Log system error
    try {
      const db = await getDatabase();
      await db.collection('print_jobs').insertOne({
        status: 'error',
        error: error instanceof Error ? error.message : String(error),
        timestamp: new Date(),
        createdAt: new Date()
      });
    } catch { }
    
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
    
  } finally {
    // Clean up temporary file
    if (tempFile) {
      try {
        await fs.promises.unlink(tempFile);
        console.log(`[Print API] Cleaned up: ${tempFile}`);
      } catch (unlinkError) {
        console.warn(`[Print API] Could not delete temp file: ${unlinkError}`);
      }
    }
  }
}
