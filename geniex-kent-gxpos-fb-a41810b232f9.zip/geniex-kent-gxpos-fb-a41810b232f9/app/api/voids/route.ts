import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase } from '@/src/lib/mongodb-utils';

export const dynamic = 'force-dynamic';

async function getNextVoidNumber(
  db: Awaited<ReturnType<typeof getDatabase>>,
  workstationId: string
): Promise<string> {
  const result = await db.collection('counters').findOneAndUpdate(
    { _id: `void_counter_${workstationId}` },
    { $inc: { seq: 1 } },
    { upsert: true, returnDocument: 'after' }
  );
  const seq: number = result?.seq ?? 1;
  return `${workstationId}-${String(seq).padStart(15, '0')}`;
}

export async function GET(request: NextRequest) {
  await initializeDatabase().catch(console.error);
  try {
    const db     = await getDatabase();
    const params = new URL(request.url).searchParams;
    const date        = params.get('date');
    const sessionId   = params.get('sessionId');
    const sessionIds  = params.get('sessionIds'); // comma-separated
    const workstationId = params.get('workstationId');

    const query: Record<string, any> = {};

    if (sessionIds) {
      query.sessionId = { $in: sessionIds.split(',').filter(Boolean) };
    } else if (sessionId) {
      query.sessionId = sessionId;
    } else if (date) {
      // legacy fallback — keep working for old records without sessionId
      const from = params.get('from');
      const to   = params.get('to');
      if (from && to) {
        query.businessDate = { $gte: from, $lte: to };
      } else if (date) {
        query.businessDate = date;
      }
    }

    if (workstationId) {
      query.workstationId = workstationId;
    }

    const voids = await db
      .collection('voidLogs')
      .find(query)
      .sort({ createdAt: 1 })
      .toArray();

    return NextResponse.json({ success: true, voids });
  } catch (error) {
    console.error('Void GET Error:', error);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  await initializeDatabase().catch(console.error);
  try {
    const db   = await getDatabase();
    const body = await request.json();

    const workstationId: string = body.workstationId ?? '001';
    const staffId: string       = body.staffId ?? '';

    // ── Resolve sessionId ────────────────────────────────────────────────────
    let sessionId: string | null = body.sessionId ?? null;

    if (!sessionId && staffId) {
      const session = await db.collection('cashierSessions').findOne(
        { staffId, status: 'open' },
        { sort: { openedAt: -1 } }
      );
      if (session) {
        sessionId = session.sessionId ?? String(session._id);
      }
    }

    // ── Resolve businessDate from the open business day ──────────────────────
    // The business day document has a `date` field set when it was opened —
    // this is the canonical business date, immune to midnight-crossing shifts.
    // No router calls needed; we query the collection directly.
    let businessDate: string | null = null;

    const activeBusinessDay = await db.collection('businessDays').findOne(
      { status: 'open' },
      { projection: { date: 1, openedAt: 1 } }
    );

    if (activeBusinessDay) {
      // Prefer the explicit `date` field; fall back to the calendar date of openedAt
      businessDate = activeBusinessDay.date
        ?? (activeBusinessDay.openedAt as string).slice(0, 10);
    }

    // Absolute fallback — today's date so the record is never orphaned
    if (!businessDate) {
      businessDate = new Date().toISOString().slice(0, 10);
    }
    // ─────────────────────────────────────────────────────────────────────────

    const voidTransactionNumber = await getNextVoidNumber(db, workstationId);

    await db.collection('voidLogs').insertOne({
      ...body,
      voidTransactionNumber,
      sessionId,
      businessDate,
      createdAt: new Date().toISOString(),
    });

    return NextResponse.json({ success: true, voidTransactionNumber });
  } catch (error) {
    console.error('Void Log Error:', error);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}