//api/numbers
import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import {
  getNextCounterValue,
  getNextDailyCounterValue,
  initializeDatabase,
  COLLECTIONS,
  initCounterIfNotExists,
} from '@/src/lib/mongodb-utils';
import { getWorkstationId } from '@/src/lib/workstation';
import { singleFlight } from '@/src/lib/singleflight';

export const dynamic = 'force-dynamic';



export async function POST(request: NextRequest) {
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  const { searchParams } = new URL(request.url);
  const type = searchParams.get('type');

  try {
    const db = await getDatabase();
    const countersCollection = db.collection(COLLECTIONS.COUNTERS);

    if (type === 'generateAll') {
      const body = await request.json().catch(() => ({}));
      const wsId = body.workstationId || '001';
      const seriesType = body.seriesType || 'WS';
      const skipOrderNumber = body.skipOrderNumber || false;

      // ADD: wrap the whole number-generation block in singleFlight
      const key = `numbers:generateAll:${wsId}:${seriesType}:${skipOrderNumber}`;

      const result = await singleFlight(key, async () => {
        const todayDateStr = new Date().toISOString().split('T')[0];

        let transactionNumber = '';
        if (seriesType === 'PS') {
          const txnRaw = await getNextCounterValue('transaction_PS');
          transactionNumber = String(txnRaw).padStart(15, '0');
        } else {
          const txnRaw = await getNextCounterValue(`transaction_${wsId}`);
          transactionNumber = String(txnRaw).padStart(15, '0');
        }

        let orderNumber = 0;
        if (!skipOrderNumber) {
          orderNumber = await getNextDailyCounterValue('order', todayDateStr);
        }

        let salesNumber = '';
        if (seriesType === 'PS') {
          const salesRaw = await getNextCounterValue('saleInvoice_PS');
          salesNumber = String(salesRaw).padStart(15, '0');
        } else {
          const salesRaw = await getNextCounterValue(`saleInvoice_${wsId}`);
          salesNumber = String(salesRaw).padStart(15, '0');
        }

        return { orderNumber, salesNumber, transactionNumber };
      });

      return NextResponse.json(result);
    }


    if (type === 'transaction') {
      const body = await request.json().catch(() => ({}));
      const wsId = body.workstationId || '001';
      const seriesType = body.seriesType || 'WS';
      let transactionNumber = '';
      if (seriesType === 'PS') {
        const txnRaw = await getNextCounterValue('transaction_PS');
        // const salesRaw = await getNextCounterValue('saleInvoice_PS');
        transactionNumber = String(txnRaw).padStart(15, '0');
      } else {
        const txnRaw = await getNextCounterValue(`transaction_${wsId}`);
        // const salesRaw = await getNextCounterValue('saleInvoice_PS');
        transactionNumber = String(txnRaw).padStart(15, '0');
      }
      // const txnNumber = await getNextCounterValue('transaction');
      const formatted15 = String(transactionNumber).padStart(15, '0');
      return NextResponse.json({
        number: formatted15,
        raw: transactionNumber,
      });
    }

    if (type === 'saleInvoice') {
      const wsId = getWorkstationId() || '001';
      const siNumber = await getNextCounterValue(`saleInvoice_${wsId}`);
      const formatted15 = String(siNumber).padStart(15, '0');
      return NextResponse.json({
        number: `${formatted15}`,
        raw: siNumber,
      });
    }

    if (type === 'voidSeries') {
      const body = await request.json().catch(() => ({}));
      const wsId = body.workstationId || '001';
      const seriesType = body.seriesType || 'WS';

      let voidNumber = '';
      if (seriesType === 'PS') {
        const raw = await getNextCounterValue('voidSeries_PS');
        voidNumber = String(raw).padStart(15, '0');
      } else {
        const raw = await getNextCounterValue(`voidSeries_${wsId}`);
        voidNumber = `${String(raw).padStart(15, '0')}`;
      }

      return NextResponse.json({ voidNumber });
    }

    if (type === 'refundSeries') {
      const body = await request.json().catch(() => ({}));
      const wsId = body.workstationId || '001';
      const seriesType = body.seriesType || 'WS';

      let refundNumber = '';
      if (seriesType === 'PS') {
        const raw = await getNextCounterValue('refundSeries_PS');
        refundNumber = String(raw).padStart(15, '0');
      } else {
        const raw = await getNextCounterValue(`refundSeries_${wsId}`);
        refundNumber = `${String(raw).padStart(15, '0')}`;
      }

      return NextResponse.json({ refundNumber });
    }

    if (type === 'cashDrop') {
      const body = await request.json().catch(() => ({}));
      const wsId = body.workstationId || '001';
      const seriesType = body.seriesType || 'WS';

      let dropNumber = '';
      let raw = 1;
      if (seriesType === 'PS') {
        raw = await getNextCounterValue('cashDrop_PS');
        dropNumber = String(raw).padStart(6, '0');
      } else {
        raw = await getNextCounterValue(`cashDrop_${wsId}`);
        dropNumber = `${String(raw).padStart(6, '0')}`;
      }

      return NextResponse.json({ dropNumber, raw });
    }

    if (type === 'order') {
      const todayDateStr = new Date().toISOString().split('T')[0];
      const orderNum = await getNextDailyCounterValue('order', todayDateStr);
      return NextResponse.json({
        number: String(orderNum).padStart(4, '0'),
        raw: orderNum,
      });
    }

    if (type === 'init') {
      const todayDateStr = new Date().toISOString().split('T')[0];

      await initCounterIfNotExists('transaction');
      await initCounterIfNotExists(`saleInvoice_${getWorkstationId() || '001'}`);
      await initCounterIfNotExists(`order_${todayDateStr}`); // match your daily key pattern

      const counters = await countersCollection.find({}).toArray();
      return NextResponse.json({
        message: 'Counters initialized',
        counters,
      });
    }

    if (type === 'getAll') {
      const allCounters = await countersCollection.find({}).toArray();
      return NextResponse.json(allCounters);
    }

    // ─── Z-Counter: increment (first print of a Z-Reading) ────────────────
    // POST /api/numbers?type=zCounter
    // Body: { workstationId: '001' }
    // Returns: { zCounter: '0001', raw: 1 }
    if (type === 'zCounter') {
      const body = await request.json().catch(() => ({}));
      const wsId = body.workstationId || getWorkstationId() || '001';
      const todayDateStr = new Date().toISOString().split('T')[0];

      const zCountersCollection = db.collection(COLLECTIONS.Z_COUNTERS);

      // Peek current doc first to check if we're about to wrap
      const existing = await zCountersCollection.findOne({ workstationId: wsId });
      const currentCount = (existing as any)?.count ?? 0;
      const currentResetCtr = (existing as any)?.resetCtr ?? 0;

      const willWrap = currentCount >= 9999;
      const newCount = willWrap ? 1 : currentCount + 1;
      const newResetCtr = willWrap ? currentResetCtr + 1 : currentResetCtr;

      await zCountersCollection.updateOne(
        { workstationId: wsId },
        {
          $set: {
            count: newCount,
            resetCtr: newResetCtr,
            lastZDate: todayDateStr,
            lastUpdated: new Date(),
          },
        },
        { upsert: true }
      );

      return NextResponse.json({
        zCounter: String(newCount).padStart(4, '0'),
        raw: newCount,
        resetCtr: String(newResetCtr).padStart(4, '0'),
        resetCtrRaw: newResetCtr,
      });
    }

    // ─── Reset Order Number (call after EOD / Z-Reading) ──────────────────
    // POST /api/numbers?type=resetOrder
    // Clears the stored date so the next getNextDailyCounterValue call
    // sees a "date mismatch" and resets the value back to 1.
    if (type === 'resetOrder') {
      await countersCollection.updateOne(
        { type: 'order' },
        { $set: { value: 0, date: '', lastUpdated: new Date() } },
        { upsert: true }
      );
      console.log('✓ Order number counter reset to 1 (next call)');
      return NextResponse.json({ success: true, message: 'Order number will reset to 1 on next use' });
    }

    if (type === 'saveZRecord') {
      const body     = await request.json().catch(() => ({}));
      const wsId     = body.workstationId || getWorkstationId() || '001';
      const date     = body.date;
      const zCounter = body.zCounter;

      // ← Use Z_READING_RECORDS, not Z_COUNTERS
      const zRecordsCollection = db.collection(COLLECTIONS.Z_READING_RECORDS);
      await zRecordsCollection.updateOne(
        { workstationId: wsId, date },
        { $set: { workstationId: wsId, date, zCounter, savedAt: new Date() } },
        { upsert: true }
      );

      return NextResponse.json({ success: true });
    }


    return NextResponse.json(
      { error: 'Unknown counter type' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Counter error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Counter error',
      },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  const { searchParams } = new URL(request.url);
  const type = searchParams.get('type');

  try {
    const db = await getDatabase();
    const countersCollection = db.collection(COLLECTIONS.COUNTERS);

    if (type === 'getAll') {
      const allCounters = await countersCollection.find({}).toArray();
      return NextResponse.json(allCounters);
    }

    // ─── Z-Counter: peek current value (for reprints / preview) ───────────
    // GET /api/numbers?type=getZCounter&workstationId=001
    // Returns: { zCounter: '0003', raw: 3, nextZCounter: '0004', nextRaw: 4 }
    if (type === 'getZCounter') {
      const wsId = searchParams.get('workstationId') || getWorkstationId() || '001';
      const zCountersCollection = db.collection(COLLECTIONS.Z_COUNTERS);
      const doc = await zCountersCollection.findOne({ workstationId: wsId });
      const zCount = (doc as any)?.count ?? 0;

      const resetCtr = (doc as any)?.resetCtr ?? 0;
      const nextCount = zCount >= 9999 ? 1 : zCount + 1;
      const nextResetCtr = zCount >= 9999 ? resetCtr + 1 : resetCtr;

      return NextResponse.json({
        zCounter:        String(zCount).padStart(4, '0'),
        raw:             zCount,
        nextZCounter:    String(nextCount).padStart(4, '0'),
        nextRaw:         nextCount,
        nextResetCtr:    String(nextResetCtr).padStart(4, '0'),
        resetCtr:        String(resetCtr).padStart(4, '0'),
        lastZDate:       (doc as any)?.lastZDate ?? null,
      });
    }
    
    if (type === 'getZRecord') {
      const wsId = searchParams.get('workstationId') || getWorkstationId() || '001';
      const date = searchParams.get('date');

      // ← Use Z_READING_RECORDS, not Z_COUNTERS
      const zRecordsCollection = db.collection(COLLECTIONS.Z_READING_RECORDS);
      const doc = await zRecordsCollection.findOne({ workstationId: wsId, date });

      return NextResponse.json({
        zCounter: (doc as any)?.zCounter ?? null,
        found:    !!doc,
      });
    }

    return NextResponse.json(
      { error: 'Unknown counter type' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Counter error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Counter error',
      },
      { status: 500 }
    );
  }
}