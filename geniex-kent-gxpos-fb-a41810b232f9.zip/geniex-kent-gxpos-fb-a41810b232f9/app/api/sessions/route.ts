//api/sessions
import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase, COLLECTIONS } from '@/src/lib/mongodb-utils';
import crypto from 'crypto';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  // Initialize database on first request
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  const { searchParams } = new URL(request.url);
  const token = searchParams.get('token');

  try {
    const db = await getDatabase();
    const sessionsCollection = db.collection(COLLECTIONS.USER_SESSIONS);

    if (!token) {
      return NextResponse.json(
        { error: 'Session token required' },
        { status: 400 }
      );
    }

    const session = await sessionsCollection.findOne({
      sessionToken: token as string,
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(session);
  } catch (error) {
    console.error('Session handler error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Server error',
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  // Initialize database on first request
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  try {
    const { userId, name, email, role, avatar, terminalId } = await request.json();
    const db = await getDatabase();
    const sessionsCollection = db.collection(COLLECTIONS.USER_SESSIONS);
    const cashierSessionsCollection = db.collection(COLLECTIONS.CASHIER_SESSIONS || 'cashierSessions');

    if (terminalId) {
        const openElsewhere = await cashierSessionsCollection.findOne({
          status: 'open',
          staffId: String(userId),
          openedAtTerminal: { $ne: terminalId },
        });

        if (openElsewhere) {
          return NextResponse.json({
            error: `You have an open register session on terminal ${openElsewhere.openedAtTerminal || 'Unknown'}. Please close it before logging in here.`,
            code: 'CROSS_TERMINAL_SESSION',
            existingSession: {
              terminalId: openElsewhere.openedAtTerminal,
              openedAt: openElsewhere.openedAt,
              sessionId: openElsewhere.sessionId,
            },
          }, { status: 409 });
        }
      }


    if (!userId) {
      return NextResponse.json(
        { error: 'User ID required' },
        { status: 400 }
      );
    }

    const sessionToken = crypto.randomBytes(32).toString('hex');
    const now = new Date();

    const newSession = {
      userId,
      name: name || '',
      email: email || '',
      role: role || 0,
      avatar: avatar || '',
      loginTime: now,
      lastActivity: now,
      sessionToken,
    };

    const result = await sessionsCollection.insertOne(newSession);

    return NextResponse.json(
      {
        _id: result.insertedId,
        ...newSession,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Session handler error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Server error',
      },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  // Initialize database on first request
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  const { searchParams } = new URL(request.url);
  const token = searchParams.get('token');

  try {
    const db = await getDatabase();
    const sessionsCollection = db.collection(COLLECTIONS.USER_SESSIONS);

    if (!token) {
      return NextResponse.json(
        { error: 'Session token required' },
        { status: 400 }
      );
    }

    const result = await sessionsCollection.findOneAndUpdate(
      { sessionToken: token as string },
      {
        $set: {
          lastActivity: new Date(),
        },
      },
      { returnDocument: 'after' }
    );

    if (!result || !result.ok || !result.value) {
      return NextResponse.json(
        { error: 'Session not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(result.value);
  } catch (error) {
    console.error('Session handler error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Server error',
      },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  // Initialize database on first request
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  const { searchParams } = new URL(request.url);
  const token = searchParams.get('token');

  try {
    const db = await getDatabase();
    const sessionsCollection = db.collection(COLLECTIONS.USER_SESSIONS);

    if (!token) {
      return NextResponse.json(
        { error: 'Session token required' },
        { status: 400 }
      );
    }

    const result = await sessionsCollection.deleteOne({
      sessionToken: token as string,
    });

    return NextResponse.json({
      deletedCount: result.deletedCount,
    });
  } catch (error) {
    console.error('Session handler error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Server error',
      },
      { status: 500 }
    );
  }
}
