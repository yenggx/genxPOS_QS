import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { COLLECTIONS } from '@/src/lib/mongodb-utils';
import { syncTransactions } from '@/src/lib/sync-service';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const orderNos = new URL(request.url).searchParams.getAll('orderNo');

    if (!orderNos.length) {
      return NextResponse.json({ success: false, error: 'orderNo parameter required' }, { status: 400 });
    }

    const db  = await getDatabase();
    const col = db.collection(COLLECTIONS.TRANSACTIONS);

    const transactions = await col.find({
      $or: [
        { OrderNo:     { $in: orderNos } },
        { orderNumber: { $in: orderNos } },
        { OrderNo:     { $in: orderNos.map(o => parseInt(o, 10)) } },
        { orderNumber: { $in: orderNos.map(o => parseInt(o, 10)) } },
      ],
    }).toArray();

    if (!transactions.length) {
      return NextResponse.json({ success: false, error: `No transactions found for: ${orderNos.join(', ')}` }, { status: 404 });
    }

    console.log('[RETRY-SYNC] Force syncing orders:', orderNos.join(', '));
    const summary = await syncTransactions(transactions);

    return NextResponse.json({ success: summary.synced > 0, ...summary });
  } catch (error) {
    console.error('[RETRY-SYNC] FATAL:', error);
    return NextResponse.json({ success: false, error: error instanceof Error ? error.message : 'Server error' }, { status: 500 });
  }
}