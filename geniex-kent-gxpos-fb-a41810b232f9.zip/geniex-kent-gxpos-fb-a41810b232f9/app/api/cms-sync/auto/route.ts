// this is a dead code now
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

/**
 * GET /api/cms-sync/auto
 * Automatically sync all pending transactions
 * Can be called periodically or triggered manually
 */
export async function GET(request: NextRequest) {
  try {
    console.log('[AUTO-SYNC] Triggering CMS sync for all pending transactions...');

    // Call the main sync endpoint
    const syncResponse = await fetch(
      new URL('/api/cms-sync', request.url),
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );

    const syncData = await syncResponse.json();
    
    console.log('[AUTO-SYNC] Sync result:', {
      success: syncData.success,
      synced: syncData.synced,
      total: syncData.total,
      failed: syncData.failed,
    });

    return NextResponse.json(syncData, { status: syncResponse.status });
  } catch (error) {
    console.error('[AUTO-SYNC] Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Server error',
      },
      { status: 500 }
    );
  }
}
