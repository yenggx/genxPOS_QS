import { NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { COLLECTIONS } from '@/src/lib/mongodb-utils';
import { syncTransactions } from '@/src/lib/sync-service';

export const dynamic = 'force-dynamic';

export async function POST() {
  try {
    const db      = await getDatabase();
    const col     = db.collection(COLLECTIONS.TRANSACTIONS);
    const pending = await col
      .find({ $or: [{ isSynced: false }, { isSynced: { $exists: false } }] })
      .sort({ createdAt: -1 })
      .toArray();

    if (pending.length === 0) {
      return NextResponse.json({ success: true, message: 'No pending transactions', synced: 0, total: 0, failed: 0 });
    }

    console.log('[CMS-SYNC] Found', pending.length, 'pending transactions');
    const summary = await syncTransactions(pending);
    console.log(`[CMS-SYNC] Done: ${summary.synced} synced, ${summary.failed} failed`);

    return NextResponse.json({ success: true, ...summary });
  } catch (error) {
    console.error('[CMS-SYNC] FATAL:', error);
    return NextResponse.json({ success: false, error: error instanceof Error ? error.message : 'Server error' }, { status: 500 });
  }
}