import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase, COLLECTIONS } from '@/src/lib/mongodb-utils';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  // Initialize database on first request
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  const { searchParams } = new URL(request.url);
  const collectionName = searchParams.get('collection');
  const action = searchParams.get('action');

  if (!collectionName || !action) {
    return NextResponse.json(
      {
        error: 'Missing collection or action parameter',
      },
      { status: 400 }
    );
  }

  try {
    const db = await getDatabase();

    // Validate collection name (security)
    const validCollections = Object.values(COLLECTIONS);
    if (!validCollections.includes(collectionName as string)) {
      return NextResponse.json(
        {
          error: 'Invalid collection name',
        },
        { status: 400 }
      );
    }

    const collection = db.collection(collectionName as string);
    const body = await request.json();

    switch (action) {
      case 'get':
        // Get single or multiple documents
        if (body?.id) {
          // Get by ID
          const doc = await collection.findOne({
            $or: [{ id: body.id }, { _id: body.id }],
          });
          return NextResponse.json(doc);
        } else if (body?.query) {
          // Get with query
          const docs = await collection
            .find(body.query)
            .limit(body.limit || 100)
            .toArray();
          return NextResponse.json(docs);
        } else {
          // Get all
          const docs = await collection
            .find({})
            .limit(body?.limit || 100)
            .toArray();
          return NextResponse.json(docs);
        }

      case 'insert':
        // Insert single document (or upsert if duplicate key exists)
        try {
          const insertResult = await collection.insertOne({
            ...body.data,
            _id: undefined, // Let MongoDB generate _id
            createdAt: new Date(),
            updatedAt: new Date(),
          });
          return NextResponse.json(
            {
              _id: insertResult.insertedId,
              ...body.data,
            },
            { status: 201 }
          );
        } catch (insertError: unknown) {
          // Handle duplicate key error by updating instead
          const mongoError = insertError as { code?: number };
          if (mongoError.code === 11000) {
            // E11000 duplicate key error - update instead
            if (body.data?.id) {
              const updateResult = await collection.findOneAndUpdate(
                { id: body.data.id },
                {
                  $set: {
                    ...body.data,
                    updatedAt: new Date(),
                  },
                },
                { returnDocument: 'after' }
              );
              return NextResponse.json(updateResult?.value || body.data, {
                status: 200,
              });
            }
          }
          // Re-throw other errors
          throw insertError;
        }

      case 'update':
        // Update document
        if (!body?.id) {
          return NextResponse.json(
            { error: 'ID required for update' },
            { status: 400 }
          );
        }
        const updateResult = await collection.findOneAndUpdate(
          { $or: [{ id: body.id }, { _id: body.id }] },
          {
            $set: {
              ...body.data,
              updatedAt: new Date(),
            },
          },
          { returnDocument: 'after' }
        );
        if (!updateResult || !updateResult.ok || !updateResult.value) {
          return NextResponse.json(
            { error: 'Document not found' },
            { status: 404 }
          );
        }
        return NextResponse.json(updateResult.value);

      case 'delete':
        // Delete document
        if (!body?.id) {
          return NextResponse.json(
            { error: 'ID required for delete' },
            { status: 400 }
          );
        }
        const deleteResult = await collection.deleteOne({
          $or: [{ id: body.id }, { _id: body.id }],
        });
        return NextResponse.json({
          deletedCount: deleteResult.deletedCount,
        });

      case 'deleteMany':
        // Delete multiple documents
        const deleteManyResult = await collection.deleteMany(body?.query || {});
        return NextResponse.json({
          deletedCount: deleteManyResult.deletedCount,
        });

      case 'clear':
        // Clear collection (be careful!)
        if (process.env.NODE_ENV !== 'development') {
          return NextResponse.json(
            { error: 'Only allowed in development' },
            { status: 403 }
          );
        }
        const clearResult = await collection.deleteMany({});
        return NextResponse.json({
          clearedCount: clearResult.deletedCount,
        });

      default:
        return NextResponse.json(
          { error: 'Unknown action' },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Database error',
      },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  // Initialize database on first request
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  const { searchParams } = new URL(request.url);
  const collectionName = searchParams.get('collection');
  const action = searchParams.get('action');

  if (!collectionName || !action) {
    return NextResponse.json(
      {
        error: 'Missing collection or action parameter',
      },
      { status: 400 }
    );
  }

  try {
    const db = await getDatabase();

    // Validate collection name (security)
    const validCollections = Object.values(COLLECTIONS);
    if (!validCollections.includes(collectionName as string)) {
      return NextResponse.json(
        {
          error: 'Invalid collection name',
        },
        { status: 400 }
      );
    }

    const collection = db.collection(collectionName as string);

    if (action === 'get') {
      const docs = await collection.find({}).limit(100).toArray();
      return NextResponse.json(docs);
    }

    return NextResponse.json(
      { error: 'Unknown action' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Database error',
      },
      { status: 500 }
    );
  }
}
