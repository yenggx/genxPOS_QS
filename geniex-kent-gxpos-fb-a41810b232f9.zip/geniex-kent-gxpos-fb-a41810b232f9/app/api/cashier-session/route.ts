// app/api/cashier-session/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase, COLLECTIONS } from '@/src/lib/mongodb-utils';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  await initializeDatabase().catch((err: unknown) => console.error('DB init error:', err));

  const { searchParams } = new URL(request.url); 
  const status     = searchParams.get('status');
  const date       = searchParams.get('date');
  const staffId    = searchParams.get('staffId');
  const terminalId = searchParams.get('terminalId');

  try {
    const db = await getDatabase();
    const cashierSessionsCollection = db.collection(COLLECTIONS.CASHIER_SESSIONS || 'cashierSessions');
    const businessDaysCollection    = db.collection('businessDays');

    if (status === 'all_open') {
      const sessions = await cashierSessionsCollection
        .find({ status: 'open' })
        .sort({ openedAt: 1 })
        .toArray();
    
      const activeBusinessDay = await businessDaysCollection.findOne({ status: 'open' });
      
      let activeTerminalsToday: string[] = [];
      if (activeBusinessDay) {
        activeTerminalsToday = await cashierSessionsCollection.distinct('openedAtTerminal', {
          businessDayId: activeBusinessDay.businessDayId,
          openedAtTerminal: { $ne: null }
        });
      }

      return NextResponse.json(
        {
          sessions,
          businessDayId:   activeBusinessDay?.businessDayId || null,
          businessDayDate: activeBusinessDay?.date          || null,
          eodLocked:       activeBusinessDay?.eodLocked     || false,
          lockedBy:        activeBusinessDay?.lockedBy      || null,
          completedTerminals: activeBusinessDay?.completedTerminals || [],
          activeTerminalsToday,
        },
        { status: 200 }
      );
    }
    

    const businessDayId = searchParams.get('businessDayId');

    if (status === 'closed') {
      const query: Record<string, any> = { status: 'closed' };

      if (businessDayId) {
        // ✅ Precise: scoped to exact business day, immune to date boundary issues
        query.businessDayId = businessDayId;
      } else if (date) {
        // Fallback for legacy callers that don't pass businessDayId
        query.$or = [
          { openedAt: { $gte: `${date}T00:00:00.000Z`, $lte: `${date}T23:59:59.999Z` } },
          { closedAt: { $gte: `${date}T00:00:00.000Z`, $lte: `${date}T23:59:59.999Z` } },
        ];
      }

      if (terminalId) {
        query.$or = [
          { openedAtTerminal: terminalId },
          { closedAtTerminal: terminalId },
        ];
      }

      const sessions = await cashierSessionsCollection
        .find(query)
        .sort({ closedAt: -1 })
        .toArray();

      return NextResponse.json({ success: true, sessions }, { status: 200 });
    }

    // Filter open sessions by terminal if provided
    const openQuery: Record<string, any> = { status: 'open' };
    if (terminalId) {
      openQuery.openedAtTerminal = terminalId;
    }

    const allOpenSessions = await cashierSessionsCollection.find(openQuery).toArray();

    let activeSession = null;
    if (staffId) {
      activeSession = allOpenSessions.find(s => String(s.staffId) === String(staffId));
    } else if (allOpenSessions.length > 0) {
      activeSession = allOpenSessions[0];
    }

    const activeBusinessDay = await businessDaysCollection.findOne({ status: 'open' });

    if (!activeSession) {
      return NextResponse.json({
        active: false,
        allOpenSessions,
        businessDayDate:     activeBusinessDay?.date || null,
        businessDayId:       activeBusinessDay?.businessDayId  || null,
        businessDayOpenedAt: activeBusinessDay?.openedAt       || null,
      }, { status: 200 });
    }

    return NextResponse.json({
      active:              true,
      session:             activeSession,
      allOpenSessions,
      businessDayDate:     activeBusinessDay?.date || null,
      businessDayId:       activeBusinessDay?.businessDayId  || null,
      businessDayOpenedAt: activeBusinessDay?.openedAt       || null,
    }, { status: 200 });

  } catch (error) {
    console.error('Cashier Session GET error:', error);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  await initializeDatabase().catch((err: unknown) => console.error('DB init error:', err));

  try {
    const {
      startingCash,
      openingBreakdown,
      staffId,
      staffName,
      terminalId,
    } = await request.json();

    const db = await getDatabase();
    const cashierSessionsCollection = db.collection(COLLECTIONS.CASHIER_SESSIONS || 'cashierSessions');
    const businessDaysCollection    = db.collection('businessDays');

    const existingOpen = await cashierSessionsCollection.findOne({ status: 'open', staffId });
    if (existingOpen) {
      return NextResponse.json({ 
        error: `You already have an open register session on terminal ${existingOpen.openedAtTerminal || 'Unknown'}. Please close it first.`,
        code: 'MULTI_LOGIN_DETECTED',
        existingSession: {
          terminalId: existingOpen.openedAtTerminal,
          openedAt: existingOpen.openedAt,
          sessionId: existingOpen.sessionId
        }
      }, { status: 409 });
    }

    let activeBusinessDay = await businessDaysCollection.findOne({ status: 'open' });

    if (activeBusinessDay?.completedTerminals?.includes(terminalId)) {
      return NextResponse.json({ 
        error: `End of Day has already been completed for terminal ${terminalId || 'Unknown'} today. You cannot open new shifts until the business day is advanced.`,
        code: 'TERMINAL_EOD_COMPLETED'
      }, { status: 403 });
    }

    if (!activeBusinessDay) {
      const newBusinessDay = {
        businessDayId:      `BD_${Date.now()}`,
        status:             'open',
        openedAt:           new Date().toISOString(),
        openedByStaffId:    staffId,
        openedByStaffName:  staffName,
        date:               new Date().toISOString().split('T')[0],
        completedTerminals: [],
      };
      const result     = await businessDaysCollection.insertOne(newBusinessDay);
      activeBusinessDay = { ...newBusinessDay, _id: result.insertedId };
    }

    // Count shifts per terminal instead of globally for the business day
    const existingShiftsCount = await cashierSessionsCollection.countDocuments({
      businessDayId: activeBusinessDay.businessDayId,
      openedAtTerminal: terminalId || null
    });
    const shiftNumber = existingShiftsCount + 1;

    const sessionId  = `shift_${Date.now()}_${staffId}`;
    const newSession = {
      sessionId,
      businessDayId:    activeBusinessDay.businessDayId,
      shiftNumber,
      startingCash,
      openingBreakdown,
      cashDrops:        [],
      staffId,
      staffName,
      status:           'open',
      openedAt:         new Date().toISOString(),
      openedAtTerminal: terminalId || null,
    };

    await cashierSessionsCollection.insertOne(newSession);

    return NextResponse.json(
      { success: true, session: newSession, businessDayId: activeBusinessDay.businessDayId, shiftNumber },
      { status: 201 }
    );
  } catch (error) {
    console.error('Cashier Session POST error:', error);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

export async function PATCH(request: NextRequest) {
  await initializeDatabase().catch((err: unknown) => console.error('DB init error:', err));

  try {
    const data = await request.json();
    const db   = await getDatabase();
    const cashierSessionsCollection = db.collection(COLLECTIONS.CASHIER_SESSIONS || 'cashierSessions');

    const query: Record<string, any> = { status: 'open' };
    if (data.sessionId)   query.sessionId = data.sessionId;
    else if (data.staffId) query.staffId  = data.staffId;

    const activeSession = await cashierSessionsCollection.findOne(query);

    if (!activeSession) {
      return NextResponse.json({ error: 'No active session found to update' }, { status: 404 });
    }

    if (data.action === 'add_drop') {
      await cashierSessionsCollection.updateOne(
        { _id: activeSession._id },
        {
          $push: {
            cashDrops: {
              amount:    data.amount,
              timestamp: data.timestamp,
              staffId:   data.staffId,
              staffName: data.staffName,
            },
          },
        }
      );
      return NextResponse.json({ success: true }, { status: 200 });
    }

    await cashierSessionsCollection.updateOne(
      { _id: activeSession._id },
      {
        $set: {
          status:           'closed',
          closedAt:         data.closedAt || new Date().toISOString(),
          actualCash:       data.actualCash,
          closingBreakdown: data.closingBreakdown,
          variance:         data.variance,
          varianceReason:   data.varianceReason || null,
          stats:            data.stats,
          closedAtTerminal: data.closedAtTerminal || null,
        },
      }
    );

    return NextResponse.json({ success: true, sessionId: activeSession.sessionId }, { status: 200 });
  } catch (error) {
    console.error('Cashier Session PATCH error:', error);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}