import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';

export const dynamic = 'force-dynamic';

// Single global settings document — no per-workstation splitting
const SETTINGS_ID = 'global';

interface DoublePrintTypes {
  REGULAR:  boolean;
  SC:       boolean;
  PWD:      boolean;
  ATHLETE:  boolean;
  DIPLOMAT: boolean;
  PEZA:     boolean;
  SOLO:     boolean;
  MEDAL:    boolean;
}

type DiscountScope = 'all' | 'dine_in' | 'take_out';

type DiscountScopes = Partial<Record<'SR' | 'PWD' | 'ATHLETE' | 'DIPLOMAT' | 'PEZA' | 'SOLO' | 'MEDAL' | 'CUSTOM',
  DiscountScope
>>;

interface SettingsData {
  workstationId?:              string; // kept for backward-compat, ignored on write
  vatNumber:                   string;
  tinNumber:                   string;
  minNumber:                   string;
  ptuNumber:                   string;
  snNumber:                    string;
  allowable_void_refund_hours?: number;
  kdsWarningMinutes?:          number;
  kdsDangerMinutes?:           number;
  cashDropWarningAmount?:      number;
  cashDropMaxAmount?:          number;

  cashFundLimit?:              number;
  soloParentLimit?:            number;
  soloParentReset?:            'weekly' | 'monthly';
  
  showStock?:                  boolean;
  zReadingType?:               'Consolidated' | 'Per Terminal' | 'Both';
  doublePrintTypes?:           DoublePrintTypes;
  discountScopes?:             DiscountScopes;
  updatedAt?:                  Date;
}

const DEFAULT_DOUBLE_PRINT: DoublePrintTypes = {
  REGULAR:  false,
  SC:       false,
  PWD:      false,
  ATHLETE:  false,
  DIPLOMAT: false,
  PEZA:     false,
  SOLO:     false,
  MEDAL:    false,
};

const DEFAULT_DISCOUNT_SCOPES: DiscountScopes = {};

const DEFAULTS: Omit<SettingsData, 'workstationId' | 'updatedAt'> = {
  vatNumber:                   '',
  tinNumber:                   '',
  minNumber:                   '',
  ptuNumber:                   '',
  snNumber:                    '',
  allowable_void_refund_hours: 24,
  kdsWarningMinutes:           5,
  kdsDangerMinutes:            10,
  cashDropWarningAmount:       0,
  cashDropMaxAmount:           0,
  cashFundLimit:               0,
  soloParentLimit:             0,
  soloParentReset:             'weekly' as const,
  showStock:                   false,
  zReadingType:                'Consolidated' as const,
  doublePrintTypes:            DEFAULT_DOUBLE_PRINT,
  discountScopes:              DEFAULT_DISCOUNT_SCOPES,
};

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/settings          (workstationId param accepted but ignored)
// ─────────────────────────────────────────────────────────────────────────────
export async function GET(_request: NextRequest) {
  try {
    const db  = await getDatabase();
    const col = db.collection('workstation_config');

    const doc = await col.findOne({ settingsId: SETTINGS_ID });

    if (!doc) {
      return NextResponse.json({ ...DEFAULTS });
    }

    return NextResponse.json({
      vatNumber:                   doc.vatNumber                   || '',
      tinNumber:                   doc.tinNumber                   || '',
      minNumber:                   doc.minNumber                   || '',
      ptuNumber:                   doc.ptuNumber                   || '',
      snNumber:                    doc.snNumber                    || '',
      allowable_void_refund_hours: doc.allowable_void_refund_hours ?? 24,
      kdsWarningMinutes:           doc.kdsWarningMinutes           ?? 5,
      kdsDangerMinutes:            doc.kdsDangerMinutes            ?? 10,
      cashDropWarningAmount:       doc.cashDropWarningAmount       ?? 0,
      cashDropMaxAmount:           doc.cashDropMaxAmount           ?? 0,
      cashFundLimit:               doc.cashFundLimit               ?? 0,
      soloParentLimit:             doc.soloParentLimit             ?? 0,
      soloParentReset:             doc.soloParentReset             ?? 'weekly',
      showStock:                   doc.showStock                   ?? false,
      zReadingType:                doc.zReadingType                ?? 'Consolidated',
      doublePrintTypes:            { ...DEFAULT_DOUBLE_PRINT, ...(doc.doublePrintTypes ?? {}) },
      discountScopes:              { ...DEFAULT_DISCOUNT_SCOPES, ...(doc.discountScopes ?? {}) },
      updatedAt:                   doc.updatedAt,
    });
  } catch (error) {
    console.error('[Settings] GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/settings
// Safe for concurrent writers — uses optimistic locking via __v (version field).
// If two terminals POST at the same time, one will retry up to 3 times.
// ─────────────────────────────────────────────────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as SettingsData;

    const db  = await getDatabase();
    const col = db.collection('workstation_config');

    const payload = {
      settingsId:                  SETTINGS_ID,
      vatNumber:                   body.vatNumber                            || '',
      tinNumber:                   body.tinNumber                            || '',
      minNumber:                   body.minNumber                            || '',
      ptuNumber:                   body.ptuNumber                            || '',
      snNumber:                    body.snNumber                             || '',
      allowable_void_refund_hours: Number(body.allowable_void_refund_hours) || 24,
      kdsWarningMinutes:           Number(body.kdsWarningMinutes)           || 5,
      kdsDangerMinutes:            Number(body.kdsDangerMinutes)            || 10,
      cashDropWarningAmount:       Number(body.cashDropWarningAmount)        || 0,
      cashDropMaxAmount:           Number(body.cashDropMaxAmount)            || 0,
      cashFundLimit:               Number(body.cashFundLimit)               || 0,
      soloParentLimit:             Number(body.soloParentLimit)             || 0,
      soloParentReset:             body.soloParentReset === 'weekly' ? 'weekly' : 'monthly',

      showStock:                   Boolean(body.showStock),
      zReadingType:                ['Consolidated', 'Per Terminal', 'Both'].includes(body.zReadingType as any) ? body.zReadingType : 'Consolidated',
      doublePrintTypes:            { ...DEFAULT_DOUBLE_PRINT, ...(body.doublePrintTypes ?? {}) },
      discountScopes:              { ...DEFAULT_DISCOUNT_SCOPES, ...(body.discountScopes ?? {}) },
      updatedAt:                   new Date(),
    };

    // Optimistic locking: read current version, write only if version matches,
    // increment version on success. Retries up to 3 times on conflict.
    const MAX_RETRIES = 3;
    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      const current = await col.findOne({ settingsId: SETTINGS_ID });
      const currentVersion = (current as any)?.__v ?? 0;

      const result = await col.updateOne(
      {
        settingsId: SETTINGS_ID,
        $or: [
          { __v: currentVersion },
          { __v: { $exists: false } },
        ],
      },
      {
        $set: {
          // settingsId removed from here — was causing the conflict
          vatNumber:                   payload.vatNumber,
          tinNumber:                   payload.tinNumber,
          minNumber:                   payload.minNumber,
          ptuNumber:                   payload.ptuNumber,
          snNumber:                    payload.snNumber,
          allowable_void_refund_hours: payload.allowable_void_refund_hours,
          kdsWarningMinutes:           payload.kdsWarningMinutes,
          kdsDangerMinutes:            payload.kdsDangerMinutes,
          cashDropWarningAmount:       payload.cashDropWarningAmount,
          cashDropMaxAmount:           payload.cashDropMaxAmount,
          cashFundLimit:               payload.cashFundLimit,
          soloParentLimit:             payload.soloParentLimit,
          soloParentReset:             payload.soloParentReset,
          showStock:                   payload.showStock,
          zReadingType:                payload.zReadingType,
          doublePrintTypes:            payload.doublePrintTypes,
          discountScopes:              payload.discountScopes,
          updatedAt:                   payload.updatedAt,
          __v:                         currentVersion + 1,
        },
        $setOnInsert: { settingsId: SETTINGS_ID },
      },
      { upsert: true },
    );


      if (result.modifiedCount > 0 || result.upsertedCount > 0) {
        return NextResponse.json({
          success: true,
          message: 'Settings saved successfully',
        });
      }

      // Another terminal won the race — wait a short random backoff then retry
      const backoff = 50 + Math.random() * 100;
      await new Promise(res => setTimeout(res, backoff));
    }

    // All retries exhausted
    return NextResponse.json(
      { error: 'Settings could not be saved due to concurrent updates. Please try again.' },
      { status: 409 },
    );

  } catch (error) {
    console.error('[Settings] POST error:', error);
    return NextResponse.json({ error: 'Failed to save settings' }, { status: 500 });
  }
}