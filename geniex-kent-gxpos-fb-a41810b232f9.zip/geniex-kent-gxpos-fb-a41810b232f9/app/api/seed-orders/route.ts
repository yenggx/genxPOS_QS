import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';

export const dynamic = 'force-dynamic';

/**
 * Seed sample orders for testing
 * POST to this endpoint to add sample orders to MongoDB
 */
export async function POST(request: NextRequest) {
  try {
    const db = await getDatabase();
    const ordersCollection = db.collection('orderTransactions');
    
    // Sample CMS format orders
    const sampleOrders = [
      {
        id: 'cms-001',
        order_number: 1001,
        total_amount: 45000, // 450 pesos in cents
        customer_name: 'John Doe',
        customer_email: 'john@example.com',
        orderDetailJSON: JSON.stringify({
          items: [
            { itemName: 'Iced Coffee', quantity: 1, price: 15000 },
            { itemName: 'Donut Box', quantity: 1, price: 30000 },
          ]
        }),
        transaction_payments: [
          { payment_method: 'CASH', amount: 45000 }
        ],
        status: 'COMPLETED',
        isSyncedFromCMS: true,
        createdAt: new Date(Date.now() - 3600000), // 1 hour ago
        updatedAt: new Date(Date.now() - 3600000),
        source: 'cms'
      },
      {
        id: 'cms-002',
        order_number: 1002,
        total_amount: 75000, // 750 pesos
        customer_name: 'Jane Smith',
        customer_email: 'jane@example.com',
        orderDetailJSON: JSON.stringify({
          items: [
            { itemName: 'Latte', quantity: 2, price: 25000 },
            { itemName: 'Croissant', quantity: 3, price: 25000 },
          ]
        }),
        transaction_payments: [
          { payment_method: 'CARD', amount: 75000 }
        ],
        status: 'COMPLETED',
        isSyncedFromCMS: true,
        createdAt: new Date(Date.now() - 7200000), // 2 hours ago
        updatedAt: new Date(Date.now() - 7200000),
        source: 'cms'
      },
      {
        id: 'cms-003',
        order_number: 1003,
        total_amount: 120000, // 1200 pesos
        customer_name: 'Bob Johnson',
        customer_email: 'bob@example.com',
        orderDetailJSON: JSON.stringify({
          items: [
            { itemName: 'Iced Caramel Macchiato', quantity: 1, price: 40000 },
            { itemName: 'Bagel with Cream Cheese', quantity: 2, price: 40000 },
          ]
        }),
        transaction_payments: [
          { payment_method: 'CASH', amount: 120000 }
        ],
        status: 'COMPLETED',
        isSyncedFromCMS: true,
        createdAt: new Date(Date.now() - 10800000), // 3 hours ago
        updatedAt: new Date(Date.now() - 10800000),
        source: 'cms'
      },
      {
        id: 'cms-004',
        order_number: 1004,
        total_amount: 60000, // 600 pesos
        customer_name: 'Alice Williams',
        customer_email: 'alice@example.com',
        orderDetailJSON: JSON.stringify({
          items: [
            { itemName: 'Iced Tea', quantity: 1, price: 10000 },
            { itemName: 'Sandwich Combo', quantity: 1, price: 50000 },
          ]
        }),
        transaction_payments: [
          { payment_method: 'CARD', amount: 60000 }
        ],
        status: 'COMPLETED',
        isSyncedFromCMS: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        source: 'cms'
      }
    ];

    // Delete existing sample orders to prevent duplicates
    const result1 = await ordersCollection.deleteMany({
      order_number: { $in: [1001, 1002, 1003, 1004] }
    });

    // Insert sample orders
    const result2 = await ordersCollection.insertMany(sampleOrders);

    return NextResponse.json({
      success: true,
      message: 'Sample orders seeded successfully',
      deleted: result1.deletedCount,
      inserted: result2.insertedCount,
      orders: sampleOrders.map(o => ({ 
        order_number: o.order_number, 
        amount: o.total_amount / 100,
        customer: o.customer_name
      }))
    });
  } catch (error) {
    console.error('[SEED API] Error seeding orders:', error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
      },
      { status: 500 }
    );
  }
}

/**
 * GET to view seeding instructions
 */
export async function GET() {
  return NextResponse.json({
    message: 'POST to this endpoint to seed sample orders',
    endpoint: '/api/seed-orders',
    method: 'POST',
    description: 'Adds 4 sample orders to MongoDB for testing'
  });
}
