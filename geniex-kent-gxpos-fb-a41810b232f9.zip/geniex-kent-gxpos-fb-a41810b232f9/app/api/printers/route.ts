import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { getWorkstationId } from '@/src/lib/workstation';

/**
 * GET /api/printers - Get printer by workstation ID
 * POST /api/printers - Save printer configuration for a workstation
 */

export async function GET(request: NextRequest) {
  try {
    const db = await getDatabase();
    const workstationId = request.nextUrl.searchParams.get('workstationId') || getWorkstationId() || '001';
    
    const printer = await db.collection('printers').findOne({ workstationId });
    
    if (!printer) {
      return NextResponse.json({
        success: false,
        error: `No printer configured for workstation ${workstationId}`
      }, { status: 404 });
    }
    
    return NextResponse.json({
      success: true,
      printer: {
        workstationId: printer.workstationId,
        printerName: printer.printerName,
        printedVia: 'thermal' // thermal, network, or local
      }
    });
  } catch (error) {
    console.error('[Printers API] Error:', error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const db = await getDatabase();
    const body = await request.json();
    const { workstationId, printerName } = body;
    
    if (!workstationId || !printerName) {
      return NextResponse.json({
        success: false,
        error: 'Missing workstationId or printerName'
      }, { status: 400 });
    }
    
    const result = await db.collection('printers').updateOne(
      { workstationId },
      { $set: { workstationId, printerName, updatedAt: new Date() } },
      { upsert: true }
    );
    
    return NextResponse.json({
      success: true,
      message: 'Printer configuration saved',
      data: { workstationId, printerName }
    });
  } catch (error) {
    console.error('[Printers API] Error:', error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
