import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { COLLECTIONS } from '@/src/lib/mongodb-utils';

export const dynamic = 'force-dynamic';

/**
 * GET /api/debug/order-status
 * Check sync status of all orders
 */
export async function GET(request: NextRequest) {
  try {
    const db = await getDatabase();
    const transactionsCollection = db.collection(COLLECTIONS.TRANSACTIONS);

    // Get all transactions sorted by OrderNo
    const allTransactions = await transactionsCollection
      .find({})
      .sort({ OrderNo: 1 })
      .toArray();

    console.log('[ORDER-STATUS] Found', allTransactions.length, 'total transactions');

    const statusReport = allTransactions.map(t => ({
      OrderNo: t.OrderNo || t.orderNumber,
      isSynced: t.isSynced ?? 'not set',
      syncedAt: t.syncedAt || 'never',
      syncedToCMS: t.syncedToCMS ?? false,
      createdAt: t.createdAt,
      items: Array.isArray(t.items) ? t.items.length : 0,
      total: t.price?.eaterPayment ? (t.price.eaterPayment / 100).toFixed(2) : 0,
    }));

    // Separate by status
    const pending = statusReport.filter(t => t.isSynced === false);
    const synced = statusReport.filter(t => t.isSynced === true);
    const notSet = statusReport.filter(t => t.isSynced === 'not set');

    console.log('[ORDER-STATUS] Pending sync:', pending.map(t => t.OrderNo).join(', '));
    console.log('[ORDER-STATUS] Already synced:', synced.map(t => t.OrderNo).join(', '));
    console.log('[ORDER-STATUS] Not set:', notSet.map(t => t.OrderNo).join(', '));

    return NextResponse.json({
      success: true,
      total: allTransactions.length,
      pending: pending.length,
      synced: synced.length,
      notSet: notSet.length,
      pendingOrders: pending,
      syncedOrders: synced,
      notSetOrders: notSet,
      allOrders: statusReport,
    });
  } catch (error) {
    console.error('[ORDER-STATUS] Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Server error',
      },
      { status: 500 }
    );
  }
}
