import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase, COLLECTIONS } from '@/src/lib/mongodb-utils';

export const dynamic = 'force-dynamic';

/**
 * GET /api/debug/check-db
 * Simple debug endpoint to check what's in the database
 */
export async function GET(request: NextRequest) {
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  try {
    const db = await getDatabase();
    const transactionsCollection = db.collection(COLLECTIONS.TRANSACTIONS);

    // Count all transactions
    const totalCount = await transactionsCollection.countDocuments();

    // Get first 5 transactions
    const recent = await transactionsCollection
      .find({})
      .sort({ createdAt: -1, date: -1 })
      .limit(5)
      .toArray();

    // Get all collection names
    const collections = await db.listCollections().toArray();

    return NextResponse.json({
      success: true,
      database: {
        totalTransactions: totalCount,
        recentTransactions: recent,
        collectionNames: collections.map(c => c.name),
      }
    });
  } catch (error) {
    console.error('[DEBUG API] Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Server error',
      },
      { status: 500 }
    );
  }
}
