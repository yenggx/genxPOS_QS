import { NextResponse } from 'next/server';
// Adjust the import path to where your sok.ts is located
import { updateCmsOrderStatusOnly } from '@/src/api/sok'; 

export async function POST(request: Request) {
  try {
    const { orderId } = await request.json();
    
    if (!orderId) {
      return NextResponse.json({ error: 'Order ID is required' }, { status: 400 });
    }
    
    await updateCmsOrderStatusOnly(orderId);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('API Route Error:', error);
    return NextResponse.json({ error: 'Failed to close order status' }, { status: 500 });
  }
}