// api/kiosk-orders/route.ts
import { NextResponse } from 'next/server';
import { fetchAndSaveCmsOrders, updateCmsOrderToClosed } from '@/src/api/sok';
import { singleFlight } from '@/src/lib/singleflight';
import { getDatabase } from '@/src/lib/mongodb';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const orders = await singleFlight('kiosk-orders:list', () => fetchAndSaveCmsOrders());
    return NextResponse.json({ status: 'success', data: orders }, { status: 200 });
  } catch (error: any) {
    console.error('Error fetching kiosk orders:', error);
    return NextResponse.json({ status: 'error', message: error.message }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = await request.json();
    const { orderId, salesNumber, updatedCart, businessDate } = body;
    
    if (!orderId || !salesNumber) {
      return NextResponse.json({ status: 'error', message: 'Missing orderId or salesNumber' }, { status: 400 });
    }

    // 1. Update remote CMS order status
    await updateCmsOrderToClosed(orderId, salesNumber);
    
    // 2. Update local Kiosk Order to reflect the finalized items and/or businessDate
    if (updatedCart || businessDate) {
      try {
        const db = await getDatabase();
        
        // Find the order in cms_orders (or fallback to kiosk_orders depending on your architecture)
        let collectionName = 'cms_orders';
        let existingOrder = await db.collection(collectionName).findOne({ order_id: orderId });
        
        if (!existingOrder) {
          collectionName = 'kiosk_orders';
          existingOrder = await db.collection(collectionName).findOne({ order_id: orderId });
        }

        if (existingOrder) {
          const updatePayload: any = {};
          if (updatedCart) updatePayload.finalCart = updatedCart;
          if (businessDate) updatePayload.businessDate = businessDate;

          await db.collection(collectionName).updateOne(
            { order_id: orderId },
            { $set: updatePayload }
          );
        }
      } catch (dbErr) {
        console.error("Failed to update local CMS order:", dbErr);
      }
    }
    
    return NextResponse.json({ status: 'success' }, { status: 200 });
  } catch (error: any) {
    console.error('Error updating CMS order:', error);
    return NextResponse.json({ status: 'error', message: error.message }, { status: 500 });
  }
}