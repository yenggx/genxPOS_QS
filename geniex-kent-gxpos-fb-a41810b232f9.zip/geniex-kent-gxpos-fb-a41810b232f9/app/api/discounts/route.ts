import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase, COLLECTIONS } from '@/src/lib/mongodb-utils';
import axios from 'axios';

export const dynamic = 'force-dynamic';

const API_URL = process.env.NEXT_PUBLIC_API_URL;
const API_KEY = process.env.NEXT_PUBLIC_KEY;
const EXTERNAL_DISCOUNTS_URL = API_URL ? `${API_URL}/discounts` : '';

export async function GET(request: NextRequest) {
  // Initialize database on first request
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  try {
    const db = await getDatabase();
    const discountsCollection = db.collection(COLLECTIONS.DISCOUNTS);

    // Try to get cached discounts from database
    const cachedDiscounts = await discountsCollection.findOne({ cacheKey: 'discounts_cache' } as any);
    const now = Date.now();
    
    // If cache exists and is less than 1 hour old, return it
    if (cachedDiscounts && cachedDiscounts.cachedAt && now - cachedDiscounts.cachedAt < 3600000) {
      console.log('[API/DISCOUNTS] ✓ Returning cached discounts (', cachedDiscounts.data?.length || 0, 'items)');
      return NextResponse.json(cachedDiscounts.data || []);
    }

    // Otherwise, fetch from external API
    if (!EXTERNAL_DISCOUNTS_URL) {
      console.warn('[API/DISCOUNTS] ✗ NEXT_PUBLIC_API_URL not configured');
      return NextResponse.json([], { status: 200 });
    }

    console.log('[API/DISCOUNTS] 🔄 Cache expired or not found, fetching from external API');
    console.log('[API/DISCOUNTS] Endpoint:', EXTERNAL_DISCOUNTS_URL);
    
    const response = await fetch(EXTERNAL_DISCOUNTS_URL, {
      method: 'GET',
      headers: { 
        'Content-Type': 'application/json',
        'POS-API-KEY': API_KEY || '',
      },
      signal: AbortSignal.timeout(10000), // 10 second timeout
    });

    if (!response.ok) {
      console.warn('[API/DISCOUNTS] ✗ Failed to fetch from external API:', response.status, response.statusText);
      const errorBody = await response.text();
      console.error('[API/DISCOUNTS] Error response:', errorBody);
      // Return cached data if available, even if expired
      if (cachedDiscounts?.data) {
        console.log('[API/DISCOUNTS] ⚠️  Using expired cache as fallback');
        return NextResponse.json(cachedDiscounts.data);
      }
      return NextResponse.json([], { status: 200 });
    }

    let discountsData = await response.json();
    console.log('[API/DISCOUNTS] ✓ Raw response received');
    console.log('[API/DISCOUNTS] Response type:', typeof discountsData);
    console.log('[API/DISCOUNTS] Is array:', Array.isArray(discountsData));
    console.log('[API/DISCOUNTS] Response keys:', Object.keys(discountsData).slice(0, 5));
    
    // Handle different response formats
    let finalData: any[] = [];
    if (Array.isArray(discountsData)) {
      finalData = discountsData;
    } else if (discountsData && typeof discountsData === 'object') {
      // Check if data is wrapped in a property
      const possibleArrays = Object.values(discountsData).filter(v => Array.isArray(v));
      if (possibleArrays.length > 0) {
        finalData = possibleArrays[0] as any[];
        console.log('[API/DISCOUNTS] Found array in wrapped response');
      }
    }
    
    console.log('[API/DISCOUNTS] ✓ Processed', finalData.length, 'discounts from external API');
    if (finalData.length > 0) {
      console.log('[API/DISCOUNTS] First discount:', JSON.stringify(finalData[0]).substring(0, 200));
    }

    // Cache the discounts in database
    const updateResult = await discountsCollection.updateOne(
      { cacheKey: 'discounts_cache' } as any,
      {
        $set: {
          cacheKey: 'discounts_cache',
          data: Array.isArray(finalData) ? finalData : [],
          cachedAt: now,
          updatedAt: new Date(),
        },
      },
      { upsert: true }
    );

    console.log('[API/DISCOUNTS] 💾 Saved', finalData.length, 'discounts to MongoDB');
    if (updateResult.upsertedId) {
      console.log('[API/DISCOUNTS] ✓ New cache created with ID:', updateResult.upsertedId);
    } else if (updateResult.modifiedCount > 0) {
      console.log('[API/DISCOUNTS] ✓ Cache updated');
    }

    return NextResponse.json(finalData);
  } catch (error: any) {
    console.error('[API/DISCOUNTS] ✗ GET error:', {
      message: error.message,
      code: error.code,
      statusCode: error.status,
    });

    if (error.message?.includes('timeout') || error.code === 'ETIMEDOUT') {
      console.error('[API/DISCOUNTS] ⚠️  Request timed out - external API may be slow or offline');
    }

    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Error fetching discounts' },
      { status: 500 }
    );
  }
}

// Force refresh endpoint (POST)
export async function POST(request: NextRequest) {
  // Initialize database on first request
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  try {
    if (!EXTERNAL_DISCOUNTS_URL) {
      console.warn('[API/DISCOUNTS] NEXT_PUBLIC_API_URL not configured');
      return NextResponse.json([], { status: 200 });
    }

    console.log('[API/DISCOUNTS] 🔄 Force refresh from external API');
    console.log('[API/DISCOUNTS] Endpoint:', EXTERNAL_DISCOUNTS_URL);
    console.log('[API/DISCOUNTS] API Key configured:', !!API_KEY);
    
    const response = await fetch(EXTERNAL_DISCOUNTS_URL, {
      method: 'GET',
      headers: { 
        'Content-Type': 'application/json',
        'POS-API-KEY': API_KEY || '',
      },
      signal: AbortSignal.timeout(10000),
    });

    if (!response.ok) {
      console.warn('[API/DISCOUNTS] ✗ Failed to fetch from external API:', response.status, response.statusText);
      // Try to return cached data as fallback
      try {
        const db = await getDatabase();
        const discountsCollection = db.collection(COLLECTIONS.DISCOUNTS);
        const cachedDiscounts = await discountsCollection.findOne({ cacheKey: 'discounts_cache' } as any);
        if (cachedDiscounts?.data) {
          console.log('[API/DISCOUNTS] ⚠️  Returning cached data due to API failure');
          return NextResponse.json(cachedDiscounts.data || []);
        }
      } catch (cacheErr) {
        console.error('[API/DISCOUNTS] ✗ Failed to retrieve cache:', cacheErr);
      }
      return NextResponse.json([], { status: 200 });
    }

    const discountsData = await response.json();
    console.log('[API/DISCOUNTS] ✓ Raw response received from POST');
    console.log('[API/DISCOUNTS] Response type:', typeof discountsData);
    console.log('[API/DISCOUNTS] Is array:', Array.isArray(discountsData));
    
    // Handle different response formats
    let finalData: any[] = [];
    if (Array.isArray(discountsData)) {
      finalData = discountsData;
    } else if (discountsData && typeof discountsData === 'object') {
      // Check if data is wrapped in a property
      const possibleArrays = Object.values(discountsData).filter(v => Array.isArray(v));
      if (possibleArrays.length > 0) {
        finalData = possibleArrays[0] as any[];
        console.log('[API/DISCOUNTS] Found array in wrapped response');
      }
    }
    
    console.log('[API/DISCOUNTS] ✓ Processed', finalData.length, 'discounts from external API');
    if (finalData.length > 0) {
      console.log('[API/DISCOUNTS] First discount:', JSON.stringify(finalData[0]).substring(0, 200));
    }

    const db = await getDatabase();
    const discountsCollection = db.collection(COLLECTIONS.DISCOUNTS);

    // Update cache with fresh data
    const updateResult = await discountsCollection.updateOne(
      { cacheKey: 'discounts_cache' } as any,
      {
        $set: {
          cacheKey: 'discounts_cache',
          data: Array.isArray(finalData) ? finalData : [],
          cachedAt: Date.now(),
          updatedAt: new Date(),
        },
      },
      { upsert: true }
    );

    console.log('[API/DISCOUNTS] 💾 Saved', finalData.length, 'discounts to MongoDB');
    if (updateResult.upsertedId) {
      console.log('[API/DISCOUNTS] ✓ New cache created with ID:', updateResult.upsertedId);
    } else if (updateResult.modifiedCount > 0) {
      console.log('[API/DISCOUNTS] ✓ Cache updated');
    }

    return NextResponse.json(finalData);
  } catch (error: any) {
    console.error('[API/DISCOUNTS] ✗ Force refresh error:', {
      message: error.message,
      code: error.code,
      statusCode: error.status,
    });
    
    // Provide helpful error message
    if (error.message?.includes('timeout') || error.code === 'ETIMEDOUT') {
      console.error('[API/DISCOUNTS] ⚠️  Request timed out - external API may be slow or offline');
    }
    
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Error fetching discounts' },
      { status: 500 }
    );
  }
}
