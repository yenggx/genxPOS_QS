//inventory API route
import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase } from '@/src/lib/mongodb-utils';

export const dynamic = 'force-dynamic';

export async function GET() {
  await initializeDatabase().catch(console.error);
  try {
    const db = await getDatabase();
    const inventory = await db.collection('inventory').find({}).toArray();
    
    const state = inventory.reduce((acc, item) => ({ 
      ...acc, 
      [item.itemId]: item.quantity 
    }), {});

    return NextResponse.json(state);
  } catch (error) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  await initializeDatabase().catch(console.error);
  try {
    const db = await getDatabase();
    const collection = db.collection('inventory');
    const updates = await request.json();

    const operations = Object.entries(updates).map(([itemId, quantity]) => ({
      updateOne: {
        filter: { itemId },
        update: { $set: { itemId, quantity, updatedAt: new Date() } },
        upsert: true
      }
    }));

    if (operations.length > 0) {
      await collection.bulkWrite(operations);
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}