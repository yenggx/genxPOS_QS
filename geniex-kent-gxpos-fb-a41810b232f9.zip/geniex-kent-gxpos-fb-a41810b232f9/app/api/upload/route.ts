import { NextResponse } from 'next/server';
import { writeFile, mkdir } from 'fs/promises';
import { join } from 'path';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase } from '@/src/lib/mongodb-utils';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  try {
    // 1. Grab the file from the form data
    const formData = await req.formData();
    const file = formData.get('file') as File | null;

    if (!file) {
      return NextResponse.json({ error: "No file received." }, { status: 400 });
    }

    // 2. Convert file to buffer and create a safe, unique filename
    const buffer = Buffer.from(await file.arrayBuffer());
    const uniqueFilename = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;

    // 3. Define the path (public/uploads) and ensure the directory exists
    const uploadDir = join(process.cwd(), 'public', 'uploads');
    await mkdir(uploadDir, { recursive: true }).catch((err) => {
      // Ignore if folder already exists
      if (err.code !== 'EEXIST') throw err;
    });

    // 4. Save the physical file to the local disk
    const filePath = join(uploadDir, uniqueFilename);
    await writeFile(filePath, buffer);

    // This is the URL the browser will use to display the image/video
    const publicUrl = `/uploads/${uniqueFilename}`;

    // 5. Save the metadata to your new MongoDB "media" collection
    await initializeDatabase().catch((err: unknown) => console.error('DB init error:', err));
    const db = await getDatabase();
    
    const mediaRecord = {
      filename: uniqueFilename,
      originalName: file.name,
      url: publicUrl,
      mimeType: file.type,
      size: file.size,
      uploadedAt: new Date()
    };

    await db.collection('media').insertOne(mediaRecord);

    // 6. Return the URL so the frontend can immediately show it on the CFD
    return NextResponse.json({ 
      success: true, 
      url: publicUrl,
      media: mediaRecord 
    }, { status: 200 });

  } catch (error) {
    console.error("Upload API error:", error);
    return NextResponse.json({ error: "Failed to upload file." }, { status: 500 });
  }
}

export async function GET() {
  try {
    await initializeDatabase().catch((err: unknown) => console.error('DB init error:', err));
    const db = await getDatabase();
    const media = await db.collection('media')
      .find({})
      .sort({ uploadedAt: -1 })
      .toArray();
    return NextResponse.json({ success: true, media }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch media." }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { filename } = await req.json();
    if (!filename) return NextResponse.json({ error: "No filename." }, { status: 400 });

    // Remove from disk
    const { unlink } = await import('fs/promises');
    const filePath = join(process.cwd(), 'public', 'uploads', filename);
    await unlink(filePath).catch(() => {}); // ignore if already gone

    // Remove from DB
    await initializeDatabase().catch((err: unknown) => console.error('DB init error:', err));
    const db = await getDatabase();
    await db.collection('media').deleteOne({ filename });

    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ error: "Failed to delete media." }, { status: 500 });
  }
}
