import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { businessDayId, workstationId, entryType, timestamp, text, transactionId, sessionId } = body;

    if (!businessDayId || !entryType || !text) {
      return NextResponse.json({ error: 'businessDayId, entryType, and text are required' }, { status: 400 });
    }

    const db = await getDatabase();
    await db.collection('ejournal_entries').insertOne({
      businessDayId,
      workstationId: workstationId || '001',
      entryType,
      timestamp: timestamp || new Date().toISOString(),
      text,
      ...(transactionId && { transactionId }),
      ...(sessionId     && { sessionId }),
    });

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}