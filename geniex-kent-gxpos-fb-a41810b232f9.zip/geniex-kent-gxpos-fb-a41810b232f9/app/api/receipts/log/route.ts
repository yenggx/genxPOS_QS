import { NextRequest, NextResponse } from 'next/server';
import { saveReceiptLog, ReceiptType } from '@/src/lib/receipt-logger';
 
export async function POST(request: NextRequest) {
  try {
    const { text, type, ref, dateStr } = await request.json() as {
      text:    string;
      type:    ReceiptType;
      ref:     string;
      dateStr?: string;
    };
 
    if (!text || !type || !ref) {
      return NextResponse.json({ error: 'text, type, and ref are required' }, { status: 400 });
    }
 
    const result = saveReceiptLog(text, type, ref, dateStr);
    return NextResponse.json(result, { status: result.success ? 200 : 500 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
