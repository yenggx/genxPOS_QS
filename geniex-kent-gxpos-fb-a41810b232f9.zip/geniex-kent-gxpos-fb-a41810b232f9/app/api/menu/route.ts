import { NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase, COLLECTIONS } from '@/src/lib/mongodb-utils';
import axios from 'axios';

export const dynamic = 'force-dynamic';

const API_URL = process.env.NEXT_PUBLIC_API_URL;
const API_KEY = process.env.NEXT_PUBLIC_KEY;
const STORE_CODE = process.env.NEXT_PUBLIC_STORE_CODE;

export async function GET() {
  try {
    console.log('GET /api/menu - Initializing database...');

    try {
      await initializeDatabase();
      console.log('✅ Database initialized');
    } catch (initErr) {
      console.error('Database initialization failed:', initErr);
      throw initErr;
    }

    console.log('🔗 Getting database connection...');
    const db = await getDatabase();
    const menuCollection = db.collection(COLLECTIONS.MENU);
    console.log('Database connection established');

    const cachedMenu = await menuCollection.findOne({ id: 'menu' });

    // If no cache, fetch from API
    if (!cachedMenu && API_URL && API_KEY && STORE_CODE) {
      try {
        console.log('No cache found, fetching from external API:', API_URL);
        const response = await axios.get(`${API_URL}/menu/${STORE_CODE}`, {
          headers: {
            'POS-API-KEY': API_KEY,
          },
          timeout: 10000,
        });

        const menuData = response.data;
        console.log('Menu fetched from external API');

        // Clear old menu and save new one
        await menuCollection.deleteMany({});
        const result = await menuCollection.insertOne({
          id: 'menu',
          payload: menuData,
          updatedAt: new Date(),
        });

        return NextResponse.json({
          _id: result.insertedId,
          id: 'menu',
          payload: menuData,
          updatedAt: new Date(),
        });
      } catch (error: any) {
        console.error('Error fetching menu from external API:', error.message || error);
        console.log('Status Code:', error.response?.status);
        console.log('Error Details:', error.response?.data || error.code);
        
        // Return empty menu instead of error if we can't fetch
        return NextResponse.json(
          { 
            id: 'menu',
            payload: { categories: [] },
            error: 'Failed to fetch from external API - returning empty menu',
            errorDetails: {
              status: error.response?.status,
              message: error.message,
              code: error.code,
            },
          },
          { status: 200 }
        );
      }
    }

    if (cachedMenu) {
      console.log('Menu retrieved from cache');
    }
    return NextResponse.json(cachedMenu || { id: 'menu', payload: { categories: [] } });
  } catch (error) {
    console.error('Menu GET handler error:', error);
    const errorMessage =
      error instanceof Error ? error.message : String(error);
    return NextResponse.json(
      {
        error: errorMessage,
        details: error instanceof Error ? error.stack : undefined,
      },
      { status: 500 }
    );
  }
}

export async function POST() {
  try {
    console.log('POST /api/menu - Initializing database...');

    // Initialize database on first request
    try {
      await initializeDatabase();
      console.log('✅ Database initialized');
    } catch (initErr) {
      console.error('Database initialization failed:', initErr);
      throw initErr;
    }

    if (!API_URL || !API_KEY || !STORE_CODE) {
      console.error('Missing environment variables:', {
        API_URL: !!API_URL,
        API_KEY: !!API_KEY,
        STORE_CODE: !!STORE_CODE,
      });
      return NextResponse.json(
        { error: 'Missing API configuration' },
        { status: 400 }
      );
    }

    console.log('🔗 Getting database connection...');
    const db = await getDatabase();
    const menuCollection = db.collection(COLLECTIONS.MENU);
    console.log('Database connection established');

    console.log('Fetching menu from external API:', API_URL);
    const response = await axios.get(`${API_URL}/menu/${STORE_CODE}`, {
      headers: {
        'POS-API-KEY': API_KEY,
      },
      timeout: 100000, // 10 second timeout
    });

    const menuData = response.data;
    console.log('✓ Menu fetched from external API, items count:', menuData?.categories?.length || 0);

    // Delete old menu and insert new one
    console.log('Saving menu to MongoDB...');
    await menuCollection.deleteMany({});
    const result = await menuCollection.insertOne({
      id: 'menu',
      payload: menuData,
      updatedAt: new Date(),
    });

    console.log('Menu saved to MongoDB');

    return NextResponse.json(
      {
        _id: result.insertedId,
        id: 'menu',
        payload: menuData,
        updatedAt: new Date(),
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error('Menu POST handler error:', error);
    
    // If external API fails, check if we have cached data to return
    let cachedMenu = null;
    try {
      const db = await getDatabase();
      const menuCollection = db.collection(COLLECTIONS.MENU);
      cachedMenu = await menuCollection.findOne({ id: 'menu' });
    } catch (cacheErr) {
      console.error('Failed to retrieve cached menu:', cacheErr);
    }

    if (cachedMenu) {
      console.log('Using cached menu due to API failure');
      return NextResponse.json(cachedMenu, { status: 200 });
    }

    const errorMessage =
      error instanceof Error ? error.message : String(error);
    
    // Provide detailed error diagnostics
    console.error('Error Details:', {
      message: errorMessage,
      status: error.response?.status,
      statusText: error.response?.statusText,
      code: error.code,
      url: error.config?.url,
    });

    return NextResponse.json(
      {
        error: errorMessage,
        errorType: error.code || error.name || 'Unknown Error',
        statusCode: error.response?.status,
        details: {
          message: error.message,
          endpoint: error.config?.url,
          statusText: error.response?.statusText,
          code: error.code,
        },
        suggestion: 
          error.response?.status === 500 
            ? 'External API returned 500 - the CMS API server may be down'
            : error.code === 'ECONNREFUSED'
              ? 'Connection refused - verify API_URL is correct and server is running'
              : error.code === 'ENOTFOUND'
                ? 'DNS resolution failed - check API_URL domain'
                : 'Check API credentials and server status',
      },
      { status: 500 }
    );
  }
}
