import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase, COLLECTIONS } from '@/src/lib/mongodb-utils';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  // Initialize database on first request
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  try {
    const { searchParams } = new URL(request.url);
    const workstationId = searchParams.get('workstationId');

    console.log('[API/CART] GET - workstationId:', workstationId);

    if (!workstationId) {
      return NextResponse.json(
        { error: 'Missing workstationId parameter' },
        { status: 400 }
      );
    }

    const db = await getDatabase();
    const cartCollection = db.collection(COLLECTIONS.CARTS);

    // Try to find by workstationId first, then by sessionId for backward compatibility
    let cartData = await cartCollection.findOne({ workstationId });
    console.log('[API/CART] GET - found by workstationId:', !!cartData);
    if (!cartData) {
      cartData = await cartCollection.findOne({ sessionId: workstationId });
      console.log('[API/CART] GET - found by sessionId:', !!cartData);
    }

    if (!cartData) {
      console.log('[API/CART] GET - no cart found');
      return NextResponse.json(null);
    }

    console.log('[API/CART] GET - returning cart with', cartData.items?.length || 0, 'items');
    return NextResponse.json(cartData);
  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Database error',
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  // Initialize database on first request
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  try {
    const { searchParams } = new URL(request.url);
    const workstationId = searchParams.get('workstationId');

    if (!workstationId) {
      return NextResponse.json(
        { error: 'Missing workstationId parameter' },
        { status: 400 }
      );
    }

    const db = await getDatabase();
    const cartCollection = db.collection(COLLECTIONS.CARTS);
    const body = await request.json();

    console.log('[API/CART] POST - saving', body.items?.length || 0, 'items');

    // Upsert cart (insert if not exists, update if exists)
    const result = await cartCollection.updateOne(
      { workstationId },
      {
        $set: {
          id: workstationId,
          workstationId,
          items: body.items || [],
          appliedDiscount: body.appliedDiscount || null,
          updatedAt: new Date(),
        },
      },
      { upsert: true }
    );

    console.log('[API/CART] POST - result:', result.matchedCount, 'matched,', result.modifiedCount, 'modified');

    return NextResponse.json(
      {
        acknowledged: result.acknowledged,
        modifiedCount: result.modifiedCount,
        upsertedId: result.upsertedId,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Database error',
      },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  // Initialize database on first request
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  try {
    const { searchParams } = new URL(request.url);
    const workstationId = searchParams.get('workstationId');

    if (!workstationId) {
      return NextResponse.json(
        { error: 'Missing workstationId parameter' },
        { status: 400 }
      );
    }

    const db = await getDatabase();
    const cartCollection = db.collection(COLLECTIONS.CARTS);

    // Delete both by workstationId and old sessionId field for cleanup
    const result = await cartCollection.deleteOne({ workstationId });
    // Also try to clean up old records stored with sessionId field
    await cartCollection.deleteOne({ sessionId: workstationId });

    return NextResponse.json(
      {
        deletedCount: result.deletedCount,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Database error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Database error',
      },
      { status: 500 }
    );
  }
}
