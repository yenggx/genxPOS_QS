// app/api/reports/esf/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { COLLECTIONS, initializeDatabase } from '@/src/lib/mongodb-utils';
import { buildEsfRows, esfRowsToCsv } from '@/src/libs/EsfGenerator';
import fs   from 'fs';
import path from 'path';

// ─── POST ──────────────────────────────────────────────────────────────────────

export async function POST(req: NextRequest) {
  await initializeDatabase().catch((err) => console.error('DB init error:', err));
  try {
    const body = await req.json() as {
      date:           string;
      businessDayId?: string;
      workstationId?: string;
      transactions:   Record<string, any>[];
      closedSessions: Record<string, any>[];
      outletName?:    string;
      catMap?:        Record<string, string>;
      zCounter?:      number;
    };

    const {
      date, businessDayId, workstationId = '001',
      transactions, closedSessions,
      outletName = '',           
      catMap = {},               
      zCounter,
    } = body;

    if (!date || !Array.isArray(transactions)) {
      return NextResponse.json(
        { success: false, error: 'date and transactions are required' },
        { status: 400 }
      );
    }
    
    const rows = buildEsfRows(transactions, closedSessions ?? [], workstationId, outletName, catMap, date);
    const csvBlob = esfRowsToCsv(rows);

    const db   = await getDatabase();
    const coll = db.collection('esfReports');
    const stores = db.collection('stores');
    const storeInfo = await stores.findOne({id: "store_data"});

    // Extract Store ID for CMS
    const storeId = storeInfo?.payload?.data?.StoreID || storeInfo?.payload?.StoreID || storeInfo?.payload?.store_id || 'UNKNOWN';

    // ==========================================
    // CMS SYNC LOGIC
    // ==========================================
    let isSynced = false;
    let cmsResponse: any = null;
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000); // 8-second timeout

      const storeId = process.env.NEXT_PUBLIC_STORE_CODE || '';
      const payload = {
        store_id: storeId,
        terminal_id: workstationId,
        report_type: 'ESF',
        date: date,
        generated_at: new Date().toISOString(),
        report_data: { rows, csv: csvBlob },
        upload_type: 'CSV',
        generated_platform: 'gXPOS',
      };
      console.log("ESF payload", payload)
      

      console.log(`[CMS SYNC] Sending ESF to CMS...`);
      const baseRoute = process.env.NEXT_PUBLIC_API_URL || '';
      const auth = process.env.NEXT_PUBLIC_KEY || '';

      const res = await fetch(`${baseRoute}/send/gxpos/reports`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json', 
          'POS-API-KEY': auth 
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      const text = await res.text();
      try { cmsResponse = JSON.parse(text); } catch { cmsResponse = text; }
      isSynced = res.ok;
    } catch (err: any) {
      console.error(`[CMS SYNC ERROR] ESF:`, err.message);
      cmsResponse = { error: err.message };
    }

    const filter: Record<string, string> = businessDayId
      ? { businessDayId }
      : { date };

    const doc = {
      ...filter,
      date,
      businessDayId: businessDayId ?? null,
      zCounter:      zCounter ?? null,
      workstationId,
      rowCount:  rows.length,
      rows,
      csv:       csvBlob,
      isSynced,          // Track Sync Status
      cmsResponse,       // Track Sync Response
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await coll.updateOne(filter, { $set: doc }, { upsert: true });

    // ── Write to local folder as .txt (content is CSV-formatted) ──────────────
    let filePath: string | null = null;
    try {
      const esfDir = path.join(process.cwd(), 'esf-reports');
      if (!fs.existsSync(esfDir)) fs.mkdirSync(esfDir, { recursive: true });
      //<STORENAME>YYYYMMDDESF
      const storeName = storeInfo?.payload?.data?.name ?? "StoreName";
      const fileName = `${storeName}${date.replaceAll('-', '')}ESF.txt`;
      filePath = path.join(esfDir, fileName);
      fs.writeFileSync(filePath, csvBlob, 'utf-8');
    } catch (fileErr) {
      // Non-fatal — DB record already saved
      console.error('[ESF file write failed]', fileErr);
    }

    return NextResponse.json({ success: true, rowCount: rows.length, filePath, isSynced });
  } catch (err: any) {
    console.error('[ESF POST]', err);
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

// ─── GET ──────────────────────────────────────────────────────────────────────

export async function GET(req: NextRequest) {
  await initializeDatabase().catch((err) => console.error('DB init error:', err));
  try {
    const { searchParams } = new URL(req.url);
    const date          = searchParams.get('date');
    const businessDayId = searchParams.get('businessDayId');
    const workstationId = searchParams.get('workstationId') ?? '001';
    const format        = searchParams.get('format') ?? 'json';

    if (!date && !businessDayId) {
      return NextResponse.json(
        { success: false, error: 'Provide ?date=YYYY-MM-DD or ?businessDayId=' },
        { status: 400 }
      );
    }

    const db   = await getDatabase();
    const coll = db.collection('esfReports');

    const filter: Record<string, string> = businessDayId
      ? { businessDayId }
      : { date: date! };

    let doc = await coll.findOne(filter, { projection: { _id: 0 } });

    // ── Filesystem fallback: read .txt file if MongoDB has no record ──────────
    if (!doc && date) {
      const esfDir = path.join(process.cwd(), 'esf-reports');

      // Try exact workstationId first, then glob any matching date
      let txtPath: string | null = null;
      const exactPath = path.join(esfDir, `ESF_${date}_${workstationId}.txt`);
      if (fs.existsSync(exactPath)) {
        txtPath = exactPath;
      } else if (fs.existsSync(esfDir)) {
        // Find any file matching ESF_<date>_*.txt
        const match = fs.readdirSync(esfDir)
          .find(f => f.startsWith(`ESF_${date}_`) && f.endsWith('.txt'));
        if (match) txtPath = path.join(esfDir, match);
      }

      if (txtPath) {
        const csvContent = fs.readFileSync(txtPath, 'utf-8');
        const lines = csvContent.split('\n').filter(l => l.trim().length > 0);

        if (lines.length > 1) {
          // Parse CSV — handle quoted fields
          const parseRow = (line: string): string[] => {
            const result: string[] = [];
            let cur = '', inQuote = false;
            for (let i = 0; i < line.length; i++) {
              const ch = line[i];
              if (ch === '"') { inQuote = !inQuote; }
              else if (ch === ',' && !inQuote) { result.push(cur.trim()); cur = ''; }
              else { cur += ch; }
            }
            result.push(cur.trim());
            return result;
          };

          // Header normalization — maps whatever the CSV uses → field names the frontend expects
          const HEADER_MAP: Record<string, string> = {
            // common variations for each field
            'terminal':          'terminal',
            'terminal#':         'terminal',
            'terminal no':       'terminal',
            'terminalid':        'terminal',

            'shift':             'shift',
            'shift#':            'shift',
            'shiftno':           'shift',
            'shiftnumber':       'shift',

            'cashier':           'cashierName',
            'cashiername':       'cashierName',
            'staffname':         'cashierName',

            'itemcode':          'itemCode',
            'item code':         'itemCode',
            'sku':               'itemCode',
            'barcode':           'itemCode',

            'description':       'itemDescription',
            'itemdescription':   'itemDescription',
            'item description':  'itemDescription',
            'productname':       'itemDescription',
            'item name':         'itemDescription',

            'sellingprice':      'sellingPrice',
            'selling price':     'sellingPrice',
            'price':             'sellingPrice',
            'unitprice':         'sellingPrice',

            'qty':               'qty',
            'quantity':          'qty',

            'regulardiscount':   'regularDiscount',
            'regular discount':  'regularDiscount',
            'reg discount':      'regularDiscount',
            'discount':          'regularDiscount',

            'discountwovat':     'discountWoVat',
            'disc w/o vat':      'discountWoVat',
            'disc wo vat':       'discountWoVat',

            'percentagediscount':'percentageDiscount',
            '% disc':            'percentageDiscount',
            '%disc':             'percentageDiscount',
            'discountpercent':   'percentageDiscount',

            'vatexempt':         'vatExempt',
            'vat exempt':        'vatExempt',
            'exemptamount':      'vatExempt',

            'deliverycharge':    'deliveryCharge',
            'delivery charge':   'deliveryCharge',
            'del charge':        'deliveryCharge',

            'amountdue':         'amountDue',
            'amount due':        'amountDue',
            'total':             'amountDue',

            'sino':              'siNo',
            'si no':             'siNo',
            'si no / txn no':    'siNo',
            'salesnumber':       'siNo',
            'invoiceno':         'siNo',
            'txnno':             'siNo',

            'vatamount':         'vatAmount',
            'vat amount':        'vatAmount',
            'vat':               'vatAmount',

            'netprice':          'netPrice',
            'net price':         'netPrice',
            'netsales':          'netPrice',

            'transtype':         'transType',
            'trans type':        'transType',
            'transactiontype':   'transType',
            'type':              'transType',

            'disctype':          'discType',
            'disc type':         'discType',
            'discounttype':      'discType',
          };

          const normalizeHeader = (h: string) =>
            HEADER_MAP[h.toLowerCase().trim()] ?? h.toLowerCase().trim();

          const headers = parseRow(lines[0]).map(normalizeHeader);
          const rows = lines.slice(1).map(line => {
            const vals = parseRow(line);
            return Object.fromEntries(headers.map((h, i) => [h, vals[i] ?? '']));
          });


          // Backfill MongoDB so future GETs are instant
          const backfillDoc = {
            date,
            workstationId,
            rowCount: rows.length,
            rows,
            csv: csvContent,
            source: 'txt-fallback',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          await coll.updateOne(filter, { $set: backfillDoc }, { upsert: true }).catch(() => {});

          doc = backfillDoc as any;
        }
      }
    }

    if (!doc) {
      return NextResponse.json(
        { success: false, error: 'ESF report not found for the given filter.' },
        { status: 404 }
      );
    }

    if (format === 'csv' || format === 'txt') {
      return new NextResponse(doc.csv as string, {
        status: 200,
        headers: {
          'Content-Type':        'text/plain',
          'Content-Disposition': `attachment; filename="ESF_${doc.date}.txt"`,
        },
      });
    }

    // Flatten so frontend can access doc.rows directly
    return NextResponse.json({ success: true, ...doc });
  } catch (err: any) {
    console.error('[ESF GET]', err);
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}