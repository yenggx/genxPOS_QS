// app/api/reports/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase } from '@/src/lib/mongodb-utils';
import { generateAndSaveEJournal } from '@/src/lib/ejournal';

export async function POST(request: NextRequest) {
  await initializeDatabase().catch((err) => console.error('DB init error:', err));

  try {
    const body = await request.json();
    const { reportType, date, workstationId, staffId, staffName, content, sessionId } = body;

    if (!date || !reportType) {
      return NextResponse.json({ error: 'Date and reportType are required' }, { status: 400 });
    }

    const db = await getDatabase();
    const reportsCollection = db.collection('reports');

    const reportData = {
      reportType,
      date,
      generatedAt: new Date().toISOString(),
      workstationId: workstationId || "001",
      staffId,
      staffName,
      content,
      ...(sessionId && { sessionId })
    };

    await reportsCollection.insertOne(reportData);

    let ejResult = null;
    if (reportType === 'Z-READING') {
      ejResult = await generateAndSaveEJournal(date, workstationId || "001");
      if (!ejResult?.success) {
        console.error("E-Journal failed but Z-Reading saved:", ejResult?.error);
      }
    }

    return NextResponse.json({ 
      success: true, 
      report: reportData,
      ejournal: ejResult 
    }, { status: 200 });

  } catch (error: any) {
    console.error('Reports API Error:', error);
    return NextResponse.json({ error: 'Server error: ' + error.message }, { status: 500 });
  }
}

