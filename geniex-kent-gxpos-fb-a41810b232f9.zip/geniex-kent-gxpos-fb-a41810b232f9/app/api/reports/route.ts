// app/api/reports/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase } from '@/src/lib/mongodb-utils';
import { generateAndSaveEJournal } from '@/src/lib/ejournal';

// Helper to sync with CMS
async function syncReportToCMS(storeId: string, terminalId: string, reportType: string, date: string, content: any, textContent?: string) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);

    const isTextReport = ['X-READING', 'Y-READING', 'Z-READING', 'E-SHIFT'].includes(reportType);
    const uploadType = isTextReport ? 'TEXTFILE' : 'CSV';

    console.log(`[CMS SYNC] Sending ${reportType} to CMS... (Format: ${uploadType})`);
    const baseRoute = process.env.NEXT_PUBLIC_API_URL || '';
    const auth = process.env.NEXT_PUBLIC_KEY || '';

    let body: any;
    const headers: any = {
      'POS-API-KEY': auth
    };

    if (isTextReport) {
      // Build FormData for multipart upload with a physical text file
      const formData = new FormData();
      formData.append('store_id', storeId);
      formData.append('terminal_id', terminalId);
      formData.append('report_type', reportType);
      formData.append('date', date);
      formData.append('generated_at', new Date().toISOString());
      formData.append('upload_type', 'TEXTFILE');
      formData.append('generated_platform', 'gXPOS');

      // Convert the text string into a Blob
      const fileString = textContent || JSON.stringify(content, null, 2);
      const blob = new Blob([fileString], { type: 'text/plain' });
      formData.append('textfile', blob, `${reportType}_${date}.txt`);

      body = formData;
      // Note: Do NOT set Content-Type for FormData, Node fetch sets the proper multipart boundary automatically
    } else {
      // Build standard JSON for CSV records
      const payload = {
        store_id: storeId,
        terminal_id: terminalId,
        report_type: reportType,
        date: date,
        generated_at: new Date().toISOString(),
        report_data: content,
        upload_type: 'CSV',
        generated_platform: 'gXPOS',
      };
      body = JSON.stringify(payload);
      headers['Content-Type'] = 'application/json';
    }

    const res = await fetch(`${baseRoute}/send/gxpos/reports`, {
      method: 'POST',
      headers,
      body,
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    let data;
    const text = await res.text();
    try { data = JSON.parse(text); } catch { data = text; }

    return { isSynced: res.ok, cmsResponse: data };
  } catch (err: any) {
    console.error(`[CMS SYNC ERROR] ${reportType}:`, err.message);
    return { isSynced: false, cmsResponse: { error: err.message } };
  }
}

export async function POST(request: NextRequest) {
  await initializeDatabase().catch((err) => console.error('DB init error:', err));

  try {
    const { reportType, date, workstationId, staffId, staffName, content, businessDayId, sessionId, textContent } = await request.json();
    console.log("SAVING REPORT TYPE[", reportType, "]");

    if (!reportType || !date) {
      return NextResponse.json({ error: 'Report type and date are required' }, { status: 400 });
    }
    const db = await getDatabase();
    const storeId = process.env.NEXT_PUBLIC_STORE_CODE || '';
    
    // Attempt to sync to the CMS
    const { isSynced, cmsResponse } = await syncReportToCMS(
      storeId,
      workstationId || "001",
      reportType,
      date,
      content,
      textContent
    );

    // Build the DB Document
    const reportData: Record<string, any> = {
      reportType,
      date,
      generatedAt: new Date().toISOString(),
      workstationId: workstationId || "001",
      generatedBy: { staffId, staffName },
      businessDayId,
      content,
      isSynced,
      cmsResponse
    };

    if (sessionId) reportData.sessionId = sessionId;

    const reportsCollection = db.collection('reports');
    await reportsCollection.insertOne(reportData);

    let ejResult = null;
    if (reportType === 'Z-READING') {
      ejResult = await generateAndSaveEJournal(date, workstationId || "001");
      if (!ejResult.success) {
        console.error("E-Journal failed but Z-Reading saved:", ejResult.error);
      }
    }

    return NextResponse.json({
      success: true,
      reportId: reportData._id,
      isSynced,
      ...(ejResult && { ejournal: ejResult })
    }, { status: 200 });

  } catch (error: any) {
    console.error('Report Save Error:', error);
    return NextResponse.json({ error: 'Server error: ' + error.message }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  await initializeDatabase().catch((err) => console.error('DB init error:', err));

  try {
    const { searchParams } = new URL(request.url);
    const reportType    = searchParams.get('type');
    const date          = searchParams.get('date');
    const from          = searchParams.get('from');
    const to            = searchParams.get('to');
    const workstationId = searchParams.get('workstationId');
    const sessionId     = searchParams.get('sessionId');
    const businessDayId = searchParams.get('businessDayId');

    if (!reportType) {
      return NextResponse.json({ error: 'type is required' }, { status: 400 });
    }

    const db = await getDatabase();
    const reportsCollection = db.collection('reports');

    const query: Record<string, any> = { reportType };
    
    // Support Date Range Queries
    if (from && to) {
      query.date = { $gte: from, $lte: to };
    } else if (date) {
      query.date = date;
    }
    
    if (workstationId)  query.workstationId = workstationId;
    if (sessionId)      query.sessionId     = sessionId;
    if (businessDayId)  query.businessDayId = businessDayId;

    // If 'from' and 'to' are provided, return ALL matching reports to be combined
    if (from && to) {
      const reports = await reportsCollection
        .find(query)
        .sort({ date: 1, generatedAt: -1 })
        .toArray();

      return NextResponse.json({ success: true, reports });
    }

    // X-READING returns all records for the date (one per shift)
    // Everything else returns only the latest
    if (['X-READING', 'Z-READING', 'E-SHIFT', 'Y-READING'].includes(reportType) && !sessionId) {
      const reports = await reportsCollection
        .find(query)
        .sort({ generatedAt: -1 })
        .toArray();

      return NextResponse.json({ success: true, reports });
    }

    const report = await reportsCollection
      .find(query)
      .sort({ generatedAt: -1 })
      .limit(1)
      .toArray();

    return NextResponse.json({
      success: true,
      report: report[0] || null,
    });

  } catch (error: any) {
    console.error('Reports GET Error:', error);
    return NextResponse.json({ error: 'Server error: ' + error.message }, { status: 500 });
  }
}