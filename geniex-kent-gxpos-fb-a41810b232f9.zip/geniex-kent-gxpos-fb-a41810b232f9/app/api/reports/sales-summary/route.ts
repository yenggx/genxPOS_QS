// app/api/reports/sales-summary/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase } from '@/src/lib/mongodb-utils';
import fs from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

const safePesos = (v: number) => (v || 0) / 100;
const formatAmt = (v: number) => parseFloat((v || 0).toFixed(4));

export async function POST(req: NextRequest) {
  await initializeDatabase().catch((err) => console.error('DB init error:', err));
  
  try {
    const body = await req.json();
    const { 
      date, 
      transactions = [], 
      closedSessions = [], 
      businessDayId, 
      workstationId = '001', 
      staffId = 'AGGREGATE', 
      staffName = 'SYSTEM' 
    } = body;

    if (!date) {
      return NextResponse.json({ error: 'Date is required' }, { status: 400 });
    }

    const db = await getDatabase();
    const reportsCollection = db.collection('reports');
    const terminalsCollection = db.collection('terminals');
    const zRecordsCollection = db.collection('zRecords');

    const terminals = await terminalsCollection.find({ status: 'REGISTERED' }).toArray();
    const posNumbers = terminals.map(t => t.pos_number).filter(Boolean);
    
    if (posNumbers.length === 0) {
      const uniqueTids = new Set<string>();
      closedSessions.forEach((s: any) => uniqueTids.add(s.openedAtTerminal || '001'));
      transactions.forEach((tx: any) => uniqueTids.add(tx.workstationId || '001'));
      if (uniqueTids.size > 0) {
        posNumbers.push(...Array.from(uniqueTids));
      } else {
        posNumbers.push('001');
      }
    }

    const sessionMap = new Map();
    closedSessions.forEach((s: any) => {
      sessionMap.set(s.sessionId, s);
    });

    const reportRows: any[] = [];

    for (const posNumber of posNumbers.sort()) {
      const terminalTx = transactions.filter((tx: any) => {
        const tId = sessionMap.get(tx.sessionId)?.openedAtTerminal || tx.workstationId || tx.KioskNo || '001';
        return tId === posNumber;
      });

      let gross = 0;
      let otherCharges = 0;
      let discounts = 0;
      let deductions = 0;
      let returns = 0;
      let vatable = 0;
      let vatAmount = 0;
      let vatExempt = 0;
      let zeroRated = 0;
      let netAmount = 0;

      const validSalesTx = terminalTx.filter((t: any) => t.salesNumber || t.transactionNumber);
      const salesNumbers = validSalesTx.map((t: any) => String(t.salesNumber || t.transactionNumber).trim()).sort();
      
      let fromSN = '0';
      let toSN = '0';
      
      if (salesNumbers.length > 0) {
        const firstNumStr = salesNumbers[0];
        const lastNumStr = salesNumbers[salesNumbers.length - 1];
        
        const firstNumMatch = firstNumStr.match(/\d+$/);
        if (firstNumMatch) {
          const prevNum = Math.max(0, parseInt(firstNumMatch[0], 10) - 1);
          const prevNumStr = String(prevNum).padStart(firstNumMatch[0].length, '0');
          const prefix = firstNumStr.substring(0, firstNumStr.length - firstNumMatch[0].length);
          fromSN = `${posNumber}-${prefix}${prevNumStr}`;
        } else {
          fromSN = `${posNumber}-${firstNumStr}`;
        }
        
        toSN = `${posNumber}-${lastNumStr}`;
      } else {
        const lastTx = await db.collection('transactions').findOne(
          { $or: [{ workstationId: posNumber }, { KioskNo: posNumber }], salesNumber: { $exists: true, $ne: null, $ne: "" } },
          { sort: { _id: -1 } }
        );
        if (lastTx && lastTx.salesNumber) {
           const sn = String(lastTx.salesNumber).trim();
           fromSN = `${posNumber}-${sn}`;
           toSN = `${posNumber}-${sn}`;
        } else {
           fromSN = `${posNumber}-000000000000000`;
           toSN = `${posNumber}-000000000000000`;
        }
      }

      for (const tx of terminalTx) {
        const isRefund = tx.status === 'refunded' || tx.orderState === 'REFUNDED';
        const isVoid   = tx.status === 'voided'   || tx.orderState === 'VOIDED';

        if (isVoid) continue; 

        let txGross = 0;
        let txOther = 0;
        
        for (const item of (tx.items || tx.cart || [])) {
          const qty = item.quantity || item.qty || 1;
          txGross += safePesos(item.price || 0) * qty;

          for (const mod of (item.modifiers || item.selectedModifiers || [])) {
            let modPesos = 0;
            if (mod.price && mod.price >= 10000 && mod.price % 100 === 0) {
              modPesos = mod.price / 10000;
            } else {
              modPesos = safePesos(mod.price || 0);
            }
            const modQty = mod.quantity || mod.qty || 1;
            txOther += modPesos * modQty;
          }
        }

        const trueGross = txGross + txOther;

        if (isRefund) {
          returns += trueGross; 
        } else {
          gross += trueGross;
          otherCharges += txOther;
          const txDiscount = safePesos(tx.discountAmount || 0);
          discounts += txDiscount;
          
          const exemptAmt = safePesos(tx.price?.VatExSales || 0);
          const zeroAmt   = safePesos(tx.price?.ZeroRated || 0);
          
          vatable += safePesos(tx.price?.VATSale || 0);
          vatAmount += safePesos(tx.price?.VatAmount || tx.price?.tax || 0);
          vatExempt += exemptAmt;
          zeroRated += zeroAmt;

          const txType = String(tx.transactionType || tx.TransactionType || '').toUpperCase();
          if (['SC', 'SRC', 'PWD', 'SRPWD', 'DIPLOMAT', 'PEZA'].includes(txType)) {
             deductions += (exemptAmt + zeroAmt) * 0.12;
          }

          netAmount += (trueGross - txDiscount);
        }
      }

      let beginning = 0;
      let ending = 0;
      
      const todayZ = await reportsCollection.findOne(
        { reportType: 'Z-READING', workstationId: posNumber, date },
        { sort: { generatedAt: -1 } }
      );
      const todayY = await reportsCollection.findOne(
        { reportType: 'Y-READING', workstationId: posNumber, date },
        { sort: { generatedAt: -1 } }
      );

      if (todayZ && todayZ.content?.grandTotals) {
         beginning = todayZ.content.grandTotals.oldGrandTTL || todayZ.content.grandTotals.oldGT || 0;
         ending = todayZ.content.grandTotals.newGrandTTL || todayZ.content.grandTotals.newGT || 0;
      } else if (todayY && todayY.content?.grandTotals) {
         beginning = todayY.content.grandTotals.oldGrandTTL || todayY.content.grandTotals.oldGT || 0;
         ending = todayY.content.grandTotals.newGrandTTL || todayY.content.grandTotals.newGT || 0;
      } else {
         const prevReport = await reportsCollection.findOne(
           { reportType: { $in: ['Z-READING', 'Y-READING'] }, workstationId: posNumber, date: { $lt: date } },
           { sort: { date: -1, generatedAt: -1 } }
         );
         beginning = prevReport?.content?.grandTotals?.newGrandTTL || prevReport?.content?.grandTotals?.newGT || 0;
         ending = beginning + gross; 
      }

      let zCount = 0;
      const zRecord = await zRecordsCollection.findOne(
        { workstationId: posNumber, date },
        { sort: { _id: -1 } }
      );
      
      if (zRecord && zRecord.zCounter) {
        zCount = Number(zRecord.zCounter);
      } else if (todayZ?.content?.zCounter) {
        zCount = Number(todayZ.content.zCounter);
      }

      reportRows.push({
        DATE: date,
        FROM: fromSN,
        TO: toSN,
        BEGINNING: formatAmt(beginning),
        ENDING: formatAmt(ending),
        NET_AMOUNT: formatAmt(netAmount),
        DISCOUNTS: formatAmt(discounts),
        DEDUCTIONS: formatAmt(deductions),
        RETURNS: formatAmt(returns),
        VOIDS: 0,
        OTHER_CHARGES: formatAmt(otherCharges),
        GROSS_AMOUNT: formatAmt(gross),
        VATABLE_SALES: formatAmt(vatable),
        VAT_AMOUNT: formatAmt(vatAmount),
        VAT_EXEMPT_SALES: formatAmt(vatExempt),
        ZERO_RATED_SALES: formatAmt(zeroRated),
        SALES_OVERRUN: 0,
        Z_COUNT: zCount,
        REMARKS: ''
      });
    }

    const COLUMNS = [
      'DATE', 'FROM', 'TO', 'BEGINNING', 'ENDING', 'NET AMOUNT', 
      'DISCOUNTS', 'DEDUCTIONS', 'RETURNS', 'VOIDS', 'OTHER CHARGES', 
      'GROSS AMOUNT', 'VATABLE SALES', 'VAT AMOUNT', 'VAT-EXEMPT SALES', 
      'ZERO RATED SALES', 'SALES OVERRUN', 'Z-COUNT', 'REMARKS'
    ];

    const escape = (v: any) => {
      const s = String(v ?? '');
      return s.includes(',') || s.includes('"') || s.includes('\n') ? `"${s.replace(/"/g, '""')}"` : s;
    };

    const headerLine1 = 'BIR SALES SUMMARY REPORT,,,,,,,,,,,,,,,,,,';
    const headerLine2 = COLUMNS.join(',');
    const emptyLine   = ',,,,,,,,,,,,,,,,,,';
    
    const dataLines = reportRows.map(r => [
      r.DATE, r.FROM, r.TO, r.BEGINNING, r.ENDING, r.NET_AMOUNT,
      r.DISCOUNTS, r.DEDUCTIONS, r.RETURNS, r.VOIDS, r.OTHER_CHARGES,
      r.GROSS_AMOUNT, r.VATABLE_SALES, r.VAT_AMOUNT, r.VAT_EXEMPT_SALES,
      r.ZERO_RATED_SALES, r.SALES_OVERRUN, r.Z_COUNT, r.REMARKS
    ].map(escape).join(','));

    const csvContent = [headerLine1, headerLine2, emptyLine, ...dataLines].join('\r\n');
    const contentPayload = { rows: reportRows, csv: csvContent };

    const storeDoc = await db.collection('store').findOne({});
    const storeId = storeDoc?.payload?.StoreID || storeDoc?.payload?.store_id || storeDoc?.payload?.data?.StoreID || 'UNKNOWN';

    let isSynced = false;
    let cmsResponse: any = null;
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000); 

      const payload = {
        store_id: process.env.NEXT_PUBLIC_STORE_CODE || '',
        terminal_id: workstationId,
        report_type: 'SALES-SUMMARY',
        date: date,
        generated_at: new Date().toISOString(),
        report_data: contentPayload,
        upload_type: 'CSV',
        generated_platform: 'gXPOS',
      };

      console.log(`[CMS SYNC] Sending SALES-SUMMARY to CMS...`);
      const baseRoute = process.env.NEXT_PUBLIC_API_URL || '';
      const auth = process.env.NEXT_PUBLIC_KEY || '';
      const res = await fetch(`${baseRoute}/send/gxpos/reports`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json', 
          'POS-API-KEY': auth 
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      const text = await res.text();
      try { cmsResponse = JSON.parse(text); } catch { cmsResponse = text; }
      isSynced = res.ok;
    } catch (err: any) {
      console.error(`[CMS SYNC ERROR] SALES-SUMMARY:`, err.message);
      cmsResponse = { error: err.message };
    }

    const filter: Record<string, string> = businessDayId 
      ? { businessDayId, reportType: 'SALES-SUMMARY' } 
      : { date, reportType: 'SALES-SUMMARY' };

    const doc = {
      ...filter,
      date,
      businessDayId: businessDayId ?? null,
      reportType: 'SALES-SUMMARY',
      workstationId,
      generatedBy: { staffId, staffName },
      rowCount: reportRows.length,
      content: contentPayload,
      isSynced,
      cmsResponse
    };

    await reportsCollection.updateOne(filter, { $set: doc }, { upsert: true });

    let filePath: string | null = null;
    try {
      const reportDir = path.join(process.cwd(), 'sales-summaries');
      if (!fs.existsSync(reportDir)) fs.mkdirSync(reportDir, { recursive: true });
      
      const fileName = `SalesSummary_${date}.csv`;
      filePath = path.join(reportDir, fileName);
      fs.writeFileSync(filePath, csvContent, 'utf-8');
    } catch (fileErr) {
      console.error('[Sales Summary file write failed]', fileErr);
    }

    return NextResponse.json({ success: true, rowCount: reportRows.length, filePath, isSynced });

  } catch (error: any) {
    console.error('[SALES-SUMMARY POST]', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  await initializeDatabase().catch((err) => console.error('DB init error:', err));
  
  const { searchParams } = new URL(req.url);
  const date = searchParams.get('date');
  const businessDayId = searchParams.get('businessDayId');
  
  if (!date && !businessDayId) {
     return NextResponse.json({ error: 'date or businessDayId required' }, { status: 400 });
  }

  const db = await getDatabase();
  const reportsCollection = db.collection('reports');

  const filter: any = { reportType: 'SALES-SUMMARY' };
  if (businessDayId) filter.businessDayId = businessDayId;
  else if (date) filter.date = date;

  const report = await reportsCollection.findOne(filter, { sort: { _id: -1 } });
  
  if (!report || !report.content || !report.content.csv) {
     return NextResponse.json({ error: 'Sales Summary not found' }, { status: 404 });
  }

  return new NextResponse(report.content.csv, {
    status: 200,
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment; filename=\"SalesSummary_${report.date}.csv\"`,
    },
  });
}