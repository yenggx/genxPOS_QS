//app/api/transactions/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase, COLLECTIONS } from '@/src/lib/mongodb-utils';
import { ObjectId } from 'mongodb';

export const dynamic = 'force-dynamic';

/**
 * GET /api/transactions
 * Fetch transactions from the database
 */
export async function GET(request: NextRequest) {
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  const { searchParams } = new URL(request.url);
  const limit  = searchParams.get('limit')  ? Number(searchParams.get('limit'))  : 5000;
  const offset = searchParams.get('offset') ? Number(searchParams.get('offset')) : 0;
  const date       = searchParams.get('date');
  const sessionId  = searchParams.get('sessionId');
  const sessionIds = searchParams.get('sessionIds'); // ← NEW: comma-separated list
  const terminalId = searchParams.get('terminalId');

  try {
    const db = await getDatabase();
    const transactionsCollection = db.collection(COLLECTIONS.TRANSACTIONS);

    const query: Record<string, unknown> = {};

    if (searchParams.has('sessionIds')) {
      const ids = (sessionIds || '').split(',').map(s => s.trim()).filter(Boolean);
      query.sessionId = { $in: ids };
    }
    else if (sessionId) {
      query.sessionId = sessionId;
    }
    else if (date) {
      const startDate = new Date(date as string);
      const endDate   = new Date(startDate);
      endDate.setDate(endDate.getDate() + 1);
      query.date = { $gte: startDate, $lt: endDate };
    }

    // Terminal filter can stack on top of any of the above
    if (terminalId) {
      query.KioskNo = terminalId;
    }

    const transactions = await transactionsCollection
      .find(query)
      .sort({ createdAt: -1, date: -1 })
      .skip(offset)
      .limit(limit)
      .toArray();

    const total = await transactionsCollection.countDocuments(query);

    return NextResponse.json({
      transactions,
      count: transactions.length,
      total,
      success: true,
    });
  } catch (error) {
    console.error('[TRANSACTIONS API] GET error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Server error', success: false },
      { status: 500 }
    );
  }
}

/**
 * POST /api/transactions
 * Save a new transaction to the database
 */
export async function POST(request: NextRequest) {
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  try {
    const transactionData = await request.json();

    console.log('[TRANSACTIONS API] POST received:', {
      hasOrderNo: !!transactionData?.OrderNo,
      hasOrderNumber: !!transactionData?.orderNumber,
      hasItems: !!transactionData?.items,
      dataKeys: transactionData ? Object.keys(transactionData).slice(0, 10) : 'none',
    });

    if (!transactionData) {
      console.error('[TRANSACTIONS API] Empty transaction data');
      return NextResponse.json(
        { error: 'Transaction data is required', success: false },
        { status: 400 }
      );
    }

    const db = await getDatabase();
    console.log('[TRANSACTIONS API] Database connected');
    
    const transactionsCollection = db.collection(COLLECTIONS.TRANSACTIONS);
    console.log('[TRANSACTIONS API] Collection:', COLLECTIONS.TRANSACTIONS);

    // Add timestamps and sync flag
    const transaction = {
      ...transactionData,
      date: transactionData.date || new Date(),
      createdAt: new Date(),
      updatedAt: new Date(),
      isSynced: false, // Mark as pending sync to CMS
    };

    console.log('[TRANSACTIONS API] Inserting transaction with OrderNo:', transaction.OrderNo || transaction.orderNumber);

    const result = await transactionsCollection.insertOne(transaction);

    console.log('[TRANSACTIONS API] ✓ Transaction saved:', {
      orderNumber: transactionData.orderNumber || transactionData.OrderNo,
      insertedId: result.insertedId,
      acknowledged: result.acknowledged,
    });

    return NextResponse.json(
      {
        success: true,
        message: 'Transaction saved successfully',
        insertedId: result.insertedId,
        transaction,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('[TRANSACTIONS API] ✗ POST error:', error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error('[TRANSACTIONS API] Error details:', {
      message: errorMessage,
      stack: error instanceof Error ? error.stack : 'no stack',
    });
    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
        details: error instanceof Error ? error.stack : undefined,
      },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/transactions
 * Update a transaction
 */
export async function PATCH(request: NextRequest) {
  await initializeDatabase().catch((err: unknown) => {
    console.error('DB init error:', err);
  });

  try {
    const updateData = await request.json();
    const { id, ...updateFields } = updateData;

    if (!id) {
      return NextResponse.json(
        { error: 'Transaction ID is required for update', success: false },
        { status: 400 }
      );
    }

    const db = await getDatabase();
    const transactionsCollection = db.collection(COLLECTIONS.TRANSACTIONS);

    // Try to find by multiple ID fields
    let query: any = {};
    
    // Try as MongoDB ObjectId first
    try {
      if (ObjectId.isValid(id)) {
        query = { _id: new ObjectId(id) };
      }
    } catch (e) {
      console.log('[TRANSACTIONS API] Not a valid MongoDB ID, trying other fields');
    }
    
    // If no match by MongoDB ID, try other fields
    if (!query._id) {
      // Try to match by id, dbId, cmsSpecialID, or transactionId fields
      query = {
        $or: [
          { _id: id },
          { id },
          { dbId: id },
          { cmsSpecialID: id ? Number(id) : undefined },
          { transactionId: id },
        ].filter(q => Object.values(q)[0] !== undefined)
      };
    }

    console.log('[TRANSACTIONS API] Searching for transaction with query:', query);

    // Update the transaction
    const result = await transactionsCollection.updateOne(
      query,
      {
        $set: {
          ...updateFields,
          updatedAt: new Date(),
        },
      }
    );

    console.log('[TRANSACTIONS API] PATCH result:', {
      transactionId: id,
      modifiedCount: result.modifiedCount,
      matchedCount: result.matchedCount,
      updatedFields: Object.keys(updateFields),
    });

    if (result.matchedCount === 0) {
      console.warn('[TRANSACTIONS API] No transaction found with ID:', id);
      return NextResponse.json(
        {
          success: false,
          error: 'Transaction not found',
          transactionId: id,
        },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Transaction updated successfully',
      modifiedCount: result.modifiedCount,
      matchedCount: result.matchedCount,
    });
  } catch (error) {
    console.error('[TRANSACTIONS API] PATCH error:', error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
        details: error instanceof Error ? error.stack : undefined,
      },
      { status: 500 }
    );
  }
}
