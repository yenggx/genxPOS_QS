import { NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase } from '@/src/lib/mongodb-utils';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    await initializeDatabase().catch((err: unknown) => console.error('DB init error:', err));
    const db = await getDatabase();
    
    const storeData = await db.collection('stores').findOne({});

    if (!storeData) {
      return NextResponse.json({ error: 'No store data found in the database.' }, { status: 404 });
    }

    return NextResponse.json(storeData, { status: 200 });
  } catch (error) {
    console.error('Store API GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch store data' }, { status: 500 });
  }
}