import { NextRequest, NextResponse } from 'next/server';
import { writeFile, mkdir, access } from 'fs/promises';
import path from 'path';

const CACHE_DIR = path.join(process.cwd(), 'public', 'menu-cache');

export async function POST(request: NextRequest) {
  try {
    const { urls } = await request.json() as { urls: string[] };
    await mkdir(CACHE_DIR, { recursive: true });

    const results = await Promise.allSettled(
      urls.map(async (url) => {
        const filename = url.split('/').pop();
        if (!filename) return;

        const filePath = path.join(CACHE_DIR, filename);

        // Skip if already on disk
        try { await access(filePath); return; } catch {}

        const res = await fetch(url);
        if (!res.ok) throw new Error(`${res.status} ${url}`);
        await writeFile(filePath, Buffer.from(await res.arrayBuffer()));
      })
    );

    const errors = results.filter(r => r.status === 'rejected');
    const cached = results.filter(r => r.status === 'fulfilled').length;
    console.log(`[IMAGE CACHE] ✓ ${cached} processed, ${errors.length} failed`);

    return NextResponse.json({ cached, errors: errors.length });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}