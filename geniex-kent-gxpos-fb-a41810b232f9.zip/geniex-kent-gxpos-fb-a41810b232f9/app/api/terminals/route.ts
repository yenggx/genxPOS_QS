import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';

export async function GET() {
  try {
    const db  = await getDatabase();
    const terminals = await db.collection('terminals').find({}).toArray();
    
    return NextResponse.json(terminals);
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch terminals" }, { status: 500 });
  }
}