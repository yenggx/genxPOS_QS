import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const db  = await getDatabase();
    
    const updateDoc = { $set: { status: body.status, updated_at: new Date() } };
    if (body.pos_number) updateDoc.$set.pos_number = body.pos_number;

    await db.collection('terminals').updateOne({ mac_address: body.mac_address }, updateDoc);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Failed to update" }, { status: 500 });
  }
}