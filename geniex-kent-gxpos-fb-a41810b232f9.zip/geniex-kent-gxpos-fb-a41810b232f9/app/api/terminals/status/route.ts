import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const mac = searchParams.get('mac');
    
    if (!mac) {
      return NextResponse.json({ error: 'MAC address required' }, { status: 400 });
    }

    const db  = await getDatabase();
    const terminal = await db.collection('terminals').findOne({ mac_address: mac });
    
    if (!terminal) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }
    
    return NextResponse.json(terminal);
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch terminal statuses!" }, { status: 500 });
  }
}