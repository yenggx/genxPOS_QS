import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';


export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const db  = await getDatabase();

    await db.collection('terminals').updateOne(
      { mac_address: body.mac_address },
      { $set: { serial_number: body.serial_number, status: 'PENDING', updated_at: new Date() } },
      { upsert: true }
    );
    
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to record usage' }, { status: 500 });
  }
}