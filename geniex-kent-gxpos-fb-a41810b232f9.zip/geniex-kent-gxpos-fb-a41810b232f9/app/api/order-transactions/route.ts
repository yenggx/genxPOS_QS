import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { COLLECTIONS } from '@/src/lib/mongodb-utils';
import { ObjectId } from 'mongodb';

export const dynamic = 'force-dynamic';

// Store CMS transactions locally
export async function POST(request: NextRequest) {
  try {
    const transactionData = await request.json();

    if (!transactionData.id) {
      return NextResponse.json(
        { success: false, error: 'Transaction ID is required' },
        { status: 400 }
      );
    }

    const db = await getDatabase();
    const ordersCollection = db.collection('orderTransactions');

    // Check if transaction already exists
    const existingTransaction = await ordersCollection.findOne({
      id: transactionData.id,
    });

    if (existingTransaction) {
      // Update existing transaction
      const result = await ordersCollection.updateOne(
        { id: transactionData.id },
        {
          $set: {
            ...transactionData,
            updatedAt: new Date(),
          },
        }
      );

      return NextResponse.json({
        success: true,
        action: 'updated',
        message: 'Transaction updated',
        modifiedCount: result.modifiedCount,
      });
    } else {
      // Insert new transaction
      const result = await ordersCollection.insertOne({
        ...transactionData,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      return NextResponse.json(
        {
          success: true,
          action: 'created',
          message: 'Transaction saved',
          insertedId: result.insertedId,
        },
        { status: 201 }
      );
    }
  } catch (error) {
    console.error('[ORDER-TXN API] Error saving transaction:', error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
        details: error instanceof Error ? error.stack : undefined,
      },
      { status: 500 }
    );
  }
}

// Get order transactions
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = searchParams.get('limit') ? Number(searchParams.get('limit')) : 50;
    const offset = searchParams.get('offset') ? Number(searchParams.get('offset')) : 0;
    const syncedOnly = searchParams.get('synced') === 'true';

    const db = await getDatabase();
    const ordersCollection = db.collection('orderTransactions');

    const query = syncedOnly ? { isSyncedFromCMS: true } : {};

    const transactions = await ordersCollection
      .find(query)
      .sort({ createdAt: -1 })
      .skip(offset)
      .limit(limit)
      .toArray();

    const total = await ordersCollection.countDocuments(query);
    return NextResponse.json({
      transactions,
      count: transactions.length,
      total,
      success: true,
    });
  } catch (error) {
    console.error('[ORDER-TXN API] Error fetching transactions:', error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
        details: error instanceof Error ? error.stack : undefined,
      },
      { status: 500 }
    );
  }
}

// Update order transaction status
export async function PATCH(request: NextRequest) {
  try {
    const updateData = await request.json();
    const { id, ...updateFields } = updateData;

    if (!id) {
      return NextResponse.json(
        { success: false, error: 'Transaction ID is required' },
        { status: 400 }
      );
    }

    const db = await getDatabase();
    const ordersCollection = db.collection('orderTransactions');

    // Try to find by multiple ID fields
    let query: any = { id };
    
    // Try as MongoDB ObjectId as fallback
    if (ObjectId.isValid(id)) {
      query = {
        $or: [
          { id },
          { _id: new ObjectId(id) },
        ]
      };
    }

    const result = await ordersCollection.updateOne(
      query,
      {
        $set: {
          ...updateFields,
          updatedAt: new Date(),
        },
      }
    );

    console.log('[ORDER-TXN API] PATCH result:', {
      transactionId: id,
      modifiedCount: result.modifiedCount,
      matchedCount: result.matchedCount,
      updatedFields: Object.keys(updateFields),
    });

    if (result.matchedCount === 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'Transaction not found',
          transactionId: id,
        },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Transaction updated successfully',
      modifiedCount: result.modifiedCount,
      matchedCount: result.matchedCount,
    });
  } catch (error) {
    console.error('[ORDER-TXN API] PATCH error:', error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
        details: error instanceof Error ? error.stack : undefined,
      },
      { status: 500 }
    );
  }
}
