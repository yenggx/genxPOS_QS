import { NextResponse } from 'next/server';
import { connectToDatabase } from '@/src/lib/mongodb';
import axios from 'axios';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    console.log('🔍 Diagnostic Check Starting...');
    console.log('📝 Environment Variables:');
    console.log('  MONGODB_URI:', process.env.MONGODB_URI ? '✓ Set' : '❌ Not set');
    console.log('  NEXT_PUBLIC_API_URL:', process.env.NEXT_PUBLIC_API_URL ? '✓ Set' : '❌ Not set');
    console.log(
      '  NEXT_PUBLIC_KEY:',
      process.env.NEXT_PUBLIC_KEY ? '✓ Set' : '❌ Not set'
    );
    console.log(
      '  NEXT_PUBLIC_STORE_CODE:',
      process.env.NEXT_PUBLIC_STORE_CODE ? '✓ Set' : '❌ Not set'
    );

    console.log('\n🔗 Testing MongoDB Connection...');
    const { client, db } = await connectToDatabase();

    console.log('✅ Connected to MongoDB');
    console.log('📊 Database Name: gXPOS');

    // Get list of databases
    const adminDb = client.db('admin');
    const dbs = await adminDb.admin().listDatabases();
    console.log('📚 Available Databases:', dbs.databases.map((d) => d.name));

    // Get collections in current database
    const collections = await db.listCollections().toArray();
    console.log(
      '📋 Collections:',
      collections.map((c) => c.name).join(', ') || 'none'
    );

    // Test external API connectivity
    const externalAPITests: any = {};
    const API_URL = process.env.NEXT_PUBLIC_API_URL;
    const API_KEY = process.env.NEXT_PUBLIC_KEY;
    const STORE_CODE = process.env.NEXT_PUBLIC_STORE_CODE;

    if (API_URL && API_KEY && STORE_CODE) {
      console.log('\n🌐 Testing External API Connectivity...');

      // Test menu endpoint
      try {
        console.log(`  Testing: ${API_URL}/menu/${STORE_CODE}`);
        const menuResponse = await axios.get(`${API_URL}/menu/${STORE_CODE}`, {
          headers: { 'POS-API-KEY': API_KEY },
          timeout: 5000,
        });
        externalAPITests.menuEndpoint = {
          status: '✓ OK',
          statusCode: menuResponse.status,
        };
        console.log('  ✓ Menu endpoint working');
      } catch (error: any) {
        externalAPITests.menuEndpoint = {
          status: '✗ Failed',
          statusCode: error.response?.status || error.code,
          error:
            error.response?.status === 500
              ? 'External API returned 500'
              : error.code === 'ECONNREFUSED'
                ? 'Connection refused'
                : error.code === 'ENOTFOUND'
                  ? 'DNS resolution failed'
                  : error.message,
        };
        console.log('  ✗ Menu endpoint failed:', externalAPITests.menuEndpoint.error);
      }

      // Test store connection endpoint
      try {
        const connectionUrl = `${API_URL.replace(/\/api\/v2\/pos\/?$/, '')}/api/v2/pos/connection/check/${STORE_CODE}`;
        console.log(`  Testing: ${connectionUrl}`);
        const connResponse = await axios.get(connectionUrl, {
          headers: { 'POS-API-KEY': API_KEY },
          timeout: 5000,
        });
        externalAPITests.storeConnectionEndpoint = {
          status: '✓ OK',
          statusCode: connResponse.status,
        };
        console.log('  ✓ Store connection endpoint working');
      } catch (error: any) {
        externalAPITests.storeConnectionEndpoint = {
          status: '✗ Failed',
          statusCode: error.response?.status || error.code,
          error:
            error.response?.status === 500
              ? 'External API returned 500'
              : error.code === 'ECONNREFUSED'
                ? 'Connection refused'
                : error.code === 'ENOTFOUND'
                  ? 'DNS resolution failed'
                  : error.message,
        };
        console.log('  ✗ Store connection endpoint failed:', externalAPITests.storeConnectionEndpoint.error);
      }
    }

    return NextResponse.json({
      status: 'ok',
      mongodb: {
        connected: true,
        database: 'gXPOS',
        collections: collections.map((c) => c.name),
      },
      externalAPI: externalAPITests,
      environment: {
        mongodb_uri: process.env.MONGODB_URI ? '✓' : '❌',
        api_url: process.env.NEXT_PUBLIC_API_URL ? '✓' : '❌',
        api_key: process.env.NEXT_PUBLIC_KEY ? '✓' : '❌',
        store_code: process.env.NEXT_PUBLIC_STORE_CODE ? '✓' : '❌',
      },
    });
  } catch (error) {
    console.error('❌ Diagnostic Error:', error);
    return NextResponse.json(
      {
        status: 'error',
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}
