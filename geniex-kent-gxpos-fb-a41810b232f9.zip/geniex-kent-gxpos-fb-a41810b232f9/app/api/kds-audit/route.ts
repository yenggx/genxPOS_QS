import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase } from '@/src/lib/mongodb-utils';
import { NextRequest, NextResponse } from 'next/server';
import { ObjectId } from 'mongodb';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const orderIds = searchParams.get('orderIds'); // comma-separated
  await initializeDatabase().catch(console.error);

  try {
    const db = await getDatabase();
    const col = db.collection('kds_audit');

    if (orderIds) {
      const ids = orderIds.split(',').filter(Boolean);
      const trails = await col.find({ orderId: { $in: ids } }).toArray();
      return NextResponse.json(trails);
    }

    return NextResponse.json([]);
  } catch (err) {
    console.error('[kds-audit GET]', err);
    return NextResponse.json([], { status: 500 });
  }
}

export async function POST(req: NextRequest) {
    
  await initializeDatabase().catch(console.error);
  const { orderId, orderNo, event } = await req.json();

  if (!orderId || !event) {
    return NextResponse.json({ success: false, error: 'Missing fields' }, { status: 400 });
  }

  try {
    const db = await getDatabase();
    const col = db.collection('kds_audit');

    // --- Determine Business Date ---
    let businessDate = '';
    try {
      const tx = await db.collection('transactions').findOne({ _id: new ObjectId(orderId) });
      if (tx) {
        if (tx.sessionId) {
          const bdi = await db.collection('cashierSessions').findOne({ sessionId: tx.sessionId });
          console.log("here", bdi)
          const bd = await db.collection('businessDays').findOne({ businessDayId: bdi?.businessDayId ?? "" });
          console.log("here", bd)
          if (bd && bd.date) businessDate = bd.date;
        }
        if (!businessDate && tx.date) {
          if (typeof tx.date === 'string') {
            businessDate = tx.date.split('T')[0];
          } else if (tx.date instanceof Date) {
            businessDate = tx.date.toISOString().split('T')[0];
          }
        }
      }
    } catch (e) {
      // Ignored if orderId is not a valid ObjectId format
    }

    // Fallback to currently open business day if no transaction match is found
    if (!businessDate) {
      const openBd = await db.collection('businessDays').findOne({ status: 'open' }, { sort: { openedAt: -1 } });
      if (openBd && openBd.date) businessDate = openBd.date;
    }

    // Override the date portion of the timestamp with the business date
    let finalTimestamp = event.timestamp || new Date().toISOString();
    if (businessDate && finalTimestamp.includes('T')) {
      const timePart = finalTimestamp.split('T')[1];
      finalTimestamp = `${businessDate}T${timePart}`;
    }

    await col.updateOne(
      { orderId },
      {
        $setOnInsert: { orderId, orderNo },
        $push: { events: { ...event, timestamp: finalTimestamp } },
      },
      { upsert: true }
    );

    // --- Sync to CMS Speed Service when order is fully served ---
    if (event.type === 'ORDER_SERVED') {
      const auditDoc = await col.findOne({ orderId });
      
      if (auditDoc) {
        // Format payload to strictly use a string _id instead of ObjectId
        const payload = {
          ...auditDoc,
          _id: auditDoc._id.toString()
        };

        const storeId = process.env.NEXT_PUBLIC_STORE_CODE || 'gXPOS-123';
        const baseUrl = process.env.NEXT_PUBLIC_API_URL || '';
        const endpoint = `${baseUrl}/send/gxpos/speedservice/report/${storeId}`;
        const auth = process.env.NEXT_PUBLIC_KEY || '';

        try {
          fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'POS-API-KEY': auth },
            body: JSON.stringify(payload)
          }).then(res => {
            if (!res.ok) {
              console.error(`[CMS Speed Service] Sync failed. Status: ${res.status}`);
            } else {
              console.log(`[CMS Speed Service] Successfully synced audit for order ${orderNo}`);
            }
          }).catch(err => {
            console.error(`[CMS Speed Service] Network error during sync:`, err.message);
          });
        } catch (err) {
          console.error(`[CMS Speed Service] Execution error:`, err);
        }
      }
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error('[kds-audit POST]', err);
    return NextResponse.json({ success: false }, { status: 500 });
  }
}