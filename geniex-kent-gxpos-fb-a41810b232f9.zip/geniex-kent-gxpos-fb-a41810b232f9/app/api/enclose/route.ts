import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { initializeDatabase } from '@/src/lib/mongodb-utils';

export async function POST(req: NextRequest) {
  await initializeDatabase().catch(console.error);

  try {
    const payload = await req.json();
    const db = await getDatabase();
    
    // Save to a completely separate collection
    const encloseCollection = db.collection('enclose_transactions');

    const result = await encloseCollection.insertOne({
      ...payload,
      isSynced: false // Ready for your CMS sync logic if needed later
    });

    return NextResponse.json({ success: true, insertedId: result.insertedId }, { status: 201 });
  } catch (error: any) {
    console.error('[Enclose POST Error]', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  await initializeDatabase().catch(console.error);

  try {
    const { searchParams } = new URL(req.url);
    const date = searchParams.get('date');
    const sessionId = searchParams.get('sessionId');

    const db = await getDatabase();
    const encloseCollection = db.collection('enclose_transactions');

    const query: any = {};
    if (date) {
      // Basic date matching (YYYY-MM-DD prefix)
      query.date = { $regex: `^${date}` }; 
    }
    if (sessionId) {
      query.sessionId = sessionId;
    }

    const records = await encloseCollection.find(query).sort({ _id: -1 }).toArray();

    return NextResponse.json({ success: true, records }, { status: 200 });
  } catch (error: any) {
    console.error('[Enclose GET Error]', error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}