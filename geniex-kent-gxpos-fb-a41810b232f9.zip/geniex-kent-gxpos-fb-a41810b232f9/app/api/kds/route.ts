// app/api/kds/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';
import { COLLECTIONS, initializeDatabase } from '@/src/lib/mongodb-utils';
import { ObjectId } from 'mongodb';

export const dynamic = 'force-dynamic';

// GET: Fetch all active kitchen orders (PREPARING or READY)
export async function GET(request: NextRequest) {
  await initializeDatabase().catch((err: unknown) => console.error('DB init error:', err));

  try {
    const db = await getDatabase();
    const transactionsCollection = db.collection(COLLECTIONS.TRANSACTIONS || 'transactions');

    // Fetch only active orders, sorted by oldest first so the kitchen does them in order
    const activeOrders = await transactionsCollection.find({
      kitchenState: { $in: ['PREPARING', 'READY'] },
      status: { $ne: 'voided' },
      orderState: { $ne: 'VOIDED' }
    })
    .sort({ orderTime: 1 }) 
    .project({
      _id: 1,
      OrderNo: 1,
      orderTime: 1,
      kitchenState: 1,
      items: 1,
      salesNumber: 1,
      'featureFlags.orderType': 1,
      transactionType: 1
    })
    .toArray();

    return NextResponse.json({ success: true, orders: activeOrders }, { status: 200 });
  } catch (error) {
    console.error('KDS GET error:', error);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

// PATCH: Update the kitchenState (Bump to READY or SERVED, or update specific item)
export async function PATCH(request: NextRequest) {
  await initializeDatabase().catch((err: unknown) => console.error('DB init error:', err));

  try {
    const { transactionId, newState, itemIndex, itemIndices } = await request.json();
    const db = await getDatabase();
    const transactionsCollection = db.collection(COLLECTIONS.TRANSACTIONS || 'transactions');

    if (!transactionId || !newState) {
      return NextResponse.json({ error: 'Missing transactionId or newState' }, { status: 400 });
    }

    // --- MULTIPLE ITEMS UPDATE (FILTERED) ---
    if (Array.isArray(itemIndices)) {
      const updateObj: any = { updatedAt: new Date().toISOString() };
      itemIndices.forEach((idx: number) => {
        updateObj[`items.${idx}.kitchenState`] = newState;
      });

      await transactionsCollection.updateOne(
        { _id: new ObjectId(transactionId) },
        { $set: updateObj }
      );

      // Auto-bump whole order logic
      const updatedTx = await transactionsCollection.findOne({ _id: new ObjectId(transactionId) });
      if (updatedTx && updatedTx.items) {
        if (newState === 'READY') {
          const allItemsReady = updatedTx.items.every((item: any) => item.kitchenState === 'READY' || item.kitchenState === 'SERVED');
          if (allItemsReady && updatedTx.kitchenState === 'PREPARING') {
            await transactionsCollection.updateOne(
              { _id: new ObjectId(transactionId) },
              { $set: { kitchenState: 'READY', preparedAt: new Date().toISOString() } }
            );
          }
        } else if (newState === 'SERVED') {
          const allItemsServed = updatedTx.items.every((item: any) => item.kitchenState === 'SERVED');
          if (allItemsServed && updatedTx.kitchenState !== 'SERVED') {
            await transactionsCollection.updateOne(
              { _id: new ObjectId(transactionId) },
              { $set: { kitchenState: 'SERVED', servedAt: new Date().toISOString() } }
            );
          }
        } else if (newState === 'PREPARING') {
           if (updatedTx.kitchenState === 'READY') {
             await transactionsCollection.updateOne(
              { _id: new ObjectId(transactionId) },
              { $set: { kitchenState: 'PREPARING' } }
            );
           }
        }
      }

      return NextResponse.json({ success: true }, { status: 200 });
    }

    // --- ITEM LEVEL UPDATE ---
    if (typeof itemIndex === 'number') {
      const updateKey = `items.${itemIndex}.kitchenState`;
      
      await transactionsCollection.updateOne(
        { _id: new ObjectId(transactionId) },
        { $set: { [updateKey]: newState, updatedAt: new Date().toISOString() } }
      );

      // Auto-bump entire order if applicable
      const updatedTx = await transactionsCollection.findOne({ _id: new ObjectId(transactionId) });
      if (updatedTx && updatedTx.items) {
        if (newState === 'READY') {
          const allItemsReady = updatedTx.items.every((item: any) => item.kitchenState === 'READY' || item.kitchenState === 'SERVED');
          if (allItemsReady && updatedTx.kitchenState === 'PREPARING') {
            await transactionsCollection.updateOne(
              { _id: new ObjectId(transactionId) },
              { $set: { kitchenState: 'READY', preparedAt: new Date().toISOString() } }
            );
          }
        } else if (newState === 'SERVED') {
          const allItemsServed = updatedTx.items.every((item: any) => item.kitchenState === 'SERVED');
          if (allItemsServed && updatedTx.kitchenState !== 'SERVED') {
            await transactionsCollection.updateOne(
              { _id: new ObjectId(transactionId) },
              { $set: { kitchenState: 'SERVED', servedAt: new Date().toISOString() } }
            );
          }
        }
      }

      return NextResponse.json({ success: true }, { status: 200 });
    }

    // --- WHOLE ORDER UPDATE ---
    const updateFields: any = {
      kitchenState: newState,
      updatedAt: new Date().toISOString()
    };

    if (newState === 'READY') {
      updateFields.preparedAt = new Date().toISOString();
      const tx = await transactionsCollection.findOne({ _id: new ObjectId(transactionId) });
      if (tx && tx.items) {
        tx.items.forEach((item: any) => { item.kitchenState = 'READY'; });
        updateFields.items = tx.items;
      }
    } else if (newState === 'SERVED') {
      updateFields.servedAt = new Date().toISOString();
    } else if (newState === 'PREPARING') {
      const tx = await transactionsCollection.findOne({ _id: new ObjectId(transactionId) });
      if (tx && tx.items) {
        tx.items.forEach((item: any) => { item.kitchenState = 'PREPARING'; });
        updateFields.items = tx.items;
      }
    }


    const result = await transactionsCollection.updateOne(
      { _id: new ObjectId(transactionId) },
      { $set: updateFields }
    );

    if (result.matchedCount === 0) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    console.error('KDS PATCH error:', error);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}