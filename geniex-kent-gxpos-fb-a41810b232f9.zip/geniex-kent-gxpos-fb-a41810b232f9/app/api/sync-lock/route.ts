// app/api/sync-lock/route.ts
import { NextResponse } from 'next/server';
import { getDatabase } from '@/src/lib/mongodb';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const db = await getDatabase();
    const syncCollection = db.collection('system_sync');
    const now = Date.now();

    const body = await request.json().catch(() => ({}));
    
    // Completely ignore manual releases to force the 10-second gap
    if (body.action === 'release') {
      return NextResponse.json({ success: true, ignored: true });
    }

    const threshold = now - 9500; // 9.5 seconds buffer

    // STEP 1: Safely guarantee the lock document exists.
    // $setOnInsert ensures we only set lastSyncTime to 0 if the document is being created for the first time.
    try {
      await syncCollection.updateOne(
        { _id: 'cms_kiosk_sync' },
        { $setOnInsert: { lastSyncTime: 0 } },
        { upsert: true }
      );
    } catch (e: any) {
      // If multiple terminals boot up at the exact same millisecond, 
      // one will create it and the others will throw an E11000 here. We safely ignore it.
      if (e.code !== 11000) throw e;
    }

    // STEP 2: Attempt to acquire the lock atomically.
    // This will ONLY succeed if the document's lastSyncTime is older than 9.5 seconds.
    // Notice we removed `upsert: true` entirely.
    const result = await syncCollection.findOneAndUpdate(
      {
        _id: 'cms_kiosk_sync',
        lastSyncTime: { $lt: threshold }
      },
      { 
        $set: { lastSyncTime: now } 
      },
      {
        returnDocument: 'after'
      }
    );

    // If result is null, another POS terminal successfully updated it recently.
    if (!result) {
      return NextResponse.json({ canFetch: false, reason: 'Sync performed recently by another POS.' });
    }

    // We successfully updated the time. We own the lock.
    return NextResponse.json({ canFetch: true });

  } catch (error) {
    console.error('[SYNC LOCK ERROR]', error);
    return NextResponse.json({ canFetch: false, error: 'Database error' }, { status: 500 });
  }
}