import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const paymentUrl = process.env.PAYMENT_URL || 'http://192.168.254.103:5000/api/pos/pay';

    console.log('[API] Incoming payment request:', JSON.stringify(body, null, 2));
    console.log('[API] Forwarding to:', paymentUrl);

    const response = await fetch(paymentUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    const data = await response.json();
    console.log('[API] Payment gateway response:', JSON.stringify(data, null, 2));
    
    return NextResponse.json(data, { status: response.status });
  } catch (error) {
    console.error('Payment API error:', error);
    return NextResponse.json(
      { error: 'Payment request failed', details: String(error) },
      { status: 500 }
    );
  }
}
