'use client';

import Image from 'next/image';
import { useEffect, useState } from 'react';
import { fetchAndStoreMenu, getMenuFromCache } from '../src/api/menu';
import { fetchAndSaveStoreAssociates, getCachedAssociates } from '../src/api/associates';
import { fetchAndSaveStoreData, getCachedStoreData } from '../src/api/stores';
import { initializeTransactionCounters, initializeOrderNumber } from '../src/api/transactionNumbers';
import { fetchAndSaveRefundReasons, getCachedRefundReasons } from '../src/api/refund-reasons';
import { fetchAndSaveVoidReasons, getCachedVoidReasons } from '../src/api/void-reason';
import { fetchAndSaveSettings, getCachedSettings } from '../src/api/settings';
import { useRouter } from 'next/navigation';
import { Toaster } from 'sileo';
import styles from './page.module.css';
import { CheckCircle2, AlertTriangle, XCircle, Wifi, WifiOff } from 'lucide-react';

type Status = 'loading' | 'ok' | 'warn' | 'fail';

type InitItem = {
  name: string;
  status: Status;
  detail: string;
};

const STATUS_ICON: Record<Status, React.ReactNode> = {
  loading: <div className="w-4 h-4 rounded-full border-2 border-white/40 border-t-white animate-spin" />,
  ok:      <CheckCircle2 size={16} className="text-green-400" />,
  warn:    <AlertTriangle size={16} className="text-yellow-400" />,
  fail:    <XCircle size={16} className="text-red-400" />,
};


export default function Home() {
  const router = useRouter();

  const [items, setItems]         = useState<InitItem[]>([]);
  const [done, setDone]           = useState(false);
  const [hasIssues, setHasIssues] = useState(false);
  const [isOnline, setIsOnline]   = useState(true);

  const set = (name: string, status: Status, detail: string) =>
    setItems(prev =>
      prev.some(i => i.name === name)
        ? prev.map(i => i.name === name ? { name, status, detail } : i)
        : [...prev, { name, status, detail }]
    );

  useEffect(() => {
    const run = async () => {
      const names = ['Menu', 'Associates', 'Store Data', 'Refund Reasons', 'Void Reasons', 'Settings', 'Counters'];
      names.forEach(n => set(n, 'loading', 'Fetching...'));

      const results = await Promise.allSettled([

        // Menu
        fetchAndStoreMenu()
          .then(r  => { set('Menu', 'ok', 'Up to date'); return r; })
          .catch(async () => {
            const cached = await getMenuFromCache();
            if (cached) {
              set('Menu', 'warn', 'Using cached — offline mode OK');
            } else {
              set('Menu', 'fail', 'No cache — menu unavailable offline');
            }
          }),

        // Associates
        fetchAndSaveStoreAssociates()
          .then(r  => { set('Associates', 'ok', 'Up to date'); return r; })
          .catch(async () => {
            const cached = await getCachedAssociates();
            if (cached?.length) {
              set('Associates', 'warn', 'Using cached — login will work offline');
            } else {
              set('Associates', 'fail', 'No cache — login unavailable offline');
            }
          }),

        // Store Data
        fetchAndSaveStoreData()
          .then(r  => { set('Store Data', 'ok', 'Up to date'); return r; })
          .catch(async () => {
            const cached = await getCachedStoreData();
            if (cached) {
              set('Store Data', 'warn', 'Using cached — receipts may be outdated');
            } else {
              set('Store Data', 'fail', 'No cache — receipt printing may fail');
            }
          }),

        // Refund Reasons
        fetchAndSaveRefundReasons()
          .then(r  => { set('Refund Reasons', 'ok', 'Up to date'); return r; })
          .catch(async () => {
            const cached = await getCachedRefundReasons();
            if (cached?.length) {
              set('Refund Reasons', 'warn', 'Using cached');
            } else {
              set('Refund Reasons', 'fail', 'No cache — refunds may not work offline');
            }
          }),

        // Void Reasons
        fetchAndSaveVoidReasons()
          .then(r  => { set('Void Reasons', 'ok', 'Up to date'); return r; })
          .catch(async () => {
            const cached = await getCachedVoidReasons();
            if (cached?.length) {
              set('Void Reasons', 'warn', 'Using cached');
            } else {
              set('Void Reasons', 'fail', 'No cache — voids may not work offline');
            }
          }),

        // Settings
        fetchAndSaveSettings()
          .then(r  => { set('Settings', 'ok', 'Up to date'); return r; })
          .catch(() => {
            const cached = getCachedSettings();
            if (cached) {
              set('Settings', 'warn', 'Using cached — some config may be outdated');
            } else {
              set('Settings', 'fail', 'No cache — workstation config unavailable');
            }
          }),

        // Counters (no cache fallback — non-fatal)
        Promise.all([
          initializeTransactionCounters(),
          initializeOrderNumber(),
        ])
          .then(() => set('Counters', 'ok', 'Initialized'))
          .catch(() => set('Counters', 'warn', 'Using last known counters')),

      ]);

      setItems(prev => {
        const bad = prev.some(i => i.status === 'fail' || i.status === 'warn');
        setHasIssues(bad);
        if (!bad) {
          setTimeout(() => router.push('/logs'), 1200);
        }
        return prev;
      });

      setDone(true);
    };
    run();
  }, [router]);

  const proceed = () => router.push('/logs');

  return (
    <>
      <Toaster position="top-center" />
      <div className={styles.loaderContainer}>
        <div className={styles.loaderContent}>
          <div className={styles.rotatingWrapper}>
            <Image src="/images/classic-nutty-choco.png" alt="Loading" width={120} height={120} className={styles.rotatingImage} priority />
          </div>
        </div>

        {/* ── Init status panel ── */}
        {items.length > 0 && (
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-full max-w-sm px-4">
            <div className="rounded-2xl overflow-hidden" style={{ background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(16px)', border: '1px solid rgba(255,255,255,0.08)' }}>

              {/* Header */}
              <div className="flex items-center justify-between px-4 pt-3 pb-2 border-b border-white/10">
                <span className="text-[11px] font-bold uppercase tracking-widest text-white/50" style={{ fontFamily: 'Poppins' }}>
                  Initialization
                </span>
                <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold ${isOnline ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                  {isOnline ? <Wifi size={10} /> : <WifiOff size={10} />}
                  {isOnline ? 'Online' : 'Offline'}
                </div>
              </div>

              {/* Item list */}
              <div className="px-4 py-3 flex flex-col gap-2">
                {items.map(item => (
                  <div key={item.name} className="flex items-start gap-2.5">
                    <div className="mt-0.5 flex-shrink-0">{STATUS_ICON[item.status]}</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[12px] font-bold text-white leading-none" style={{ fontFamily: 'Poppins' }}>{item.name}</p>
                      <p className="text-[10px] text-white/45 mt-0.5 leading-tight" style={{ fontFamily: 'Poppins' }}>{item.detail}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Proceed button — only when done and there are issues */}
              {done && hasIssues && (
                <div className="px-4 pb-4 pt-1">
                  <button
                    onClick={proceed}
                    className="w-full py-3 rounded-xl text-sm font-black uppercase tracking-widest text-white transition-all active:scale-95"
                    style={{ fontFamily: 'Poppins', background: 'linear-gradient(135deg, #f97316, #ea580c)', boxShadow: '0 4px 16px rgba(249,115,22,0.35)' }}
                  >
                    Proceed Anyway →
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </>
  );
}