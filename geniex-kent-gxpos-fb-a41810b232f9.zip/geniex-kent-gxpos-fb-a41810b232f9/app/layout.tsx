import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { GlobalKeyboardProvider } from "./components/GlobalKeyboard";
import { PrinterProvider } from "./context/PrinterContext";
import { ConnectionProvider } from "./context/ConnectionContext";
import { Suspense } from 'react';
import { SyncProvider } from "./context/SyncContext";
import { CfdProvider } from "./context/CfdContext";
import { WorkstationInit } from "./components/WorkstationInit";
import GlobalKioskSync from "./context/GlobalKioskSync";


const geistSans = Geist({ variable: "--font-geist-sans", subsets: ["latin"] });
const geistMono = Geist_Mono({ variable: "--font-geist-mono", subsets: ["latin"] });

export const metadata: Metadata = { title: "FnB POS", description: "POS System" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`} suppressHydrationWarning>
      <body className="min-h-full flex flex-col" suppressHydrationWarning>
        <ConnectionProvider>
          <PrinterProvider>
            <CfdProvider>         
              <GlobalKioskSync /> {/* do not remove this*/}
              <SyncProvider>
                <GlobalKeyboardProvider>
                  <Suspense fallback={
                    <div className="flex flex-1 items-center justify-center" style={{ background: "#F0EFEF" }}>
                      <div className="w-8 h-8 rounded-full border-4 border-orange-200 border-t-orange-500 animate-spin" />
                    </div>
                  }>
                    <WorkstationInit />
                    {children}
                  </Suspense>
                </GlobalKeyboardProvider>
              </SyncProvider>
            </CfdProvider>
          </PrinterProvider>
        </ConnectionProvider>
      </body>
    </html>
  );
}
