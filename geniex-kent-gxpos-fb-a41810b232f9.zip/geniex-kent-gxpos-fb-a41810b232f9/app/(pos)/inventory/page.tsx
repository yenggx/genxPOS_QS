'use client';
import { useEffect, useState, useMemo, useRef } from "react";
import { FiSearch, FiArchive, FiCheck, FiRefreshCw, FiChevronRight, FiPackage, FiDelete } from 'react-icons/fi';
import { getMenuFromCache } from '@/src/api/menu';
import { sileo, Toaster } from 'sileo';
import { DonutPlaceholder } from "@/app/components/pos/ProductCard";
import { resolveMenuImageUrl } from "@/src/utils/menuImages";

const C = {
  orange: '#f97316', orangeHover: '#ea580c',
  bg: '#F0EFEF', surface: 'rgba(255,255,255,0.45)',
  border: 'rgba(255,255,255,0.8)', text: '#1a1a1a', textSub: '#64748b'
};

const glass = {
  panel: {
    background: "rgba(255,255,255,0.18)", backdropFilter: "blur(20px)",
    WebkitBackdropFilter: "blur(20px)", border: "1px solid rgba(255,255,255,0.35)",
    boxShadow: "inset 0 1px 0 rgba(255,255,255,0.5), 0 8px 32px rgba(0,0,0,0.12)"
  } as React.CSSProperties,
  card: {
    background: "rgba(255,255,255,0.6)", backdropFilter: "blur(12px)",
    border: "1px solid rgba(255,255,255,0.8)", boxShadow: "0 4px 16px rgba(0,0,0,0.04)"
  } as React.CSSProperties
};


// ── Image with loading skeleton ────────────────────────────────────────────────
function ItemImage({ src, alt, className, style }: { src: string; alt: string; className?: string; style?: React.CSSProperties }) {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);

  return (
    <div className={`relative overflow-hidden ${className}`} style={style}>
      {/* Skeleton shimmer */}
      {!loaded && !error && (
        <div className="absolute inset-0"><DonutPlaceholder /></div>
      )}
      {error && (
        <div className="absolute inset-0"><DonutPlaceholder /></div>
      )}

      {/* Actual image */}
      {src && !error && (
        <img
          src={src}
          alt={alt}
          className="w-full h-full object-contain"
          style={{ opacity: loaded ? 1 : 0, transition: 'opacity .3s ease' }}
          onLoad={() => setLoaded(true)}
          onError={() => setError(true)}
        />
      )}

      <style>{`
        @keyframes shimmer {
          0%   { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
      `}</style>
    </div>
  );
}

// ── Numpad Modal ───────────────────────────────────────────────────────────────
function NumpadModal({
  open,
  itemName,
  itemImg,           // ← new prop
  initialValue,
  onConfirm,
  onClose,
}: {
  open: boolean;
  itemName: string;
  itemImg: string;   // ← new prop
  initialValue: number | undefined;
  onConfirm: (qty: number) => void;
  onClose: () => void;
}) {
  const [input, setInput] = useState('');
  const [imgLoaded, setImgLoaded] = useState(false);

  useEffect(() => {
    if (open) {
      setInput(initialValue ? String(initialValue) : '');
      setImgLoaded(false); // reset on each open
    }
  }, [open, initialValue]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') press(e.key);
      else if (e.key === 'Backspace') backspace();
      else if (e.key === 'Enter') confirm();
      else if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, input]);

  const press = (val: string) => {
    setInput(prev => {
      const next = prev === '' ? val : prev + val;
      const num = parseInt(next);
      if (isNaN(num) || next.length > 5) return prev;
      return String(num);
    });
  };

  const backspace = () => setInput(prev => prev.slice(0, -1));
  const confirm   = () => onConfirm(parseInt(input) || 0);

  const accentColor = '#f97316';
  const stripColor  = 'linear-gradient(90deg, #f97316 0%, #fb923c 60%, #fdba74 100%)';

  return (
    <div
      className="fixed inset-0 flex items-center justify-center z-50"
      style={{
        background: 'rgba(15,23,42,0.82)',
        backdropFilter: 'blur(14px)',
        WebkitBackdropFilter: 'blur(14px)',
        opacity: open ? 1 : 0,
        pointerEvents: open ? 'all' : 'none',
        transition: 'opacity .22s ease',
      }}
      onClick={onClose}
    >
      <div
        className="rounded-3xl w-full max-w-sm mx-4 relative overflow-hidden shadow-2xl"
        style={{
          background: '#ffffff',
          transform: open ? 'scale(1) translateY(0)' : 'scale(0.88) translateY(20px)',
          transition: 'transform .3s cubic-bezier(0.34,1.56,0.64,1)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top strip */}
        <div style={{ height: 6, background: stripColor }} />

        <div className="p-7">
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-7 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-base transition-all hover:bg-black/5"
            style={{
              background: 'rgba(0,0,0,0.05)',
              color: '#bbb',
              border: '1px solid rgba(0,0,0,0.07)',
              fontFamily: 'Poppins',
            }}
          >
            ✕
          </button>

          {/* Header — item image replaces the emoji */}
          <div className="flex items-center gap-3 mb-4">
            <div
              className="w-12 h-12 rounded-2xl flex-shrink-0 overflow-hidden relative"
              style={{
                background: `${accentColor}15`,
                border: `1.5px solid ${accentColor}30`,
              }}
            >
              {/* Skeleton */}
              {!imgLoaded && <div className="absolute inset-0"><DonutPlaceholder /></div>}

              {itemImg ? (
                <img
                  src={itemImg}
                  alt={itemName}
                  className="w-full h-full object-contain p-1"
                  style={{ opacity: imgLoaded ? 1 : 0, transition: 'opacity .3s ease' }}
                  onLoad={() => setImgLoaded(true)}
                />
              ) : (
                <DonutPlaceholder />
              )}
            </div>

            <div>
              <p style={{
                fontFamily: 'Poppins', fontSize: 10, color: '#ccc',
                fontWeight: 700, letterSpacing: 1.2,
                textTransform: 'uppercase', marginBottom: 2,
              }}>
                Physical Count
              </p>
              <h2 style={{
                fontFamily: 'Poppins', fontSize: 18,
                fontWeight: 900, color: '#1a1a1a', lineHeight: 1,
              }}>
                {itemName}
              </h2>
            </div>
          </div>

          {/* Quantity display */}
          <div
            className="rounded-xl px-6 py-4 mb-5"
            style={{
              fontFamily: 'Poppins',
              background: `${accentColor}10`,
              border: `1.5px solid ${accentColor}30`,
              color: accentColor,
              minHeight: 72,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
            }}
          >
            {input.length > 0 ? (
              <>
                <span style={{ fontSize: 24, fontWeight: 900, letterSpacing: '-0.02em' }}>
                  {input}
                </span>
                <span style={{ fontSize: 14, fontWeight: 700, opacity: 0.6, marginTop: 4 }}>
                  pcs
                </span>
              </>
            ) : (
              <span style={{ color: '#ddd', fontSize: 14, fontWeight: 500 }}>
                Enter quantity
              </span>
            )}
          </div>

          {/* Keypad + Actions */}
          <div className="flex gap-4 items-start">
            <div className="grid grid-cols-3 gap-2.5 flex-1">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                <button
                  key={num}
                  onClick={() => press(String(num))}
                  className="h-14 rounded-xl text-xl font-bold transition-all hover:bg-gray-100 active:scale-95"
                  style={{
                    background: 'rgba(0,0,0,0.04)',
                    fontFamily: 'Poppins',
                    color: '#1a1a1a',
                    border: '1px solid rgba(0,0,0,0.07)',
                  }}
                >
                  {num}
                </button>
              ))}

              <button
                onClick={() => press('0')}
                className="col-span-2 h-14 rounded-xl text-xl font-bold transition-all hover:bg-gray-100 active:scale-95"
                style={{
                  background: 'rgba(0,0,0,0.04)',
                  fontFamily: 'Poppins',
                  color: '#1a1a1a',
                  border: '1px solid rgba(0,0,0,0.07)',
                }}
              >
                0
              </button>

              <button
                onClick={backspace}
                className="h-14 rounded-xl text-xl font-bold transition-all active:scale-95"
                style={{
                  background: `${accentColor}15`,
                  color: accentColor,
                  fontFamily: 'Poppins',
                  border: `1px solid ${accentColor}30`,
                }}
              >
                ⌫
              </button>
            </div>

            <div className="flex flex-col gap-2.5">
              <button
                onClick={confirm}
                className="w-16 rounded-xl font-bold transition-all hover:brightness-110 active:scale-95 flex items-center justify-center"
                style={{
                  height: 122,
                  background: '#4ade80',
                  border: '1px solid rgba(255,255,255,0.5)',
                  color: '#fff',
                  fontSize: 32,
                }}
              >
                ✓
              </button>

              <button
                onClick={onClose}
                className="w-16 h-12 rounded-xl text-sm font-bold transition-all hover:bg-gray-100"
                style={{
                  background: 'rgba(0,0,0,0.04)',
                  color: '#666',
                  fontFamily: 'Poppins',
                  border: '1px solid rgba(0,0,0,0.07)',
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────
export default function InventoryPage() {
  const [loading, setLoading] = useState(true);
  const [mounted, setMounted] = useState(false);
  const [items, setItems] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [inventoryState, setInventoryState] = useState<Record<string, number>>({});
  const [modalItemImg, setModalItemImg] = useState('');

  const [modalOpen, setModalOpen] = useState(false);
  const [modalItemId, setModalItemId] = useState<string | null>(null);
  const [modalItemName, setModalItemName] = useState('');

  useEffect(() => { setMounted(true); }, []);

  useEffect(() => {
    const loadMenuAndInventory = async () => {
      try {
        setLoading(true);
        const [menuRecord, inventoryRes] = await Promise.all([
          getMenuFromCache(),
          fetch('/api/inventory')
        ]);

        if (inventoryRes.ok) {
          const invData = await inventoryRes.json();
          // Safeguard map the DB array structure to an object if needed
          if (invData && typeof invData === 'object' && !Array.isArray(invData)) {
            setInventoryState(invData);
          } else if (Array.isArray(invData)) {
            const state = invData.reduce((acc: any, item: any) => ({ ...acc, [item.itemId || item.id]: item.quantity }), {});
            setInventoryState(state);
          }
        }

        if (!menuRecord) return;

        const flatItems: any[] = [];
        const cats: any[] = [];

        (menuRecord.categories || []).forEach((cat: any) => {
          const processItems = (itemList: any[]) =>
            (itemList || [])
              // FIX: Ignore combo items (items that rely on modifiers for their stock) only ignore MD- ids, CL- ids are still stockable
              .filter((it: any) => {
                if (!it.modifierGroups || it.modifierGroups.length === 0) return true;
                // Only ignore items whose modifiers are MD- (combo items that rely on the
                // modifier choice for their stock, e.g. Combo 1/2 donut selections).
                // CL- (size labels) and AD- (addons with their own separate stock, like
                // Sugar Packets) never disqualify the parent item from being stockable.
                return !it.modifierGroups.some((mg: any) =>
                  (mg.modifiers || []).some((mod: any) => mod.id.startsWith('MD-'))
                );
              })
              .map((it: any) => {
                // Must match getInventoryId in POSDashboard — gx_item_code first, id as fallback
                const stockId = it.gx_item_code ? `IT-${it.gx_item_code}` : it.id;
                return {
                  ...it,
                  stockId,
                  categoryId: cat.id,
                  categoryName: cat.name,
                  img: resolveMenuImageUrl(it.photos?.[0] || it.image || '')
                };
              });

          const currentCatItems: any[] = [];

          if (cat.subcategories?.length) {
            cat.subcategories.forEach((sub: any) => { currentCatItems.push(...processItems(sub.items)); });
          } else {
            currentCatItems.push(...processItems(cat.items));
          }

          // Only add the category to the sidebar if it contains at least one valid stock item
          if (currentCatItems.length > 0) {
            cats.push({ id: cat.id, name: cat.name });
            flatItems.push(...currentCatItems);
          }
        });

        setItems(flatItems);
        setCategories(cats);
      } catch (err) {
        console.error("Failed to load inventory:", err);
      } finally {
        setLoading(false);
      }
    };
    loadMenuAndInventory();
  }, []);

  const filteredItems = useMemo(() =>
    items.filter(item => {
      const matchesCat = activeCategory === "all" || item.categoryId === activeCategory;
      const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
      
      return matchesCat && matchesSearch;
    }), [items, activeCategory, searchQuery]);

  const openNumpad = (id: string, name: string, img: string) => {
    setModalItemId(id);
    setModalItemName(name);
    setModalItemImg(img);
    setModalOpen(true);
  };

  const handleConfirm = (qty: number) => {
    if (modalItemId) {
      setInventoryState(prev => {
        const next = { ...prev };
        if (qty > 0) next[modalItemId] = qty;
        else delete next[modalItemId];
        return next;
      });
    }
    setModalOpen(false);
    setModalItemId(null);
  };

  const handleSaveInventory = async () => {
    try {
      const res = await fetch('/api/inventory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(inventoryState)
      });

      if (res.ok) {
        sileo.success({
          title: "Inventory Updated",
          description: `Successfully updated stock for ${Object.keys(inventoryState).length} items.`,
          fill: "#171717",
          position: "top-center", 
          duration: 1000
        });
      } else {
        sileo.error({ 
          title: "Update Failed", 
          description: "Could not save inventory to the database.",
          fill: "#171717"
        });
      }
    } catch (err) {
      sileo.error({ 
        title: "Connection Error", 
        description: "Failed to connect to the local database.",
        fill: "#171717"
      });
    }
  };

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-[#F0EFEF]">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
          <p className="font-bold text-orange-600 tracking-widest uppercase text-xs">Loading Inventory...</p>
        </div>
      </div>
    );
  }

  return (
    <>
        <style dangerouslySetInnerHTML={{__html: `
            ::-webkit-scrollbar { width: 8px; height: 8px; }
            ::-webkit-scrollbar-track { background: rgba(0, 0, 0, 0.05); border-radius: 4px; }
            ::-webkit-scrollbar-thumb { background: rgba(249, 115, 22, 0.6); border-radius: 4px; }
            ::-webkit-scrollbar-thumb:hover { background: rgba(249, 115, 22, 0.9); }
            * { scrollbar-width: thin; scrollbar-color: rgba(249, 115, 22, 0.6) rgba(0, 0, 0, 0.05); }
        `}} />
        <div className="flex-1 flex flex-col overflow-hidden p-6" style={{ background: C.bg, fontFamily: "Poppins" }}>

        <div
            className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8"
            style={{
            opacity: mounted ? 1 : 0, transform: mounted ? 'translateY(0)' : 'translateY(-18px)',
            transition: 'opacity .55s cubic-bezier(0.22,1,0.36,1), transform .55s cubic-bezier(0.22,1,0.36,1)',
            }}
        >
            <div>
            <div className="flex items-center gap-3 mb-1">
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg"
                style={{ background: "linear-gradient(135deg,#f97316 0%,#ea580c 100%)" }}>
                <FiArchive size={24} />
                </div>
                <h1 className="text-3xl font-black text-gray-900 tracking-tight">
                Stock <span style={{ color: C.orange }}>Inventory</span>
                </h1>
            </div>
            <p className="text-sm text-gray-500 font-medium">Manage and count your current donut and beverage supplies.</p>
            </div>

            <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
                <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 z-10" size={16} />
                <input
                type="text" placeholder="Search items..." value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 text-black rounded-2xl outline-none transition-all"
                style={{ ...glass.card, background: "white" }}
                />
            </div>
            <button onClick={handleSaveInventory}
                className="px-6 py-3 rounded-2xl bg-gray-900 text-white font-bold flex items-center gap-2 shadow-lg active:scale-95 transition-all">
                <FiCheck /> Save Changes
            </button>
            </div>
        </div>

        <div className="flex gap-6 flex-1 overflow-hidden">

            <div
            className="w-64 flex flex-col gap-2 overflow-y-auto hide-scroll pr-2"
            style={{
                opacity: mounted ? 1 : 0, transform: mounted ? 'translateX(0)' : 'translateX(-18px)',
                transition: 'opacity .55s cubic-bezier(0.22,1,0.36,1) .1s, transform .55s cubic-bezier(0.22,1,0.36,1) .1s',
            }}
            >
            <h3 className="text-[10px] font-bold text-gray-400 tracking-widest uppercase mb-2 px-2">Categories</h3>
            <button
                onClick={() => setActiveCategory("all")}
                className={`w-full text-left px-4 py-3 rounded-xl font-bold text-sm transition-all flex items-center justify-between
                ${activeCategory === "all" ? 'bg-orange-500 text-white shadow-md' : 'bg-white/50 text-gray-600 hover:bg-white/80'}`}
            >
                All Items <FiChevronRight className={activeCategory === "all" ? "opacity-100" : "opacity-0"} />
            </button>
            {categories.map(cat => (
                <button key={cat.id} onClick={() => setActiveCategory(cat.id)}
                className={`w-full text-left px-4 py-3 rounded-xl font-bold text-sm transition-all flex items-center justify-between
                    ${activeCategory === cat.id ? 'bg-orange-500 text-white shadow-md' : 'bg-white/50 text-gray-600 hover:bg-white/80'}`}
                >
                {cat.name} <FiChevronRight className={activeCategory === cat.id ? "opacity-100" : "opacity-0"} />
                </button>
            ))}
            </div>

            <div
            className="flex-1 rounded-[32px] overflow-hidden flex flex-col"
            style={{
                ...glass.panel,
                opacity: mounted ? 1 : 0, transform: mounted ? 'scale(1)' : 'scale(0.93)',
                transition: 'opacity .55s cubic-bezier(0.22,1,0.36,1) .18s, transform .55s cubic-bezier(0.22,1,0.36,1) .18s',
            }}
            >
            <div className="grid grid-cols-12 gap-4 px-8 py-4 border-b border-white/20 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                <div className="col-span-6">Item Description</div>
                <div className="col-span-3 text-center">Category</div>
                <div className="col-span-3 text-right">Physical Count</div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 hide-scroll">
                {filteredItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full opacity-30">
                    <FiPackage size={64} className="mb-4" />
                    <p className="font-bold uppercase tracking-widest">No Items Found</p>
                </div>
                ) : (
                  filteredItems.map((item, idx) => {
                      const qty = inventoryState[item.stockId] ?? inventoryState[item.id];
                      const hasQty = qty !== undefined && qty > 0;
                      return (
                      <div
                          key={item.id}
                          className="grid grid-cols-12 gap-4 items-center px-6 py-4 rounded-2xl transition-all hover:scale-[1.005]"
                          style={{
                          backgroundColor: "#e4e4e4",
                          boxShadow: "inset 2px 2px 4px rgba(255,255,255,0.8), inset -2px -2px 4px rgba(0,0,0,0.05), 0 4px 8px rgba(0,0,0,0.05)",
                          opacity: mounted ? 1 : 0, transform: mounted ? 'translateY(0)' : 'translateY(12px)',
                          transition: `opacity .45s cubic-bezier(0.22,1,0.36,1) ${0.25 + idx * 0.045}s, transform .45s cubic-bezier(0.22,1,0.36,1) ${0.25 + idx * 0.045}s, box-shadow .2s ease`,
                          }}
                      >
                          <div className="col-span-6 flex items-center gap-4">
                              <div className="w-12 h-12 rounded-xl bg-white p-1 overflow-hidden border border-gray-100 flex-shrink-0">
                                  <ItemImage src={item.img} alt={item.name} className="w-full h-full" />
                              </div>
                              <div className="min-w-0">
                                  <p className="font-black text-gray-800 uppercase text-sm truncate">{item.name}</p>
                                  <p className="text-[10px] text-gray-400 font-bold">ID: {item.stockId || item.id}</p>
                              </div>
                          </div>

                          <div className="col-span-3 text-center">
                          <span className="px-3 py-1 rounded-lg bg-orange-100 text-orange-600 text-[10px] font-black uppercase tracking-tighter">
                              {item.categoryName}
                          </span>
                          </div>

                          <div className="col-span-3 flex justify-end">
                          <button
                              onClick={() => openNumpad(item.stockId || item.id, item.name, item.img)}
                              className="min-w-[90px] px-4 py-2.5 rounded-xl font-black text-sm transition-all active:scale-95"
                              style={{
                              background: hasQty ? 'linear-gradient(135deg,#f97316,#ea580c)' : 'white',
                              color: hasQty ? 'white' : '#94a3b8',
                              border: hasQty ? '1.5px solid transparent' : '1.5px solid rgba(255,255,255,0.9)',
                              boxShadow: hasQty ? '0 4px 12px rgba(249,115,22,0.35)' : '0 2px 8px rgba(0,0,0,0.05)',
                              fontFamily: 'Poppins',
                              }}
                          >
                              {hasQty ? `${qty} pcs` : '— tap —'}
                          </button>
                          </div>
                      </div>
                      );
                  })
                )}
            </div>

            <div className="px-8 py-6 bg-white/30 backdrop-blur-md border-t border-white/20 flex justify-between items-center">
                <div className="flex gap-8">
                <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Showing</p>
                    <p className="text-xl font-black text-gray-900">{filteredItems.length} <span className="text-sm text-gray-500">Items</span></p>
                </div>
                <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Items to Update</p>
                    <p className="text-xl font-black text-orange-600">{Object.keys(inventoryState).length} <span className="text-sm text-orange-400">Entries</span></p>
                </div>
                </div>
                <button onClick={() => setInventoryState({})}
                className="flex items-center gap-2 text-xs font-bold text-gray-400 hover:text-red-500 transition-colors">
                <FiRefreshCw /> Reset All Counts
                </button>
            </div>
            </div>
        </div>

            <NumpadModal
                open={modalOpen}
                itemName={modalItemName}
                itemImg={modalItemImg}        
                initialValue={modalItemId ? inventoryState[modalItemId] : undefined}
                onConfirm={handleConfirm}
                onClose={() => setModalOpen(false)}
            />
        </div>
    </>
  );
}