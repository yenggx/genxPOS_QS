"use client";
import { useState, useEffect, useRef } from "react";
import ReceiptPreviewDemo from "../../components/ReceiptPreviewDemo";
import { useRouter } from "next/navigation";
import {
  MdStore, MdPrint, MdLock, MdHome, MdInfoOutline, MdDelete, MdSave,
  MdCheckCircle, MdWifi, MdSignalWifiOff, MdRefresh, MdReceiptLong, MdSettings, MdMonitor
} from "react-icons/md";
import { FaReceipt, FaIdBadge, FaServer, FaFileLines, FaBarcode } from "react-icons/fa6";
import { Unlock, Lock, HelpCircle, AlertCircle, Usb, Rocket } from "lucide-react";
import { sileo } from "sileo";

// IMPORT OUR NEW CONTEXT
import { usePrinter } from "@/app/context/PrinterContext";
import { useCfd } from "@/app/context/CfdContext";
import { getWorkstationId } from "@/src/lib/workstation";

const theme = {
  card: { background: "#FFFFFF", border: "1px solid #E5E7EB", boxShadow: "0 4px 12px rgba(0,0,0,0.03)", borderRadius: 16 } as React.CSSProperties,
  panel: { background: "#FFFFFF", border: "1px solid rgba(0,0,0,0.08)", boxShadow: "0 8px 24px rgba(0,0,0,0.05)" } as React.CSSProperties,
  input: { background: "#FFFFFF", border: "1px solid #E5E7EB", borderRadius: 8, transition: "all 0.2s ease" } as React.CSSProperties,
  inputFocus: { border: "1px solid #FF6700", boxShadow: "0 0 0 3px rgba(255,103,0,0.1)" } as React.CSSProperties,
  readonlyInput: { background: "#F9FAFB", border: "1px solid #E5E7EB", borderRadius: 8 } as React.CSSProperties,
};

type FiscalKey = "vatNumber" | "tinNumber" | "minNumber" | "ptuNumber" | "snNumber";
interface FiscalField { key: FiscalKey; label: string; sublabel: string; icon: string; placeholder: string; maxLength: number; }

const FISCAL_FIELDS: FiscalField[] = [
  { key: "vatNumber", label: "VAT #", sublabel: "Value Added Tax Registration",  icon: "vat", placeholder: "e.g. 123-456-789-000", maxLength: 20 },
  { key: "tinNumber", label: "TIN #", sublabel: "Taxpayer Identification Number", icon: "tin", placeholder: "e.g. 000-000-000-000", maxLength: 20 },
  { key: "minNumber", label: "MIN #", sublabel: "Machine Identification Number",  icon: "min", placeholder: "e.g. 00000000001",      maxLength: 20 },
  { key: "ptuNumber", label: "PTU #", sublabel: "Permit to Use Number",           icon: "ptu", placeholder: "e.g. AA000000000000",   maxLength: 20 },
  { key: "snNumber",  label: "SN #",  sublabel: "Serial Number",                  icon: "sn",  placeholder: "e.g. SN-00000000001",   maxLength: 20 },
];

const SIDEBAR_SECTIONS = [
  { id: "store",   label: "Store Info", icon: "store",   accent: "rgba(255,103,0,1)" },
  { id: "receipt", label: "Receipt",    icon: "printer", accent: "rgba(255,103,0,1)" },
  { id: "config",  label: "Config",     icon: "settings",accent: "rgba(255,103,0,1)" },
  { id: "screens", label: "Screens",    icon: "monitor", accent: "rgba(255,103,0,1)" },
  { id: "system",  label: "System",     icon: "system",  accent: "rgba(255,103,0,1)" },
];

type ConnStatus = "connected" | "disconnected" | "idle" | "checking";
interface Connection { label: string; sub: string; status: ConnStatus; }
type LogLevel = "error" | "warn" | "info";
interface LogEntry { level: LogLevel; message: string; time: string; }

export interface ReceiptFormat {
  id: number; name: string; header: string; footer: string;
  created_at: string; updated_at: string;
}

export interface StoreData {
  id: number; store_id: string; series_type: string; number_of_work_station: number;
  name: string; description: string; open_time: string; close_time: string;
  address: string; email: string; contact_number: string; pos_type: string;
  longitude: string; latitude: string; merchant_id: string; merchant_code: string;
  partner_merchant_id: string; currency: string; code: string; exponent: string;
  services_charge: number; allowable_void_refund_hours?: number; created_at: string; updated_at: string;
  receiptFormats?: ReceiptFormat[];
}

function getIcon(key: string, props: { size?: number; className?: string; color?: string } = {}) {
  const s = props.size || 20; const c = props.className || ""; const col = props.color || "#1a1a1a";
  const m: { [k: string]: React.ReactNode } = {
    store:   <MdStore size={s} className={c} color={col} />,
    printer: <MdPrint size={s} className={c} color={col} />,
    system:  <MdLock size={s} className={c} color={col} />,
    settings:<MdSettings size={s} className={c} color={col} />,
    monitor: <MdMonitor size={s} className={c} color={col} />,
    home:    <MdHome size={s} className={c} color={col} />,
    info:    <MdInfoOutline size={s} className={c} color={col} />,
    wifi:    <MdWifi size={s} className={c} color={col} />,
    nowifi:  <MdSignalWifiOff size={s} className={c} color={col} />,
    refresh: <MdRefresh size={s} className={c} color={col} />,
    xread:   <MdReceiptLong size={s} className={c} color={col} />,
    zread:   <MdReceiptLong size={s} className={c} color={col} />,
    vat:     <FaReceipt size={s-2} className={c} color={col} />,
    tin:     <FaIdBadge size={s-2} className={c} color={col} />,
    min:     <FaServer size={s-2} className={c} color={col} />,
    ptu:     <FaFileLines size={s-2} className={c} color={col} />,
    sn:      <FaBarcode size={s-2} className={c} color={col} />,
    delete:  <MdDelete size={s} className={c} color={col} />,
    save:    <MdSave size={s} className={c} color={col} />,
    check:   <MdCheckCircle size={s} className={c} color={col} />,
  };
  return m[key] || null;
}

function SectionLabel({ title }: { title: string }) {
  return (
    <p style={{
      fontSize: 10, fontWeight: 800, color: "#FF6700", letterSpacing: 1,
      textTransform: "uppercase", fontFamily: "Poppins",
      borderBottom: "1px solid #F3F4F6", paddingBottom: 6, marginTop: 12, marginBottom: 8
    }}>{title}</p>
  );
}

function EditableStoreField({ icon, label, sublabel, value, onChange, placeholder, mono = false }: {
  icon: string; label: string; sublabel: string; value: string; onChange: (v: string) => void; placeholder?: string; mono?: boolean;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <div className="flex flex-col gap-2 w-full">
      <div className="flex items-start gap-2">
        <div style={{ marginTop: 2 }}>{getIcon(icon, { size: 12, color: "#888" })}</div>
        <div className="flex flex-col">
          <p style={{ fontSize: 11, fontWeight: 700, color: "#1A1A1A", fontFamily: "Poppins", lineHeight: 1 }}>{label}</p>
          <p style={{ fontSize: 9, color: "#888" }}>{sublabel}</p>
        </div>
      </div>
      <input type="text" value={value} placeholder={placeholder || `Enter ${label.toLowerCase()}`}
        onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 outline-none"
        style={{ ...theme.input, ...(focused ? theme.inputFocus : {}), fontFamily: mono ? "'Courier New', Courier, monospace" : "inherit", color: "#1A1A1A", fontSize: 12, fontWeight: 500 }} />
    </div>
  );
}

function FiscalInputField({ field, value, onChange }: { field: FiscalField; value: string; onChange: (val: string) => void; }) {
  const [focused, setFocused] = useState(false);
  const hasValue = value.length > 0;
  return (
    <div className="flex flex-col gap-2 w-full mb-2">
      <div className="flex items-start gap-2">
        <div style={{ marginTop: 2 }}>{getIcon(field.icon, { size: 12, color: "#888" })}</div>
        <div className="flex flex-col">
          <p style={{ fontSize: 11, fontWeight: 700, color: "#1A1A1A", fontFamily: "Poppins", lineHeight: 1 }}>{field.label}</p>
          <p style={{ fontSize: 9, color: "#888" }}>{field.sublabel}</p>
        </div>
      </div>
      <div className="relative overflow-hidden" style={{ ...theme.input, ...(focused ? theme.inputFocus : {}) }}>
        <input type="text" value={value} maxLength={field.maxLength} placeholder={field.placeholder}
          onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} onChange={(e) => onChange(e.target.value)}
          className="w-full pl-3 pr-10 py-2 bg-transparent outline-none"
          style={{ fontFamily: "'Courier New', Courier, monospace", color: "#1A1A1A", fontSize: 12, fontWeight: 700, letterSpacing: 0.8 }} />
        <span className="absolute right-4 top-1/2 -translate-y-1/2 font-semibold" style={{ fontSize: 9, color: "#A1A1AA" }}>{value.length}/{field.maxLength}</span>
        {hasValue && <div style={{ position: "absolute", right: 0, top: "15%", bottom: "15%", width: 4, borderRadius: "4px 0 0 4px", background: "#FF6700" }} />}
      </div>
    </div>
  );
}

function ReadonlyField({ icon, label, sublabel, value, mono = false, badge }: { icon: string; label: string; sublabel: string; value: string; mono?: boolean; badge?: string; }) {
  return (
    <div className="flex flex-col gap-2 w-full">
      <div className="flex items-start gap-2">
        <div style={{ marginTop: 2 }}>{getIcon(icon, { size: 12, color: "#888" })}</div>
        <div className="flex flex-col">
          <p style={{ fontSize: 11, fontWeight: 700, color: "#1A1A1A", fontFamily: "Poppins", lineHeight: 1 }}>{label}</p>
          <p style={{ fontSize: 9, color: "#888" }}>{sublabel}</p>
        </div>
      </div>
      <div className="flex items-center gap-2 px-3 py-2" style={theme.readonlyInput}>
        <p style={{ fontFamily: mono ? "'Courier New', Courier, monospace" : "inherit", fontSize: 12, color: "#444", fontWeight: 700, flex: 1 }}>{value || "—"}</p>
        {badge && <span className="px-2 py-0.5 rounded-full font-bold flex-shrink-0" style={{ fontSize: 8, background: "rgba(255,103,0,0.08)", color: "#FF6700", border: "1px solid rgba(255,103,0,0.2)" }}>{badge}</span>}
      </div>
    </div>
  );
}

function ConnDot({ status }: { status: ConnStatus }) {
  const c: Record<ConnStatus, string> = { connected: "#22c55e", disconnected: "#ef4444", idle: "#f59e0b", checking: "#60a5fa" };
  const sh: Record<ConnStatus, string> = { connected: "0 0 7px rgba(34,197,94,0.8)", disconnected: "0 0 7px rgba(239,68,68,0.8)", idle: "0 0 7px rgba(245,158,11,0.8)", checking: "0 0 7px rgba(96,165,250,0.8)" };
  return <div style={{ width: 8, height: 8, borderRadius: "50%", background: c[status], boxShadow: sh[status], flexShrink: 0 }} />;
}

function LogBadge({ level }: { level: LogLevel }) {
  const m: Record<LogLevel, { label: string; bg: string; color: string }> = {
    error: { label: "ERR",  bg: "rgba(239,68,68,0.15)",  color: "#dc2626" },
    warn:  { label: "WARN", bg: "rgba(245,158,11,0.15)", color: "#d97706" },
    info:  { label: "INFO", bg: "rgba(59,130,246,0.15)", color: "#2563eb" },
  };
  const s = m[level];
  return <span className="px-2 py-0.5 rounded-full font-black" style={{ fontSize: 8, background: s.bg, color: s.color, textTransform: "uppercase", letterSpacing: 1, flexShrink: 0 }}>{s.label}</span>;
}

const logRowBg: Record<LogLevel, React.CSSProperties> = {
  error: { background: "rgba(239,68,68,0.06)",  border: "1px solid rgba(239,68,68,0.14)"  },
  warn:  { background: "rgba(245,158,11,0.06)", border: "1px solid rgba(245,158,11,0.14)" },
  info:  { background: "rgba(59,130,246,0.06)", border: "1px solid rgba(59,130,246,0.14)" },
};

const INITIAL_LOGS: LogEntry[] = [
  { level: "error", message: "Payment gateway connection timeout after 30s",            time: "09:42:11" },
  { level: "error", message: "Receipt print failed — printer offline (localhost:9100)", time: "09:38:55" },
  { level: "info",  message: "System startup complete. All services initialized.",      time: "08:00:00" },
];

// --- Local formatting tools for test receipt ---
function padRight(str: string, len: number) { return (str + ' '.repeat(len)).slice(0, len); }
function padLeft(str: string, len: number) { return (' '.repeat(len) + str).slice(-len); }
function centerText(str: string, len: number) {
    const pad = Math.max(0, len - str.length);
    const padL = Math.floor(pad / 2);
    return ' '.repeat(padL) + str + ' '.repeat(pad - padL);
}
function divider(width: number) { return '-'.repeat(width); }
function formatAmount(amount: number) {
    return amount.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function formatHtmlToTextLines(htmlStr: string, width: number) {
    if (!htmlStr) return '';
    let text = htmlStr.replace(/<br\s*[\/]?>/gi, '\n').replace(/<\/p>|<\/div>|<\/h[1-6]>/gi, '\n');
    text = text.replace(/<[^>]*>?/gm, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&');
    const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    let out = '';
    for (const line of lines) {
        if (line.length > width) {
            out += centerText(line.substring(0, width), width) + '\n';
            out += centerText(line.substring(width, width * 2), width) + '\n';
        } else {
            out += centerText(line, width) + '\n';
        }
    }
    return out;
}

function buildTestReceiptText({ storeData, receiptFormat, data, width }: any) {
    let out = '';
    const div    = divider(width) + '\n';
    const valW   = 12; 
    const lblW   = width - valW; 

    if (receiptFormat?.header) {
        out += formatHtmlToTextLines(receiptFormat.header, width);
    } else if (storeData?.name) {
        out += centerText(storeData.name, width) + '\n';
    }

    out += '\n' + centerText("THIS SERVES AS YOUR SALES INVOICE", width) + '\n\n';
    out += padRight('SALES INVOICE NO.', 20) + padLeft(data.salesNumber || '', width - 20) + '\n';
    out += padRight('TXN NUMBER', 20)        + padLeft(data.transactionNumber || '', width - 20) + '\n';

    const now = new Date();
    const pad2 = (n: number) => String(n).padStart(2, '0');
    const dateStr = `${pad2(now.getMonth() + 1)}/${pad2(now.getDate())}/${String(now.getFullYear()).slice(-2)} ${pad2(now.getHours())}:${pad2(now.getMinutes())}`;

    out += padRight(`CASHIER: ${data.staffId || '-'}`, 20) + padLeft(`T1 ${dateStr}`, width - 20) + '\n';
    out += `${(data.orderType || 'DINE-IN').toUpperCase()}\n`;
    out += div;
    out += centerText(`ORDER SLIP NO.: ${data.orderNumber || ''}`, width) + '\n';
    out += div;

    let itemCount = 0;
    const items = data.items || [];
    for (const item of items) {
        const qty       = item.quantity || 1;
        const basePrice = item.price || 0;
        itemCount      += qty;
        out += `${item.itemName}\n`;
        out += padRight(`  ${qty} @ ${formatAmount(basePrice)}`, lblW) + padLeft(formatAmount(basePrice * qty), valW) + '\n';
    }

    out += '\n';
    let totalPaid = 0;
    out += padLeft('TOTAL :', lblW) + padLeft(formatAmount(data.total || 0), valW) + '\n';

    const payments = data.payments || [];
    for (const p of payments) {
        const pAmt   = p.amount || 0;
        const method = (p.method || 'CASH').toUpperCase();
        totalPaid   += pAmt;
        out += padLeft(`${method.padEnd(5, ' ')} :`, lblW) + padLeft(formatAmount(pAmt), valW) + '\n';
    }

    const change = data.change !== undefined ? data.change : Math.max(0, totalPaid - (data.total || 0));
    out += padLeft('CHANGE DUE :', lblW) + padLeft(formatAmount(change), valW) + '\n';
    out += '\n';
    out += centerText(`NO. OF ITEMS : ${itemCount}`, width) + '\n';
    out += padRight('VATable Sales',     lblW) + padLeft(formatAmount(data.vatableSales   || 0), valW) + '\n';
    out += padRight('VAT Amount',        lblW) + padLeft(formatAmount(data.tax             || 0), valW) + '\n';
    out += padRight('VAT Exempt Sales',  lblW) + padLeft(formatAmount(data.vatExemptSales || 0), valW) + '\n';
    out += padRight('Zero-Rated Sales',  lblW) + padLeft(formatAmount(data.zeroRatedSales || 0), valW) + '\n';
    out += '\n';

    const sigLine = '-'.repeat(Math.floor(width * 0.8));
    out += centerText(sigLine, width) + '\n';
    out += centerText("CUSTOMER SIGNATURE", width) + '\n';
    out += centerText("(Store's Copy)", width) + '\n';
    out += div;

    if (receiptFormat?.footer) {
        out += formatHtmlToTextLines(receiptFormat.footer, width);
    }
    return out;
}


// ── Workstation identity ──────────────────────────────────────────────────────
const WORKSTATION_ID = getWorkstationId() || '001';

// ── Double-print configuration ────────────────────────────────────────────────
const DOUBLE_PRINT_OPTIONS = [
  { id: 'REGULAR',  label: 'Regular',         sublabel: 'Standard customer transaction',      icon: '🧾' },
  { id: 'SC',       label: 'Senior Citizen',   sublabel: '20% SC discount transaction',        icon: '👴' },
  { id: 'PWD',      label: 'PWD',              sublabel: '20% Person with Disability',         icon: '♿' },
  { id: 'ATHLETE',  label: 'Athlete',          sublabel: '20% Registered Athlete discount',    icon: '🏅' },
  { id: 'DIPLOMAT', label: 'Diplomat',         sublabel: 'VAT-exempt (zero-rated)',            icon: '🏛️' },
  { id: 'PEZA',     label: 'PEZA Zone',        sublabel: 'VAT-exempt (no VAT)',                icon: '🏢' },
  { id: 'SOLO',     label: 'Solo Parent',      sublabel: 'Custom solo-parent discount',        icon: '👨‍👦' },
  { id: 'MEDAL',    label: 'Medal of Valor',   sublabel: '20% Medal of Valor discount',        icon: '🎖️' },
] as const;

export default function SettingsPage() {
  const { cfdConfig, updateCfdConfig, cfdOpen, cfdWindowRef, launchCfd } = useCfd();
  const router = useRouter();
  const [activeSection, setActiveSection] = useState("store");
  const [loading, setLoading]             = useState(false);
  const [saved, setSaved]                 = useState(false);
  const [storeLoading, setStoreLoading]   = useState(true);
  const [storeData, setStoreData]         = useState<StoreData | null>(null);
  const [doublePrintTypes, setDoublePrintTypes] = useState<Record<string, boolean>>({
    REGULAR: false, SC: false, PWD: false, ATHLETE: false,
    DIPLOMAT: false, PEZA: false, SOLO: false, MEDAL: false,
  });
  const [doublePrintOpen, setDoublePrintOpen] = useState(false);
  const [discountScopeOpen, setDiscountScopeOpen] = useState(false);

  type DiscountScope = "all" | "dine_in" | "take_out";
  const DISCOUNT_SCOPE_OPTIONS: { id: DiscountScope; label: string; icon: string }[] = [
    { id: "all",      label: "All",      icon: "🌐" },
    { id: "dine_in",  label: "Dine In",  icon: "🍽️" },
    { id: "take_out", label: "Take Out", icon: "🛍️" },
  ];
  const DISCOUNT_SCOPE_TYPES = [
    { id: "SR",       label: "Senior Citizen", sublabel: "20% SC discount",           icon: "👴" },
    { id: "PWD",      label: "PWD",            sublabel: "20% Person w/ Disability",  icon: "♿" },
    { id: "ATHLETE",  label: "Athlete",         sublabel: "20% Registered Athlete",    icon: "🏅" },
    { id: "DIPLOMAT", label: "Diplomat",        sublabel: "VAT-exempt (zero-rated)",   icon: "🏛️" },
    { id: "PEZA",     label: "PEZA Zone",       sublabel: "VAT-exempt (no VAT)",       icon: "🏢" },
    { id: "SOLO",     label: "Solo Parent",     sublabel: "20% Solo Parent",           icon: "👨‍👦" },
    { id: "MEDAL",    label: "Medal of Valor",  sublabel: "20% Medal of Valor",        icon: "🎖️" },
    { id: "CUSTOM",   label: "Custom",          sublabel: "Custom amount, no limit",   icon: "✏️" },
  ] as const;

  const [discountScopes, setDiscountScopes] = useState<Record<string, DiscountScope>>({});

  const [editableStore, setEditableStore] = useState({
    name: "", email: "", contact_number: "", address: "",
    open_time: "", close_time: "", services_charge: "", allowable_void_refund_hours: "",
    longitude: "", latitude: ""
  });

  const [fiscalFields, setFiscalFields] = useState<Record<FiscalKey, string>>({
    vatNumber: "", tinNumber: "", minNumber: "", ptuNumber: "", snNumber: "",
  });

  const [kdsTimers, setKdsTimers] = useState({ warningMinutes: "5", dangerMinutes: "10" });
  const [cashDropLimits, setCashDropLimits] = useState({ warningAmount: "10000", maxAmount: "20000" });
  const [cashFundLimit, setCashFundLimit] = useState({ limit: "1000" });
  const [soloParentLimit, setSoloParentLimit] = useState({ limit: "2000" });
  const [soloParentReset, setSoloParentReset] = useState<"weekly" | "monthly">("weekly");
  const [grabConfig, setGrabConfig] = useState({ merchantId: "", secret: "" });
  const [zReadingType, setZReadingType] = useState<"Consolidated" | "Per Terminal" | "Both">("Consolidated");

  const [selectedFormatId, setSelectedFormatId] = useState<number | null>(null);

  const [connections, setConnections] = useState<Connection[]>([
    { label: "CMS Server",      sub: "cms.geniex.tech:8443", status: "connected"    },
    { label: "Internet",        sub: "Checking...",          status: "checking"     },
    { label: "Payment Gateway", sub: "pay.geniex.tech",       status: "disconnected" },
  ]);
  const [logs, setLogs]           = useState<LogEntry[]>(INITIAL_LOGS);
  const [logFilter, setLogFilter] = useState<"all" | LogLevel>("all");
  const [retrying, setRetrying]   = useState(false);
  const [uptime, setUptime]       = useState(0);

  // --- NEW SCREEN DETECTION STATE ---
  const [availableScreens, setAvailableScreens] = useState<any[]>([]);
  const [selectedCustomerScreenId, setSelectedCustomerScreenId] = useState<string>("");
  const [screenApiSupported, setScreenApiSupported] = useState(true);
  const [idleMediaUrl, setIdleMediaUrl] = useState("");

  type MediaType = 'image' | 'video';
  interface MediaItem { id: string; url: string; type: MediaType; duration: number; name: string; }
  interface DisplayModeConfig { mode: 'static' | 'carousel'; items: MediaItem[]; }
  interface CfdConfig { idle: DisplayModeConfig; ongoing: DisplayModeConfig; }
  // CFD specific state
  const [cfdTab, setCfdTab] = useState<'idle' | 'ongoing'>('idle');
  const [mediaLibrary, setMediaLibrary] = useState<any[]>([]);
  const [libraryLoading, setLibraryLoading] = useState(false);
  const [selectedClipId, setSelectedClipId] = useState<string | null>(null);
  const [previewPlaying, setPreviewPlaying] = useState(false);
  const [previewIndex, setPreviewIndex] = useState(0);
  const [previewProgress, setPreviewProgress] = useState(0);
  const previewTimerRef = useRef<NodeJS.Timeout | null>(null);
  const previewProgressRef = useRef<NodeJS.Timeout | null>(null);
  const videoPreviewRef = useRef<HTMLVideoElement | null>(null);

  const fetchMediaLibrary = async () => {
    setLibraryLoading(true);
    try {
      const res = await fetch('/api/upload');
      const data = await res.json();
      if (data.success) setMediaLibrary(data.media || []);
    } catch {}
    finally { setLibraryLoading(false); }
  };

  useEffect(() => {
    if (activeSection === 'screens') fetchMediaLibrary();
  }, [activeSection]);

  
  // Temp state for the media add form
  const [newMediaUrl, setNewMediaUrl] = useState("");
  const [newMediaType, setNewMediaType] = useState<MediaType>('image');
  const [newMediaDuration, setNewMediaDuration] = useState(5);
  const [isUploading, setIsUploading] = useState(false);
  const [showStock, setShowStock] = useState<boolean>(false);
  const handleToggleShowStock = () => {
    setShowStock(prev => {
      const next = !prev;
      return next;
    });
  };

  const handleUpdateCfdMode = (mode: 'static' | 'carousel') => {
    updateCfdConfig({ ...cfdConfig, [cfdTab]: { ...cfdConfig[cfdTab], mode } });
  };

  const handleRemoveMedia = (id: string) => {
    const updatedItems = cfdConfig[cfdTab].items.filter((i) => i.id !== id);
    updateCfdConfig({ ...cfdConfig, [cfdTab]: { ...cfdConfig[cfdTab], items: updatedItems } });
  };

  useEffect(() => {
    if (typeof window !== "undefined") {
      setScreenApiSupported("getScreenDetails" in window);
      
      const savedScreen = localStorage.getItem("customer_display_id");
      const cachedScreens = localStorage.getItem("cached_screens");
      const savedCfdConfig = localStorage.getItem("cfd_config");

      if (savedScreen) setSelectedCustomerScreenId(savedScreen);
      // Load cached screens so we don't need to re-detect every time
      if (cachedScreens) setAvailableScreens(JSON.parse(cachedScreens));
      if (savedCfdConfig) {
        const parsed = JSON.parse(savedCfdConfig);
      }
    }
  }, []);

  useEffect(() => {
    return () => {
      if (previewTimerRef.current) clearTimeout(previewTimerRef.current);
      if (previewProgressRef.current) clearInterval(previewProgressRef.current);
    };
  }, []);


  const handleDetectScreens = async () => {
    try {
      if (!("getScreenDetails" in window)) {
        setScreenApiSupported(false);
        return;
      }

      // Check permission state first
      const permission = await navigator.permissions.query({ name: "window-management" as PermissionName });
      
      if (permission.state === "denied") {
        sileo.error({ title: "Permission Denied", description: "Go to browser site settings and reset the Window Management permission.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
        return;
      }

      const screenDetails = await (window as any).getScreenDetails();

      const plainScreens = screenDetails.screens.map((s: any, idx: number) => ({
        id: String(idx),                        // always the index, never the label
        label: s.label || `Display ${idx + 1}`,
        width: s.width,
        height: s.height,
        left: s.left,
        top: s.top,
        isPrimary: s.isPrimary,
      }));

      setAvailableScreens(plainScreens);
    } catch (err: any) {
      if (err?.name === "NotAllowedError") {
        sileo.error({ title: "Permission Denied", description: "Allow 'Window Management' in your browser's site settings, then try again.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
      } else {
        sileo.error({ title: "Detection Failed", description: String(err?.message || err), fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
      }
    }
  };

  const handleSelectScreen = (screenId: string) => {
    setSelectedCustomerScreenId(screenId);
    sileo.success({ title: "Display Assigned", description: "Customer display updated successfully.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }, duration: 1000});
  };

  const saveMediaUrl = (url: string) => {
    setIdleMediaUrl(url);
  };
  // -----------------------------------

  // Hook into our global printer context
  const { usbPrinter, tillStatus, pairPrinter, unpairPrinter, printDirect, checkStatusNow } = usePrinter();

  const uptimeRef = useRef(3620);

  useEffect(() => {
    const t = setInterval(() => { uptimeRef.current++; setUptime(uptimeRef.current); }, 1000);
    return () => clearInterval(t);
  }, []);
  const fmtUptime = (s: number) => `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m ${s % 60}s`;

  const handlePrintTest = async () => {
    if (!usbPrinter) {
      sileo.error({ title: "No Printer", description: "Please pair a printer first.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }});
      return;
    }
    
    try {
      const testData = {
          orderNumber: 1,
          salesNumber: "001-00000001",
          transactionNumber: "0000000001",
          staffId: "Cashier 1",
          transactionType: "REGULAR",
          orderType: "DineIn",
          items: [
              { quantity: 1, itemName: "Test Donut", price: 50, modifiers: [] },
              { quantity: 2, itemName: "Test Coffee", price: 100, modifiers: [] }
          ],
          subtotal: 223.21,
          total: 250,
          tax: 26.79,
          discountAmount: 0,
          vatableSales: 223.21,
          vatExemptSales: 0,
          zeroRatedSales: 0,
          payments: [ { method: "cash", amount: 250 } ],
          change: 0,
      };

      const formatToUse = storeData?.receiptFormats?.find(f => f.id === selectedFormatId) || storeData?.receiptFormats?.[0] || { header: "", footer: "Test Print successful!" };

      const receiptText = buildTestReceiptText({ 
          storeData, 
          receiptFormat: formatToUse, 
          data: testData,
          width: 48 
      });
      
      // Print and pop the drawer!
      await printDirect(receiptText, true);

      sileo.success({ title: "Test Receipt Printed!", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }, duration: 1000});
    } catch (error) {
      console.error(error);
      sileo.error({ title: "Print Failed", description: "Hardware blocked or disconnected.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }});
    }
  };

  useEffect(() => {
    const t = setTimeout(() => {
      setConnections(prev => prev.map(c => c.label === "Internet" ? { ...c, sub: "8.8.8.8 — 12ms", status: "connected" } : c));
    }, 1200);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const load = async () => {
      setStoreLoading(true);
      try {
        const res = await fetch("/api/store");
        const json = await res.json();
        const data: StoreData = json?.payload;
        setStoreData(data);
        setEditableStore({
          name: data.name || "", email: data.email || "", contact_number: data.contact_number || "", address: data.address || "",
          open_time: data.open_time || "", close_time: data.close_time || "",
          services_charge: String(data.services_charge ?? ""), allowable_void_refund_hours: String(data.allowable_void_refund_hours ?? 24),
          longitude: data.longitude || "", latitude: data.latitude || ""
        });
        localStorage.setItem("store_data", JSON.stringify(data));
      } catch {
        const mock: StoreData = {
          id: 1, store_id: "store-00001", series_type: "WS", number_of_work_station: 5,
          name: "F&B - San Lorenzo", description: "<p>Test Store</p>",
          open_time: "10:00:00", close_time: "23:59:00",
          address: "718, P. Paterno Street, Quiapo, Manila, 1001, Philippines",
          email: "test@geniex.tech", contact_number: "0956512534",
          pos_type: "gxpos", longitude: "120.9842", latitude: "14.5995",
          merchant_id: "gXPOS-123", merchant_code: "DCE3RYZ", partner_merchant_id: "F&B - San Lorenzo",
          currency: "PHP", code: "", exponent: "2", services_charge: 0, allowable_void_refund_hours: 24,
          created_at: "2026-03-27T02:27:49.000000Z", updated_at: "2026-04-09T03:33:51.000000Z",
          receiptFormats: [
            { id: 1, name: "XRead",                   header: "<p>X-Read Format</p>",  footer: "<p>Thank you</p>",  created_at: "2026-04-09T03:07:18.000000Z", updated_at: "2026-04-09T03:07:18.000000Z" },
            { id: 2, name: "ZRead",                   header: "<p>Z-Read Format</p>",  footer: "<p>End of Day</p>", created_at: "2026-04-09T03:07:45.000000Z", updated_at: "2026-04-09T03:07:45.000000Z" },
            { id: 3, name: "Regular Transaction",     header: "<p>Regular Receipt</p>", footer: "<p>Thank you</p>", created_at: "2026-04-09T03:08:28.000000Z", updated_at: "2026-04-09T03:08:28.000000Z" },
          ],
        };
        setStoreData(mock);
        setEditableStore({
          name: mock.name, email: mock.email, contact_number: mock.contact_number, address: mock.address,
          open_time: mock.open_time, close_time: mock.close_time,
          services_charge: String(mock.services_charge), allowable_void_refund_hours: String(mock.allowable_void_refund_hours),
          longitude: mock.longitude, latitude: mock.latitude
        });
        localStorage.setItem("store_data", JSON.stringify(mock));
      } finally { setStoreLoading(false); }
    };
    load();
  }, [activeSection]);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch(`/api/settings?workstationId=${WORKSTATION_ID}`);
        if (!res.ok) return;
        const data = await res.json();
        setFiscalFields({ vatNumber: data.vatNumber || "", tinNumber: data.tinNumber || "", minNumber: data.minNumber || "", ptuNumber: data.ptuNumber || "", snNumber: data.snNumber || "" });
        setEditableStore(p => ({ ...p, allowable_void_refund_hours: String(data.allowable_void_refund_hours ?? 24) }));
        setKdsTimers({ warningMinutes: String(data.kdsWarningMinutes ?? 5), dangerMinutes: String(data.kdsDangerMinutes ?? 10) });
        setCashDropLimits({
          warningAmount: String(data.cashDropWarningAmount ?? "10000"),
          maxAmount: String(data.cashDropMaxAmount ?? "20000"),
        });
        
        setCashFundLimit({ limit: String(data.cashFundLimit ?? "1000") });
        setSoloParentLimit({ limit: String(data.soloParentLimit ?? "2000") });
        setSoloParentReset(data.soloParentReset ?? "monthly");

        setShowStock(data.showStock ?? false);
        if (data.zReadingType) setZReadingType(data.zReadingType);
        if (data.doublePrintTypes) setDoublePrintTypes(prev => ({ ...prev, ...data.doublePrintTypes }));
        if (data.discountScopes)   setDiscountScopes(prev => ({ ...prev, ...data.discountScopes }));
      } catch { }
    };
    load();
  }, []);

  const handleSaveAll = async () => {
    setLoading(true);
    try {
      await Promise.all([
        fetch("/api/store",    { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(editableStore) }),
        fetch("/api/settings", { method: "POST",  headers: { "Content-Type": "application/json" }, 
          body: JSON.stringify({
            workstationId: WORKSTATION_ID,
            ...fiscalFields,
            allowable_void_refund_hours: editableStore.allowable_void_refund_hours,
            kdsWarningMinutes: Number(kdsTimers.warningMinutes),
            kdsDangerMinutes: Number(kdsTimers.dangerMinutes),
            grabConfig,
            cashDropWarningAmount: Number(cashDropLimits.warningAmount),
            cashDropMaxAmount: Number(cashDropLimits.maxAmount),
            cashFundLimit: Number(cashFundLimit.limit),
            soloParentLimit: Number(soloParentLimit.limit),
            soloParentReset: soloParentReset,
            showStock: showStock,
            zReadingType: zReadingType,
            doublePrintTypes,
            discountScopes,
          }) 
        }),
      ]);
      localStorage.setItem('double_print_types', JSON.stringify(doublePrintTypes));
      localStorage.setItem('discount_scopes', JSON.stringify(discountScopes));
      const cur = JSON.parse(localStorage.getItem("store_data") || "{}");
      localStorage.setItem("store_data", JSON.stringify({ ...cur, allowable_void_refund_hours: editableStore.allowable_void_refund_hours }));
    } catch { }
    
    setSaved(true); setTimeout(() => setSaved(false), 3000); setLoading(false);
  };

  const handleRetryConnections = () => {
    setRetrying(true);
    setConnections(prev => prev.map(c => ({ ...c, status: "checking" as ConnStatus })));
    setTimeout(() => {
      setConnections([
        { label: "CMS Server",      sub: "cms.geniex.tech:8443", status: "connected"    },
        { label: "Internet",        sub: "8.8.8.8 — 12ms",       status: "connected"    },
        { label: "Payment Gateway", sub: "pay.geniex.tech",       status: "disconnected" },
      ]);
      setLogs(prev => [{ level: "info", message: "Manual connection retry completed.", time: new Date().toLocaleTimeString("en-PH", { hour12: false }) }, ...prev]);
      setRetrying(false);
    }, 2000);
  };

  const filteredLogs = logFilter === "all" ? logs : logs.filter(l => l.level === logFilter);

  const statusBadge = (s: ConnStatus) => {
    const map: Record<ConnStatus, { label: string; color: string; bg: string; border: string }> = {
      connected:    { label: "Connected",    color: "#16a34a", bg: "rgba(22,163,74,0.10)",  border: "rgba(22,163,74,0.25)"  },
      disconnected: { label: "Disconnected", color: "#dc2626", bg: "rgba(239,68,68,0.10)",  border: "rgba(239,68,68,0.25)"  },
      idle:         { label: "Idle",         color: "#d97706", bg: "rgba(245,158,11,0.10)", border: "rgba(245,158,11,0.25)" },
      checking:     { label: "Checking…",    color: "#2563eb", bg: "rgba(59,130,246,0.10)", border: "rgba(59,130,246,0.25)" },
    };
    const b = map[s];
    return <span className="px-2 py-0.5 rounded-full font-bold ml-auto" style={{ fontSize: 9, background: b.bg, color: b.color, border: `1px solid ${b.border}` }}>{b.label}</span>;
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
 
    const isVideo = file.type.startsWith('video/');
 
    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
 
      const res = await fetch('/api/upload', { method: 'POST', body: formData });
      if (!res.ok) throw new Error("Failed to upload to local DB");
 
      const data = await res.json();
      const permanentUrl = data.url || data.fileUrl || data.path;
      if (!permanentUrl) throw new Error("API did not return a file URL");
 
      // 1. Refresh library so the new file appears there immediately
      await fetchMediaLibrary();
 
      // 2. Auto-add directly to the active CFD tab timeline
      const newItem: MediaItem = {
        id: Date.now().toString(),
        url: permanentUrl,
        type: isVideo ? 'video' : 'image',
        duration: 5,
        name: file.name,
      };
      const currentMode = cfdConfig[cfdTab].mode;
      const updatedItems = currentMode === 'static' ? [newItem] : [...cfdConfig[cfdTab].items, newItem];
      const newConfig = { ...cfdConfig, [cfdTab]: { ...cfdConfig[cfdTab], items: updatedItems } };
      updateCfdConfig(newConfig);
      setSelectedClipId(newItem.id);
 
      sileo.success({ title: "Added to timeline", description: `Added to ${cfdTab} screen.`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }, duration: 1000});
    } catch (err) {
      console.error("Upload error:", err);
      sileo.error({ title: "Upload Failed", description: "Make sure your /api/upload endpoint is set up.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
    } finally {
      setIsUploading(false);
      e.target.value = "";
    }
  };

  return (
    <>
      <style>{`
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255, 103, 0, 0.4); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(255, 103, 0, 0.7); }
      `}</style>
      <div className="flex flex-col overflow-hidden select-none" style={{ width: "100vw", height: "100%", fontFamily: "Poppins", background: "#F0EFEF" }}>
        <div className="flex flex-1 overflow-hidden">

          <div style={{
            display: "flex", flexDirection: "column", alignItems: "center",
            padding: "16px 8px", gap: 4, width: 90, borderRadius: 22,
            background: "#FFFFFF",
            border: "1px solid rgba(0,0,0,0.05)",
            boxShadow: "0 4px 12px rgba(0,0,0,0.03)",
            flexShrink: 0, marginTop: 12, marginBottom: 12, marginLeft: 16,
          }}>
            {SIDEBAR_SECTIONS.map((sec) => {
              const isActive = activeSection === sec.id;
              return (
                <button key={sec.id} onClick={() => setActiveSection(sec.id)} style={{
                  display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                  padding: "8px 4px 6px", gap: 4, width: "100%", cursor: "pointer",
                  background: isActive ? sec.accent : "transparent", border: "none", borderRadius: 14, transition: "background 0.15s",
                }}>
                  <div style={{ fontSize: 20, display: "flex", alignItems: "center", justifyContent: "center", width: 24, height: 24 }}>
                    {getIcon(sec.icon, { size: 20, color: isActive ? "#fff" : "#FF6700" })}
                  </div>
                  <span style={{ textTransform: "uppercase", fontFamily: "Poppins", fontSize: 10, fontWeight: 700, textAlign: "center", lineHeight: 1.2, color: isActive ? "#fff" : "#FF6700" }}>
                    {sec.label}
                  </span>
                </button>
              );
            })}
            <div style={{ width: "60%", height: 1, background: "#E5E7EB", margin: "8px 0 6px" }} />
            <div style={{ marginTop: "auto", padding: "4px 0 2px" }}>
              <img src="/images/menux-black.png" alt="POS Logo" style={{ width: 50, height: 50, objectFit: "contain" }} />
            </div>
          </div>

          <div className="flex-1 overflow-hidden flex flex-col px-6 py-5">
            <div style={{ display: "flex", flexDirection: "column", gap: 12, height: "100%" }}>
              
              <div style={{ display: "flex", alignItems: "flex-end", justifyItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
                <div>
                  <p style={{ fontSize: 10, color: "#888", fontWeight: 700, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 2 }}>Configuration</p>
                  <h1 style={{ fontFamily: "Poppins", fontSize: 26, fontWeight: 800, color: "#1A1A1A", lineHeight: 1 }}>
                    Store & <span style={{ color: "#FF6700" }}>Settings</span>
                  </h1>
                </div>
                
                <div className="flex items-center gap-3">
                  {/* Dynamic Till Status Indicator */}
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border bg-white shadow-sm" style={{ borderColor: "#E5E7EB" }}>
                    {tillStatus === "OPEN" ? <Unlock size={14} className="text-red-500" /> : 
                     tillStatus === "CLOSED" ? <Lock size={14} className="text-green-500" /> : 
                     tillStatus === "ERROR" ? <AlertCircle size={14} className="text-red-500" /> : 
                     <HelpCircle size={14} className="text-gray-400" />}
                    <span className="text-xs font-bold font-poppins text-gray-700">Till: {tillStatus}</span>
                  </div>

                  {storeData && !storeLoading && (
                    <button
                      onClick={handleSaveAll}
                      disabled={loading}
                      className="rounded-full px-6 py-2.5 text-sm font-bold text-white transition-all hover:brightness-110 active:scale-95 disabled:opacity-50 flex items-center gap-2"
                      style={{
                        fontFamily: "Poppins", textTransform: "uppercase", fontSize: 11,
                        background: saved ? "#16a34a" : "#FF6700",
                        border: "none", transition: "all 0.3s",
                      }}
                    >
                      {loading ? "Saving…"
                        : saved
                          ? <>{getIcon("check", { size: 14, color: "#fff" })} Saved</>
                          : <>{getIcon("save",  { size: 14, color: "#fff" })} Save Changes</>}
                    </button>
                  )}
                </div>
              </div>

              <div style={{ height: 3, background: "linear-gradient(90deg, #FF6700 0%, #E11383 55%, transparent 100%)", borderRadius: 999, flexShrink: 0 }} />

              {storeLoading && (
                <div className="flex-1 flex flex-col gap-3">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="h-14 rounded-2xl animate-pulse" style={{ background: "rgba(0,0,0,0.05)" }} />
                  ))}
                </div>
              )}

              {!storeLoading && !storeData && (
                <div className="flex-1 flex flex-col items-center justify-center gap-3" style={{ color: "#aaa" }}>
                  <p style={{ fontSize: 14, fontWeight: 700 }}>Could not load store data</p>
                </div>
              )}

              {!storeLoading && storeData && activeSection === "store" && (
                <div style={{ flex: 1, minHeight: 0, overflowY: "auto" }}>
                  <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 16 }}>
                  
                    <div style={{ ...theme.card, padding: 24, overflowY: "auto", display: "flex", flexDirection: "column" }}>
                      <p style={{ fontFamily: "Poppins", fontSize: 12, color: "#FF6700", letterSpacing: 1.2, textTransform: "uppercase", fontWeight: 800, marginBottom: 8 }}>Store Details</p>
                      
                      <SectionLabel title="Basic Info" />
                      <div className="flex flex-col gap-4">
                        <div className="flex flex-col gap-2 w-full">
                          <p style={{ fontSize: 10, fontWeight: 800, color: "#FF6700", letterSpacing: 1, textTransform: "uppercase", fontFamily: "Poppins" }}>Store Code</p>
                          <div className="flex items-center gap-2 px-3 py-2" style={theme.readonlyInput}>
                            <p style={{ fontFamily: "'Courier New', Courier, monospace", fontSize: 12, color: "#1A1A1A", fontWeight: 700, flex: 1 }}>{storeData.store_id}</p>
                            <span className="px-2 py-0.5 rounded-full font-bold flex-shrink-0" style={{ fontSize: 9, background: "rgba(255,103,0,0.08)", color: "#FF6700", border: "1px solid rgba(255,103,0,0.2)" }}>READ-ONLY</span>
                          </div>
                        </div>

                        <EditableStoreField icon="store" label="Store Name" sublabel="Display name of this branch" value={editableStore.name} onChange={(v) => setEditableStore(p => ({ ...p, name: v }))} />
                        <div className="grid grid-cols-2 gap-4">
                          <EditableStoreField icon="info" label="Email" sublabel="Contact email" value={editableStore.email} onChange={(v) => setEditableStore(p => ({ ...p, email: v }))} placeholder="store@example.com" />
                          <EditableStoreField icon="info" label="Contact Number" sublabel="Primary phone" value={editableStore.contact_number} onChange={(v) => setEditableStore(p => ({ ...p, contact_number: v }))} placeholder="09XXXXXXXXX" mono />
                        </div>
                        <EditableStoreField icon="info" label="Address" sublabel="Full store address" value={editableStore.address} onChange={(v) => setEditableStore(p => ({ ...p, address: v }))} />
                        
                        <div className="grid grid-cols-2 gap-4">
                          <EditableStoreField icon="info" label="Longitude" sublabel="Map coordinate" value={editableStore.longitude} onChange={(v) => setEditableStore(p => ({ ...p, longitude: v }))} placeholder="0.000" mono />
                          <EditableStoreField icon="info" label="Latitude" sublabel="Map coordinate" value={editableStore.latitude} onChange={(v) => setEditableStore(p => ({ ...p, latitude: v }))} placeholder="0.000" mono />
                        </div>
                      </div>

                      <SectionLabel title="Operating Hours" />
                      <div className="grid grid-cols-2 gap-4">
                        <EditableStoreField icon="info" label="Open Time"  sublabel="HH:MM:SS" value={editableStore.open_time}  onChange={(v) => setEditableStore(p => ({ ...p, open_time: v }))}  placeholder="10:00:00" mono />
                        <EditableStoreField icon="info" label="Close Time" sublabel="HH:MM:SS" value={editableStore.close_time} onChange={(v) => setEditableStore(p => ({ ...p, close_time: v }))} placeholder="23:59:00" mono />
                      </div>

                      <SectionLabel title="Operations" />
                      <div className="grid grid-cols-2 gap-4">
                        <EditableStoreField icon="info" label="Service Charge (%)" sublabel="Additional fee" value={editableStore.services_charge} onChange={(v) => setEditableStore(p => ({ ...p, services_charge: v }))} placeholder="0" mono />
                      </div>
                    </div>

                    <div className="h-fit" style={{ ...theme.card, padding: 24, overflowY: "auto", display: "flex", flexDirection: "column" }}>
                      <p style={{ fontFamily: "Poppins", fontSize: 12, color: "#E11383", letterSpacing: 1.2, textTransform: "uppercase", fontWeight: 800, marginBottom: 12 }}>BIR / Fiscal Numbers</p>
                      <div className="flex flex-col gap-3">
                        {FISCAL_FIELDS.map((field) => (
                          <FiscalInputField key={field.key} field={field} value={fiscalFields[field.key]} onChange={(val) => setFiscalFields(p => ({ ...p, [field.key]: val }))} />
                        ))}
                      </div>
                    </div>

                  </div>
                </div>
              )}

              {!storeLoading && storeData && activeSection === "config" && (
                <div style={{ flex: 1, minHeight: 0, overflowY: "auto" }}>
                  {/* ── Discount Scope Panel ── */}
                  <div className="mb-5" style={{ ...theme.card, padding: 0, overflow: 'hidden', gridColumn: '1 / -1' }}>
                    {/* Header toggle */}
                    <button
                      onClick={() => setDiscountScopeOpen(p => !p)}
                      style={{ width: '100%', padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'transparent', border: 'none', cursor: 'pointer' }}
                    >
                      <div style={{ textAlign: 'left' }}>
                        <p style={{ fontFamily: 'Poppins', fontSize: 12, color: '#FF6700', letterSpacing: 1.2, textTransform: 'uppercase', fontWeight: 800, lineHeight: 1 }}>
                          🏷️ Discount Scope
                        </p>
                        <p style={{ fontFamily: 'Poppins', fontSize: 9, color: '#888', marginTop: 3, fontWeight: 600 }}>
                          Control which order types each discount type applies to
                        </p>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        {Object.keys(discountScopes).length > 0 && (
                          <span style={{ fontFamily: 'Poppins', fontSize: 9, fontWeight: 800, padding: '2px 8px', borderRadius: 999, background: 'rgba(255,103,0,0.1)', color: '#FF6700', border: '1px solid rgba(255,103,0,0.25)' }}>
                            {Object.keys(discountScopes).length} configured
                          </span>
                        )}
                        <span style={{ fontSize: 11, color: '#FF6700', transform: discountScopeOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s', display: 'inline-block' }}>▼</span>
                      </div>
                    </button>

                    {discountScopeOpen && (
                      <div style={{ borderTop: '1px solid #F3F4F6', display: 'grid', gridTemplateColumns: '.5fr 1fr', minHeight: 320 }}>

                        {/* LEFT — disabled pool */}
                        <div style={{ borderRight: '1px solid #F3F4F6', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
                          <div style={{ padding: '10px 16px 8px', borderBottom: '1px solid #F3F4F6', flexShrink: 0 }}>
                            <p style={{ fontFamily: 'Poppins', fontSize: 9, fontWeight: 800, color: '#aaa', letterSpacing: 1.2, textTransform: 'uppercase' }}>Available — click to enable</p>
                          </div>
                          <div style={{ flex: 1, overflowY: 'auto', padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 6 }}>
                            {DISCOUNT_SCOPE_TYPES.filter(t => !discountScopes[t.id]).map(type => (
                              <button
                                key={type.id}
                                onClick={() => setDiscountScopes(prev => ({ ...prev, [type.id]: 'all' }))}
                                style={{
                                  display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px',
                                  background: '#F9FAFB', border: '1px solid #E5E7EB', borderRadius: 10,
                                  cursor: 'pointer', textAlign: 'left', transition: 'all 0.15s',
                                  width: '100%',
                                }}
                                onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,103,0,0.04)'; (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(255,103,0,0.2)'; }}
                                onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = '#F9FAFB'; (e.currentTarget as HTMLButtonElement).style.borderColor = '#E5E7EB'; }}
                              >
                                <span style={{ fontSize: 18, flexShrink: 0 }}>{type.icon}</span>
                                <div style={{ flex: 1, minWidth: 0 }}>
                                  <p style={{ fontFamily: 'Poppins', fontSize: 11, fontWeight: 700, color: '#555', lineHeight: 1 }}>{type.label}</p>
                                  <p style={{ fontFamily: 'Poppins', fontSize: 9, color: '#aaa', marginTop: 2 }}>{type.sublabel}</p>
                                </div>
                                <span style={{ fontFamily: 'Poppins', fontSize: 9, fontWeight: 800, color: 'rgba(255,103,0,0.5)', flexShrink: 0 }}>+ Enable</span>
                              </button>
                            ))}
                            {DISCOUNT_SCOPE_TYPES.filter(t => !discountScopes[t.id]).length === 0 && (
                              <div style={{ padding: '24px 0', textAlign: 'center' }}>
                                <p style={{ fontFamily: 'Poppins', fontSize: 10, color: '#ccc', fontWeight: 700 }}>All types configured ✓</p>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* RIGHT — enabled with scope pills */}
                        <div style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
                          <div style={{ padding: '10px 16px 8px', borderBottom: '1px solid #F3F4F6', flexShrink: 0 }}>
                            <p style={{ fontFamily: 'Poppins', fontSize: 9, fontWeight: 800, color: '#FF6700', letterSpacing: 1.2, textTransform: 'uppercase' }}>Enabled — select scope</p>
                          </div>
                          <div style={{ flex: 1, overflowY: 'auto', padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 6 }}>
                            {DISCOUNT_SCOPE_TYPES.filter(t => discountScopes[t.id]).map(type => {
                              const currentScope = discountScopes[type.id];
                              return (
                                <div
                                  key={type.id}
                                  style={{
                                    display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px',
                                    background: 'rgba(255,103,0,0.04)', border: '1px solid rgba(255,103,0,0.2)',
                                    borderRadius: 10,
                                  }}
                                >
                                  <span style={{ fontSize: 18, flexShrink: 0 }}>{type.icon}</span>
                                  <div style={{ flex: 1, minWidth: 0 }}>
                                    <p style={{ fontFamily: 'Poppins', fontSize: 11, fontWeight: 700, color: '#1a1a1a', lineHeight: 1 }}>{type.label}</p>
                                    {/* Scope pills */}
                                    <div style={{ display: 'flex', gap: 4, marginTop: 6, flexWrap: 'wrap' }}>
                                      {DISCOUNT_SCOPE_OPTIONS.map(opt => {
                                        const isActive = currentScope === opt.id;
                                        return (
                                          <button
                                            key={opt.id}
                                            onClick={() => setDiscountScopes(prev => ({ ...prev, [type.id]: opt.id }))}
                                            style={{
                                              fontFamily: 'Poppins', fontSize: 9, fontWeight: 800,
                                              padding: '3px 10px', borderRadius: 999,
                                              border: `1px solid ${isActive ? '#FF6700' : '#E5E7EB'}`,
                                              background: isActive ? '#FF6700' : '#fff',
                                              color: isActive ? '#fff' : '#888',
                                              cursor: 'pointer', transition: 'all 0.15s',
                                              letterSpacing: 0.5, textTransform: 'uppercase',
                                            }}
                                          >
                                            {opt.icon} {opt.label}
                                          </button>
                                        );
                                      })}
                                    </div>
                                  </div>
                                  {/* Remove button */}
                                  <button
                                    onClick={() => setDiscountScopes(prev => { const next = { ...prev }; delete next[type.id]; return next; })}
                                    style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.15)', borderRadius: 6, color: '#ef4444', cursor: 'pointer', padding: '3px 8px', fontSize: 10, fontWeight: 800, flexShrink: 0 }}
                                  >✕</button>
                                </div>
                              );
                            })}
                            {DISCOUNT_SCOPE_TYPES.filter(t => discountScopes[t.id]).length === 0 && (
                              <div style={{ padding: '24px 0', textAlign: 'center' }}>
                                <p style={{ fontFamily: 'Poppins', fontSize: 10, color: '#ccc', fontWeight: 700 }}>No discount types enabled yet</p>
                                <p style={{ fontFamily: 'Poppins', fontSize: 9, color: '#ddd', marginTop: 4 }}>Click types on the left to add them</p>
                              </div>
                            )}
                          </div>
                        </div>

                      </div>
                    )}
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                    <div className="h-fit" style={{ ...theme.card, padding: 24, overflowY: "auto", display: "flex", flexDirection: "column" }}>
                      <p style={{ fontFamily: "Poppins", fontSize: 12, color: "#FF6700", letterSpacing: 1.2, textTransform: "uppercase", fontWeight: 800, marginBottom: 8 }}>General Config</p>
                      
                      <SectionLabel title="Limits & Restrictions" />
                      <div className="grid grid-cols-1 gap-4">
                        <EditableStoreField icon="info" label="Void/Refund Limit" sublabel="Hours allowed" value={editableStore.allowable_void_refund_hours} onChange={(v) => setEditableStore(p => ({ ...p, allowable_void_refund_hours: v }))} placeholder="24" mono />
                      </div>

                      <SectionLabel title="KDS Timers" />
                      <div className="grid grid-cols-2 gap-4">
                        <EditableStoreField icon="info" label="Warning" sublabel="Minutes to yellow" value={kdsTimers.warningMinutes} onChange={(v) => setKdsTimers(p => ({ ...p, warningMinutes: v }))} placeholder="5"  mono />
                        <EditableStoreField icon="info" label="Danger"  sublabel="Minutes to red"    value={kdsTimers.dangerMinutes}  onChange={(v) => setKdsTimers(p => ({ ...p, dangerMinutes: v }))}  placeholder="10" mono />
                      </div>

                      <SectionLabel title="Cash Drop Limits" />
                      <div className="grid grid-cols-2 gap-4">
                        <EditableStoreField
                          icon="info"
                          label="Warning Amount"
                          sublabel="Notify cashier at this value"
                          value={cashDropLimits.warningAmount}
                          onChange={(v) => setCashDropLimits(p => ({ ...p, warningAmount: v }))}
                          placeholder="e.g. 5000"
                          mono
                        />
                        <EditableStoreField
                          icon="info"
                          label="Max Amount"
                          sublabel="Trigger cash drop at this value"
                          value={cashDropLimits.maxAmount}
                          onChange={(v) => setCashDropLimits(p => ({ ...p, maxAmount: v }))}
                          placeholder="e.g. 10000"
                          mono
                        />
                      </div>

                      <SectionLabel title="Cash Fund Limits" />
                      <div className="grid grid-cols-1 gap-4">
                        <EditableStoreField
                          icon="info"
                          label="Cash Fund Limit"
                          sublabel="Starting cash allowed in drawer"
                          value={cashFundLimit.limit}
                          onChange={(v) => setCashFundLimit({ limit: v })}
                          placeholder="e.g. 2000"
                          mono
                        />
                      </div>

                      <SectionLabel title="Solo Parent Spending Limit" />
                      <div className="grid grid-cols-1 gap-4">
                        <EditableStoreField
                          icon="info"
                          label="Solo Parent Limit"
                          sublabel="Max spend eligible for Solo Parent discount"
                          value={soloParentLimit.limit}
                          onChange={(v) => setSoloParentLimit({ limit: v })}
                          placeholder="e.g. 1000"
                          mono
                        />
                        <div className="flex flex-col gap-2">
                          <div className="flex items-start gap-2">
                            <div style={{ marginTop: 2 }}>{getIcon("info", { size: 12, color: "#888" })}</div>
                            <div className="flex flex-col">
                              <p style={{ fontSize: 11, fontWeight: 700, color: "#1A1A1A", fontFamily: "Poppins", lineHeight: 1 }}>Reset Timing</p>
                              <p style={{ fontSize: 9, color: "#888" }}>How often the spending limit resets per customer</p>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            {(["weekly", "monthly"] as const).map((option) => (
                              <button
                                key={option}
                                onClick={() => setSoloParentReset(option)}
                                style={{
                                  flex: 1,
                                  padding: "8px 0",
                                  borderRadius: 8,
                                  border: `1px solid ${soloParentReset === option ? "#FF6700" : "#E5E7EB"}`,
                                  background: soloParentReset === option ? "#FF6700" : "#F9FAFB",
                                  color: soloParentReset === option ? "#fff" : "#888",
                                  fontFamily: "Poppins",
                                  fontSize: 11,
                                  fontWeight: 700,
                                  textTransform: "uppercase",
                                  letterSpacing: 0.8,
                                  cursor: "pointer",
                                  transition: "all 0.15s",
                                  boxShadow: soloParentReset === option ? "0 0 8px rgba(255,103,0,0.3)" : "none",
                                }}
                              >
                                {option === "weekly" ? "📅 Weekly" : "🗓️ Monthly"}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      <SectionLabel title="Display" />
                      <div className="flex items-center justify-between px-3 py-2 rounded-xl" style={{ background: "#F9FAFB", border: "1px solid #E5E7EB" }}>
                        <div>
                          <p style={{ fontSize: 11, fontWeight: 700, color: "#1A1A1A", fontFamily: "Poppins", lineHeight: 1 }}>Show Stock</p>
                          <p style={{ fontSize: 9, color: "#888", marginTop: 2 }}>Display available quantity on product cards</p>
                        </div>
                        <button
                          onClick={handleToggleShowStock}
                          className="relative flex-shrink-0 transition-all duration-300 active:scale-95"
                          style={{
                            width: 44,
                            height: 24,
                            borderRadius: 999,
                            background: showStock ? "#FF6700" : "#D1D5DB",
                            border: "none",
                            cursor: "pointer",
                            boxShadow: showStock ? "0 0 8px rgba(255,103,0,0.4)" : "none",
                            transition: "background 0.25s, box-shadow 0.25s",
                          }}
                        >
                          <span
                            style={{
                              position: "absolute",
                              top: 3,
                              left: showStock ? 23 : 3,
                              width: 18,
                              height: 18,
                              borderRadius: "50%",
                              background: "#fff",
                              boxShadow: "0 1px 4px rgba(0,0,0,0.2)",
                              transition: "left 0.25s cubic-bezier(0.16, 1, 0.3, 1)",
                            }}
                          />
                        </button>
                      </div>
                      
                      <SectionLabel title="End of Day Config" />
                      <div className="flex flex-col gap-2 mb-4">
                        <div className="flex items-start gap-2">
                          <div style={{ marginTop: 2 }}>{getIcon("zread", { size: 12, color: "#888" })}</div>
                          <div className="flex flex-col">
                            <p style={{ fontSize: 11, fontWeight: 700, color: "#1A1A1A", fontFamily: "Poppins", lineHeight: 1 }}>Z-Reading Type</p>
                            <p style={{ fontSize: 9, color: "#888" }}>Choose how Z-Read is generated</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          {(["Consolidated", "Per Terminal", "Both"] as const).map((option) => (
                            <button
                              key={option}
                              onClick={() => setZReadingType(option)}
                              style={{
                                flex: 1,
                                padding: "8px 0",
                                borderRadius: 8,
                                border: `1px solid ${zReadingType === option ? "#FF6700" : "#E5E7EB"}`,
                                background: zReadingType === option ? "#FF6700" : "#F9FAFB",
                                color: zReadingType === option ? "#fff" : "#888",
                                fontFamily: "Poppins",
                                fontSize: 10,
                                fontWeight: 700,
                                textTransform: "uppercase",
                                letterSpacing: 0.5,
                                cursor: "pointer",
                                transition: "all 0.15s",
                                boxShadow: zReadingType === option ? "0 0 8px rgba(255,103,0,0.3)" : "none",
                              }}
                            >
                              {option}
                            </button>
                          ))}
                        </div>
                      </div>

                      <SectionLabel title="Currency Settings" />
                      <div className="grid grid-cols-3 gap-2">
                        <ReadonlyField icon="info" label="Code"     sublabel="" value={storeData.currency} />
                        <ReadonlyField icon="info" label="Symbol"   sublabel="" value={storeData.code} />
                        <ReadonlyField icon="info" label="Exponent" sublabel="" value={storeData.exponent} mono />
                      </div>
                    </div>
                    <div className="h-fit" style={{ ...theme.card, padding: 24, overflowY: "auto", display: "flex", flexDirection: "column" }}>
                      <p style={{ fontFamily: "Poppins", fontSize: 12, color: "#16a34a", letterSpacing: 1.2, textTransform: "uppercase", fontWeight: 800, marginBottom: 8 }}>Integrations</p>
                        <SectionLabel title="Grab Config" />
                        <div className="grid grid-cols-1 gap-4">
                          <EditableStoreField icon="info" label="Grab Merchant ID" sublabel="Unique ID provided by Grab" value={grabConfig.merchantId} onChange={(v) => setGrabConfig(p => ({ ...p, merchantId: v }))} placeholder="e.g. GRAB-12345" mono />
                          <EditableStoreField icon="info" label="Grab Secret Key" sublabel="API Key for integration" value={grabConfig.secret} onChange={(v) => setGrabConfig(p => ({ ...p, secret: v }))} placeholder="**********" mono />
                        </div>
                    </div>
                  </div>
                </div>
              )}

              {activeSection === "receipt" && (
                <div style={{ flex: 1, minHeight: 0, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                  <div className="flex flex-col gap-4">
                    <div style={{ ...theme.card, padding: 24 }}>
                      <p style={{ fontFamily: "Poppins", fontSize: 12, color: "#FF6700", letterSpacing: 1.2, textTransform: "uppercase", fontWeight: 800, marginBottom: 12 }}>Receipt Type</p>
                      <div className="flex flex-col gap-2 mb-4">
                        <p style={{ fontSize: 11, fontWeight: 700, color: "#1A1A1A", fontFamily: "Poppins" }}>Select Receipt Format</p>
                        <select value={selectedFormatId || ""} onChange={(e) => setSelectedFormatId(Number(e.target.value))}
                          className="px-3 py-2 outline-none"
                          style={{ ...theme.input, fontSize: 12, fontWeight: 500, color: "#1A1A1A", cursor: "pointer" }}>
                          <option value="">Select a format…</option>
                          {storeData?.receiptFormats?.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                        </select>
                      </div>
                    </div>
                    {/* ── Double Print Configuration ── */}
                    <div style={{ ...theme.card, padding: 0, overflow: 'hidden' }}>
                      {/* Header / toggle */}
                      <button
                        onClick={() => setDoublePrintOpen(p => !p)}
                        style={{
                          width: '100%', padding: '14px 20px', display: 'flex',
                          alignItems: 'center', justifyContent: 'space-between',
                          background: 'transparent', border: 'none', cursor: 'pointer',
                        }}
                      >
                        <div style={{ textAlign: 'left' }}>
                          <p style={{ fontFamily: 'Poppins', fontSize: 12, color: '#FF6700', letterSpacing: 1.2, textTransform: 'uppercase', fontWeight: 800, lineHeight: 1 }}>
                            🖨 Double Print
                          </p>
                          <p style={{ fontFamily: 'Poppins', fontSize: 9, color: '#888', marginTop: 3, fontWeight: 600 }}>
                            Customer Copy + Accountant's Copy (BIR)
                          </p>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          {/* Active-count badge */}
                          {Object.values(doublePrintTypes).filter(Boolean).length > 0 && (
                            <span style={{
                              fontFamily: 'Poppins', fontSize: 9, fontWeight: 800,
                              padding: '2px 8px', borderRadius: 999,
                              background: 'rgba(255,103,0,0.1)', color: '#FF6700',
                              border: '1px solid rgba(255,103,0,0.25)',
                            }}>
                              {Object.values(doublePrintTypes).filter(Boolean).length} ON
                            </span>
                          )}
                          <span style={{
                            fontSize: 11, color: '#FF6700',
                            transform: doublePrintOpen ? 'rotate(180deg)' : 'rotate(0deg)',
                            transition: 'transform 0.2s',
                            display: 'inline-block',
                          }}>▼</span>
                        </div>
                      </button>

                      {/* Collapsible body */}
                      {doublePrintOpen && (
                        <div style={{ borderTop: '1px solid #F3F4F6', padding: '12px 20px 16px', display: 'flex', flexDirection: 'column', gap: 6 }}>
                          <p style={{ fontFamily: 'Poppins', fontSize: 9, color: '#aaa', fontWeight: 600, marginBottom: 4, lineHeight: 1.5 }}>
                            When enabled for a transaction type, the printer will automatically print two copies — one for the customer and one for the accountant.
                          </p>

                          {DOUBLE_PRINT_OPTIONS.map((opt) => {
                            const isOn = doublePrintTypes[opt.id] ?? false;
                            return (
                              <div
                                key={opt.id}
                                style={{
                                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                                  padding: '8px 12px', borderRadius: 10,
                                  background: isOn ? 'rgba(255,103,0,0.05)' : '#F9FAFB',
                                  border: `1px solid ${isOn ? 'rgba(255,103,0,0.2)' : '#E5E7EB'}`,
                                  transition: 'all 0.15s',
                                }}
                              >
                                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                  <span style={{ fontSize: 16 }}>{opt.icon}</span>
                                  <div>
                                    <p style={{ fontFamily: 'Poppins', fontSize: 11, fontWeight: 700, color: isOn ? '#FF6700' : '#1A1A1A', lineHeight: 1 }}>
                                      {opt.label}
                                    </p>
                                    <p style={{ fontFamily: 'Poppins', fontSize: 9, color: '#888', marginTop: 2, fontWeight: 500 }}>
                                      {opt.sublabel}
                                    </p>
                                  </div>
                                </div>
                                {/* Toggle switch */}
                                <button
                                  onClick={() => setDoublePrintTypes(prev => ({ ...prev, [opt.id]: !prev[opt.id] }))}
                                  style={{
                                    width: 40, height: 22, borderRadius: 999, border: 'none', cursor: 'pointer',
                                    background: isOn ? '#FF6700' : '#D1D5DB',
                                    boxShadow: isOn ? '0 0 6px rgba(255,103,0,0.35)' : 'none',
                                    position: 'relative', flexShrink: 0,
                                    transition: 'background 0.2s, box-shadow 0.2s',
                                  }}
                                >
                                  <span style={{
                                    position: 'absolute', top: 3,
                                    left: isOn ? 21 : 3,
                                    width: 16, height: 16, borderRadius: '50%',
                                    background: '#fff',
                                    boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
                                    transition: 'left 0.2s cubic-bezier(0.16,1,0.3,1)',
                                  }} />
                                </button>
                              </div>
                            );
                          })}

                          {/* Quick actions */}
                          <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                            <button
                              onClick={() => setDoublePrintTypes(Object.fromEntries(DOUBLE_PRINT_OPTIONS.map(o => [o.id, true])))}
                              style={{ flex: 1, fontFamily: 'Poppins', fontSize: 9, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, padding: '5px 0', border: '1px solid rgba(255,103,0,0.2)', borderRadius: 8, background: 'rgba(255,103,0,0.05)', color: '#FF6700', cursor: 'pointer' }}
                            >Enable All</button>
                            <button
                              onClick={() => setDoublePrintTypes(Object.fromEntries(DOUBLE_PRINT_OPTIONS.map(o => [o.id, false])))}
                              style={{ flex: 1, fontFamily: 'Poppins', fontSize: 9, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, padding: '5px 0', border: '1px solid #E5E7EB', borderRadius: 8, background: '#F3F4F6', color: '#888', cursor: 'pointer' }}
                            >Disable All</button>
                          </div>
                        </div>
                      )}
                    </div>
                    <div style={{ ...theme.card, padding: 24 }}>
                      <p style={{ fontFamily: "Poppins", fontSize: 12, color: "#6D4C41", letterSpacing: 1.2, textTransform: "uppercase", fontWeight: 800, marginBottom: 12 }}>Printer Config</p>
                      
                      {!usbPrinter ? (
                        <button onClick={pairPrinter} className="w-full py-4 text-sm font-bold text-white transition-all hover:brightness-110 active:scale-95 flex items-center justify-center gap-2" style={{ fontFamily: "Poppins", textTransform: "uppercase", background: "#FF6700", borderRadius: 8 }}>
                          <Usb size={18} /> Pair USB Printer
                        </button>
                      ) : (
                        <div className="flex flex-col gap-4">
                          <div className="p-4 rounded-xl border flex justify-between items-center bg-gray-50">
                            <div>
                              <p className="text-xs font-bold text-gray-800 uppercase tracking-widest">{usbPrinter.productName || "POS Printer"}</p>
                              <p className="text-[10px] text-gray-500">Connected via WebUSB</p>
                            </div>
                            <span className="text-xs font-bold text-green-600 bg-green-100 px-3 py-1 rounded-full">Paired</span>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                             <button onClick={checkStatusNow} className="py-2.5 text-xs font-bold transition-all hover:bg-gray-100 active:scale-95 flex items-center justify-center gap-2 border rounded-lg text-gray-700 bg-white shadow-sm">
                                <Lock size={14} /> Check Till Status
                             </button>
                             <button onClick={handlePrintTest} className="py-2.5 text-xs font-bold transition-all hover:bg-gray-100 active:scale-95 flex items-center justify-center gap-2 border rounded-lg text-gray-700 bg-white shadow-sm">
                                <MdPrint size={14} /> Print Test Receipt
                             </button>
                          </div>
                          
                          <button 
                            onClick={unpairPrinter} 
                            className="text-[10px] text-red-500 font-bold uppercase tracking-widest hover:underline mt-2 self-start"
                          >
                             Unpair Printer
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                    

                  <div style={{ ...theme.card, padding: 24, display: "flex", flexDirection: "column" }}>
                    <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-4">
                      <p style={{ fontFamily: "Poppins", fontSize: 12, color: "#E11383", letterSpacing: 1.2, textTransform: "uppercase", fontWeight: 800, flex: 1 }}>Live Preview</p>
                      {selectedFormatId && (
                        <span className="px-2 py-0.5 rounded-full font-bold" style={{ fontSize: 9, background: "rgba(225,19,131,0.10)", color: "#E11383", border: "1px solid rgba(225,19,131,0.25)" }}>
                          {storeData?.receiptFormats?.find(f => f.id === selectedFormatId)?.name || "Format"}
                        </span>
                      )}
                    </div>
                    <div className="flex-1 flex items-start justify-center overflow-y-auto">
                      {storeData?.receiptFormats && selectedFormatId
                        ? <ReceiptPreviewDemo receiptFormats={storeData.receiptFormats} selectedFormatId={selectedFormatId} fiscalFields={fiscalFields} />
                        : <p style={{ color: "#aaa", textAlign: "center", padding: "20px", fontSize: 12 }}>Select a format to preview</p>
                      }
                    </div>
                  </div>
                </div>
              )}

              {activeSection === "screens" && (
                <>
                  <style>{`
                    .ve-label { font-size: 9px; font-weight: 800; letter-spacing: 1.5px; text-transform: uppercase; font-family: Poppins; color: #888; }
                    .ve-title { font-size: 10px; font-weight: 800; letter-spacing: 1.2px; text-transform: uppercase; font-family: Poppins; }
                    .ve-tab-act { background: #FF6700; color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(255,103,0,0.3); }
                    .ve-tab-off { color: #aaa; background: transparent; }
                    .ve-tab-act, .ve-tab-off { font-size: 10px; font-weight: 700; font-family: Poppins; padding: 6px 14px; border: none; cursor: pointer; transition: all 0.15s; letter-spacing: 0.8px; text-transform: uppercase; }
                    .ve-btn { font-family: Poppins; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px; border: none; border-radius: 8px; cursor: pointer; transition: all 0.15s; padding: 7px 14px; }
                    .ve-btn:active { transform: scale(0.97); }
                    .ve-input { background: #F9FAFB; border: 1px solid #E5E7EB; border-radius: 8px; color: #1a1a1a; font-family: Poppins; font-size: 11px; padding: 7px 11px; outline: none; width: 100%; transition: border 0.15s; }
                    .ve-input:focus { border-color: #FF6700; box-shadow: 0 0 0 3px rgba(255,103,0,0.1); }
                    .ve-input::placeholder { color: #bbb; }
                    .ve-select { background: #F9FAFB; border: 1px solid #E5E7EB; border-radius: 8px; color: #1a1a1a; font-family: Poppins; font-size: 10px; font-weight: 700; padding: 7px 10px; outline: none; cursor: pointer; width: 100%; }
                    .ve-select:focus { border-color: #FF6700; }
                    .ve-media-thumb { position: relative; border-radius: 8px; overflow: hidden; background: #f3f4f6; border: 2px solid transparent; cursor: pointer; transition: border-color 0.15s, box-shadow 0.15s; aspect-ratio: 16/9; }
                    .ve-media-thumb:hover { border-color: #FF6700; box-shadow: 0 0 0 1px rgba(255,103,0,0.15); }
                    .ve-media-thumb .m-overlay { position: absolute; inset: 0; background: rgba(0,0,0,0.65); opacity: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 5px; transition: opacity 0.15s; }
                    .ve-media-thumb:hover .m-overlay { opacity: 1; }
                    .ve-track-clip { border-radius: 6px; height: 52px; flex-shrink: 0; position: relative; cursor: pointer; display: flex; align-items: center; padding: 0 8px; gap: 6px; border: 2px solid transparent; transition: border-color 0.15s, box-shadow 0.15s; }
                    .ve-track-clip.selected { border-color: #FF6700 !important; box-shadow: 0 0 0 2px rgba(255,103,0,0.2); }
                    .scrollbar-or::-webkit-scrollbar { width: 4px; height: 4px; }
                    .scrollbar-or::-webkit-scrollbar-track { background: transparent; }
                    .scrollbar-or::-webkit-scrollbar-thumb { background: rgba(255,103,0,0.3); border-radius: 4px; }
                    .pulse-dot { width: 6px; height: 6px; border-radius: 50%; background: #22c55e; box-shadow: 0 0 6px rgba(34,197,94,0.8); animation: pglow 2s ease-in-out infinite; flex-shrink: 0; }
                    @keyframes pglow { 0%,100%{box-shadow:0 0 4px rgba(34,197,94,0.6);}50%{box-shadow:0 0 10px rgba(34,197,94,1);} }
                    .prop-row { display: flex; flex-direction: column; gap: 4px; }
                    .prop-label { font-size: 9px; font-weight: 800; color: #888; letter-spacing: 1px; text-transform: uppercase; font-family: Poppins; }
                  `}</style>

                  {(() => {
                    const selectedClip = cfdConfig[cfdTab].items.find(i => i.id === selectedClipId) ?? null;

                    const updateClip = (id: string, patch: Partial<MediaItem>) => {
                      const newConfig = {
                        ...cfdConfig,
                        [cfdTab]: {
                          ...cfdConfig[cfdTab],
                          items: cfdConfig[cfdTab].items.map((i) => (i.id === id ? { ...i, ...patch } : i)),
                        },
                      };
                      updateCfdConfig(newConfig); // ← context version
                    };

                    const moveClip = (id: string, dir: -1 | 1) => {
                      const items = [...cfdConfig[cfdTab].items];
                      const idx = items.findIndex(i => i.id === id);
                      if (idx < 0) return;
                      const swapIdx = idx + dir;
                      if (swapIdx < 0 || swapIdx >= items.length) return;
                      [items[idx], items[swapIdx]] = [items[swapIdx], items[idx]];
                      updateCfdConfig({ ...cfdConfig, [cfdTab]: { ...cfdConfig[cfdTab], items } });
                    };

                    const activeItems = cfdConfig[cfdTab].items;

                    const stopPlayer = () => {
                      if (previewTimerRef.current) clearTimeout(previewTimerRef.current);
                      if (previewProgressRef.current) clearInterval(previewProgressRef.current);
                      previewTimerRef.current = null;
                      previewProgressRef.current = null;
                    };

                    const startClip = (idx: number, items: typeof activeItems) => {
                      if (items.length === 0) return;
                      const safeIdx = idx % items.length;
                      setPreviewIndex(safeIdx);
                      setPreviewProgress(0);
                      setSelectedClipId(items[safeIdx].id);
                      stopPlayer();

                      const item = items[safeIdx];

                      if (item.type === 'image') {
                        const totalMs = item.duration * 1000;
                        const tick = 50;
                        let elapsed = 0;
                        previewProgressRef.current = setInterval(() => {
                          elapsed += tick;
                          setPreviewProgress(Math.min(elapsed / totalMs, 1));
                          if (elapsed >= totalMs) {
                            clearInterval(previewProgressRef.current!);
                            startClip(safeIdx + 1, items);
                          }
                        }, tick);
                      }
                      // video: progress driven by onTimeUpdate
                    };

                    const handleVideoTimeUpdate = (e: React.SyntheticEvent<HTMLVideoElement>) => {
                      const v = e.currentTarget;
                      if (!v.duration) return;
                      setPreviewProgress(v.currentTime / v.duration);
                    };

                    const handleVideoEnded = () => {
                      startClip(previewIndex + 1, activeItems);
                    };

                    const togglePlay = () => {
                      if (activeItems.length === 0) return;
                      if (previewPlaying) {
                        stopPlayer();
                        setPreviewPlaying(false);
                        videoPreviewRef.current?.pause();
                      } else {
                        setPreviewPlaying(true);
                        startClip(previewIndex, activeItems);
                        videoPreviewRef.current?.play();
                      }
                    };

                    // Stop player when tab switches or items change
                    // (call stopPlayer in the tab switch buttons too — see below)

                    return (
                      <div style={{ flex: 1, minHeight: 0, display: "flex", flexDirection: "column", background: "#F0EFEF", borderRadius: 16, overflow: "hidden", border: "1px solid #E5E7EB" }}>

                        {/* ── TOP TOOLBAR ── */}
                        <div style={{ width: "100%",display: "flex",  alignItems: "flex-end", justifyContent: "space-between", padding: "10px 16px", borderBottom: "1px solid #E5E7EB", background: "#fff", flexShrink: 0 }}>
                          <div className="flex items-center w-full justify-end gap-2 ">
                            {/* CFD status pill */}
                            <div style={{ display: "flex", alignItems: "center", gap: 5, padding: "4px 10px", borderRadius: 999, background: cfdOpen ? "rgba(22,163,74,0.08)" : "rgba(0,0,0,0.04)", border: `1px solid ${cfdOpen ? "rgba(22,163,74,0.25)" : "#E5E7EB"}` }}>
                              <div style={{ width: 6, height: 6, borderRadius: "50%", background: cfdOpen ? "#22c55e" : "#d1d5db", boxShadow: cfdOpen ? "0 0 6px rgba(34,197,94,0.8)" : "none", flexShrink: 0, transition: "all 0.3s" }} />
                              <span style={{ fontFamily: "Poppins", fontSize: 9, fontWeight: 700, color: cfdOpen ? "#16a34a" : "#aaa", textTransform: "uppercase", letterSpacing: 0.8 }}>
                                {cfdOpen ? "CFD Live" : "CFD Offline"}
                              </span>
                            </div>

                            {availableScreens.filter(s => !s.isPrimary).length > 0 && (
                              <select className="ve-select" style={{ width: "auto", fontSize: 10 }} value={selectedCustomerScreenId} onChange={(e) => handleSelectScreen(e.target.value)}>
                                <option value="">Select display…</option>
                                {availableScreens.filter(s => !s.isPrimary).map((s, i) => (
                                  <option key={i} value={s.id}>{s.label} ({s.width}×{s.height})</option>
                                ))}
                              </select>
                            )}
                            <button onClick={handleDetectScreens} className="ve-btn" style={{ background: "#F3F4F6", color: "#666", border: "1px solid #E5E7EB" }}>
                              <MdMonitor size={12} style={{ display: "inline", marginRight: 4, verticalAlign: -2 }} />Detect
                            </button>
                            <button
                              onClick={() => launchCfd(selectedCustomerScreenId)}
                              className="ve-btn"
                              style={{
                                background: cfdOpen
                                  ? 'linear-gradient(135deg,#2563eb,#1d4ed8)'
                                  : 'linear-gradient(135deg,#10b981,#059669)',
                                color: '#fff',
                                boxShadow: cfdOpen
                                  ? '0 2px 8px rgba(37,99,235,0.35)'
                                  : '0 2px 8px rgba(16,185,129,0.35)',
                              }}
                            >
                              <Rocket size={11} style={{ display: 'inline', marginRight: 4, verticalAlign: -2 }} />
                              {cfdOpen ? 'Update CFD' : 'Launch CFD'}
                            </button>
                          </div>
                        </div>

                        {/* ── THREE PANELS ── */}
                        <div style={{ flex: 1, minHeight: 0, display: "grid", gridTemplateColumns: "210px 1fr 270px", overflow: "hidden" }}>

                          {/* LEFT — MEDIA LIBRARY */}
                          <div style={{ borderRight: "1px solid #E5E7EB", display: "flex", flexDirection: "column", overflow: "hidden", background: "#fff" }}>
                            <div style={{ padding: "10px 12px 8px", borderBottom: "1px solid #F3F4F6", display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
                              <span className="ve-title" style={{ color: "#7c3aed" }}>Library</span>
                              <div className="flex items-center gap-1">
                                <button onClick={fetchMediaLibrary} className="ve-btn" style={{ background: "#F3F4F6", color: "#888", padding: "4px 8px" }}>
                                  <MdRefresh size={12} />
                                </button>
                                <label className="ve-btn" style={{ background: "rgba(255,103,0,0.08)", color: "#FF6700", border: "1px solid rgba(255,103,0,0.2)", padding: "4px 10px", cursor: "pointer" }}>
                                  {isUploading ? "…" : "+ Upload"}
                                  <input type="file" accept="image/*,video/*" className="hidden" onChange={handleFileUpload} disabled={isUploading} />
                                </label>
                              </div>
                            </div>

                            <div className="scrollbar-or" style={{ flex: 1, overflowY: "auto", padding: 10, display: "flex", flexDirection: "column", gap: 6 }}>
                              {libraryLoading ? (
                                Array.from({ length: 4 }).map((_, i) => (
                                  <div key={i} className="animate-pulse" style={{ aspectRatio: "16/9", borderRadius: 8, background: "#F3F4F6" }} />
                                ))
                              ) : mediaLibrary.length === 0 ? (
                                <div style={{ textAlign: "center", padding: "32px 12px", color: "#ddd" }}>
                                  <MdMonitor size={28} color="#e5e7eb" style={{ margin: "0 auto 8px" }} />
                                  <p style={{ fontFamily: "Poppins", fontSize: 10, fontWeight: 700, color: "#ccc" }}>No media uploaded yet</p>
                                </div>
                              ) : mediaLibrary.map((item) => {
                                const isVideo = item.mimeType?.startsWith('video/');
                                return (
                                  <div key={item._id} className="ve-media-thumb">
                                    {isVideo
                                      ? <video src={item.url} className="w-full h-full" style={{ objectFit: "cover" }} muted />
                                      : <img src={item.url} className="w-full h-full" style={{ objectFit: "cover" }} alt="" />
                                    }
                                    <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: "4px 6px", background: "rgba(0,0,0,0.5)", display: "flex", justifyContent: "center" }}>
                                      <span style={{
                                        fontFamily: "Poppins", fontSize: 8, fontWeight: 800,
                                        color: item.mimeType?.startsWith('video/') ? "#fbbf24" : item.mimeType === 'image/gif' ? "#a78bfa" : "#86efac",
                                        textTransform: "uppercase", letterSpacing: 1,
                                      }}>
                                        {item.mimeType?.startsWith('video/') ? "VIDEO" : item.mimeType === 'image/gif' ? "GIF" : "IMAGE"}
                                      </span>
                                    </div>
                                    <div className="m-overlay">
                                      <button
                                        onClick={() => {
                                          const newItem: MediaItem = { id: Date.now().toString(), url: item.url, type: isVideo ? 'video' : 'image', duration: 5, name: item.originalName };
                                          const currentMode = cfdConfig[cfdTab].mode;
                                          const updatedItems = currentMode === 'static' ? [newItem] : [...cfdConfig[cfdTab].items, newItem];
                                          updateCfdConfig({ ...cfdConfig, [cfdTab]: { ...cfdConfig[cfdTab], items: updatedItems } });
                                          setSelectedClipId(newItem.id);
                                          sileo.success({ title: "Added to CFD", description: `Added to ${cfdTab} screen.`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
                                        }}
                                        className="ve-btn" style={{ background: "#FF6700", color: "#fff", fontSize: 9, padding: "5px 14px" }}
                                      >+ Add to {cfdTab}</button>
                                      <button
                                        onClick={async () => {
                                          await fetch('/api/upload', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ filename: item.filename }) });
                                          setMediaLibrary(prev => prev.filter(m => m._id !== item._id));
                                          sileo.success({ title: "Deleted", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }, duration: 1000 });
                                        }}
                                        className="ve-btn" style={{ background: "#dc2626", color: "#fff", fontSize: 9, padding: "5px 14px" }}
                                      >Delete</button>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>

                          {/* CENTER — PREVIEW + TIMELINE */}
                          <div style={{ display: "flex", flexDirection: "column", overflow: "hidden", background: "#F0EFEF" }}>

                            {/* Preview */}
                            <div style={{ flex: 1, minHeight: 0, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
                              {/* Preview viewport */}
                              <div style={{ width: "100%", maxWidth: 540, display: "flex", flexDirection: "column", gap: 0 }}>
                                {/* Screen */}
                                <div style={{ aspectRatio: "16/9", background: "#111", borderRadius: "12px 12px 0 0", overflow: "hidden", border: "1px solid #d1d5db", borderBottom: "none", position: "relative", boxShadow: "0 8px 32px rgba(0,0,0,0.15)" }}>
                                  {cfdTab === 'ongoing' ? (
                                    <div style={{ width: "100%", height: "100%", display: "flex" }}>
                                      {/* Left 40% — order summary mock */}
                                      <div style={{ width: "40%", height: "100%", background: "#f9fafb", display: "flex", flexDirection: "column", borderRight: "1px solid #e5e7eb" }}>
                                        <div style={{ background: "#FF6700", padding: "8px 10px", flexShrink: 0 }}>
                                          <p style={{ fontFamily: "Poppins", fontSize: 8, fontWeight: 900, color: "#fff", textTransform: "uppercase", letterSpacing: 1, lineHeight: 1 }}>Order Summary</p>
                                          <p style={{ fontFamily: "Poppins", fontSize: 7, color: "rgba(255,255,255,0.75)", fontWeight: 600, marginTop: 1 }}>3 Items</p>
                                        </div>
                                        <div style={{ flex: 1, padding: "8px 10px", display: "flex", flexDirection: "column", gap: 6, overflowY: "hidden", background: "#f9fafb" }}>
                                          {[{ name: "Classic Donut", qty: 2, price: "100.00" }, { name: "Hot Coffee", qty: 1, price: "80.00" }, { name: "Munchkins ×6", qty: 1, price: "65.00" }].map((item, i) => (
                                            <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingBottom: 5, borderBottom: "1px solid #e5e7eb" }}>
                                              <div>
                                                <p style={{ fontFamily: "Poppins", fontSize: 7, fontWeight: 700, color: "#111", lineHeight: 1 }}>{item.name}</p>
                                                <p style={{ fontFamily: "Poppins", fontSize: 6, color: "#888", fontWeight: 600, marginTop: 1 }}>Qty: {item.qty}</p>
                                              </div>
                                              <p style={{ fontFamily: "Poppins", fontSize: 7, fontWeight: 900, color: "#FF6700" }}>{item.price}</p>
                                            </div>
                                          ))}
                                        </div>
                                        <div style={{ borderTop: "1px solid #e5e7eb", padding: "6px 10px", background: "#fff", flexShrink: 0 }}>
                                          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                                            <p style={{ fontFamily: "Poppins", fontSize: 8, fontWeight: 900, color: "#111", textTransform: "uppercase", letterSpacing: 0.5 }}>TOTAL</p>
                                            <p style={{ fontFamily: "Poppins", fontSize: 12, fontWeight: 900, color: "#FF6700" }}>245.00</p>
                                          </div>
                                        </div>
                                      </div>

                                      {/* Right 60% — playing ad */}
                                      <div style={{ width: "60%", height: "100%", position: "relative", background: "#f3f4f6" }}>
                                        {activeItems.length > 0 ? (() => {
                                          const item = activeItems[previewIndex] ?? activeItems[0];
                                          return item.type === 'video'
                                            ? <video
                                                ref={videoPreviewRef}
                                                key={item.id}
                                                src={item.url}
                                                style={{ width: "100%", height: "100%", objectFit: "contain" }}
                                                muted playsInline
                                                autoPlay={previewPlaying}
                                                onTimeUpdate={handleVideoTimeUpdate}
                                                onEnded={handleVideoEnded}
                                              />
                                            : <img key={item.id} src={item.url} style={{ width: "100%", height: "100%", objectFit: "contain" }} alt="" />;
                                        })() : (
                                          <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 6 }}>
                                            <div style={{ width: 36, height: 36, borderRadius: 10, background: "rgba(255,103,0,0.08)", border: "1px solid rgba(255,103,0,0.15)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                                              <MdMonitor size={20} color="#FF6700" />
                                            </div>
                                            <p style={{ fontFamily: "Poppins", fontSize: 8, fontWeight: 700, color: "#bbb" }}>No ads added</p>
                                          </div>
                                        )}
                                        <div style={{ position: "absolute", top: 6, right: 6, background: "rgba(255,103,0,0.85)", borderRadius: 4, padding: "2px 6px" }}>
                                          <p style={{ fontFamily: "Poppins", fontSize: 7, fontWeight: 800, color: "#fff", textTransform: "uppercase", letterSpacing: 1 }}>Ads</p>
                                        </div>
                                      </div>
                                    </div>
                                  ) : (
                                    // IDLE: full screen
                                    activeItems.length > 0 ? (() => {
                                      const item = activeItems[previewIndex] ?? activeItems[0];
                                      return item.type === 'video'
                                        ? <video
                                            ref={videoPreviewRef}
                                            key={item.id}
                                            src={item.url}
                                            style={{ width: "100%", height: "100%", objectFit: "contain" }}
                                            muted playsInline
                                            autoPlay={previewPlaying}
                                            onTimeUpdate={handleVideoTimeUpdate}
                                            onEnded={handleVideoEnded}
                                          />
                                        : <img key={item.id} src={item.url} style={{ width: "100%", height: "100%", objectFit: "contain" }} alt="" />;
                                    })() : (
                                      <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8 }}>
                                        <MdMonitor size={40} color="#333" />
                                        <p style={{ fontFamily: "Poppins", fontSize: 11, fontWeight: 700, color: "#555" }}>No media</p>
                                        <p style={{ fontFamily: "Poppins", fontSize: 9, color: "#444" }}>Add clips from the library</p>
                                      </div>
                                    )
                                  )}

                                  {/* Selected clip label */}
                                  {activeItems[previewIndex] && (
                                    <div style={{ position: "absolute", bottom: 8, left: 8, right: 8, background: "rgba(255,103,0,0.85)", borderRadius: 6, padding: "5px 10px", display: "flex", alignItems: "center", gap: 6 }}>
                                      <span style={{ fontFamily: "Poppins", fontSize: 9, fontWeight: 800, color: "#fff", flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                                        Clip {previewIndex + 1}
                                      </span>
                                      <span style={{ fontFamily: "Poppins", fontSize: 8, fontWeight: 700, color: "rgba(255,255,255,0.8)", background: "rgba(0,0,0,0.2)", borderRadius: 4, padding: "1px 6px", flexShrink: 0 }}>
                                        {previewIndex + 1} / {activeItems.length}
                                      </span>
                                    </div>
                                  )}
                                </div>

                                {/* ── PLAYER CONTROLS ── */}
                                <div style={{ background: "#fff", border: "1px solid #d1d5db", borderTop: "none", borderRadius: "0 0 12px 12px", padding: "8px 12px", display: "flex", flexDirection: "column", gap: 6 }}>
                                  {/* Progress bar */}
                                  <div style={{ height: 3, background: "#F3F4F6", borderRadius: 99, overflow: "hidden" }}>
                                    <div style={{ height: "100%", width: `${previewProgress * 100}%`, background: "#FF6700", borderRadius: 99, transition: "width 0.05s linear" }} />
                                  </div>

                                  {/* Clip scrubber dots */}
                                  {activeItems.length > 1 && (
                                    <div style={{ display: "flex", gap: 4, alignItems: "center", justifyContent: "center" }}>
                                      {activeItems.map((_, i) => (
                                        <button
                                          key={i}
                                          onClick={() => { if (previewPlaying) startClip(i, activeItems); else { setPreviewIndex(i); setSelectedClipId(activeItems[i].id); setPreviewProgress(0); } }}
                                          style={{ width: i === previewIndex ? 18 : 6, height: 6, borderRadius: 99, background: i === previewIndex ? "#FF6700" : "#E5E7EB", border: "none", cursor: "pointer", transition: "all 0.2s", padding: 0 }}
                                        />
                                      ))}
                                    </div>
                                  )}

                                  {/* Controls row */}
                                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                    {/* Prev */}
                                    <button
                                      onClick={() => { const i = (previewIndex - 1 + activeItems.length) % activeItems.length; if (previewPlaying) startClip(i, activeItems); else { setPreviewIndex(i); setSelectedClipId(activeItems[i]?.id ?? null); setPreviewProgress(0); } }}
                                      disabled={activeItems.length < 2}
                                      style={{ background: "#F3F4F6", border: "1px solid #E5E7EB", borderRadius: 6, padding: "4px 10px", cursor: "pointer", color: "#666", fontSize: 12, fontWeight: 700, fontFamily: "Poppins", opacity: activeItems.length < 2 ? 0.4 : 1 }}
                                    >‹</button>

                                    {/* Play/Pause */}
                                    <button
                                      onClick={togglePlay}
                                      disabled={activeItems.length === 0}
                                      style={{ flex: 1, background: activeItems.length === 0 ? "#F3F4F6" : previewPlaying ? "rgba(255,103,0,0.1)" : "#FF6700", border: `1px solid ${previewPlaying ? "rgba(255,103,0,0.3)" : "#FF6700"}`, borderRadius: 8, padding: "6px 0", cursor: "pointer", color: previewPlaying ? "#FF6700" : "#fff", fontSize: 10, fontWeight: 800, fontFamily: "Poppins", letterSpacing: 1, textTransform: "uppercase", transition: "all 0.15s" }}
                                    >
                                      {activeItems.length === 0 ? "No clips" : previewPlaying ? "⏸ Pause" : "▶ Play"}
                                    </button>

                                    {/* Next */}
                                    <button
                                      onClick={() => { const i = (previewIndex + 1) % activeItems.length; if (previewPlaying) startClip(i, activeItems); else { setPreviewIndex(i); setSelectedClipId(activeItems[i]?.id ?? null); setPreviewProgress(0); } }}
                                      disabled={activeItems.length < 2}
                                      style={{ background: "#F3F4F6", border: "1px solid #E5E7EB", borderRadius: 6, padding: "4px 10px", cursor: "pointer", color: "#666", fontSize: 12, fontWeight: 700, fontFamily: "Poppins", opacity: activeItems.length < 2 ? 0.4 : 1 }}
                                    >›</button>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* Timeline */}
                            <div style={{ borderTop: "1px solid #E5E7EB", background: "#fff", padding: "10px 16px 12px", flexShrink: 0 }}>
                              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                                <div className="flex items-center gap-2">
                                  <div style={{ width: 3, height: 14, background: "#FF6700", borderRadius: 2 }} />
                                  <span className="ve-label">Timeline — {cfdTab}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <span className="ve-label">{cfdConfig[cfdTab].items.length} clip{cfdConfig[cfdTab].items.length !== 1 ? 's' : ''}</span>
                                  {selectedClip && (
                                    <button onClick={() => setSelectedClipId(null)} className="ve-btn" style={{ background: "#F3F4F6", color: "#888", padding: "2px 8px", fontSize: 9 }}>deselect</button>
                                  )}
                                </div>
                              </div>
                              {/* Track row */}
                              <div className="scrollbar-or" style={{ overflowX: "auto", overflowY: "hidden" }}>
                                <div style={{ display: "flex", gap: 6, minWidth: "max-content", padding: "2px 0 2px", minHeight: 60, alignItems: "center" }}>
                                  {cfdConfig[cfdTab].items.length === 0 ? (
                                    <div style={{ height: 52, width: 360, border: "2px dashed #E5E7EB", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center" }}>
                                      <span style={{ fontFamily: "Poppins", fontSize: 9, color: "#ccc", fontWeight: 700 }}>Add clips from the library →</span>
                                    </div>
                                  ) : cfdConfig[cfdTab].items.map((item, idx) => {
                                    const isSelected = selectedClipId === item.id;
                                    const clipW = item.type === 'image' ? Math.max(80, item.duration * 16) : 110;
                                    const clipBg = item.type === 'video' ? "rgba(255,103,0,0.08)" : "rgba(124,58,237,0.07)";
                                    const clipBorder = item.type === 'video' ? "rgba(255,103,0,0.35)" : "rgba(124,58,237,0.35)";
                                    return (
                                      <div
                                        key={item.id}
                                        className={`ve-track-clip${isSelected ? ' selected' : ''}`}
                                        style={{ width: clipW, background: clipBg, border: `2px solid ${isSelected ? '#FF6700' : clipBorder}` }}
                                        onClick={() => setSelectedClipId(isSelected ? null : item.id)}
                                      >
                                        {item.type === 'image'
                                          ? <img src={item.url} style={{ height: 36, width: 36, objectFit: "cover", borderRadius: 4, flexShrink: 0, opacity: 0.85 }} alt="" />
                                          : <span style={{ fontSize: 18, flexShrink: 0 }}>🎥</span>
                                        }
                                        <div style={{ minWidth: 0, flex: 1 }}>
                                          <p style={{ fontFamily: "Poppins", fontSize: 8, fontWeight: 800, color: item.type === 'video' ? "#FF6700" : "#7c3aed", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                                            CLIP {idx + 1}
                                          </p>
                                          <p style={{ fontFamily: "Poppins", fontSize: 7, color: "#aaa", fontWeight: 700 }}>
                                            {item.type === 'image' ? `${item.duration}s` : 'auto'}
                                          </p>
                                        </div>
                                        <button
                                          onClick={(e) => { e.stopPropagation(); handleRemoveMedia(item.id); if (selectedClipId === item.id) setSelectedClipId(null); }}
                                          style={{ position: "absolute", top: 3, right: 3, background: "rgba(239,68,68,0.15)", border: "none", borderRadius: 4, color: "#ef4444", cursor: "pointer", padding: "1px 5px", fontSize: 9, fontWeight: 800 }}
                                        >✕</button>
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* RIGHT — PROPERTIES */}
                          <div style={{ borderLeft: "1px solid #E5E7EB", display: "flex", flexDirection: "column", overflow: "hidden", background: "#fff" }}>

                            {/* Screen tab switcher */}
                            <div style={{ padding: "10px 12px", borderBottom: "1px solid #F3F4F6", flexShrink: 0 }}>
                              <div style={{ display: "flex", background: "#F3F4F6", borderRadius: 10, padding: 3, gap: 2 }}>
                                <button onClick={() => { setCfdTab('idle'); setSelectedClipId(null); setSelectedClipId(null); stopPlayer(); setPreviewPlaying(false); setPreviewIndex(0); setPreviewProgress(0); }} className={cfdTab === 'idle' ? 've-tab-act' : 've-tab-off'} style={{ flex: 1, borderRadius: 8 }}>Idle</button>
                                <button onClick={() => { setCfdTab('ongoing'); setSelectedClipId(null); setSelectedClipId(null); stopPlayer(); setPreviewPlaying(false); setPreviewIndex(0); setPreviewProgress(0); }} className={cfdTab === 'ongoing' ? 've-tab-act' : 've-tab-off'} style={{ flex: 1, borderRadius: 8 }}>Ongoing</button>
                              </div>
                            </div>

                            <div className="scrollbar-or" style={{ flex: 1, overflowY: "auto", padding: 14, display: "flex", flexDirection: "column", gap: 14 }}>

                              {/* ── CLIP PROPERTIES (when selected) ── */}
                              {selectedClip ? (
                                <>
                                  <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 12px", background: "rgba(255,103,0,0.05)", borderRadius: 10, border: "1px solid rgba(255,103,0,0.15)" }}>
                                    <div style={{ width: 40, height: 40, borderRadius: 8, overflow: "hidden", flexShrink: 0, background: "#f3f4f6", border: "1px solid #e5e7eb" }}>
                                      {selectedClip.type === 'image'
                                        ? <img src={selectedClip.url} style={{ width: "100%", height: "100%", objectFit: "cover" }} alt="" />
                                        : <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>🎥</div>
                                      }
                                    </div>
                                    <div style={{ flex: 1, minWidth: 0 }}>
                                      <p style={{ fontFamily: "Poppins", fontSize: 10, fontWeight: 800, color: "#1a1a1a" }}>
                                        Clip {cfdConfig[cfdTab].items.findIndex(i => i.id === selectedClip.id) + 1}
                                      </p>
                                      <p style={{ fontFamily: "Poppins", fontSize: 9, color: "#FF6700", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5 }}>
                                        selected
                                      </p>
                                    </div>
                                  </div>

                                  <div style={{ borderBottom: "1px solid #F3F4F6", paddingBottom: 14, display: "flex", flexDirection: "column", gap: 10 }}>
                                    <p className="ve-label" style={{ color: "#FF6700" }}>Clip Properties</p>
 
                                    {/* Type badge — read-only */}
                                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                                      <span style={{
                                        fontFamily: "Poppins", fontSize: 9, fontWeight: 800,
                                        textTransform: "uppercase", letterSpacing: 1,
                                        padding: "3px 10px", borderRadius: 999,
                                        background: selectedClip.type === 'video' ? "rgba(255,103,0,0.1)" : selectedClip.url.toLowerCase().endsWith('.gif') ? "rgba(124,58,237,0.1)" : "rgba(22,163,74,0.1)",
                                        color: selectedClip.type === 'video' ? "#FF6700" : selectedClip.url.toLowerCase().endsWith('.gif') ? "#7c3aed" : "#16a34a",
                                      }}>
                                        {selectedClip.type === 'video' ? "VIDEO" : selectedClip.url.toLowerCase().endsWith('.gif') ? "GIF" : "IMAGE"}
                                      </span>
                                    </div>
 
                                    {/* Duration — only for non-video */}
                                    {selectedClip.type === 'image' && (
                                      <div className="prop-row">
                                        <span className="prop-label">Duration (seconds)</span>
                                        <div className="flex items-center gap-2">
                                          <input
                                            type="range" min="1" max="60" step="1"
                                            value={selectedClip.duration}
                                            onChange={(e) => updateClip(selectedClip.id, { duration: Number(e.target.value) })}
                                            style={{ flex: 1, accentColor: "#FF6700" }}
                                          />
                                          <input
                                            type="number" min="1" max="60"
                                            className="ve-input" style={{ width: 56, textAlign: "center" }}
                                            value={selectedClip.duration}
                                            onChange={(e) => updateClip(selectedClip.id, { duration: Math.max(1, Number(e.target.value)) })}
                                          />
                                        </div>
                                      </div>
                                    )}
 
                                    <div className="flex gap-2">
                                      <button
                                        onClick={() => moveClip(selectedClip.id, -1)}
                                        disabled={cfdConfig[cfdTab].items.findIndex(i => i.id === selectedClip.id) === 0}
                                        className="ve-btn" style={{ flex: 1, background: "#F3F4F6", color: "#666", fontSize: 9, border: "1px solid #E5E7EB" }}
                                      >← Move Earlier</button>
                                      <button
                                        onClick={() => moveClip(selectedClip.id, 1)}
                                        disabled={cfdConfig[cfdTab].items.findIndex(i => i.id === selectedClip.id) === cfdConfig[cfdTab].items.length - 1}
                                        className="ve-btn" style={{ flex: 1, background: "#F3F4F6", color: "#666", fontSize: 9, border: "1px solid #E5E7EB" }}
                                      >Move Later →</button>
                                    </div>
 
                                    <button
                                      onClick={() => { handleRemoveMedia(selectedClip.id); setSelectedClipId(null); }}
                                      className="ve-btn" style={{ background: "rgba(239,68,68,0.08)", color: "#dc2626", border: "1px solid rgba(239,68,68,0.2)", width: "100%" }}
                                    >Remove Clip</button>
                                  </div>

                                  {/* Back to general props */}
                                  <button onClick={() => setSelectedClipId(null)} className="ve-btn" style={{ background: "#F3F4F6", color: "#888", fontSize: 9, border: "1px solid #E5E7EB", width: "100%" }}>
                                    ← Back to Screen Settings
                                  </button>
                                </>
                              ) : (
                                <>
                                  {/* ── SCREEN SETTINGS (no selection) ── */}
                                  <div>
                                    <p className="ve-label" style={{ marginBottom: 6 }}>Playback Mode</p>
                                    <select className="ve-select" value={cfdConfig[cfdTab].mode} onChange={(e) => handleUpdateCfdMode(e.target.value as 'static' | 'carousel')}>
                                      <option value="static">Static — Single file, loops</option>
                                      <option value="carousel">Carousel — Multiple clips in sequence</option>
                                    </select>
                                    <p style={{ fontFamily: "Poppins", fontSize: 9, color: "#aaa", marginTop: 6, fontWeight: 600, lineHeight: 1.5 }}>
                                      {cfdConfig[cfdTab].mode === 'static' ? "One file plays on loop indefinitely." : "Clips play in sequence. Click a clip in the timeline to edit its duration."}
                                    </p>
                                  </div>

                                  {/* Display assignment */}
                                  <div style={{ borderTop: "1px solid #F3F4F6", paddingTop: 12, display: "flex", flexDirection: "column", gap: 6 }}>
                                    <p className="ve-label">Display Assignment</p>
                                    {!screenApiSupported && (
                                      <div style={{ background: "rgba(239,68,68,0.06)", border: "1px solid rgba(239,68,68,0.15)", borderRadius: 8, padding: "8px 10px" }}>
                                        <p style={{ fontFamily: "Poppins", fontSize: 9, color: "#dc2626", fontWeight: 700 }}>Chrome or Edge required</p>
                                      </div>
                                    )}
                                    {availableScreens.length === 0 ? (
                                      <button onClick={handleDetectScreens} className="ve-btn" style={{ background: "#F3F4F6", color: "#888", width: "100%", border: "2px dashed #E5E7EB" }}>
                                        <MdMonitor size={12} style={{ display: "inline", marginRight: 4, verticalAlign: -2 }} />Detect Displays
                                      </button>
                                    ) : availableScreens.map((screen, idx) => {
                                      const isSelected = selectedCustomerScreenId === screen.id;
                                      return (
                                        <div key={idx} style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 10px", borderRadius: 8, background: isSelected ? "rgba(255,103,0,0.05)" : "#F9FAFB", border: `1px solid ${isSelected ? "rgba(255,103,0,0.25)" : "#E5E7EB"}` }}>
                                          <MdMonitor size={14} color={isSelected ? "#FF6700" : "#aaa"} />
                                          <div style={{ flex: 1, minWidth: 0 }}>
                                            <p style={{ fontFamily: "Poppins", fontSize: 9, fontWeight: 800, color: isSelected ? "#FF6700" : "#555", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{screen.label}</p>
                                            <p style={{ fontFamily: "Poppins", fontSize: 8, color: "#aaa", fontWeight: 700 }}>{screen.width}×{screen.height}{screen.isPrimary ? " (primary)" : ""}</p>
                                          </div>
                                          {!screen.isPrimary && (
                                            <button onClick={() => handleSelectScreen(screen.id)} className="ve-btn" style={{ background: isSelected ? "#FF6700" : "#E5E7EB", color: isSelected ? "#fff" : "#666", padding: "4px 10px", fontSize: 9 }}>
                                              {isSelected ? "✓" : "Set"}
                                            </button>
                                          )}
                                        </div>
                                      );
                                    })}
                                  </div>
                                </>
                              )}
                            </div>

                            
                          </div>
                        </div>
                      </div>
                    );
                  })()}
                </>
              )}

              {activeSection === "system" && (
                <div style={{ flex: 1, minHeight: 0, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                  <div style={{ ...theme.card, padding: 24, display: "flex", flexDirection: "column" }}>
                    <p style={{ fontFamily: "Poppins", fontSize: 12, color: "#10b981", letterSpacing: 1.2, textTransform: "uppercase", fontWeight: 800, marginBottom: 12 }}>Connections</p>
                    <div className="flex flex-col gap-3">
                      {connections.map((conn, i) => (
                        <div key={i} className="flex items-center gap-3 rounded-xl px-4 py-3" style={{ background: "#F9FAFB", border: "1px solid #E5E7EB" }}>
                          <ConnDot status={conn.status} />
                          <div className="flex-1 min-w-0">
                            <p style={{ fontSize: 12, fontWeight: 700, color: "#1A1A1A" }}>{conn.label}</p>
                            <p style={{ fontSize: 10, color: "#888", fontFamily: "'Courier New', monospace" }}>{conn.sub}</p>
                          </div>
                          {statusBadge(conn.status)}
                        </div>
                      ))}
                    </div>
                    <button onClick={handleRetryConnections} disabled={retrying}
                      className="mt-4 w-full py-2.5 text-sm font-bold text-white transition-all hover:brightness-110 active:scale-95 disabled:opacity-60 flex items-center justify-center gap-2"
                      style={{ fontFamily: "Poppins", textTransform: "uppercase", background: "#FF6700", borderRadius: 8 }}>
                      {getIcon("refresh", { size: 14, color: "#fff" })}
                      {retrying ? "Checking…" : "Retry All"}
                    </button>
                  </div>

                  <div style={{ ...theme.card, padding: 24, display: "flex", flexDirection: "column" }}>
                    <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-4">
                      <p style={{ fontFamily: "Poppins", fontSize: 12, color: "#dc2626", letterSpacing: 1.2, textTransform: "uppercase", fontWeight: 800, flex: 1 }}>Error Logs</p>
                      <select value={logFilter} onChange={(e) => setLogFilter(e.target.value as typeof logFilter)}
                        className="px-2 py-1 outline-none" style={{ ...theme.input, fontSize: 10, fontWeight: 600, color: "#1A1A1A" }}>
                        <option value="all">All</option>
                        <option value="error">Errors</option>
                        <option value="warn">Warnings</option>
                        <option value="info">Info</option>
                      </select>
                    </div>
                    <div className="flex-1 overflow-y-auto flex flex-col gap-2 mb-4" style={{ maxHeight: 380 }}>
                      {filteredLogs.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-10" style={{ color: "#888" }}>
                          <p style={{ fontSize: 12 }}>No logs to display.</p>
                        </div>
                      ) : filteredLogs.map((log, i) => (
                        <div key={i} className="flex items-start gap-2 rounded-xl px-3 py-2" style={logRowBg[log.level]}>
                          <LogBadge level={log.level} />
                          <p style={{ fontSize: 11, color: "#1A1A1A", flex: 1, lineHeight: 1.4 }}>{log.message}</p>
                          <span style={{ fontSize: 9, color: "#666", flexShrink: 0, fontFamily: "'Courier New', monospace" }}>{log.time}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => setLogs([])}
                        className="flex-1 py-2 text-xs font-bold transition-all hover:bg-gray-100 flex items-center justify-center gap-1"
                        style={{ fontFamily: "Poppins", textTransform: "uppercase", background: "#F3F4F6", color: "#666", borderRadius: 8, border: "1px solid #D1D5DB" }}>
                        {getIcon("delete", { size: 14, color: "#666" })} Clear
                      </button>
                      <button className="flex-[2] py-2 text-xs font-bold text-white transition-all hover:brightness-110 flex items-center justify-center"
                        style={{ fontFamily: "Poppins", textTransform: "uppercase", background: "#FF6700", borderRadius: 8 }}>
                        Export Logs
                      </button>
                    </div>
                  </div>
                </div>
              )}

            </div>
          </div>
        </div>
      </div>
    </>
  );
}