"use client";

import { useEffect, useState, useRef, useCallback } from "react";
import { useRouter, usePathname } from "next/navigation";
import { FiHome, FiShoppingCart, FiBarChart2, FiRotateCcw, FiClock, FiSettings, FiArchive, FiDownload, FiMonitor } from 'react-icons/fi';
import { TicketSlash, UserRound } from "lucide-react";
import { sileo, Toaster } from "sileo";

import { getAssociateByPin } from '../../src/api/associates';
import { useIdleTimeout } from "../hooks/useIdleTimeout";
import { formatMoney } from "../components/pos/ProductCard";
import { resolveMenuImageUrl } from "@/src/utils/menuImages";

// ─── STYLES ────────────────────────────────────────────────────────────────
const glass = {
  panel: {
    background: "rgba(255,255,255,0.18)",
    backdropFilter: "blur(20px)",
    WebkitBackdropFilter: "blur(20px)",
    border: "1px solid rgba(255,255,255,0.35)",
    boxShadow: "inset 0 1px 0 rgba(255,255,255,0.5), 0 8px 32px rgba(0,0,0,0.12)"
  } as React.CSSProperties,
  modal: {
    background: "rgba(255,255,255,0.85)",
    backdropFilter: "blur(32px)",
    WebkitBackdropFilter: "blur(32px)",
    border: "1.5px solid rgba(255,255,255,0.95)",
    boxShadow: "0 32px 80px rgba(0,0,0,0.16), inset 0 1px 0 rgba(255,255,255,1)"
  } as React.CSSProperties,
};

const IDLE_COLORS = [
  "#f97316", "#3b82f6", "#22c55e", "#ec4899", "#a855f7",
  "#14b8a6", "#f59e0b", "#ef4444", "#06b6d4", "#84cc16",
];

export function Avatar({ src, alt, className, style }: { src: string; alt: string; className?: string; style?: React.CSSProperties }) {
  const [stage, setStage] = useState<'local' | 'remote' | 'dead'>('local');

  useEffect(() => {
    setStage('local');
  }, [src]);

  if (stage === 'dead' || !src) {
    return (
      <div className={`flex items-center justify-center bg-orange-100 ${className}`} style={style}>
        <UserRound size={24} className="text-orange-400" />
      </div>
    );
  }

  return (
    <img
      src={stage === 'local' ? resolveMenuImageUrl(src) : src}
      alt={alt}
      className={className}
      style={style}
      onError={() => {
        if (stage === 'local') setStage('remote');
        else setStage('dead');
      }}
    />
  );
}


// ─── SESSION GUARD OVERLAY ─────────────────────────────────────────────────
function SessionGuardOverlay({ visible }: { visible: boolean }) {
  if (!visible) return null;
  return (
    <div className="fixed inset-0 z-[9999998] flex flex-col items-center justify-center" style={{ background: "rgba(0,0,0,0.82)", backdropFilter: "blur(18px)" }}>
      <div className="flex flex-col items-center gap-5">
        <div className="w-14 h-14 rounded-full border-4 border-orange-500/30 border-t-orange-500 animate-spin" />
        <div className="flex flex-col items-center gap-1 text-center">
          <span className="text-white text-lg font-black tracking-wide" style={{ fontFamily: "Poppins" }}>
            No Active Session
          </span>
          <span className="text-white/50 text-xs font-medium tracking-widest uppercase" style={{ fontFamily: "Poppins" }}>
            Redirecting to login…
          </span>
        </div>
      </div>
    </div>
  );
}


// ─── LOCK SCREEN COMPONENT ─────────────────────────────────────────────────
function LockScreenOverlay({ isLocked, onUnlock, currentStaffId, staffName, staffAvatar }: { isLocked: boolean, onUnlock: () => void, currentStaffId: string, staffName: string, staffAvatar: string }) {
  const screenRef = useRef<HTMLDivElement>(null);
  const logoRef   = useRef<HTMLDivElement>(null);
  const rafRef    = useRef<number>(0);

  const stateRef = useRef({ x: 100, y: 100, vx: 1.8, vy: 1.6, colorIdx: 0, W: 0, H: 0, lW: 0, lH: 0 });

  const [color, setColor]       = useState(IDLE_COLORS[0]);
  const [pos, setPos]           = useState({ x: 100, y: 100 });
  const [clock, setClock]       = useState("");
  const [flash, setFlash]       = useState(false);
  const [flashPos, setFlashPos] = useState({ x: 0, y: 0 });
  const [imgError, setImgError] = useState(false);

  const [showPinPad, setShowPinPad] = useState(false);
  const [pin, setPin] = useState("");

  useEffect(() => {
    if (!isLocked) { setShowPinPad(false); setPin(""); }
  }, [isLocked]);

  useEffect(() => {
    const tick = () => {
      const n = new Date();
      setClock(`${n.toLocaleTimeString("en-PH", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false })}   ·   ${n.toLocaleDateString("en-PH", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  const bounce = useCallback(() => {
    if (showPinPad || !isLocked) return;
    const s = stateRef.current;
    if (!s.W || !s.lW) return;

    s.x += s.vx; s.y += s.vy;
    let hit = false;

    if (s.x <= 0)           { s.x = 0;          s.vx =  Math.abs(s.vx); hit = true; }
    if (s.x >= s.W - s.lW)  { s.x = s.W - s.lW; s.vx = -Math.abs(s.vx); hit = true; }
    if (s.y <= 0)           { s.y = 0;          s.vy =  Math.abs(s.vy); hit = true; }
    if (s.y >= s.H - s.lH)  { s.y = s.H - s.lH; s.vy = -Math.abs(s.vy); hit = true; }

    if (hit) {
      s.colorIdx = (s.colorIdx + 1) % IDLE_COLORS.length;
      setColor(IDLE_COLORS[s.colorIdx]);
      setFlashPos({ x: s.x + s.lW / 2, y: s.y + s.lH / 2 });
      setFlash(true);
      setTimeout(() => setFlash(false), 180);
    }
    setPos({ x: Math.round(s.x), y: Math.round(s.y) });
    rafRef.current = requestAnimationFrame(bounce);
  }, [showPinPad, isLocked]);

  useEffect(() => {
    if (showPinPad || !isLocked) {
      cancelAnimationFrame(rafRef.current);
      return;
    }
    const init = () => {
      const sc = screenRef.current; const lg = logoRef.current;
      if (!sc || !lg) return;
      const s = stateRef.current;
      s.W = sc.offsetWidth; s.H = sc.offsetHeight;
      s.lW = lg.offsetWidth || 280; s.lH = lg.offsetHeight || 280;

      if (s.x === 100 && s.y === 100) {
        const angle = Math.random() * Math.PI * 2;
        s.x = Math.random() * Math.max(1, s.W - s.lW);
        s.y = Math.random() * Math.max(1, s.H - s.lH);
        s.vx = Math.cos(angle) * 1.8;
        s.vy = Math.sin(angle) * 1.6;
      }
      setPos({ x: Math.round(s.x), y: Math.round(s.y) });
      rafRef.current = requestAnimationFrame(bounce);
    };
    const t = setTimeout(init, 100);
    const ro = new ResizeObserver(() => {
      if (screenRef.current) { stateRef.current.W = screenRef.current.offsetWidth; stateRef.current.H = screenRef.current.offsetHeight; }
    });
    if (screenRef.current) ro.observe(screenRef.current);
    return () => { clearTimeout(t); cancelAnimationFrame(rafRef.current); ro.disconnect(); };
  }, [bounce, showPinPad, isLocked]);

  const verifyPin = async (enteredPin: string) => {
    try {
      const associate = await getAssociateByPin(enteredPin);
      if (!associate) {
        sileo.error({ title: "Invalid PIN!", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
        setPin("");
        return;
      }
      if (String(associate.user.id) === String(currentStaffId)) {
        onUnlock();
      } else {
        sileo.error({ title: "Access Denied", description: "Only the active cashier can unlock.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
        setPin("");
      }
    } catch {
      sileo.error({ title: "Error verifying PIN", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
      setPin("");
    }
  };

  return (
    <div ref={screenRef} className={`fixed inset-0 z-[999999] overflow-hidden bg-black select-none outline-none transition-opacity duration-700 ease-in-out ${isLocked ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`} tabIndex={0}>
      <div className={`absolute inset-0 transition-opacity duration-500 cursor-pointer ${showPinPad ? 'opacity-0 pointer-events-none' : 'opacity-100'}`} onClick={() => setShowPinPad(true)}>
        <div ref={logoRef} style={{ position: "absolute", left: pos.x, top: pos.y, color, transition: "color 0.2s" }}>
          {!imgError ? (
            <img src="/images/menux_white.png" alt="MenuX" onError={() => setImgError(true)} style={{ width: 240, height: 240, objectFit: "contain", filter: `drop-shadow(0 0 14px ${color}) drop-shadow(0 0 4px ${color})`, transition: "filter 0.2s" }} />
          ) : (
            <div style={{ width: 240, height: 240, borderRadius: 18, border: `4px solid ${color}`, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 24px ${color}55` }}>
              <span style={{ fontFamily: "Impact, 'Arial Black', sans-serif", fontSize: 72, color }}>MX</span>
            </div>
          )}
        </div>
        {flash && <div style={{ position: "absolute", left: flashPos.x - 120, top: flashPos.y - 120, width: 240, height: 240, borderRadius: "50%", background: `radial-gradient(circle, ${color}66 0%, transparent 70%)` }} />}
        <div style={{ position: "absolute", bottom: 36, left: "50%", transform: "translateX(-50%)", fontFamily: "'Courier New', monospace", fontSize: 13, color: "rgba(255,255,255,0.18)", letterSpacing: 2 }}>{clock}</div>
        <div style={{ position: "absolute", bottom: 16, left: "50%", transform: "translateX(-50%)", fontFamily: "Impact", fontSize: 9, color: "rgba(255,255,255,0.10)", letterSpacing: 3, textTransform: "uppercase" }}>TAP ANYWHERE TO RESUME</div>
      </div>

      <div className={`absolute inset-0 flex items-center justify-center transition-all duration-500 ease-[cubic-bezier(0.25,1,0.5,1)] ${showPinPad ? 'opacity-100 backdrop-blur-xl bg-black/60 scale-100' : 'opacity-0 scale-95 pointer-events-none'}`}>
        <div className="rounded-[32px] p-8 w-full max-w-sm flex flex-col items-center" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", boxShadow: "0 32px 64px rgba(0,0,0,0.5)" }}>
          <div className="w-20 h-20 rounded-full overflow-hidden mb-4 border-2 border-orange-500 shadow-[0_0_15px_rgba(249,115,22,0.3)]">
            <Avatar src={staffAvatar} alt={staffName} className="w-full h-full object-cover" />
          </div>
          <h2 className="text-white text-lg font-bold font-poppins">{staffName || "Cashier"}</h2>
          <p className="text-gray-400 text-xs font-poppins mb-6">Enter PIN to unlock register</p>
          <div className="flex gap-3 mb-8 h-4 items-center justify-center">
            {[...Array(4)].map((_, i) => (
              <div key={i} className={`rounded-full transition-all duration-200 ${i < pin.length ? 'w-4 h-4 bg-orange-500 shadow-[0_0_10px_#f97316]' : 'w-3 h-3 bg-white/20'}`} />
            ))}
          </div>
          <div className="grid grid-cols-3 gap-4 w-full mb-6">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
              <button key={num} onClick={() => { if (pin.length < 4) { const newPin = pin + String(num); setPin(newPin); if (newPin.length === 4) verifyPin(newPin); } }} className="h-16 rounded-2xl text-2xl font-bold text-white transition-all hover:bg-white/20 active:scale-95 font-poppins" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}>{num}</button>
            ))}
            <button onClick={() => { setPin(""); setShowPinPad(false); }} className="h-16 rounded-2xl text-sm font-bold text-gray-400 transition-all hover:bg-white/10 active:scale-95 font-poppins uppercase tracking-wider">Cancel</button>
            <button onClick={() => { if (pin.length < 4) { const newPin = pin + "0"; setPin(newPin); if (newPin.length === 4) verifyPin(newPin); } }} className="h-16 rounded-2xl text-2xl font-bold text-white transition-all hover:bg-white/20 active:scale-95 font-poppins" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}>0</button>
            <button onClick={() => setPin(p => p.slice(0, -1))} className="h-16 rounded-2xl text-2xl font-bold text-red-400 transition-all hover:bg-white/10 active:scale-95 font-poppins flex items-center justify-center">⌫</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN MASTER LAYOUT ────────────────────────────────────────────────────
export default function POSLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();

  useIdleTimeout();

  const [isLocked, setIsLocked] = useState(false);
  const [showSessionMenu, setShowSessionMenu] = useState(false);
  const [hasActiveSession, setHasActiveSession] = useState(false);
  const [sessionDetails, setSessionDetails] = useState<{id: string, cash: string, time: string, shiftNo: number | null} | null>(null);
  const [isEnclosedMode, setIsEnclosedMode] = useState(false);


  const [staffId, setStaffId] = useState("");
  const [staffName, setStaffName] = useState("");
  const [staffAvatar, setStaffAvatar] = useState("");
  const [timeStr, setTimeStr] = useState("");
  const [dateStr, setDateStr] = useState("");

  // ── Session guard ──────────────────────────────────────────────────────
  const [sessionBlocked, setSessionBlocked] = useState(false);
  const redirectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    // /settings is intentionally reachable from the login screen (triple-click logo)
    // without a session — block everything else.
    if (pathname === '/settings') {
      setSessionBlocked(false);
      return;
    }

    const token = localStorage.getItem('sessionToken');
    const user  = localStorage.getItem('currentUser');

    if (!token || !user) {
      setSessionBlocked(true);
      if (redirectTimer.current) clearTimeout(redirectTimer.current);
      redirectTimer.current = setTimeout(() => {
        router.push('/logs');
      }, 2000);
    } else {
      setSessionBlocked(false);
    }

    return () => {
      if (redirectTimer.current) clearTimeout(redirectTimer.current);
    };
  }, [pathname, router]);
  // ──────────────────────────────────────────────────────────────────────

  useEffect(() => {
    try { setIsLocked(localStorage.getItem("pos_locked") === "true"); }
    catch {}
  }, []);

  const [businessDate, setBusinessDate] = useState<string | null>(null);
  const [isManagerBypass, setIsManagerBypass] = useState(false);
  const [accountRole, setAccountRole] = useState<number | null>(null);

  // Clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString("en-PH", { hour: "2-digit", minute: "2-digit", hour12: false }));
      setDateStr(now.toLocaleDateString("en-GB"));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // Global Lock Listener
  useEffect(() => {
    const handleTriggerLock = () => setIsLocked(true);
    window.addEventListener('trigger-lock', handleTriggerLock);
    return () => window.removeEventListener('trigger-lock', handleTriggerLock);
  }, []);

  // Staff & bypass state
  useEffect(() => {
    try {
      const lastLoginStr = localStorage.getItem('lastLogin');
      if (lastLoginStr) {
        const lastLogin = JSON.parse(lastLoginStr);
        if (lastLogin?.user_id) setStaffId(String(lastLogin.user_id));
        if (lastLogin?.name) setStaffName(String(lastLogin.name));
        if (lastLogin?.avatar) setStaffAvatar(String(lastLogin.avatar));
        if (lastLogin?.role) setAccountRole(Number(lastLogin.role));
      }
      setIsManagerBypass(localStorage.getItem('managerBypass') === 'true');
    } catch {}
  }, [pathname]);

  // Session data
  useEffect(() => {
    if (typeof window !== 'undefined') {
      setIsEnclosedMode(localStorage.getItem('enclosedMode') === 'true' || new URLSearchParams(window.location.search).get('mode') === 'enclosed');
    }

    if (!staffId) return;
    fetch(`/api/cashier-session?staffId=${staffId}`)
      .then(res => res.json())
      .then(data => {
        if (data.businessDayOpenedAt) {
          const bDate = new Date(data.businessDayOpenedAt);
          setBusinessDate(bDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }).toUpperCase());
        } else {
          setBusinessDate(null);
        }

        if (data.active && data.session) {
          setHasActiveSession(true);
          setSessionDetails({
            id: data.session.sessionId,
            cash: data.session.startingCash,
            time: data.session.openedAt,
            shiftNo: data.session.shiftNumber || null,
          });
        } else {
          setHasActiveSession(false);
          setSessionDetails(null);
        }
      })
      .catch(() => setHasActiveSession(false));
  }, [pathname, showSessionMenu, staffId]);

  const handleSignOut = () => {
    localStorage.removeItem("currentUser");
    localStorage.removeItem("sessionToken");
    localStorage.removeItem("managerBypass");
    router.push("/logs");
  };

  const navItems = [
    { label: "Home",          route: "/dashboard",               icon: <FiHome size={16} /> },
    { label: "Kiosk",         route: "/kiosk",             icon: <FiMonitor size={16} /> },
    { label: "Order History", route: "/OrderTransactionHistory", icon: <FiShoppingCart size={16} /> },
    { label: "Reports",       route: "/Report",                  icon: <FiBarChart2 size={16} /> },
    { label: "Refund",        route: "/refunds",                 icon: <FiRotateCcw size={16} /> },
    { label: "Void",          route: "/voids",                   icon: <TicketSlash size={16} /> },
    { label: "Inventory",     route: "/inventory",               icon: <FiArchive size={16} /> },
    { label: "EOD",           route: "/eod",                     icon: <FiClock size={16} /> },
  ];

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden select-none" style={{ background: "#F0EFEF", fontFamily: "Poppins" }}>
      <main className="flex flex-col h-screen w-screen overflow-hidden relative transition-all duration-300">
        {/* ── TOP NAVBAR ── */}
        <div className="flex items-center px-6 gap-3 relative z-50 flex-shrink-0" style={{ height: 70, ...glass.panel, borderBottom: "1px solid rgba(255,255,255,0.35)", borderRadius: 0 }}>

          {pathname === '/settings' ? (
            <>
              <div className="flex flex-col leading-none mr-2">
                <span style={{ fontSize: 20, fontWeight: 900, color: "#f97316", fontFamily: "Poppins" }}>DUNKIN&apos;</span>
                <span style={{ fontSize: 7, fontWeight: 700, color: "#f97316", letterSpacing: 1 }}>PASALUBONG NG BAYAN</span>
              </div>
              <div className="flex items-center gap-2 ml-4">
                <button
                  onClick={() => !isManagerBypass && router.push("/dashboard")}
                  disabled={isManagerBypass}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1 transition-all ${isManagerBypass ? 'opacity-50 cursor-not-allowed' : 'hover:brightness-95 active:scale-95'}`}
                  style={{ fontFamily: "Poppins", textTransform: "uppercase", background: "rgba(255,255,255,0.2)", color: "#555", border: "1px solid rgba(255,255,255,0.3)", backdropFilter: "blur(6px)" }}>
                  <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: 16, height: 16 }}>
                    <FiHome size={14} color="#000" />
                  </span>
                  Home
                </button>
                <span style={{ color: "#bbb", fontSize: 14 }}>›</span>
                <span className="px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1"
                  style={{ fontFamily: "Poppins", textTransform: "uppercase", background: "rgba(249,115,22,0.15)", color: "#f97316", border: "1px solid rgba(249,115,22,0.4)" }}>
                  <span style={{ display: "flex", alignItems: "center", justifyContent: "center", width: 16, height: 16 }}>
                    <FiSettings size={14} color="#f97316" />
                  </span>
                  Settings
                </span>
              </div>
              <div className="ml-auto" />
            </>
          ) : (
            <>
              <img src="/images/logo.svg" alt="Dunkin' Pasalubong" style={{ height: 50, objectFit: "contain", marginRight: 8 }} />
              <div className="ml-auto flex items-center gap-3">
                {!isManagerBypass && (
                  <div
                    className={`transition-all duration-300 ease-in-out flex overflow-hidden ${
                      pathname === '/dashboard' 
                        ? 'max-w-[150px] opacity-100' 
                        : 'max-w-0 opacity-0 pointer-events-none'
                    }`}
                  >
                    <button
                      onClick={() => window.dispatchEvent(new Event('trigger-enclose'))}
                      className="flex items-center whitespace-nowrap gap-1 px-3 py-1.5 rounded-full text-xs font-semibold hover:brightness-95 active:scale-95"
                      style={{
                        textTransform: "uppercase",
                        background: "rgba(255,255,255,0.2)",
                        color: "#555",
                        border: "1px solid rgba(255,255,255,0.3)",
                        backdropFilter: "blur(6px)"
                      }}>
                      <FiDownload size={16} /> Paid In
                    </button>
                  </div>
                )}
                {navItems.map((item) => {
                  if(!isManagerBypass && item.label === "Reports") return null; // Hide Reports button for manager bypass
                  const isActive = pathname === item.route;
                  const isHomeDisabled = isManagerBypass && item.label === "Home";
                  return (
                    <button key={item.label} onMouseEnter={() => router.prefetch(item.route)} onClick={() => !isHomeDisabled && router.push(item.route)}
                      disabled={isHomeDisabled}
                      className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${isHomeDisabled ? 'opacity-40 cursor-not-allowed grayscale' : 'hover:brightness-95 active:scale-95'}`}
                      style={{
                        textTransform: "uppercase",
                        background: isActive ? "rgba(249,115,22,0.15)" : "rgba(255,255,255,0.2)",
                        color: isActive ? "#f97316" : "#555",
                        border: isActive ? "1px solid rgba(249,115,22,0.4)" : "1px solid rgba(255,255,255,0.3)",
                        backdropFilter: "blur(6px)"
                      }}>
                      {item.icon}{item.label}
                    </button>
                  );
                })}
              </div>
            </>
          )}

          {/* Right — time & avatar */}
          <div className="flex items-center gap-3 ml-2">
            <span className="px-3 py-1.5 rounded-full text-xs font-semibold tracking-wide" style={{ background: "rgba(255,255,255,0.3)", backdropFilter: "blur(8px)", border: "1px solid rgba(255,255,255,0.5)", color: "#444" }}>
              {businessDate} {/* {timeStr} &nbsp; {dateStr} */}
            </span>

            <div className="relative">
              <button onClick={() => setShowSessionMenu(!showSessionMenu)} className="w-10 h-10 rounded-full overflow-hidden block focus:outline-none transition-transform active:scale-95" style={{ border: "2px solid rgba(249,115,22,0.7)", boxShadow: "0 0 0 2px rgba(255,255,255,0.5)" }}>
                <Avatar src={staffAvatar} alt={staffName} className="w-full h-full object-cover" />
              </button>

              {showSessionMenu && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setShowSessionMenu(false)} />
                  <div className="absolute right-0 mt-3 w-72 rounded-3xl p-5 z-50 flex flex-col gap-3" style={glass.modal}>
                    <div className="flex items-center gap-3 mb-2 border-b border-gray-200 pb-3">
                      <div className="w-12 h-12 rounded-full overflow-hidden shrink-0" style={{ border: "2px solid #f97316" }}>
                        <Avatar src={staffAvatar} alt={staffName} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-gray-900 leading-tight truncate">{staffName || "Cashier Name"}</p>
                        <p className="text-xs text-gray-500 mb-1">ID: {staffId || "Unknown"}</p>
                      </div>
                    </div>

                    {hasActiveSession && sessionDetails ? (
                      <div className="flex flex-col gap-2">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Current Session</p>
                        <div className="bg-orange-50 rounded-xl p-3 border border-orange-100">
                          <p className="text-xs text-orange-800 mb-1">Shift No: <strong>{sessionDetails.shiftNo}</strong></p>
                          <p className="text-xs text-orange-800 mb-1">Opened: <strong>{businessDate}</strong> <strong>{new Date(sessionDetails.time).toLocaleTimeString()}</strong></p>
                          <p className="text-xs text-orange-800">Starting Cash: <strong>{formatMoney(parseFloat(sessionDetails.cash))}</strong></p>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col gap-2">
                        <p className="text-[10px] font-bold text-red-400 uppercase tracking-widest">{isManagerBypass && (accountRole === 2) ? "Manager Bypass Active" : accountRole === 1 ? "Accounting Bypass Active" : "No Active Session"}</p>
                        {!isManagerBypass && (
                          <button onClick={() => { setShowSessionMenu(false); router.push('/dashboard'); }} className="w-full py-2.5 mt-1 rounded-xl text-sm font-bold text-white transition-all" style={{ background: "#111827" }}>
                            Open Register
                          </button>
                        )}
                      </div>
                    )}

                    <div className="border-t border-gray-100 pt-3 mt-1 flex flex-col gap-2">
                      <button onClick={() => { setShowSessionMenu(false); setIsLocked(true); localStorage.setItem("pos_locked", "true"); }} className="w-full py-2.5 rounded-xl text-sm font-bold transition-all hover:bg-gray-100 active:scale-95 border border-gray-200 text-gray-700">
                        Lock Screen
                      </button>
                      {!isManagerBypass && (
                        <button onClick={() => { 
                          setShowSessionMenu(false); 
                          if (isEnclosedMode) {
                            localStorage.removeItem('enclosedMode');
                          }
                          router.push('/eod?mode=turnover'); 
                        }} className="w-full py-2.5 rounded-xl text-sm font-bold transition-all hover:bg-orange-50 active:scale-95 border border-orange-200 text-orange-600">
                          {isEnclosedMode ? "Exit Enclosed Mode" : "Cashier Turnover"}
                        </button>
                      ) }
                      <button onClick={() => { setShowSessionMenu(false); handleSignOut(); }} className="w-full py-2.5 rounded-xl text-sm font-bold transition-all hover:bg-red-50 active:scale-95 border border-red-200 text-red-600 mt-1">
                        Sign Out
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {children}
      </main>

      {/* ── GLOBAL OVERLAYS ── */}
      <SessionGuardOverlay visible={sessionBlocked} />

      <LockScreenOverlay
        isLocked={isLocked}
        onUnlock={() => { setIsLocked(false); localStorage.setItem("pos_locked", "false"); }}
        currentStaffId={staffId}
        staffName={staffName}
        staffAvatar={staffAvatar}
      />

      <div className="z-[9999999]">
        <Toaster position="top-center" />
      </div>
    </div>
  );
}