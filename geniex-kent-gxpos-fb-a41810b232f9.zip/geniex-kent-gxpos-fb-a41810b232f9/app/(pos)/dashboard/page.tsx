/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { FiLock, FiDownload, FiAlertTriangle, FiX, FiUser, FiMessageSquare } from 'react-icons/fi';
import { getAssociateByPin } from '../../../src/api/associates';
import { getNextOrderNumber } from '../../../src/api/transactionNumbers';
import { getMenuFromCache } from '../../../src/api/menu';
import { loadCartFromDatabase, saveCartToDatabase, clearCartFromDatabase } from '../../../src/api/cart';
import { getDiscountsFromCache, refreshDiscountsFromAPI, type SimpleDiscount } from '../../../src/api/discounts';
import { getCounters, formatTransactionPayload, saveTransaction } from '../../../src/api/transactions';
import { getCachedVoidReasons } from '../../../src/api/void-reason';
import { sileo, Toaster } from 'sileo';
import { KeyboardInput } from '../../components/KeyboardInput';
import { DonutPlaceholder, ProductCard, formatMoney } from "@/app/components/pos/ProductCard";
import OpenRegisterModal from "@/app/components/pos/OpenRegister";
import { glass } from "@/app/components/pos/constants";

// IMPORT PRINTER CONTEXT
import { usePrinter } from "@/app/context/PrinterContext"; 
import { Unlock, Lock, HelpCircle, AlertCircle, Utensils, ShoppingBag } from "lucide-react";
import { DiscountModal } from "@/app/components/pos/POSModals";
import { ImWarning } from "react-icons/im";// adjust path to wherever you keep it
import { resolveMenuImageUrl } from "@/src/utils/menuImages";
import { useConnection } from "@/app/context/ConnectionContext";
import { useSyncContext } from "@/app/context/SyncContext";
import { PinModal as ManagerPinModal } from "@/app/components/pos/PinModal";
import { getWorkstationId } from "@/src/lib/workstation";
import { logEJournalEntry } from '@/src/lib/ejournal-client';
import placeholder from '@/public/images/placeholder.png'




type DiscountType = number | "SR_PWD" | "SC" | "PWD_DISC" | "VIP" | "ATHLETE" | null;

const DISCOUNT_OPTIONS = [
  { id: "SR_PWD" as DiscountType, label: "SR / PWD", sublabel: "Senior Citizen & Person with Disability", icon: "♿", rate: 0.20, color: "#2563eb", bg: "rgba(37,99,235,0.07)", border: "rgba(37,99,235,0.20)", activeBg: "rgba(37,99,235,0.12)", activeBorder: "#2563eb" },
  { id: "ATHLETE" as DiscountType, label: "NAAC", sublabel: "NAAC Athlete", icon: "🏅", rate: 0.20, color: "#dc2626", bg: "rgba(220,38,38,0.07)", border: "rgba(220,38,38,0.20)", activeBg: "rgba(220,38,38,0.12)", activeBorder: "#dc2626" },
  { id: "VIP" as DiscountType, label: "VIP", sublabel: "VIP Member Discount", icon: "⭐", rate: 0.20, color: "#f97316", bg: "rgba(249,115,22,0.07)", border: "rgba(249,115,22,0.20)", activeBg: "rgba(249,115,22,0.12)", activeBorder: "#f97316" },
];

type TransactionType = "REGULAR" | "SR" | "PWD" | "ATHLETE" | "VIP" | "DIPLOMAT" | "PEZA" | "SOLO" | "MEDAL" | "CUSTOM";

const DIPLOMAT_FLOW_TYPES: TransactionType[] = ["DIPLOMAT", "ATHLETE", "PEZA", "SOLO", "MEDAL", "CUSTOM"];
const isSRPWD = (type: TransactionType | null | undefined): boolean =>
  type === 'SR' || type === 'PWD';

// ─── SR/PWD multi-customer helpers ──────────────────────────────────────────

/** Parse the CustomerInfo object into a flat CustomerEntry array */
const parseSrpwdCustomers = (info: CustomerInfo | null): CustomerEntry[] => {
  if (!info) return [];
  try {
    const parsed = JSON.parse(info.address || '');
    if (Array.isArray(parsed) && parsed.length > 0) return parsed;
  } catch {}
  if (info.name || info.idNum)
    return [{ name: info.name || '', idNum: info.idNum || '', tin: info.tin || '', address: '' }];
  return [];
};

const isComboItem = (c: any): boolean => {
  const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
  return mods.some((m: any) => String(m.id || '').startsWith('MD-'));
};

const isLiquidName = (name: string): boolean => {
  if (!name) return false;
  const n = name.toLowerCase();
  // Filter out items that contain coffee/choco flavors but are actually solid food or bundles
  if (/\b(creme|kreme|roll|donut|doughnut|marble|glazed|bavarian|munchkin|sprinkle|filled|sundae|bun|box|bundle|premium|classic|savory|meal)\b/i.test(n)) {
    return false;
  }
  return /\b(coffee|latte|cappuccino|cappuc|macchiato|espresso|brew|mocha|americano|matcha|tea|refresh|soda|juice|drink|water|beverage|coke|sprite|royal|pepsi|coolatta|drip)/i.test(n);
};

const isLiquidItem = (c: any): boolean => {
  if (isComboItem(c)) return false;
  const mgs = c.modifierGroups || [];
  const allCLOrAD = mgs.length > 0 && mgs.every((mg: any) =>
    (mg.modifiers || []).every((m: any) => {
      const idStr = String(m.id || '');
      return idStr.startsWith('CL-') || idStr.startsWith('AD-');
    })
  );
  if (allCLOrAD) return true;
  return isLiquidName(c.name || '');
};

const isComboWithLiquid = (c: any): boolean => {
  if (!isComboItem(c)) return false;
  if (isLiquidName(c.name || '')) return true;
  const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
  return mods.some((m: any) => isLiquidName(m.name || ''));
};

const getUnitValue = (c: any): number => {
  const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
  const modsPrice = mods.reduce((s: number, m: any) => s + ((m.price || 0) * (m.qty || 1)) / 100, 0);
  let unitValue = c.price + modsPrice;
  if (isComboItem(c) && c.modifierGroups?.length > 0 && c.udfs?.['UDF-1']?.value) {
    const udfVal = Number(c.udfs['UDF-1'].value);
    if (!isNaN(udfVal)) unitValue = udfVal;
  }
  return unitValue;
};

/**
 * SC/PWD-specific auto-selection logic.
 *
 * Priority per slot:
 *   1. Combo meal (MD modifiers) — highest value first
 *   2. If no combo available for this slot: 1 solid + 1 liquid pair (highest value each)
 *      - If only one of the two exists, pick just that one
 *
 * For N > 1 customers, repeat the above N times without re-using already-selected indices.
 */
const autoSelectSrpwdItemKeys = (cart: any[], N: number): string[] => {
  const selected = new Set<string>();
  const usedIdx  = new Set<number>();

  const pickBestAvailable = (
    candidates: { idx: number; unitValue: number }[]
  ): number | null => {
    const sorted = candidates
      .filter(c => !usedIdx.has(c.idx))
      .sort((a, b) => b.unitValue - a.unitValue);
    return sorted.length > 0 ? sorted[0].idx : null;
  };

  const fullComboIndices = cart
    .map((c, idx) => ({ idx, unitValue: getUnitValue(c) }))
    .filter(({ idx }) => isComboItem(cart[idx]) && isComboWithLiquid(cart[idx]));

  const solidBundleIndices = cart
    .map((c, idx) => ({ idx, unitValue: getUnitValue(c) }))
    .filter(({ idx }) => isComboItem(cart[idx]) && !isComboWithLiquid(cart[idx]));

  const alaCarteSolidIndices = cart
    .map((c, idx) => ({ idx, unitValue: getUnitValue(c) }))
    .filter(({ idx }) => !isComboItem(cart[idx]) && !isLiquidItem(cart[idx]));

  const liquidIndices = cart
    .map((c, idx) => ({ idx, unitValue: getUnitValue(c) }))
    .filter(({ idx }) => !isComboItem(cart[idx]) && isLiquidItem(cart[idx]));

  for (let slot = 0; slot < N; slot++) {
    const fullComboIdx = pickBestAvailable(fullComboIndices);
    if (fullComboIdx !== null) {
      selected.add(`item-${fullComboIdx}`);
      usedIdx.add(fullComboIdx);
      continue;
    }

    const solidBundleIdx = pickBestAvailable(solidBundleIndices);
    if (solidBundleIdx !== null) {
      selected.add(`item-${solidBundleIdx}`);
      usedIdx.add(solidBundleIdx);
      
      const liquidIdx = pickBestAvailable(liquidIndices);
      if (liquidIdx !== null) {
        selected.add(`item-${liquidIdx}`);
        usedIdx.add(liquidIdx);
      }
      continue;
    }

    const solidIdx  = pickBestAvailable(alaCarteSolidIndices);
    const liquidIdx = pickBestAvailable(liquidIndices);

    if (solidIdx !== null) {
      selected.add(`item-${solidIdx}`);
      usedIdx.add(solidIdx);
    }
    if (liquidIdx !== null) {
      selected.add(`item-${liquidIdx}`);
      usedIdx.add(liquidIdx);
    }
  }

  return [...selected];
};
// ────────────────────────────────────────────────────────────────────────────


const TRANSACTION_TYPES = [
  { id: "SR"  as TransactionType, label: "SC (Senior Citizen)", sublabel: "Senior Citizen (SC) Discount (20%)", icon: "👴", autoDiscount: "SC",       color: "#2563eb", bg: "rgba(37,99,235,0.07)",   border: "rgba(37,99,235,0.20)",   activeBg: "rgba(37,99,235,0.12)",   activeBorder: "#2563eb" },
{ id: "PWD" as TransactionType, label: "PWD",                 sublabel: "Person with Disability (20%)",       icon: "♿", autoDiscount: "PWD_DISC", color: "#7c3aed", bg: "rgba(124,58,237,0.07)", border: "rgba(124,58,237,0.20)", activeBg: "rgba(124,58,237,0.12)", activeBorder: "#7c3aed" },
  { id: "ATHLETE" as TransactionType, label: "NAAC", sublabel: "NAAC Athlete (20% Discount)",       icon: "🏅", autoDiscount: "ATHLETE",          color: "#dc2626", bg: "rgba(220,38,38,0.07)",  border: "rgba(220,38,38,0.20)",  activeBg: "rgba(220,38,38,0.12)",  activeBorder: "#dc2626" },
  { id: "DIPLOMAT" as TransactionType, label: "Diplomat",      sublabel: "VAT Exemption (Zero Rated)",              icon: "🏛️", autoDiscount: "VAT_EXEMPT_ONLY", color: "#8b5cf6", bg: "rgba(139,92,246,0.07)", border: "rgba(139,92,246,0.20)", activeBg: "rgba(139,92,246,0.12)", activeBorder: "#8b5cf6" },
  { id: "PEZA"     as TransactionType, label: "PEZA Zone",     sublabel: "VAT Exemption (No VAT)",                  icon: "🏢", autoDiscount: "VAT_EXEMPT_ONLY", color: "#0ea5e9", bg: "rgba(14,165,233,0.07)",  border: "rgba(14,165,233,0.20)",  activeBg: "rgba(14,165,233,0.12)",  activeBorder: "#0ea5e9" },
    { id: "SOLO"     as TransactionType, label: "Solo Parent",   sublabel: "Solo Parent Discount (20%)",              icon: "👨‍👦", autoDiscount: "SOLO_PARENT",     color: "#16a34a", bg: "rgba(22,163,74,0.07)",  border: "rgba(22,163,74,0.20)",  activeBg: "rgba(22,163,74,0.12)",  activeBorder: "#16a34a" },
  { id: "MEDAL"    as TransactionType, label: "Medal of Valor",sublabel: "Medal of Valor Discount (20%)",           icon: "🎖️", autoDiscount: "MEDAL_HONOR",     color: "#b45309", bg: "rgba(180,83,9,0.07)",   border: "rgba(180,83,9,0.20)",   activeBg: "rgba(180,83,9,0.12)",   activeBorder: "#b45309" },
  { id: "CUSTOM"   as TransactionType, label: "Custom",        sublabel: "Custom Discount (No Limit)",              icon: "✏️", autoDiscount: "CUSTOM_DISC",     color: "#0891b2", bg: "rgba(8,145,178,0.07)",  border: "rgba(8,145,178,0.20)",  activeBg: "rgba(8,145,178,0.12)",  activeBorder: "#0891b2" },
];

export interface CustomerInfo {
  name: string;
  idNum: string;
  tin?: string;
  address?: string;
}

const getInventoryId = (modOrItem: any) => {
  if (!modOrItem) return "";
  if (modOrItem.itemCode) {
    return `IT-${modOrItem.itemCode}`;
  }
  if (modOrItem.id && (String(modOrItem.id).startsWith('MD-') || String(modOrItem.id).startsWith('AD-'))) {
    return `IT-${modOrItem.id.split('|')[1]}`;
  }

  return modOrItem.id;
};

const hasOnlyCLModifiers = (item: any): boolean => {
  if (!item.modifierGroups || item.modifierGroups.length === 0) return false;
  return item.modifierGroups.every((mg: any) =>
    (mg.modifiers || []).every((mod: any) => String(mod.id || '').startsWith('CL-'))
  );
};

const isComboGroup = (group: any): boolean =>
  (group.modifiers || []).some((mod: any) => String(mod.id || '').startsWith('MD-'));

const calculateItemStock = (item: any, inventoryState: Record<string, number>) => {
  
  const groups = item.modifierGroups || [];
  const comboGroups = groups.filter(isComboGroup);

  // No modifier groups, or none of them are MD- combo groups (just CL- sizes
  // and/or AD- addons) → the item tracks its own stock.
  if (comboGroups.length === 0) {
    return inventoryState[getInventoryId(item)] ?? 0;
  }

  // Real combo/bundle — stock comes from what's available in each required MD- group.
  let minComboStock = Infinity;
  for (const group of comboGroups) {
    if (!group.isRequired) continue;
    let totalGroupStock = 0;
    for (const mod of group.modifiers || []) {
      totalGroupStock += (inventoryState[getInventoryId(mod)] ?? 0);
    }
    const required = group.selectionRangeMin || 1;
    if (totalGroupStock < required) return 0;
    minComboStock = Math.min(minComboStock, Math.floor(totalGroupStock / required));
  }

  return minComboStock === Infinity ? 999 : minComboStock;
};

function ShiftDateMismatchModal({ businessDate, onClose }: { businessDate: string, onClose: () => void }) {
  const todayDate = new Date();
  const todayFormatted = todayDate.toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase();
  const systemDateStr = todayDate.toISOString().split('T')[0];

  let businessDateFormatted = "";
  let isFuture = false;

  if (businessDate) {
    const [year, month, day] = businessDate.split('-').map(Number);
    const bDate = new Date(year, month - 1, day);
    businessDateFormatted = bDate.toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase();
    
    // Compare dates (YYYY-MM-DD strings sort alphabetically)
    isFuture = businessDate > systemDateStr;
  }

  return (
    <div className="fixed inset-0 flex items-center justify-center z-[9999] animate-fade-in" style={{ background: "rgba(15, 23, 42, 0.8)", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)" }}>
      <div className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden flex flex-col p-8 animate-scale-in shadow-2xl" style={{ background: "#ffffff" }}>
        <div className="w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto" style={{ background: "rgba(239, 68, 68, 0.1)", color: "#ef4444" }}>
          <FiAlertTriangle size={32} />
        </div>
        <h2 className="text-2xl font-black text-gray-900 mb-2 text-center font-poppins">Shift Date Mismatch</h2>
        <p className="text-sm text-gray-500 font-medium mb-6 text-center leading-relaxed">
          You are resuming a shift from a <strong>{isFuture ? "future" : "previous"}</strong> business date (<strong>{businessDateFormatted || businessDate}</strong>).<br /><br />
          Today is <strong>{todayFormatted}</strong>.<br /><br />
          Please finalize your current transactions and close this shift so you can open a new one matching the correct date.
        </p>
        <button onClick={onClose} className="w-full py-3.5 rounded-xl font-bold text-white transition-colors shadow-md bg-red-500 hover:bg-red-600" style={{ fontFamily: "Poppins" }}>
          Understood
        </button>
      </div>
    </div>
  );
}

function DrawerOpenWarningModal() {
  return (
    <div className="fixed inset-0 flex items-center justify-center z-[9999] animate-fade-in" style={{ background: "rgba(15, 23, 42, 0.8)", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)" }}>
      <div className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden flex flex-col p-8 animate-scale-in shadow-2xl" style={{ background: "#ffffff" }}>
        <div className="w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto" style={{ background: "rgba(239, 68, 68, 0.1)", color: "#ef4444" }}>
          <FiAlertTriangle size={32} />
        </div>
        <h2 className="text-2xl font-black text-gray-900 mb-2 text-center font-poppins">Cash Drawer Open</h2>
        <p className="text-sm text-gray-500 font-medium mb-8 text-center leading-relaxed">
          The cash drawer is currently open. You cannot process transactions until it is securely closed.
        </p>
        <div className="w-full py-4 rounded-xl font-bold text-center text-red-500 bg-red-50 border border-red-100 animate-pulse" style={{ fontFamily: "Poppins" }}>
          Awaiting drawer closure...
        </div>
      </div>
    </div>
  );
}

function CashLimitWarningModal({ currentCash, onUnderstood, onDropCash }: { currentCash: number, onUnderstood: () => void, onDropCash: () => void }) {
  return (
    <div className="fixed inset-0 flex items-center justify-center z-[250] animate-fade-in" style={{ background: "rgba(15, 23, 42, 0.8)", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)" }}>
      <div className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden flex flex-col p-8 animate-scale-in shadow-2xl" style={{ background: "#ffffff" }}>
        <div className="w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto" style={{ background: "rgba(234, 179, 8, 0.1)", color: "#ca8a04" }}>
          <FiAlertTriangle size={32} />
        </div>
        <h2 className="text-2xl font-black text-gray-900 mb-2 text-center font-poppins">Nearing Cash Limit</h2>
        <p className="text-sm text-gray-500 font-medium mb-8 text-center leading-relaxed">
          Your drawer cash is nearing your maximum limit. Please perform a partial deposit (cash drop) soon to secure the funds.
        </p>
        <div className="flex gap-3">
          <button onClick={onUnderstood} className="flex-1 py-3 rounded-xl font-bold text-gray-700 bg-gray-100 hover:bg-gray-200 transition-colors shadow-sm">Skip</button>
          <button onClick={onDropCash} className="flex-1 py-3 rounded-xl font-bold text-white transition-colors shadow-md" style={{ background: "#f97316" }}>Drop Cash</button>
        </div>
      </div>
    </div>
  );
}

function CashDropModal({ currentCash, onConfirm, onClose, isForced }: { currentCash: number; onConfirm: (amount: number, breakdown: Record<number, number>) => void; onClose: () => void; isForced: boolean; }) {
  const [denominations, setDenominations] = useState<Record<number, number>>({
    1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0
  });

  const dropTotal = Object.entries(denominations).reduce((sum, [val, count]) => sum + parseFloat(val) * count, 0);

  const handleTap = (value: number) => {
    setDenominations(prev => {
      const next = (prev[value] || 0) + 1;
      const testTotal = Object.entries(prev).reduce((s, [v, c]) => s + parseFloat(v) * c, 0) + value;
      if (testTotal > currentCash) {
        sileo.error({ title: "Exceeds Drawer Cash", description: `Drop amount exceeds current drawer cash.`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
        return prev;
      }
      return { ...prev, [value]: next };
    });
  };

  const handleRemove = (value: number) => {
    setDenominations(prev => ({ ...prev, [value]: Math.max(0, (prev[value] || 0) - 1) }));
  };

  const clearAll = () => setDenominations({ 1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0 });

  const getBillColor = (val: number) => {
    switch (val) {
      case 1000: return { border: "rgba(59,130,246,0.4)", text: "#2563eb", bg: "rgba(59,130,246,0.07)" };
      case 500:  return { border: "rgba(234,179,8,0.4)",  text: "#ca8a04", bg: "rgba(234,179,8,0.07)" };
      case 200:  return { border: "rgba(34,197,94,0.4)",  text: "#16a34a", bg: "rgba(34,197,94,0.07)" };
      case 100:  return { border: "rgba(168,85,247,0.4)", text: "#9333ea", bg: "rgba(168,85,247,0.07)" };
      case 50:   return { border: "rgba(239,68,68,0.4)",  text: "#dc2626", bg: "rgba(239,68,68,0.07)" };
      default:   return { border: "rgba(148,163,184,0.5)", text: "#475569", bg: "rgba(148,163,184,0.07)" };
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center z-[200] animate-fade-in" style={{ background: "rgba(15,23,42,0.8)", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)" }}>
      <div className="rounded-3xl w-full max-w-2xl mx-4 relative overflow-hidden animate-scale-in shadow-2xl" style={{ background: "#ffffff" }}>
        <div className="px-8 py-6 border-b border-gray-100 flex items-center justify-between bg-gray-50">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center" style={{ background: "rgba(249,115,22,0.1)", color: "#f97316" }}>
              <FiDownload size={28} />
            </div>
            <div>
              <h2 className="text-2xl font-black text-gray-900" style={{ fontFamily: "Poppins" }}>Cash Drop</h2>
              <p className="text-sm text-gray-500 font-medium" style={{ fontFamily: "Poppins" }}>
                {isForced ? "Drawer limit reached — drop cash before continuing." : "Tap bills and coins to count the drop amount."}
              </p>
            </div>
          </div>
          {!isForced && (
            <button onClick={onClose} className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg hover:bg-gray-200 transition-colors" style={{ color: "#666" }}>✕</button>
          )}
        </div>
        <div className="p-8 bg-gray-50">
          <div className="rounded-2xl bg-white border border-gray-200 overflow-hidden shadow-sm mb-6">
            <div className="p-4 flex justify-between items-center bg-orange-50">
              <span className="text-xs font-bold text-[#F5821F] uppercase tracking-widest" style={{ fontFamily: "Poppins" }}>Drop Amount</span>
              <span className="text-xl font-black text-[#F5821F]" style={{ fontFamily: "Poppins" }}>{formatMoney(dropTotal)}</span>
            </div>
          </div>
          <h4 className="text-[10px] font-bold text-gray-400 tracking-widest uppercase mb-3" style={{ fontFamily: "Poppins" }}>Paper Bills</h4>
          <div className="grid grid-cols-5 gap-3 mb-4">
            {[1000, 500, 200, 100, 50].map(val => {
              const colors = getBillColor(val);
              const count = denominations[val] || 0;
              return (
                <div key={val} className="flex flex-col gap-1">
                  <button onClick={() => handleTap(val)} className="relative h-16 rounded-2xl flex items-center justify-center font-black text-base transition-all active:scale-95 bg-white shadow-sm hover:shadow-md"
                    style={{ border: `2px solid ${colors.border}`, color: colors.text, fontFamily: "Poppins", background: count > 0 ? colors.bg : "white" }}>
                    {val}
                    {count > 0 && <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-gray-900 text-white text-[10px] flex items-center justify-center border-2 border-white shadow-sm">{count}</span>}
                  </button>
                  {count > 0 && (
                    <button onClick={() => handleRemove(val)} className="text-[10px] font-bold text-red-400 hover:text-red-600 text-center transition-colors" style={{ fontFamily: "Poppins" }}>− remove</button>
                  )}
                </div>
              );
            })}
          </div>
          <h4 className="text-[10px] font-bold text-gray-400 tracking-widest uppercase mb-3" style={{ fontFamily: "Poppins" }}>Coins</h4>
          <div className="flex gap-3 flex-wrap mb-6">
            {[20, 10, 5, 1, 0.25].map(val => {
              const colors = getBillColor(val);
              const count = denominations[val] || 0;
              return (
                <div key={val} className="flex flex-col items-center gap-1">
                  <button onClick={() => handleTap(val)} className="relative w-14 h-14 rounded-full flex items-center justify-center font-bold text-xs transition-all active:scale-95 bg-white shadow-sm hover:shadow-md"
                    style={{ border: `2px solid ${colors.border}`, color: colors.text, fontFamily: "Poppins", background: count > 0 ? colors.bg : "white" }}>
                    {val}
                    {count > 0 && <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-gray-900 text-white text-[9px] flex items-center justify-center border-2 border-white">{count}</span>}
                  </button>
                  {count > 0 && (
                    <button onClick={() => handleRemove(val)} className="text-[9px] font-bold text-red-400 hover:text-red-600 transition-colors" style={{ fontFamily: "Poppins" }}>−</button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
        <div className="px-8 py-5 border-t border-gray-100 flex items-center justify-between bg-white">
          <button onClick={clearAll} className="px-5 py-2.5 rounded-xl bg-gray-100 text-gray-500 font-bold text-sm hover:bg-gray-200 transition-colors" style={{ fontFamily: "Poppins" }}>
            Clear All
          </button>
          <button
            onClick={() => onConfirm(dropTotal, denominations)}
            disabled={dropTotal <= 0}
            className="px-8 py-3 rounded-xl font-bold text-white disabled:opacity-50 disabled:cursor-not-allowed transition-all hover:brightness-110 active:scale-95 shadow-md"
            style={{ background: "#111827", fontFamily: "Poppins" }}
          >
            Confirm Drop {formatMoney(dropTotal)} →
          </button>
        </div>
      </div>
    </div>
  );
}

function VoidReasonModal({ reasons, selectedReason, onChangeReason, onConfirm, onClose }: { reasons: any[]; selectedReason: string; onChangeReason: (val: string) => void; onConfirm: () => void; onClose: () => void; }) {
  return (
     <div className="fixed inset-0 flex items-center justify-center z-[250] animate-fade-in" style={{ background: "rgba(15, 23, 42, 0.8)", backdropFilter: "blur(12px)" }}>
       <div className="rounded-3xl w-full max-w-md mx-4 relative bg-white shadow-2xl p-7 animate-scale-in">
         <button onClick={onClose} className="absolute top-7 right-7 text-gray-400 hover:text-gray-700 transition-colors"><FiX size={24} /></button>
         <div className="flex items-center gap-4 mb-4">
           <div className="w-12 h-12 rounded-2xl flex items-center justify-center bg-red-100 text-red-600 shadow-inner">
             <FiAlertTriangle size={24} />
           </div>
           <div>
            <h2 className="text-xl font-bold font-poppins text-gray-900 leading-tight">Void Items</h2>
            <p className="text-xs text-gray-500 font-medium">Select a reason to proceed.</p>
           </div>
         </div>
         <div className="mb-6">
           <select 
              value={selectedReason} 
              onChange={(e) => onChangeReason(e.target.value)} 
              className="w-full p-4 border border-gray-300 rounded-xl outline-none focus:border-red-500 bg-gray-50 text-gray-800 font-poppins text-sm cursor-pointer shadow-sm"
            >
              <option value="" disabled>-- Choose void reason --</option>
              {reasons.map((r, i) => {
                const val = r.reason || r.name || (typeof r === 'string' ? r : JSON.stringify(r));
                return <option key={i} value={val}>{val}</option>;
              })}
           </select>
         </div>
         <div className="flex gap-3">
           <button onClick={onClose} className="flex-1 py-3.5 rounded-xl font-bold bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors">Cancel</button>
           <button onClick={onConfirm} disabled={!selectedReason} className="flex-1 py-3.5 rounded-xl font-bold text-white bg-red-600 hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-md">Continue to PIN →</button>
         </div>
       </div>
     </div>
  );
}

function DiplomatPromptModal({ transactionType, onClose, onNext, initialData }: { transactionType: TransactionType; onClose: () => void, onNext: (data: CustomerInfo) => void, initialData?: CustomerInfo | null }) {
  useEffect(() => {
    if (transactionType === 'PEZA') {
      onNext({ name: '', idNum: '', tin: '', address: '' });
    }
  }, [transactionType, onNext]);

  if (transactionType === 'PEZA') {
    return null;
  }

  const [name, setName] = useState(initialData?.name || '');
  const [idNum, setIdNum] = useState(initialData?.idNum || '');

  

  const typeConfig = TRANSACTION_TYPES.find(t => t.id === transactionType);
  const accentColor = typeConfig?.color || "#8b5cf6";
  const stripBg = `linear-gradient(90deg, ${accentColor} 0%, ${accentColor}cc 100%)`;

  const labelMap: Record<string, { title: string; namePlaceholder: string; idPlaceholder: string }> = {
    DIPLOMAT: { title: "Diplomat Exemption",   namePlaceholder: "Enter Diplomat Full Name", idPlaceholder: "Enter Diplomat ID Number" },
    ATHLETE:  { title: "Athlete Discount",     namePlaceholder: "Enter Athlete Full Name",  idPlaceholder: "Enter Athlete ID / Reg. Number" },
    PEZA:     { title: "PEZA Zone Exemption",  namePlaceholder: "Enter Customer Full Name", idPlaceholder: "Enter PEZA ID / Company Number" },
    SOLO:     { title: "Solo Parent Discount", namePlaceholder: "Enter Customer Full Name", idPlaceholder: "Enter Solo Parent ID Number" },
    MEDAL:    { title: "Medal of Valor",       namePlaceholder: "Enter Awardee Full Name",  idPlaceholder: "Enter Medal / ID Number" },
    SRPWD:    { title: "Senior / PWD Discount", namePlaceholder: "Enter Customer Full Name",  idPlaceholder: "Enter Senior / PWD ID Number" },
    SR:     { title: "Senior Citizen Discount",  namePlaceholder: "Enter Customer Full Name",  idPlaceholder: "Enter Senior Citizen ID Number" },
    PWD:    { title: "PWD Discount",             namePlaceholder: "Enter Customer Full Name",  idPlaceholder: "Enter PWD ID Number" },


  };
  const labels = labelMap[transactionType] || labelMap.DIPLOMAT;

  const isFormValid = name.trim() !== '' && idNum.trim() !== '';

  return (
    <div className="fixed inset-0 flex items-center justify-center z-[150] animate-fade-in" style={{ background: "rgba(160,150,145,0.30)", backdropFilter: "blur(14px)" }} onClick={onClose}>
      <div className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden animate-scale-in bg-white shadow-2xl" onClick={e => e.stopPropagation()}>
        <div style={{ height: 5, background: stripBg }} />
        <div className="p-7">
          <button onClick={onClose} className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-gray-400 hover:bg-gray-100 transition-colors">✕</button>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-sm" style={{ background: `${accentColor}18`, border: `1px solid ${accentColor}30` }}>
              {typeConfig?.icon || "👤"}
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest mb-0.5" style={{ fontFamily: "Poppins", color: accentColor }}>
                {labels.title}
              </p>
              <h2 className="text-lg font-black text-gray-900 leading-none" style={{ fontFamily: "Poppins" }}>Customer Details</h2>
            </div>
          </div>
          <div className="flex flex-col gap-4 mb-6">
            <div>
              <label className="text-xs font-bold text-gray-500 mb-1.5 block" style={{ fontFamily: "Poppins" }}>Full Name <span className="text-red-500">*</span></label>
              <KeyboardInput keyboardLayout="default" value={name} onChange={val => setName(val)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold text-gray-900 outline-none transition-colors" placeholder={labels.namePlaceholder} style={{ fontFamily: "Poppins" }} />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 mb-1.5 block" style={{ fontFamily: "Poppins" }}>ID Number <span className="text-red-500">*</span></label>
              <KeyboardInput keyboardLayout="default" value={idNum} onChange={val => setIdNum(val)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold text-gray-900 outline-none transition-colors" placeholder={labels.idPlaceholder} style={{ fontFamily: "Poppins" }} />
            </div>
          </div>
          <button onClick={() => onNext({ name, idNum, tin: '', address: '' })} disabled={!isFormValid} className="w-full py-3.5 rounded-xl font-bold text-white disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95 shadow-md" style={{ fontFamily: "Poppins", background: accentColor }}>
            Proceed to Verification →
          </button>
        </div>
      </div>
    </div>
  );
}

function SoloDiscountModal({ rawTotal, onApply, onClose }: { rawTotal: number; onApply: (amount: number) => void; onClose: () => void; }) {
  const [mode, setMode] = useState<'percentage' | 'fixed'>('percentage');
  const [inputValue, setInputValue] = useState('');

  const maxFixed = parseFloat((rawTotal / 1.12).toFixed(2)); // max fixed = net of VAT

  const validationError = (() => {
    if (!inputValue || inputValue === '.') return null;
    const val = parseFloat(inputValue);
    if (isNaN(val)) return null;
    if (mode === 'percentage') {
      if (val < 0.01) return `Minimum is 0.01%`;
      if (val > 100)  return `Maximum is 100%`;
    } else {
      if (val <= 0)        return `Must be greater than ₱0.00`;
      if (val > maxFixed)  return `Maximum fixed discount is ${formatMoney(maxFixed)} (net of VAT)`;
    }
    return null;
  })();

  const isApplyDisabled = !inputValue || inputValue === '.' || validationError !== null || parseFloat(inputValue) <= 0;

  const handleNumpad = (val: string) => {
    if (val === '⌫') {
      setInputValue(prev => prev.slice(0, -1));
      return;
    }
    if (val === '.') {
      if (!inputValue.includes('.')) setInputValue(prev => prev + val);
      return;
    }
    const next = inputValue + val;
    const num  = parseFloat(next);
    // Hard-block typing beyond 100% in percentage mode
    if (mode === 'percentage' && !isNaN(num) && num > 100) return;
    setInputValue(next);
  };

  const handleApply = () => {
    if (isApplyDisabled) return;
    const val = parseFloat(inputValue);
    if (mode === 'percentage') {
      const calculatedDiscount = (rawTotal / 1.12) * (val / 100);
      onApply(calculatedDiscount);
    } else {
      onApply(val);
    }
  };


  return (
    <div className="fixed inset-0 flex items-center justify-center z-[160] animate-fade-in" style={{ background: "rgba(160,150,145,0.40)", backdropFilter: "blur(14px)" }} onClick={onClose}>
      <div className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden flex flex-col bg-white shadow-2xl animate-scale-in" onClick={e => e.stopPropagation()}>
        <div style={{ height: 5, background: "linear-gradient(90deg, #16a34a 0%, #22c55e 100%)" }} />
        <div className="p-7">
          <button onClick={onClose} className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-gray-400 hover:bg-gray-100 transition-colors">✕</button>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-sm" style={{ background: "rgba(22, 163, 74, 0.1)", border: "1px solid rgba(22, 163, 74, 0.2)", color: "#16a34a" }}>
              👨‍👦
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest mb-0.5 text-green-600" style={{ fontFamily: "Poppins" }}>Custom</p>
              <h2 className="text-lg font-black text-gray-900 leading-none" style={{ fontFamily: "Poppins" }}>Custom Discount</h2>
            </div>
          </div>

          <div className="flex bg-gray-100 p-1.5 rounded-xl mb-6 border border-gray-200">
            <button onClick={() => { setMode('percentage'); setInputValue(''); }} className={`flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-lg transition-all ${mode === 'percentage' ? 'bg-white shadow-sm text-green-600' : 'text-gray-500'}`} style={{ fontFamily: "Poppins" }}>Percentage</button>
            <button onClick={() => { setMode('fixed'); setInputValue(''); }} className={`flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-lg transition-all ${mode === 'fixed' ? 'bg-white shadow-sm text-green-600' : 'text-gray-500'}`} style={{ fontFamily: "Poppins" }}>Fixed Value</button>
          </div>

          <div className="bg-gray-50 rounded-2xl p-5 border border-gray-200 mb-6 flex flex-col items-center">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2" style={{ fontFamily: "Poppins" }}>{mode === 'percentage' ? 'Enter Percentage' : 'Enter Amount'}</span>
            <div className="flex items-end gap-1">
              {mode === 'fixed' && <span className="text-2xl font-bold text-gray-400 mb-1"></span>}
              <span className="text-5xl font-black text-gray-900" style={{ fontFamily: "Poppins" }}>{inputValue || '0'}</span>
              {mode === 'percentage' && <span className="text-2xl font-bold text-gray-400 mb-1">%</span>}
            </div>
            {validationError ? (
              <span className="text-xs font-bold text-red-500 mt-2 bg-red-50 border border-red-200 px-3 py-1.5 rounded-full text-center leading-snug">
                ⚠ {validationError}
              </span>
            ) : inputValue && mode === 'percentage' ? (
              <span className="text-xs font-bold text-green-600 mt-2 bg-green-100 px-3 py-1 rounded-full">
                {formatMoney((rawTotal / 1.12) * (parseFloat(inputValue) / 100) || 0)} OFF
              </span>
            ) : inputValue && mode === 'fixed' ? (
              <span className="text-xs font-bold text-green-600 mt-2 bg-green-100 px-3 py-1 rounded-full">
                {((parseFloat(inputValue) / rawTotal) * 100 || 0).toFixed(1)}% OFF
              </span>
            ) : null}
          </div>

          <div className="grid grid-cols-3 gap-2 mb-6">
            {['1','2','3','4','5','6','7','8','9','.','0','⌫'].map(btn => (
              <button key={btn} onClick={() => handleNumpad(btn)} className="h-14 bg-white border border-gray-200 rounded-xl text-xl font-bold text-gray-800 hover:bg-gray-50 active:scale-95 transition-all shadow-sm flex items-center justify-center" style={{ fontFamily: "Poppins", color: btn === '⌫' ? '#ef4444' : '#1f2937' }}>
                {btn}
              </button>
            ))}
          </div>

          <button
            onClick={handleApply}
            disabled={isApplyDisabled}
            className="w-full py-4 rounded-xl font-bold text-white transition-all active:scale-95 shadow-md disabled:cursor-not-allowed"
            style={{
              fontFamily: "Poppins",
              background: isApplyDisabled
                ? validationError
                  ? "rgba(239,68,68,0.5)"   // red tint when validation error
                  : "rgba(22,163,74,0.4)"   // faded green when just empty
                : "#16a34a",               // full green when valid
              opacity: isApplyDisabled && !validationError ? 0.5 : 1,
            }}
          >
            {validationError ? "Fix the error above →" : "Apply Custom Discount →"}
          </button>
        </div>
      </div>
    </div>
  );
}

export interface CustomerEntry {
  name: string;
  idNum: string;
  tin?: string;
  address?: string;
}

function CustomerInfoModal({ initialData, onClose, onSave }: { initialData?: CustomerInfo | null, onClose: () => void, onSave: (data: CustomerInfo) => void }) {
  const [customers, setCustomers] = useState<CustomerEntry[]>(() => {
    // Try to parse multiple customers from address field
    if (initialData?.address) {
      try {
        const parsed = JSON.parse(initialData.address);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch {}
    }
    // Single customer or empty
    if (initialData?.name || initialData?.idNum) {
      return [{ name: initialData.name || '', idNum: initialData.idNum || '', tin: initialData.tin || '', address: '' }];
    }
    return [{ name: '', idNum: '', tin: '', address: '' }];
  });

  const addCustomer = () => setCustomers(prev => [...prev, { name: '', idNum: '', tin: '', address: '' }]);
  const removeCustomer = (idx: number) => setCustomers(prev => prev.filter((_, i) => i !== idx));
  const updateCustomer = (idx: number, field: keyof CustomerEntry, value: string) => {
    setCustomers(prev => prev.map((c, i) => i === idx ? { ...c, [field]: value } : c));
  };

  const handleSave = () => {
    const primary = customers[0] || { name: '', idNum: '', tin: '', address: '' };
    onSave({
      name: primary.name,
      idNum: primary.idNum,
      tin: primary.tin || '',
      // Always encode the full array so re-opening restores all customers
      address: JSON.stringify(customers),
    });
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center z-[150] animate-fade-in" style={{ background: "rgba(160,150,145,0.30)", backdropFilter: "blur(14px)" }} onClick={onClose}>
      <div className="rounded-3xl w-full max-w-lg mx-4 relative overflow-hidden animate-scale-in bg-white shadow-2xl" style={{ maxHeight: '80vh', display: 'flex', flexDirection: 'column' }} onClick={e => e.stopPropagation()}>
        <div style={{ height: 5, background: "linear-gradient(90deg, #f97316 0%, #ea580c 100%)" }} />
        
        {/* Header */}
        <div className="px-7 pt-7 pb-4 flex-shrink-0">
          <button onClick={onClose} className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-gray-400 hover:bg-gray-100 transition-colors">✕</button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-orange-500 bg-orange-50 border border-orange-100">
              <FiUser size={20} />
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest text-orange-500" style={{ fontFamily: "Poppins" }}>Optional Details</p>
              <h2 className="text-lg font-black text-gray-900 leading-none" style={{ fontFamily: "Poppins" }}>Customer Info</h2>
            </div>
          </div>
        </div>

        {/* Scrollable customer list */}
        <div className="flex-1 overflow-y-auto px-7 pb-4 hide-scroll flex flex-col gap-4">
          {customers.map((customer, idx) => (
            <div key={idx} className="bg-gray-50 rounded-2xl p-4 border border-gray-200 relative">
              {/* Row header */}
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] font-black uppercase tracking-widest text-orange-500" style={{ fontFamily: "Poppins" }}>
                  Customer {customers.length > 1 ? idx + 1 : ''}
                </span>
                {customers.length > 1 && (
                  <button onClick={() => removeCustomer(idx)} className="text-[10px] font-bold text-red-400 hover:text-red-600 uppercase tracking-widest bg-red-50 hover:bg-red-100 px-2.5 py-1 rounded-lg transition-colors" style={{ fontFamily: "Poppins" }}>
                    Remove
                  </button>
                )}
              </div>

              {/* Name + ID on one row */}
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div>
                  <label className="text-[10px] font-bold text-gray-500 mb-1 block uppercase tracking-wide" style={{ fontFamily: "Poppins" }}>Full Name</label>
                  <KeyboardInput keyboardLayout="default" value={customer.name} onChange={val => updateCustomer(idx, 'name', val)} className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2.5 text-sm font-bold text-gray-900 outline-none focus:border-orange-500 transition-colors" placeholder="Full Name" style={{ fontFamily: "Poppins" }} />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-gray-500 mb-1 block uppercase tracking-wide" style={{ fontFamily: "Poppins" }}>ID Number</label>
                  <KeyboardInput keyboardLayout="default" value={customer.idNum} onChange={val => updateCustomer(idx, 'idNum', val)} className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2.5 text-sm font-bold text-gray-900 outline-none focus:border-orange-500 transition-colors" placeholder="ID Number" style={{ fontFamily: "Poppins" }} />
                </div>
              </div>

              {/* TIN + Address on one row */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-gray-500 mb-1 block uppercase tracking-wide" style={{ fontFamily: "Poppins" }}>TIN</label>
                  <KeyboardInput keyboardLayout="default" value={customer.tin || ''} onChange={val => updateCustomer(idx, 'tin', val)} className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2.5 text-sm font-bold text-gray-900 outline-none focus:border-orange-500 transition-colors" placeholder="TIN" style={{ fontFamily: "Poppins" }} />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-gray-500 mb-1 block uppercase tracking-wide" style={{ fontFamily: "Poppins" }}>Address</label>
                  <KeyboardInput keyboardLayout="default" value={customer.address || ''} onChange={val => updateCustomer(idx, 'address', val)} className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2.5 text-sm font-bold text-gray-900 outline-none focus:border-orange-500 transition-colors" placeholder="Address" style={{ fontFamily: "Poppins" }} />
                </div>
              </div>
            </div>
          ))}

          {/* Add Customer button */}
          <button onClick={addCustomer} className="w-full py-4 bg-white border-2 border-dashed border-orange-200 text-orange-400 rounded-2xl font-bold uppercase tracking-widest text-xs hover:border-orange-400 hover:text-orange-600 hover:bg-orange-50 transition-colors active:scale-95" style={{ fontFamily: "Poppins" }}>
            + Add Customer
          </button>
        </div>

        {/* Footer */}
        <div className="px-7 py-5 border-t border-gray-100 flex-shrink-0">
          <button onClick={handleSave} className="w-full py-3.5 rounded-xl font-bold text-white transition-all active:scale-95 shadow-md bg-orange-500 hover:bg-orange-600" style={{ fontFamily: "Poppins" }}>
            Save Information
          </button>
        </div>
      </div>
    </div>
  );
}

const getSelectableLines = (currentCart: any[], _remoteProducts: any, type: string) => {
  return currentCart.map((c, cIdx) => {
    const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
    const modsPrice = mods.reduce((s: number, m: any) => s + ((m.price || 0) * (m.qty || 1)) / 100, 0);

    // Determine whether this line has real MD modifiers (not CL-only or AD-only)
    const hasMDModifiers = mods.some((m: any) => String(m.id || '').startsWith('MD-'));

    // Unit value: for MD-modifier combos use UDF-1 gross; for ala carte use price + modsPrice
    let unitValue = c.price + modsPrice;
    if (isSRPWD(type) && hasMDModifiers && c.modifierGroups?.length > 0 && c.udfs?.['UDF-1']?.value) {
      const udfVal = Number(c.udfs['UDF-1'].value);
      if (!isNaN(udfVal)) unitValue = udfVal;
    }

    const total = unitValue * c.qty;

    return {
      key: `item-${cIdx}`,
      name: c.name,
      qty: c.qty,
      price: c.price + modsPrice,
      unitValue,   // ← new field
      total,
      img: c.imgReal || '',
      isCombo: mods.length > 0,
      modifiers: mods,
      selectable: true,
      taxable: c.taxable !== false,
      itemRef: c
    };
  });
};

export function LineItemDiscountModal({
  cart, type, remoteProducts, onClose, onApply, customerInfo, initialSelectedKeys = [],
}: {
  cart: any[];
  type: string;
  remoteProducts: any;
  onClose: () => void;
  onApply: (slotDetails: any[], keys: string[]) => void;
  customerInfo?: CustomerInfo | null;
  initialSelectedKeys?: string[];
}) {
  // Derive N from customerInfo
  const N = useMemo(() => {
    const customers = parseSrpwdCustomers(customerInfo ?? null);
    return Math.max(1, customers.length);
  }, [customerInfo]);
  const lines = useMemo(
    () => getSelectableLines(cart, remoteProducts, type),
    [cart, remoteProducts, type],
  );

  // Initialise selection: prefer passed-in keys, else auto-select
  const [selectedKeys, setSelectedKeys] = useState<string[]>(() =>
    initialSelectedKeys.length > 0
      ? initialSelectedKeys
      : autoSelectSrpwdItemKeys(cart, 1),
  );

  const toggleKey = (key: string) => {
    setSelectedKeys(prev =>
      prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]
    );
  };

  const previewAmount = selectedKeys.reduce((sum, key) => {
    const l = lines.find(l => l.key === key);
    return sum + (l ? (l.total / 1.12) * 0.20 : 0);
  }, 0);

  const slotDetails = useMemo(() => {
    const customers = parseSrpwdCustomers(customerInfo ?? null);
    if (customers.length > 0)
      return customers.map(c => ({ name: c.name || '', idNum: c.idNum || '', isConfirmed: true }));
    return [{ name: '', idNum: '', isConfirmed: true }];
  }, [customerInfo]);

  return (
    <div
      className="fixed inset-0 flex items-center justify-center z-[150] animate-fade-in"
      style={{ background: 'rgba(160,150,145,0.40)', backdropFilter: 'blur(14px)' }}
      onClick={onClose}
    >
      <div
        className="rounded-3xl w-full max-w-4xl mx-4 relative overflow-hidden flex flex-col bg-white shadow-2xl animate-scale-in"
        style={{ maxHeight: '70vh' }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-8 py-6 border-b border-gray-100 flex justify-between items-center bg-gray-50 flex-shrink-0">
          <div>
            <h2 className="text-xl font-black text-gray-900 uppercase tracking-tight" style={{ fontFamily: 'Poppins' }}>
              {TRANSACTION_TYPES.find(t => t.id === type)?.label} — Select Items
            </h2>
            <p className="text-xs text-gray-500 font-medium mt-1" style={{ fontFamily: 'Poppins' }}>
              {selectedKeys.length} item{selectedKeys.length !== 1 ? 's' : ''} selected for discount
              {' · '}select the item(s) that qualify for the discount
            </p>
          </div>
          {/* N/N badge */}
          <div className="flex items-center gap-3">
            <div
              className="px-4 py-2 rounded-full text-sm font-black"
              style={{
                background: selectedKeys.length === N ? 'rgba(34,197,94,0.12)' : 'rgba(249,115,22,0.12)',
                color:      selectedKeys.length === N ? '#16a34a' : '#f97316',
                fontFamily: 'Poppins',
              }}
            >
              {selectedKeys.length} selected
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-gray-400 hover:bg-gray-200 transition-colors text-lg"
            >✕</button>
          </div>
        </div>

        {/* Item list */}
        <div className="flex-1 overflow-y-auto p-8 hide-scroll">
          <div className="space-y-3">
            {lines.map(l => {
              const isSelected = selectedKeys.includes(l.key);
              const discount   = (l.total / 1.12) * 0.20;

              return (
                <button
                  key={l.key}
                  onClick={() => toggleKey(l.key)}
                  className={`w-full text-left px-5 py-4 rounded-2xl border flex items-center gap-4 transition-all ${
                    isSelected
                      ? 'border-orange-500 bg-orange-50 shadow-md ring-1 ring-orange-500'
                      : 'border-gray-200 bg-white hover:border-orange-300 hover:shadow-sm'
                  }`}
                >
                  {/* Checkbox */}
                  <div
                    className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                      isSelected ? 'border-orange-500 bg-orange-500 text-white' : 'border-gray-300 bg-white'
                    }`}
                  >
                    {isSelected && <span style={{ fontSize: 12 }}>✓</span>}
                  </div>

                  {/* Image */}
                  <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center overflow-hidden border border-gray-200 flex-shrink-0 p-1">
                    {l.img
                      ? <img src={l.img} className="w-full h-full object-contain" alt={l.name} />
                      : <span className="text-2xl">🍩</span>}
                  </div>

                  {/* Name + mods */}
                  <div className="flex-1 min-w-0">
                    <span
                      className={`block text-sm font-bold truncate ${isSelected ? 'text-orange-900' : 'text-gray-800'}`}
                      style={{ fontFamily: 'Poppins' }}
                    >
                      {l.name}
                    </span>
                    {l.isCombo && (
                      <div className="flex flex-wrap gap-1 mt-1">
                        {l.modifiers.slice(0, 3).map((m: any, mi: number) => (
                          <span
                            key={mi}
                            className="text-[9px] font-bold text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded"
                            style={{ fontFamily: 'Poppins' }}
                          >
                            {m.qty}x {m.name}
                          </span>
                        ))}
                        {l.modifiers.length > 3 && (
                          <span className="text-[9px] font-bold text-gray-400" style={{ fontFamily: 'Poppins' }}>
                            +{l.modifiers.length - 3} more
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Price */}
                  <div className="text-right flex-shrink-0">
                    <span
                      className={`block text-sm font-black ${isSelected ? 'text-orange-700' : 'text-gray-900'}`}
                      style={{ fontFamily: 'Poppins' }}
                    >
                      {formatMoney(l.total)}
                    </span>
                    {isSelected && (
                      <span
                        className="text-[10px] font-black text-orange-600 block mt-1"
                        style={{ fontFamily: 'Poppins' }}
                      >
                        − {formatMoney(discount)}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="px-8 py-5 border-t border-gray-100 bg-white flex justify-between items-center shadow-[0_-4px_20px_rgba(0,0,0,0.03)] flex-shrink-0 z-10">
          <div>
            <span
              className="text-xs font-bold text-gray-400 uppercase tracking-widest block mb-1"
              style={{ fontFamily: 'Poppins' }}
            >
              Total Discount
            </span>
            <span className="text-3xl font-black text-orange-600" style={{ fontFamily: 'Poppins' }}>
              − {formatMoney(previewAmount)}
            </span>
          </div>
          <div className="flex gap-4">
            <button
              onClick={onClose}
              className="px-8 py-4 rounded-xl font-bold text-gray-600 bg-gray-100 hover:bg-gray-200 transition-colors text-sm"
              style={{ fontFamily: 'Poppins' }}
            >
              Cancel
            </button>
            <button
              onClick={() => selectedKeys.length > 0 && onApply(slotDetails, selectedKeys)}
              disabled={selectedKeys.length === 0}
              className="px-10 py-4 rounded-xl font-bold text-white bg-gray-900 hover:bg-black transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-xl active:scale-95 text-sm"
              style={{ fontFamily: 'Poppins' }}
            >
              Apply Discount →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function TransactionTypeModal({ selectedType, onSelect, onClose, customerInfo, onClearDiscount, getDisabledReason }: { selectedType: TransactionType; onSelect: (type: TransactionType) => void; onClose: () => void; customerInfo?: CustomerInfo | null; onClearDiscount: () => void; getDisabledReason: (id: string) => string | null; }) {
  const [selected, setSelected] = useState<TransactionType>(selectedType);
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 animate-fade-in" style={{ background: "rgba(160,150,145,0.30)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)" }} onClick={onClose}>
      <div className="rounded-3xl w-full max-w-fit mx-4 relative overflow-hidden animate-scale-in" style={glass.modal} onClick={(e) => e.stopPropagation()}>
        <div style={{ height: 5, background: "linear-gradient(90deg, #f97316 0%, #fb923c 60%, #fed7aa 100%)" }} />
        <div className="p-7">
          <button onClick={onClose} className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-base transition-all hover:bg-black/5" style={{ background: "rgba(0,0,0,0.05)", color: "#bbb", border: "1px solid rgba(0,0,0,0.07)" }}>✕</button>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: "linear-gradient(135deg, #fef2f2, #fee2e2)", border: "1.5px solid rgba(220,38,38,0.18)", boxShadow: "0 2px 10px rgba(220,38,38,0.10)" }}>
                <span style={{ fontSize: 22 }}>🏷️</span>
              </div>
              <div>
                <p style={{ fontFamily: "Poppins", fontSize: 10, color: "#ccc", fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 2 }}>Customer Type</p>
                <h2 style={{ fontFamily: "Poppins", fontSize: 16, fontWeight: 900, color: "#1a1a1a", lineHeight: 1 }}>Select <span style={{ color: "#f97316" }}>Transaction Type</span></h2>
              </div>
            </div>
            {selectedType !== "REGULAR" && (
              <button onClick={() => { onClearDiscount(); onClose(); }} className="px-4 py-2 rounded-xl text-xs font-bold text-red-500 bg-red-50 hover:bg-red-100 transition-colors border border-red-200" style={{ fontFamily: "Poppins" }}>
                Remove Discount
              </button>
            )}
          </div>
          <div>
            {/* ── Category label helper ── */}
            {(() => {
              const GOV   = ["SR", "PWD", "ATHLETE", "SOLO", "MEDAL"];
              const ZERO  = ["DIPLOMAT", "PEZA"];
              const OTHER = ["CUSTOM"];

              const renderOption = (opt: typeof TRANSACTION_TYPES[number]) => {
                const isSelected = selected === opt.id;
                const disabledReason = getDisabledReason(opt.id);
                const allowed    = disabledReason === null;
                return (
                  <button
                    key={opt.id}
                    onClick={() => { if (!allowed) return; setSelected(opt.id); onSelect(opt.id); }}
                    className="flex items-center gap-4 rounded-2xl p-4 text-left w-full transition-all duration-200 focus:outline-none"
                    style={{
                      background:  isSelected ? opt.activeBg : opt.bg,
                      border:      `2px solid ${isSelected ? opt.activeBorder : opt.border}`,
                      boxShadow:   isSelected ? `0 4px 16px ${opt.color}22` : "none",
                      transform:   isSelected ? "scale(1.01)" : "scale(1)",
                      opacity:     allowed ? 1 : 0.4,
                      cursor:      allowed ? 'pointer' : 'not-allowed',
                      position:    'relative',
                    }}
                  >
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 text-2xl" style={{ fontFamily: "Poppins", background: isSelected ? `${opt.color}18` : "rgba(255,255,255,0.6)", border: `1px solid ${opt.border}` }}>{opt.icon}</div>
                    <div className="flex-1">
                      <p style={{ fontSize: 16, fontWeight: 900, color: isSelected ? opt.color : "#1a1a1a", fontFamily: "Poppins", letterSpacing: 0.5 }}>{opt.label}</p>
                      <p style={{ fontFamily: "Poppins", fontSize: 11, color: "#aaa", marginTop: 1 }}>{opt.sublabel}</p>
                    </div>
                    {opt.autoDiscount && opt.autoDiscount !== "VAT_EXEMPT_ONLY" && opt.id !== "SOLO" && opt.id !== "CUSTOM" && (
                      <div className="flex flex-col items-end gap-1">
                        <span className="px-3 py-1 rounded-full text-xs font-black" style={{ fontFamily: "Poppins", background: isSelected ? opt.color : "rgba(0,0,0,0.06)", color: isSelected ? "#fff" : "#999", transition: "all 0.2s" }}>20% OFF</span>
                        {isSelected && <span style={{ fontFamily: "Poppins", color: opt.color, fontSize: 11, fontWeight: 900, lineHeight: 1 }}>✓</span>}
                      </div>
                    )}
                    {opt.id === "CUSTOM" && (
                      <div className="flex flex-col items-end gap-1">
                        <span className="px-3 py-1 rounded-full text-xs font-black" style={{ fontFamily: "Poppins", background: isSelected ? opt.color : "rgba(0,0,0,0.06)", color: isSelected ? "#fff" : "#999", transition: "all 0.2s" }}>CUSTOM</span>
                        {isSelected && <span style={{ fontFamily: "Poppins", color: opt.color, fontSize: 11, fontWeight: 900, lineHeight: 1 }}>✓</span>}
                      </div>
                    )}
                    {opt.autoDiscount === "VAT_EXEMPT_ONLY" && (
                      <div className="flex flex-col items-end gap-1">
                        <span className="px-3 py-1 rounded-full text-xs font-black" style={{ fontFamily: "Poppins", background: isSelected ? opt.color : "rgba(0,0,0,0.06)", color: isSelected ? "#fff" : "#999", transition: "all 0.2s" }}>12% OFF</span>
                        {isSelected && <span style={{ fontFamily: "Poppins", color: opt.color, fontSize: 11, fontWeight: 900, lineHeight: 1 }}>✓</span>}
                      </div>
                    )}
                    {!opt.autoDiscount && (
                      <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: isSelected ? opt.color : "rgba(0,0,0,0.08)", border: `2px solid ${isSelected ? opt.color : "rgba(0,0,0,0.12)"}`, transition: "all 0.2s" }}>
                        {isSelected && <span style={{ fontFamily: "Poppins", color: "#fff", fontSize: 11, fontWeight: 900, lineHeight: 1 }}>✓</span>}
                      </div>
                    )}
                    {!allowed && (
                      <div style={{ position: 'absolute', inset: 0, borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
                        <span style={{ fontFamily: 'Poppins', fontSize: 9, fontWeight: 800, color: '#666', background: 'rgba(255,255,255,0.92)', padding: '3px 10px', borderRadius: 999, textTransform: 'uppercase', letterSpacing: 1 }}>🚫 {disabledReason}</span>
                      </div>
                    )}
                  </button>
                );
              };

              const SectionLabel = ({ label }: { label: string }) => (
                <p className="text-[9px] font-black uppercase tracking-[0.15em] px-1 mb-1 mt-3 first:mt-0" style={{ fontFamily: "Poppins", color: "#bbb" }}>{label}</p>
              );

              return (
                <div className="flex flex-col gap-1">
                  <SectionLabel label="🏛️ Government Discounts" />
                  <div className="grid grid-cols-2 gap-2">
                    {TRANSACTION_TYPES.filter(o => GOV.includes(o.id)).map(renderOption)}
                  </div>

                  <SectionLabel label="🌐 Zero Rated" />
                  <div className="grid grid-cols-2 gap-2">
                    {TRANSACTION_TYPES.filter(o => ZERO.includes(o.id)).map(renderOption)}
                  </div>

                  <SectionLabel label="✏️ Others" />
                  <div className="grid grid-cols-1 gap-2">
                    {TRANSACTION_TYPES.filter(o => OTHER.includes(o.id)).map(renderOption)}
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      </div>
    </div>
  );
}

const Panda = () => (
  <svg width="16" height="16" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" fill="none" strokeWidth="3" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round">
    <path d="M24.145,34.288a4.6476,4.6476,0,0,0,4.7112-3.5551.538.538,0,0,0-.5237-.6343H19.9537a.5374.5374,0,0,0-.5247.6286A4.5335,4.5335,0,0,0,24.145,34.288Z"/>
    <path d="M40.1786,13.3114a4.75,4.75,0,0,0,1.7332-3.9,5.0583,5.0583,0,0,0-5.2-5.0555,4.9192,4.9192,0,0,0-4.3334,2.3112A18.7,18.7,0,0,0,24,4.7885a19.8078,19.8078,0,0,0-8.3779,1.8782,4.9192,4.9192,0,0,0-4.3334-2.3112A5.15,5.15,0,0,0,6.0882,9.411a5.4557,5.4557,0,0,0,1.7332,3.9A18.8375,18.8375,0,0,0,4.5,24.1445a19.5,19.5,0,0,0,39,0,18.5,18.5,0,0,0-3.3214-10.8331Z"/>
    <path d="M23.18,27.5546a2.4979,2.4979,0,0,0,1.9211-.0105c.9815-.4159,2.3656-1.1675,2.3656-2.1,0-.8671-2.4553-1.0111-3.3214-1.0111s-3.3223.144-3.3223,1.0111C20.7292,26.3842,22.1657,27.1416,23.18,27.5546Z"/>
    <path d="M35.4121,15.7667c-1.7332-1.1552-5.4886-1.7332-6.9327.1449a2.9463,2.9463,0,0,0,0,4.0445A15.1652,15.1652,0,0,1,32.0907,25.59c.4331,1.7332,1.1552,2.31,2.4553,2.31s3.9-2.0222,4.3334-5.3445A7.2549,7.2549,0,0,0,35.4121,15.7667Z"/>
    <path d="M31.5127,19.9551a1.0106,1.0106,0,1,1,1.01-1.01A.9868.9868,0,0,1,31.5127,19.9551Z"/>
    <path d="M19.6675,15.9107c-1.4441-1.8772-5.2-1.3-6.9327-.145a7.4155,7.4155,0,0,0-3.4674,6.7887c.2891,3.3214,2.8893,5.3446,4.3335,5.3446,1.3011,0,2.0222-.7221,2.4553-2.31.433-1.7342,1.8772-3.6114,3.6113-5.6336A2.9038,2.9038,0,0,0,19.6675,15.9107Z"/>
    <path d="M16.9232,19.9551a1.0106,1.0106,0,1,1,1.01-1.01A.9868.9868,0,0,1,16.9232,19.9551Z"/>
  </svg>
);

const Grab = () => (
  <svg width="16" height="16"  viewBox="0 -160.65 522.6 522.6" xmlns="http://www.w3.org/2000/svg" fill="currentColor">
    <path d="M415.9 63.4V0h13v54.5c-3.6 1.8-8.5 5.2-13 8.9zm-22.6 19.1c4-4.8 8.1-9.6 13-13.7V0h-13v82.5zm-150.6 50.4c0 16.9 6.7 33 19 45.3 12.2 12.2 28.3 19 45.3 19 7.2 0 14.6-1.5 19.8-4.1v-13c-6.1 2.6-13.5 4.1-19.8 4.1-27.8 0-51.2-23.4-51.2-51.2v-11.7c0-27.8 23.5-51.2 51.2-51.2 13.8 0 26.7 5.3 36.3 14.9 9.6 9.6 14.9 22.5 14.9 36.3v76h13v-78.5c-.8-16.6-7.9-32.1-19.9-43.7-12.1-11.6-27.8-18-44.3-18-16.9 0-33 6.7-45.3 19-12.2 12.2-19 28.3-19 45.3v11.5zm194.6-31.2c5.9-5.9 13.5-9.2 21-9.2 16.1 0 28.6 12.6 28.6 28.6v11.7c0 16.1-12.6 28.6-28.6 28.6-7.8 0-15.3-4.3-21.2-12-5.2-6.8-8.6-16.1-9.1-24.4l-10.5 13c2.1 9.8 7.2 19.3 14.5 25.9 7.5 6.8 16.9 10.6 26.3 10.6 23 0 41.7-18.7 41.7-41.6v-11.7c0-10.9-4.4-21.3-12.4-29.2-8-8-18.4-12.4-29.3-12.4-6.9 0-17.8 2.5-30.8 14.2-3.5 3.5-11.7 11.7-16.7 17.5-8.4 9.2-20.5 22.9-30.9 36.8v20.3c11.5-14.8 18.1-23.1 29-35.6 9.6-11.4 21.6-25.1 28.4-31.1zM130.1 77.2V61.8c-11.8-6.3-24.6-9.1-41.6-9.1-17.4 0-33.9 6.4-46.4 17.9-12.6 11.6-19.5 26.8-19.5 43v4.2c0 33.6 26.9 60.9 60.1 60.9 26.9 0 38-8.8 40.8-11.6V128h-44v13h31.8v19.6h-.1c-4.1 1.6-12.6 5-28.5 5-12.6 0-24.5-4.9-33.3-13.9-8.9-9-13.7-21-13.7-34v-4.2c0-25.9 24.2-47.9 52.9-47.9 19.7.1 31.5 3.4 41.5 11.6zm94.8 15.3c4.9 0 9.1.8 12.5 2.4 1.6-4 3.3-7.4 5.7-11.4-3.5-2.5-12-4.1-18.2-4.1-23.7 0-41.6 17.9-41.6 41.7v76h13v-76c0-16.8 11.7-28.6 28.6-28.6zM0 113.6v4.2c0 22.6 8.6 43.6 24.1 59.3 15.5 15.6 36.3 24.2 58.5 24.2 17.9 0 33.7-4 47.1-12 11-6.6 15.9-13.2 16.3-13.8v-70H79.5v13H133v53.1c-6.3 6.3-21.2 16.8-50.3 16.8-19 0-36.6-7.3-49.6-20.5-12.9-13.1-20-30.9-20-50v-4.2c0-18.1 8.1-36.1 22.3-49.4 14.5-13.6 33.4-21.1 53.2-21.1 18.5 0 31.3 2.8 41.6 9.1V37.6C119.4 33 106.5 31 88.5 31 40.5 31 0 68.8 0 113.6zm348.5 83.5v-76c0-23.4-18.3-41.7-41.7-41.7-10.9 0-21.3 4.4-29.3 12.4s-12.4 18.4-12.4 29.2v11.7c0 22.6 19.1 41.6 41.6 41.6 6.2 0 14.6-1.5 19.8-5.8V155c-5.1 4.1-12.4 6.5-19.8 6.5-16 0-28.6-12.6-28.6-28.6v-11.7c0-16.1 12.6-28.6 28.6-28.6 16.1 0 28.6 12.6 28.6 28.6v76h13.2zM224.9 69.9c8.8 0 16.5 1.9 23.4 5.8 3.2-4.1 6.5-7.3 9-9.8-7.3-5.6-19.7-9-32.3-9-18.1 0-34.5 6.5-46.2 18.4-11.6 11.7-18 28-18 45.9v76h13v-76c-.1-30.2 20.9-51.3 51.1-51.3zm278.7 6c-12.2-12.2-28.3-19-45.3-19-12.4 0-24.8 4.6-31.7 9.2-14.2 9.4-25.8 19.7-46.8 46.8v19.5c17.8-23.2 34.6-41.4 47.4-51.5 8.4-6.7 20.3-10.9 31.1-10.9 27.8 0 51.2 23.5 51.2 51.2v11.7c0 13.7-5.4 26.6-15.2 36.3-9.7 9.6-22.5 14.9-36 14.9-22.8 0-42.9-15.7-48.3-37l-9.2 11.1c6.7 22.4 30.9 38.9 57.5 38.9 17 0 33-6.8 45.3-19 12.2-12.3 19-28.3 19-45.3v-11.7c0-16.9-6.8-33-19-45.2z"/>
  </svg>
);


function NumpadModal({
  open,
  itemName,
  itemImg,           // ← new prop
  initialValue,
  onConfirm,
  onClose,
}: {
  open: boolean;
  itemName: string;
  itemImg: string;   // ← new prop
  initialValue: number | undefined;
  onConfirm: (qty: number) => void;
  onClose: () => void;
}) {
  const [input, setInput] = useState('');
  const [imgLoaded, setImgLoaded] = useState(false);

  useEffect(() => {
    if (open) {
      setInput(initialValue ? String(initialValue) : '');
      setImgLoaded(false); // reset on each open
    }
  }, [open, initialValue]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') press(e.key);
      else if (e.key === 'Backspace') backspace();
      else if (e.key === 'Enter') confirm();
      else if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, input]);

  const press = (val: string) => {
    setInput(prev => {
      const next = prev === '' ? val : prev + val;
      const num = parseInt(next);
      if (isNaN(num) || next.length > 5) return prev;
      return String(num);
    });
  };

  const backspace = () => setInput(prev => prev.slice(0, -1));
  const confirm   = () => onConfirm(parseInt(input) || 0);

  const accentColor = '#f97316';
  const stripColor  = 'linear-gradient(90deg, #f97316 0%, #fb923c 60%, #fdba74 100%)';

  return (
    <div
      className="fixed inset-0 flex items-center justify-center z-301"
      style={{
        background: 'rgba(15,23,42,0.82)',
        backdropFilter: 'blur(14px)',
        WebkitBackdropFilter: 'blur(14px)',
        opacity: open ? 1 : 0,
        pointerEvents: open ? 'all' : 'none',
        transition: 'opacity .22s ease',
      }}
      onClick={onClose}
    >
      <div
        className="rounded-3xl w-full max-w-sm mx-4 relative overflow-hidden shadow-2xl"
        style={{
          background: '#ffffff',
          transform: open ? 'scale(1) translateY(0)' : 'scale(0.88) translateY(20px)',
          transition: 'transform .3s cubic-bezier(0.34,1.56,0.64,1)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top strip */}
        <div style={{ height: 6, background: stripColor }} />

        <div className="p-7">
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-7 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-base transition-all hover:bg-black/5"
            style={{
              background: 'rgba(0,0,0,0.05)',
              color: '#bbb',
              border: '1px solid rgba(0,0,0,0.07)',
              fontFamily: 'Poppins',
            }}
          >
            ✕
          </button>

          {/* Header — item image replaces the emoji */}
          <div className="flex items-center gap-3 mb-4">
            <div
              className="w-12 h-12 rounded-2xl flex-shrink-0 overflow-hidden relative"
              style={{
                background: `${accentColor}15`,
                border: `1.5px solid ${accentColor}30`,
              }}
            >
              {/* Skeleton */}
              {!imgLoaded && itemImg && (
                <div
                  className="absolute inset-0"
                  style={{
                    background: 'linear-gradient(90deg, #fde8d4 25%, #fef0e4 50%, #fde8d4 75%)',
                    backgroundSize: '200% 100%',
                    animation: 'shimmer 1.4s infinite',
                  }}
                />
              )}

              {itemImg ? (
                <img
                  src={itemImg}
                  alt={itemName}
                  className="w-full h-full object-contain p-1"
                  style={{ opacity: imgLoaded ? 1 : 0, transition: 'opacity .3s ease' }}
                  onLoad={() => setImgLoaded(true)}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-xl">🍩</div>
              )}
            </div>

            <div>
              <p style={{
                fontFamily: 'Poppins', fontSize: 10, color: '#ccc',
                fontWeight: 700, letterSpacing: 1.2,
                textTransform: 'uppercase', marginBottom: 2,
              }}>
                Physical Count
              </p>
              <h2 style={{
                fontFamily: 'Poppins', fontSize: 18,
                fontWeight: 900, color: '#1a1a1a', lineHeight: 1,
              }}>
                {itemName}
              </h2>
            </div>
          </div>

          {/* Quantity display */}
          <div
            className="rounded-xl px-6 py-4 mb-5"
            style={{
              fontFamily: 'Poppins',
              background: `${accentColor}10`,
              border: `1.5px solid ${accentColor}30`,
              color: accentColor,
              minHeight: 72,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
            }}
          >
            {input.length > 0 ? (
              <>
                <span style={{ fontSize: 24, fontWeight: 900, letterSpacing: '-0.02em' }}>
                  {input}
                </span>
                <span style={{ fontSize: 14, fontWeight: 700, opacity: 0.6, marginTop: 4 }}>
                  pcs
                </span>
              </>
            ) : (
              <span style={{ color: '#ddd', fontSize: 14, fontWeight: 500 }}>
                Enter quantity
              </span>
            )}
          </div>

          {/* Keypad + Actions */}
          <div className="flex gap-4 items-start">
            <div className="grid grid-cols-3 gap-2.5 flex-1">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                <button
                  key={num}
                  onClick={() => press(String(num))}
                  className="h-14 rounded-xl text-xl font-bold transition-all hover:bg-gray-100 active:scale-95"
                  style={{
                    background: 'rgba(0,0,0,0.04)',
                    fontFamily: 'Poppins',
                    color: '#1a1a1a',
                    border: '1px solid rgba(0,0,0,0.07)',
                  }}
                >
                  {num}
                </button>
              ))}

              <button
                onClick={() => press('0')}
                className="col-span-2 h-14 rounded-xl text-xl font-bold transition-all hover:bg-gray-100 active:scale-95"
                style={{
                  background: 'rgba(0,0,0,0.04)',
                  fontFamily: 'Poppins',
                  color: '#1a1a1a',
                  border: '1px solid rgba(0,0,0,0.07)',
                }}
              >
                0
              </button>

              <button
                onClick={backspace}
                className="h-14 rounded-xl text-xl font-bold transition-all active:scale-95"
                style={{
                  background: `${accentColor}15`,
                  color: accentColor,
                  fontFamily: 'Poppins',
                  border: `1px solid ${accentColor}30`,
                }}
              >
                ⌫
              </button>
            </div>

            <div className="flex flex-col gap-2.5">
              <button
                onClick={confirm}
                className="w-16 rounded-xl font-bold transition-all hover:brightness-110 active:scale-95 flex items-center justify-center"
                style={{
                  height: 122,
                  background: '#4ade80',
                  border: '1px solid rgba(255,255,255,0.5)',
                  color: '#fff',
                  fontSize: 32,
                }}
              >
                ✓
              </button>

              <button
                onClick={onClose}
                className="w-16 h-12 rounded-xl text-sm font-bold transition-all hover:bg-gray-100"
                style={{
                  background: 'rgba(0,0,0,0.04)',
                  color: '#666',
                  fontFamily: 'Poppins',
                  border: '1px solid rgba(0,0,0,0.07)',
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}


const getEffectiveTotal = (c: any) => {
  const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
  const modsPrice = mods.reduce((s: number, m: any) => s + ((m.price || 0) * (m.qty || 1)) / 100, 0);
  const gross = (c.price + modsPrice) * c.qty;
  if (c.modifierGroups?.length > 0 && c.udfs?.['UDF-1']?.value) {
    const udfVal = Number(c.udfs['UDF-1'].value);
    if (!isNaN(udfVal)) return udfVal * c.qty;
  }
  return gross;
};

function EncloseModal({ onClose, onSave }: { onClose: () => void, onSave: (data: { name: string, price: number, notes: string, paymentMethod: string }) => void }) {
  const [name, setName] = useState("");
  const [notes, setNotes] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("CASH");

  const [manualEntry, setManualEntry] = useState('');
  const [denominations, setDenominations] = useState<Record<number, number>>({
    1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0
  });

  const handleTap = (value: number) => {
    setManualEntry('');
    setDenominations(prev => ({ ...prev, [value]: (prev[value] || 0) + 1 }));
  };

  const clearCount = () => {
    setManualEntry('');
    setDenominations({ 1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0 });
  };

  const tappedTotal = Object.entries(denominations).reduce((sum, [val, count]) => sum + (parseFloat(val) * count), 0);
  const displayTotal = manualEntry ? parseFloat(manualEntry) : tappedTotal;

  const isApplyDisabled = !name.trim() || displayTotal <= 0;

  const getBillColor = (val: number) => {
    switch (val) {
      case 1000: return { border: "rgba(59, 130, 246, 0.3)", text: "#2563eb" };
      case 500:  return { border: "rgba(234, 179, 8, 0.3)",  text: "#ca8a04" };
      case 200:  return { border: "rgba(34, 197, 94, 0.3)",  text: "#16a34a" };
      case 100:  return { border: "rgba(168, 85, 247, 0.3)", text: "#9333ea" };
      case 50:   return { border: "rgba(239, 68, 68, 0.3)",  text: "#dc2626" };
      default:   return { border: "rgba(148, 163, 184, 0.4)", text: "#475569" };
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 animate-fade-in" style={{ background: "rgba(15, 23, 42, 0.75)", backdropFilter: "blur(16px)" }} onClick={onClose}>
      <div className="rounded-3xl w-full max-w-4xl mx-4 relative overflow-hidden flex flex-col bg-white shadow-2xl animate-scale-in" onClick={e => e.stopPropagation()}>
        <div className="px-7 py-4 flex items-center justify-between border-b border-gray-100">
          <div>
            <h2 className="text-2xl font-black text-gray-900" style={{ fontFamily: "Poppins" }}>Enclose Transaction</h2>
            <p className="text-xs text-gray-500 font-medium" style={{ fontFamily: "Poppins" }}>Record cash/expense adjustments directly to the drawer.</p>
          </div>
          <button onClick={onClose} className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-gray-400 hover:bg-gray-100 transition-colors">✕</button>
        </div>

        <div className="flex flex-col md:flex-row" style={{ minHeight: "400px" }}>
          <div className="w-full md:w-1/2 p-7 bg-white flex flex-col gap-5 border-r border-gray-100">
            <div>
                <label className="text-[10px] font-bold text-gray-500 mb-1.5 block uppercase tracking-wide" style={{ fontFamily: "Poppins" }}>Title / Name</label>
                <KeyboardInput keyboardLayout="default" value={name} onChange={setName} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3.5 text-sm font-bold text-gray-900 outline-none focus:border-blue-500 transition-colors" placeholder="e.g. Toll Fee, Supplies" style={{ fontFamily: "Poppins" }} />
            </div>
            <div>
                <label className="text-[10px] font-bold text-gray-500 mb-1.5 block uppercase tracking-wide" style={{ fontFamily: "Poppins" }}>Notes</label>
                <KeyboardInput keyboardLayout="default" value={notes} onChange={setNotes} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3.5 text-sm font-bold text-gray-900 outline-none focus:border-blue-500 transition-colors" placeholder="e.g. Ticket #123" style={{ fontFamily: "Poppins" }} />
            </div>

            <div>
              <label className="text-[10px] font-bold text-gray-500 mb-1.5 block uppercase tracking-wide" style={{ fontFamily: "Poppins" }}>Payment Method</label>
              <div className="grid grid-cols-2 gap-2">
                {["CASH", "CARD", "GCASH", "MAYA"].map(method => (
                  <button 
                    key={method} 
                    onClick={() => {
                      setPaymentMethod(method);
                      if (method !== 'CASH') {
                        setDenominations({ 1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0 });
                      }
                    }}
                    className={`py-3 rounded-xl font-bold text-xs transition-colors border ${paymentMethod === method ? 'bg-blue-50 border-blue-200 text-blue-600' : 'bg-gray-50 border-gray-200 text-gray-500 hover:bg-gray-100'}`}
                    style={{ fontFamily: "Poppins" }}
                  >
                    {method}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="w-full md:w-1/2 flex flex-col p-7 gap-5 bg-gray-50">
            <div className="flex-shrink-0 h-16 rounded-2xl flex items-center px-5 justify-between bg-white border-2 border-orange-200 shadow-sm">
              <span className="text-orange-400 font-bold text-sm uppercase tracking-widest" style={{ fontFamily: "Poppins" }}>Amount</span>
              <span className="text-3xl font-black text-gray-900" style={{ fontFamily: "Poppins" }}>
                {displayTotal > 0 ? formatMoney(displayTotal) : "0.00"}
              </span>
            </div>
            {paymentMethod !== 'CASH' && (
              <div>
                <label className="text-[10px] font-bold text-gray-400 tracking-widest uppercase mb-1.5 block" style={{ fontFamily: "Poppins" }}>
                  Amount
                </label>
                <KeyboardInput 
                  keyboardLayout="numeric" 
                  value={manualEntry} 
                  onChange={(val) => { setManualEntry(val); setDenominations({1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0}); }} 
                  className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3 text-lg font-bold text-gray-900 outline-none focus:border-orange-500 transition-colors" 
                  placeholder="e.g. 150.00" 
                  style={{ fontFamily: "Poppins" }} 
                />
              </div>
            )}

            {paymentMethod === 'CASH' && (
              <>
                <div>
                  <h4 className="text-[10px] font-bold text-gray-400 tracking-widest uppercase mb-2.5" style={{ fontFamily: "Poppins" }}>Or Tap Paper Bills</h4>
                  <div className="grid grid-cols-5 gap-2">
                    {[1000, 500, 200, 100, 50].map(val => {
                      const colors = getBillColor(val);
                      const count = denominations[val] || 0;
                      return (
                        <button key={val} onClick={() => handleTap(val)} className="relative h-14 rounded-xl flex items-center justify-center font-black text-sm transition-transform active:scale-95 bg-white shadow-sm hover:shadow-md" style={{ border: `2px solid ${colors.border}`, color: colors.text, fontFamily: "Poppins" }}>
                          {val}
                          {count > 0 && <span className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-gray-900 text-white text-[9px] flex items-center justify-center border-2 border-white shadow-sm">{count}</span>}
                        </button>
                      );
                    })}
                  </div>
                </div>
                <div>
                  <h4 className="text-[10px] font-bold text-gray-400 tracking-widest uppercase mb-2.5" style={{ fontFamily: "Poppins" }}>Coins</h4>
                  <div className="flex gap-2">
                    {[20, 10, 5, 1, 0.25].map(val => {
                      const colors = getBillColor(val);
                      const count = denominations[val] || 0;
                      return (
                        <button key={val} onClick={() => handleTap(val)} className="relative w-12 h-12 rounded-full flex items-center justify-center font-bold text-xs transition-transform active:scale-95 bg-white shadow-sm hover:shadow-md" style={{ border: `2px solid ${colors.border}`, color: colors.text, fontFamily: "Poppins" }}>
                          {val}
                          {count > 0 && <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-gray-900 text-white text-[8px] flex items-center justify-center border-2 border-white">{count}</span>}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        <div className="px-7 py-4 border-t border-gray-100 flex items-center justify-between bg-white rounded-b-3xl">
          <button onClick={clearCount} className="px-5 py-3 rounded-xl bg-gray-100 text-gray-500 font-bold text-sm transition-colors hover:bg-gray-200" style={{ fontFamily: "Poppins" }}>
            Clear Amount
          </button>
          <button
            onClick={() => onSave({ name, notes, price: displayTotal, paymentMethod })}
            disabled={isApplyDisabled}
            className="px-10 py-3 rounded-xl font-bold text-white transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed bg-blue-600 hover:bg-blue-700 shadow-md"
            style={{ fontFamily: "Poppins" }}
          >
            Save Transaction →
          </button>
        </div>
      </div>
    </div>
  );
}

function CustomItemModal({ onClose, onAdd }: { onClose: () => void, onAdd: (name: string, price: number) => void }) {
  const [name, setName] = useState("");
  const [priceStr, setPriceStr] = useState("");

  const handleNumpad = (val: string) => {
    if (val === '⌫') {
      setPriceStr(prev => prev.slice(0, -1));
      return;
    }
    if (val === '.') {
      if (!priceStr.includes('.')) setPriceStr(prev => prev + val);
      return;
    }
    if (priceStr.length >= 8) return;
    setPriceStr(prev => prev + val);
  };

  const isApplyDisabled = !name.trim() || !priceStr || isNaN(parseFloat(priceStr)) || parseFloat(priceStr) <= 0;

  return (
    <div className="fixed inset-0 flex items-center justify-center z-[200] animate-fade-in" style={{ background: "rgba(160,150,145,0.40)", backdropFilter: "blur(14px)" }} onClick={onClose}>
      <div className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden flex flex-col bg-white shadow-2xl animate-scale-in" onClick={e => e.stopPropagation()}>
        <div style={{ height: 5, background: "linear-gradient(90deg, #f97316 0%, #ea580c 100%)" }} />
        <div className="p-7">
          <button onClick={onClose} className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-gray-400 hover:bg-gray-100 transition-colors">✕</button>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-sm" style={{ background: "rgba(249, 115, 22, 0.1)", border: "1px solid rgba(249, 115, 22, 0.2)", color: "#f97316" }}>
              📦
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest mb-0.5 text-orange-600" style={{ fontFamily: "Poppins" }}>Enclosed Mode</p>
              <h2 className="text-lg font-black text-gray-900 leading-none" style={{ fontFamily: "Poppins" }}>Custom Item</h2>
            </div>
          </div>

          <div className="mb-4">
            <label className="text-[10px] font-bold text-gray-500 mb-1 block uppercase tracking-wide" style={{ fontFamily: "Poppins" }}>Item Name</label>
            <KeyboardInput keyboardLayout="default" value={name} onChange={setName} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold text-gray-900 outline-none focus:border-orange-500 transition-colors" placeholder="e.g. Commission" style={{ fontFamily: "Poppins" }} />
          </div>

          <div className="bg-gray-50 rounded-2xl p-4 border border-gray-200 mb-6 flex flex-col items-center">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1" style={{ fontFamily: "Poppins" }}>Item Price</span>
            <div className="flex items-end gap-1">
              <span className="text-xl font-bold text-gray-400 mb-1">₱</span>
              <span className="text-4xl font-black text-gray-900" style={{ fontFamily: "Poppins" }}>{priceStr || '0'}</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 mb-6">
            {['1','2','3','4','5','6','7','8','9','.','0','⌫'].map(btn => (
              <button key={btn} onClick={() => handleNumpad(btn)} className="h-14 bg-white border border-gray-200 rounded-xl text-xl font-bold text-gray-800 hover:bg-gray-50 active:scale-95 transition-all shadow-sm flex items-center justify-center" style={{ fontFamily: "Poppins", color: btn === '⌫' ? '#ef4444' : '#1f2937' }}>
                {btn}
              </button>
            ))}
          </div>

          <button
            onClick={() => onAdd(name, parseFloat(priceStr))}
            disabled={isApplyDisabled}
            className="w-full py-4 rounded-xl font-bold text-white transition-all active:scale-95 shadow-md disabled:cursor-not-allowed bg-orange-500 hover:bg-orange-600"
            style={{
              fontFamily: "Poppins",
              opacity: isApplyDisabled ? 0.5 : 1,
            }}
          >
            Add Custom Item →
          </button>
        </div>
      </div>
    </div>
  );
}

function ItemNoteModal({ itemName, initialNote, onSave, onClose }: { itemName: string; initialNote: string; onSave: (note: string) => void; onClose: () => void; }) {
  const [note, setNote] = useState(initialNote);
  return (
    <div className="fixed inset-0 flex items-center justify-center z-[100000] animate-fade-in" style={{ background: "rgba(15,23,42,0.7)", backdropFilter: "blur(10px)" }} onClick={onClose}>
      <div className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden bg-white shadow-2xl animate-scale-in" onClick={e => e.stopPropagation()}>
        <div style={{ height: 5, background: "linear-gradient(90deg, #f97316 0%, #ea580c 100%)" }} />
        <div className="p-7">
          <button onClick={onClose} className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-gray-400 hover:bg-gray-100 transition-colors">✕</button>
          <div className="flex items-center gap-3 mb-5">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-sm" style={{ background: "rgba(249,115,22,0.1)", border: "1px solid rgba(249,115,22,0.2)", color: "#f97316" }}>
              <FiMessageSquare size={20} />
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest mb-0.5 text-orange-600" style={{ fontFamily: "Poppins" }}>Item Note</p>
              <h2 className="text-lg font-black text-gray-900 leading-tight" style={{ fontFamily: "Poppins" }}>{itemName}</h2>
            </div>
          </div>
          <KeyboardInput
            keyboardLayout="default"
            value={note}
            onChange={setNote}
            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold text-gray-900 outline-none focus:border-orange-500 transition-colors mb-6"
            placeholder="e.g. No sugar, extra napkins..."
            style={{ fontFamily: "Poppins" }}
          />
          <div className="flex gap-3">
            {initialNote && (
              <button onClick={() => onSave('')} className="px-5 py-3.5 rounded-xl font-bold bg-red-50 text-red-500 hover:bg-red-100 transition-colors text-sm" style={{ fontFamily: "Poppins" }}>
                Clear
              </button>
            )}
            <button onClick={() => onSave(note)} className="flex-1 py-3.5 rounded-xl font-bold text-white bg-orange-500 hover:bg-orange-600 transition-colors shadow-md" style={{ fontFamily: "Poppins" }}>
              Save Note
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function POSDashboard() {
  const router = useRouter();

  // CONTEXT PRINTER HOOK
  const { tillStatus, openDrawer, printDirect, usbPrinter } = usePrinter();

  // ── Solo Parent discount tracker ──────────────────────────────────────────
  // const checkSoloLimit = async (idNum: string, pendingDiscountAmt: number): Promise<boolean> => {
  //   // Returns true = OK to proceed, false = limit exceeded
  //   try {
  //     const res  = await fetch(`/api/solo-discount-tracker?idNum=${encodeURIComponent(idNum)}`);
  //     const data = await res.json();

  //     if (data.limit <= 0) return true; // 0 means no limit configured

  //     const wouldTotal = data.totalDiscountUsed + pendingDiscountAmt;

  //     if (wouldTotal > data.limit) {
  //       const remaining = Math.max(0, data.limit - data.totalDiscountUsed);
  //       sileo.error({
  //         title: "Solo Parent Limit Reached",
  //         description: `This customer has already used ₱${data.totalDiscountUsed.toFixed(2)} of their ₱${data.limit.toFixed(2)} ${data.resetTiming} limit. Remaining: ₱${remaining.toFixed(2)}.`,
  //         fill: "#171717",
  //         styles: { title: "text-white!", description: "text-white/75!" },
  //       });
  //       return false;
  //     }
  //     return true;
  //   } catch {
  //     // Network error — allow proceed (fail open) but warn
  //     sileo.error({
  //       title: "Limit Check Failed",
  //       description: "Could not verify Solo Parent discount limit. Proceeding anyway.",
  //       fill: "#171717",
  //       styles: { title: "text-white!", description: "text-white/75!" },
  //     });
  //     return true;
  //   }
  // };
  // REPLACE the existing checkSoloLimit with:
  const checkSoloLimit = async (idNum: string, pendingDiscountAmt: number): Promise<boolean> => {
    try {
      const res  = await fetch(`/api/solo-discount-tracker?idNum=${encodeURIComponent(idNum)}`);
      const data = await res.json();

      if (data.limit <= 0) return true; // no limit configured

      const wouldTotal = data.totalDiscountUsed + pendingDiscountAmt;

      if (wouldTotal > data.limit) {
        const remaining = Math.max(0, data.limit - data.totalDiscountUsed);
        sileo.error({
          title: "Solo Parent Limit Reached",
          description: `This customer has already used ₱${data.totalDiscountUsed.toFixed(2)} of their ₱${data.limit.toFixed(2)} ${data.resetTiming} limit. Remaining: ₱${remaining.toFixed(2)}.`,
          fill: "#171717",
          styles: { title: "text-white!", description: "text-white/75!" },
        });
        return false;
      }
      return true;
    } catch {
      sileo.error({
        title: "Limit Check Failed",
        description: "Could not verify Solo Parent discount limit. Proceeding anyway.",
        fill: "#171717",
        styles: { title: "text-white!", description: "text-white/75!" },
      });
      return true; // fail-open
    }
  };


  const [hasActiveSession, setHasActiveSession]   = useState<boolean>(true);
  const [showSessionMenu, setShowSessionMenu]     = useState(false);
  const [sessionDetails, setSessionDetails]       = useState<{id: string, cash: string, time: string, number: string, businessDayId: string, shiftNumber: string} | null>(null);

  const [drawerCash, setDrawerCash]               = useState<number>(0);
  const [showCashDropModal, setShowCashDropModal] = useState<boolean>(false);
  const [showLimitWarningModal, setShowLimitWarningModal] = useState<boolean>(false);

  const [workstationId, setWorkstationId]         = useState<string>(getWorkstationId() || "001");
  const [activeCategory, setActiveCategory]       = useState<string>("");
  const [activeSubcategory, setActiveSubcategory] = useState<string>("");

  const [cart, setCart]                           = useState<any[]>([]);
  const [itemNoteModal, setItemNoteModal] = useState<{ idx: number; name: string; currentNote: string } | null>(null);
  const [remoteProducts, setRemoteProducts]       = useState<Record<string, { sections: { title: string; items: any[] }[]; subcategories?: { id: string; name: string; items: any[] }[] }>>();
  const [loadingMenu, setLoadingMenu]             = useState(false);
  const [remoteCategories, setRemoteCategories]   = useState<{ key: string; id: string; name: string; img?: string }[]>();

  const [inventoryState, setInventoryState]       = useState<Record<string, number>>({});

  const [appliedDiscount, setAppliedDiscount]     = useState<DiscountType>(null);
  const [showDiscountModal, setShowDiscountModal] = useState(false);
  const [availableDiscounts, setAvailableDiscounts] = useState<SimpleDiscount[]>([]);
  const [loadingDiscounts, setLoadingDiscounts]   = useState(false);

  const [transactionType, setTransactionType]     = useState<TransactionType>("REGULAR");
  const [showTransactionTypeModal, setShowTransactionTypeModal] = useState(false);
  const [orderType, setOrderType] = useState<"DineIn" | "TakeOut" | "Grab" | "Panda" | "">("");

  const [showPaymentModal, setShowPaymentModal]   = useState(false);
  const [selectedCartItems, setSelectedCartItems] = useState<number[]>([]);

  const [managerPinModal, setManagerPinModal]     = useState<{ show: boolean; action: "delete" | "transactionType" | "discount" | null }>({ show: false, action: null });
  const [pendingTransactionType, setPendingTransactionType] = useState<TransactionType | null>(null);
  const [pendingDiscount, setPendingDiscount]     = useState<DiscountType | null>(null);

  const [showDiplomatModal, setShowDiplomatModal] = useState(false);
  const [tempDiplomatData, setTempDiplomatData]   = useState<CustomerInfo | null>(null);
  const [diplomatData, setDiplomatData]           = useState<CustomerInfo | null>(null);

  const [showCustomerInfoModal, setShowCustomerInfoModal] = useState(false);
  const [customerInfo, setCustomerInfo] = useState<CustomerInfo | null>(null);

  const [showLineItemDiscountModal, setShowLineItemDiscountModal] = useState(false);
  const [tempCustomLineDiscount, setTempCustomLineDiscount] = useState<{ slotDetails: Array<{name: string, idNum: string}>, selectedKeys: string[] } | null>(null);
  const [customLineDiscount, setCustomLineDiscount] = useState<{ slotDetails: Array<{name: string, idNum: string}>, selectedKeys: string[] } | null>(null);

  const [showSoloDiscountModal, setShowSoloDiscountModal] = useState(false);
  const [tempCustomSoloDiscountAmt, setTempCustomSoloDiscountAmt] = useState<number | null>(null);
  const [customSoloDiscountAmt, setCustomSoloDiscountAmt] = useState<number | null>(null);

  const [showCustomItemModal, setShowCustomItemModal] = useState(false);
  const [showEncloseModal, setShowEncloseModal] = useState(false);

  const [paymentMethod, setPaymentMethod]         = useState<string>("cash");
  const [paymentSubMethod, setPaymentSubMethod]   = useState<string>("");
  const [inputAmount, setInputAmount]             = useState<string>("");
  const [payments, setPayments]                   = useState<Array<{ method: string; amount: number; refCode?: string; tendered?: number }>>([]);
  const [orderNumber, setOrderNumber]             = useState<string>("");
  const [salesNumber, setSalesNumber]             = useState<string>("");
  const [kioskOrderNo, setKioskOrderNo]           = useState<string | null>(null);
  const [kioskOrderId, setKioskOrderId]           = useState<string | null>(null);
  const [transactionNumber, setTransactionNumber] = useState<string>("");
  const [staffId, setStaffId]                     = useState<string>("");
  const [staffName, setStaffName]                 = useState<string>("");

  const [showPrinterBypass, setShowPrinterBypass] = useState(false);
  const [isTerminalProcessing, setIsTerminalProcessing] = useState(false);
  const [srpwdFlowActive, setSrpwdFlowActive] = useState(false);
  const [activeBusinessDate, setActiveBusinessDate] = useState<string | null>(null);
  const [showShiftDateMismatchModal, setShowShiftDateMismatchModal] = useState(false);

  useEffect(() => {
    setWorkstationId(getWorkstationId());
    fetch('/api/cashier-session?status=all_open')
      .then(res => res.json())
      .then(data => {
        if (data.businessDayDate) {
          setActiveBusinessDate(data.businessDayDate);
        }
      })
      .catch(err => console.error("Failed to fetch business date", err));
  }, []);

  
  const saveItemNote = (note: string) => {
    if (!itemNoteModal) return;
    setCart(prev => prev.map((c, i) => i === itemNoteModal.idx ? { ...c, notes: note.trim() } : c));
    setItemNoteModal(null);
  };

  const [productQtyModal, setProductQtyModal] = useState<any | null>(null);

  const [voidReasonsList, setVoidReasonsList] = useState<any[]>([]);
  const [showVoidReasonModal, setShowVoidReasonModal] = useState(false);
  const [selectedVoidReason, setSelectedVoidReason] = useState("");

  const [currentUserRole, setCurrentUserRole]     = useState<number>(1);
  const [showCustomQtyNumpad, setShowCustomQtyNumpad] = useState(false);
  const [isPrinterExpanded, setIsPrinterExpanded] = useState(false);
  
  const isOnline = useConnection();
  const { syncNow } = useSyncContext();
  const { status: syncStatus, pendingCount, lastSyncedAt } = useSyncContext();

  const [srpwdReassigning, setSrpwdReassigning] = useState(false);

  //FOR DEBUGGING
  const [debugPaymentApiResponse, setDebugPaymentApiResponse] = useState<any>(null);

  //for processing payments
  const isProcessingPayment = useRef(false);

  // Ref so the cart-length effect can read the latest value without it being a dep
  const customLineDiscountRef = useRef<typeof customLineDiscount>(null);
  const customerInfoRef = useRef<typeof customerInfo>(null);
  useEffect(() => { customerInfoRef.current = customerInfo; }, [customerInfo]);


  useEffect(() => { customLineDiscountRef.current = customLineDiscount; }, [customLineDiscount]);

  

  useEffect(() => {
    getCachedVoidReasons().then((reasons) => {
      if (reasons) setVoidReasonsList(reasons);
    });
  }, []);


  // Hydration-safe: read localStorage after mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem("printer_indicator_expanded");
      if (saved !== null) setIsPrinterExpanded(saved === "true");
    } catch {}
  }, []);

  const togglePrinterExpanded = () => {
    setIsPrinterExpanded(prev => {
      const next = !prev;
      try { localStorage.setItem("printer_indicator_expanded", String(next)); } catch {}
      return next;
    });
  };


  const [cashLimits, setCashLimits] = useState({
    dropWarning: 9000,
    dropMax: 20000,
    fundLimit: 0,
  });

  const [showStock, setShowStock] = useState<boolean>(false);
  const [fiscal, setFiscal] = useState<any>(null);
  const [discountScopes, setDiscountScopes] = useState<Record<string, string>>({});
  
  const WORKSTATION_ID = getWorkstationId() || '001';
  useEffect(() => {
    fetch(`/api/settings?workstationId=${WORKSTATION_ID}`)
      .then(res => res.json())
      .then(data => {
        setCashLimits({
          dropWarning: Number(data.cashDropWarningAmount) || 9000,
          dropMax:     Number(data.cashDropMaxAmount)     || 20000,
          fundLimit:   Number(data.cashFundLimit)         || 0,
        });
        setShowStock(Boolean(data.showStock));
        setFiscal(data);
        if (data.discountScopes) setDiscountScopes(data.discountScopes);
      })
      .catch(() => {});
  }, []);

  // Add after state declarations, before handlers:
  const computeSoloDiscountAmt = useCallback((currentCart: any[], currentRawTotal: number): number => {
    // SOLO always uses 20% of net (rawTotal / 1.12)
    return (currentRawTotal / 1.12) * 0.20;
  }, []);

   // ─── SR/PWD cart-growth watcher ───────────────────────────────────────────
  const prevCartLengthRef    = useRef<number>(-1);
  const prevTransactionType  = useRef<string>(transactionType);
 
  useEffect(() => {
    const prevTxType = prevTransactionType.current;
    prevTransactionType.current = transactionType;
 
    if (!isSRPWD(transactionType)) {
      prevCartLengthRef.current = cart.length;
      return;
    }
 
    if (!isSRPWD(prevTxType as TransactionType)) {
      prevCartLengthRef.current = cart.length;
      return;
    }
 
    const clDiscount = customLineDiscountRef.current;
    if (!clDiscount) {
      prevCartLengthRef.current = cart.length;
      return;
    }
 
    const prevLen = prevCartLengthRef.current;
    const currLen = cart.length;
    prevCartLengthRef.current = currLen;
 
    if (prevLen < 0 || currLen <= prevLen) return;
 
    const currentCustomerInfo = customerInfoRef.current;
    const customers = parseSrpwdCustomers(currentCustomerInfo);
    const N = Math.max(1, customers.length);

    const expandedCart: any[] = [];
    cart.forEach(c => {
      // Unconditionally split all items into qty 1 so auto-select can isolate pairs
      for (let i = 0; i < c.qty; i++) {
        expandedCart.push({ ...c, qty: 1 });
      }
    });

    prevCartLengthRef.current = expandedCart.length;
    setCart(expandedCart);

    const autoKeys = autoSelectSrpwdItemKeys(expandedCart, N);
    setTempCustomLineDiscount(prev => ({
      slotDetails: prev?.slotDetails ?? [{
        name: currentCustomerInfo?.name || '',
        idNum: currentCustomerInfo?.idNum || '',
        isConfirmed: true,
      }],
      selectedKeys: autoKeys,
    }));
    setSrpwdReassigning(true);
    setPendingTransactionType(transactionType);
    setShowLineItemDiscountModal(true);
  }, [cart.length, transactionType]); // eslint-disable-line react-hooks/exhaustive-deps
  // ──────────────────────────────────────────────────────────────────────────

  const getCartDeductions = useCallback((currentCart: any[]) => {
    const deductions: Record<string, number> = {};
    const deduct = (itemObj: any, qty: number) => {
      const targetId = getInventoryId(itemObj);
      if (targetId && !String(targetId).startsWith('CUSTOM-')) {
        deductions[targetId] = (deductions[targetId] || 0) + qty;
      }
    };
    currentCart.forEach((c: any) => {
        const groups = c.modifierGroups || [];
        const isCombo = groups.some((g: any) => (g.modifiers || []).some((mod: any) => String(mod.id || '').startsWith('MD-')));
        
        if (!isCombo) {
          deduct(c, c.qty);
        }
        
        const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
        mods.forEach((m: any) => {
          if (!String(m.id || '').startsWith('CL-')) {
            deduct(m, m.qty * c.qty);
          }
        });
    });
    return deductions;
  }, []);

  const checkStockBeforePayment = async (): Promise<{
    ok: boolean;
    outOfStock: Array<{ itemName: string; available: number; requested: number }>;
  }> => {
    // Always fetch the latest inventory — stocks may have changed since the cart was built
    let freshInventory = { ...inventoryState };
    try {
      const res = await fetch('/api/inventory');
      if (res.ok) {
        const data = await res.json();
        const mapped = Array.isArray(data)
          ? data.reduce((acc: any, item: any) => ({ ...acc, [item.itemId || item.id]: item.quantity }), {})
          : (data && typeof data === 'object' ? data : null);
        if (mapped) { freshInventory = mapped; setInventoryState(mapped); }
      }
    } catch {}

    // What does the current cart require?
    const needed = getCartDeductions(cart);

    // Which inventory IDs are now short?
    const shortfallIds = new Set(
      Object.entries(needed)
        .filter(([id, qty]) => qty > (freshInventory[id] ?? 0))
        .map(([id]) => id)
    );

    if (shortfallIds.size === 0) return { ok: true, outOfStock: [] };

    // Map shortfall IDs back to human-readable cart item names
    const outOfStock: Array<{ itemName: string; available: number; requested: number }> = [];
    const seen = new Set<string>();

    cart.forEach((c: any) => {
      const groups = c.modifierGroups || [];
      const isCombo = groups.some((g: any) => (g.modifiers || []).some((mod: any) => String(mod.id || '').startsWith('MD-')));

      if (!isCombo) {
        const id = getInventoryId(c);
        if (shortfallIds.has(id) && !seen.has(id)) {
          seen.add(id);
          outOfStock.push({
            itemName: c.name,
            available: freshInventory[id] ?? 0,
            requested: needed[id] ?? 0,
          });
        }
      }

      const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
      mods.forEach((m: any) => {
        if (String(m.id || '').startsWith('CL-')) return;
        const id = getInventoryId(m);
        if (shortfallIds.has(id) && !seen.has(id)) {
          seen.add(id);
          outOfStock.push({ itemName: `${c.name} — ${m.name}`, available: freshInventory[id] ?? 0, requested: needed[id] ?? 0 });
        }
      });
    });

    return { ok: false, outOfStock };
  };

  const addBulkToCart = async (item: any, amount: number) => {  // make async
    // SOLO limit pre-check
    if (transactionType === 'SOLO' && customerInfo?.idNum) {
      const newItemGross = item.price * amount;
      const projectedRaw = rawTotal + newItemGross;
      const projectedDiscount = (projectedRaw / 1.12) * 0.20;
      const ok = await checkSoloLimit(customerInfo.idNum, projectedDiscount);
      if (!ok) return;
    }
    const hasAnyModifiers = (item.modifierGroups || []).filter(
      (g: any) => (g.modifiers || []).length > 0
    ).length > 0;

    if (hasAnyModifiers) {
      setProductQtyModal(null);
      addToCart(item);
      return;
    }

    const stockId = getInventoryId(item);
    const isCustom = String(stockId).startsWith('CUSTOM-');
    const available = inventoryState[stockId] ?? 0;
    const currentDeductions = getCartDeductions(cart);
    const inCart = currentDeductions[stockId] || 0;

    if (!isCustom && inCart + amount > available) {
       sileo.error({ title: "Out of Stock", description: `Only ${available} amount of stock is available.`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }});
       return;
    }

    setCart((prev) => {
      if (isSRPWD(transactionType)) {
        const newItems = Array.from({ length: amount }).map(() => ({ ...item, qty: 1, modifiers: [] }));
        return [...prev, ...newItems];
      }
      const existing = prev.find((c) => c.id === item.id && Array.isArray(c.modifiers) && c.modifiers.length === 0);
      if (existing) {
        const idx = prev.indexOf(existing);
        setPopId(`${item.id}-${idx}`);
        setTimeout(() => setPopId(null), 300);
        return prev.map((c) => (c === existing ? { ...c, qty: c.qty + amount } : c));
      }
      return [...prev, { ...item, qty: amount, modifiers: [] }];
    });
    setProductQtyModal(null);
    if (!isSRPWD(transactionType) || !customLineDiscountRef.current) {
      setCustomLineDiscount(null);
      setTempCustomLineDiscount(null);
      setCustomSoloDiscountAmt(null);
    }
  };

  const [modifierSelectionMode, setModifierSelectionMode] = useState(false);
  const [pendingItem, setPendingItem]             = useState<any>(null);
  const [selectedModifiers, setSelectedModifiers] = useState<Record<string, Record<string, { data: any, qty: number }>>>({});
  const [qtyModal, setQtyModal]                   = useState<{ group: any, mod: any, qty: number, max: number } | null>(null);
  const [currentStep, setCurrentStep]             = useState(0);
  const [showReview, setShowReview]               = useState(false);

  const [debugMode, setDebugMode]                 = useState(false);

  const cartContainerRef = useRef<HTMLDivElement>(null);
  const [popId, setPopId] = useState<string|null>(null);

  const tapTimerRef = useRef<NodeJS.Timeout | null>(null);

  const [cartItemQtyModal, setCartItemQtyModal] = useState<{ item: any; idx: number; currentQty: number } | null>(null);
  const cartLongPressRef = useRef<NodeJS.Timeout | null>(null);

  

  const startCartLongPress = (c: any, idx: number) => {
    cartLongPressRef.current = setTimeout(() => {
      cartLongPressRef.current = null;
      setCartItemQtyModal({ item: c, idx, currentQty: c.qty });
    }, 500);
  };
  const cancelCartLongPress = () => {
    if (cartLongPressRef.current) { clearTimeout(cartLongPressRef.current); cartLongPressRef.current = null; }
  };
  const touchStartPos = useRef<{ x: number, y: number } | null>(null);
  const isDragging = useRef(false);

  const handleGlobalTouchStart = useCallback((e: React.TouchEvent | React.MouseEvent) => {
    isDragging.current = false;
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    touchStartPos.current = { x: clientX, y: clientY };
  }, []);

  const handleGlobalTouchMove = useCallback((e: React.TouchEvent | React.MouseEvent) => {
    if (!touchStartPos.current) return;
    
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    const dx = clientX - touchStartPos.current.x;
    const dy = clientY - touchStartPos.current.y;
    
    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
      isDragging.current = true;
      cancelCartLongPress();
    }
  }, []);

  const handleGlobalTouchEnd = useCallback(() => {
    setTimeout(() => {
      isDragging.current = false;
      touchStartPos.current = null;
    }, 50);
  }, []);

  const handleGlobalClickCapture = useCallback((e: React.MouseEvent) => {
    if (isDragging.current) {
      e.stopPropagation();
      e.preventDefault();
    }
  }, []);

  useEffect(() => {
    if (cartContainerRef.current) {
      cartContainerRef.current.scrollTo({ top: cartContainerRef.current.scrollHeight, behavior: "smooth" });
    }
  }, [cart.length]);

  const getDiscountInfo = (discountId: DiscountType | string | number | null): any => {
    if (!discountId) return null;
    const defaultDiscount = DISCOUNT_OPTIONS.find((d) => d.id === discountId);
    if (defaultDiscount) return defaultDiscount;
    const dbDiscount = availableDiscounts.find((d) => d.id === discountId);
    if (dbDiscount) {
      return {
        id: dbDiscount.id, label: dbDiscount.campaign_name, sublabel: "Campaign Discount", icon: "🏷️",
        discount_type: dbDiscount.discount_type, discount_value: parseFloat(dbDiscount.discount_value),
        discount_cap: dbDiscount.discount_cap || 0,
        rate: dbDiscount.discount_type === 'percentage' ? parseFloat(dbDiscount.discount_value) / 100 : 0,
      };
    }
    if (discountId === "SC")
      return { id: "SC", label: "SC (Senior Citizen)", sublabel: "Senior Citizen Discount", icon: "👴",
        rate: 0.20, color: "#2563eb", bg: "rgba(37,99,235,0.07)", border: "rgba(37,99,235,0.20)",
        activeBg: "rgba(37,99,235,0.12)", activeBorder: "#2563eb" };
    if (discountId === "PWD_DISC")
      return { id: "PWD_DISC", label: "PWD", sublabel: "Person with Disability Discount", icon: "♿",
        rate: 0.20, color: "#7c3aed", bg: "rgba(124,58,237,0.07)", border: "rgba(124,58,237,0.20)",
        activeBg: "rgba(124,58,237,0.12)", activeBorder: "#7c3aed" };
    if (discountId === "VAT_EXEMPT_ONLY") return { id: "VAT_EXEMPT_ONLY", label: "VAT Exempt", sublabel: "VAT Exemption", icon: "✨", isVatExempt: true };
    return null;
  };

  const calculateDiscountAmount = (discountInfo: any, grossAmount: number, currentCart: any[], txType: string): number => {
    if (!discountInfo) return 0;
    if (discountInfo.isVatExempt) {
      if (txType === 'PEZA') {
        let taxableAmount = 0;
        currentCart.forEach(c => {
          if (c.taxable !== false) {
            const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
            const modsPrice = mods.reduce((mSum: number, m: any) => mSum + ((m.price || 0) * (m.qty || 1)) / 100, 0);
            taxableAmount += (c.price + modsPrice) * c.qty;
          }
        });
        return taxableAmount / 1.12 * 0.12;
      }
      return grossAmount / 1.12 * 0.12;
    }
    let amount = 0;
    if (discountInfo.discount_type) {
      if (discountInfo.discount_type === 'percentage') amount = grossAmount * (discountInfo.discount_value / 100);
      else if (discountInfo.discount_type === 'fixed_amount') amount = Math.min(discountInfo.discount_value, grossAmount);
    } else {
      amount = grossAmount * (discountInfo.rate || 0);
    }
    if (discountInfo.discount_cap && discountInfo.discount_cap > 0) amount = Math.min(amount, discountInfo.discount_cap);
    return amount;
  };

  const buildDefaultModifiers = (item: any): Record<string, Record<string, { data: any; qty: number }>> => {
    const defaults: Record<string, Record<string, { data: any; qty: number }>> = {};
    const currentDeductions = getCartDeductions(cart);
    for (const group of (item.modifierGroups || [])) {
      const defaultMods = (group.modifiers || []).filter((m: any) => m.isDefault);
      if (defaultMods.length === 0) continue;
      defaults[group.id] = {};
      for (const mod of defaultMods) {
        if (!String(mod.id || '').startsWith('CL-')) {
          const modStockId = getInventoryId(mod);
          const available = inventoryState[modStockId] ?? 0;
          const inCart = currentDeductions[modStockId] || 0;
          if (available - inCart < 1) continue;
        }
        defaults[group.id][mod.id] = { data: mod, qty: 1 };
      }
    }
    return defaults;
  };

  

  useEffect(() => {
    const fetchInventory = async () => {
      try {
        const res = await fetch('/api/inventory');
        if (res.ok) {
          const data = await res.json();
          if (data && typeof data === 'object' && !Array.isArray(data)) {
            setInventoryState(data);
          } else if (Array.isArray(data)) {
            const state = data.reduce((acc: any, item: any) => ({ ...acc, [item.itemId || item.id]: item.quantity }), {});
            setInventoryState(state);
          }
        }
      } catch (err) {
        console.error("Inventory fetch error:", err);
      }
    };
    fetchInventory();
    const intervalId = setInterval(fetchInventory, 5000); 
    return () => clearInterval(intervalId);
  }, []);

  useEffect(() => {
    const handleTriggerEnclose = () => setShowEncloseModal(true);
    window.addEventListener('trigger-enclose', handleTriggerEnclose);
    return () => window.removeEventListener('trigger-enclose', handleTriggerEnclose);
  }, []);

  const handleOpenShift = async (floatAmount: number, breakdown: Record<number, number>) => {
    
    try {
      const res = await fetch('/api/cashier-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          startingCash: String(floatAmount),
          openingBreakdown: breakdown,
          staffId: staffId || "Unknown",
          staffName: staffName || "Unknown",
          terminalId: getWorkstationId() || '001',
        })
      });
      if (!res.ok) {  
        const errData = await res.json();
        if (res.status === 409) {
          if (errData.code === 'MULTI_LOGIN_DETECTED') {  
            sileo.error({
              title: "Register Already Open",
              description: `You have an open register session on terminal ${errData.existingSession?.terminalId || 'Unknown'}. Close it first.`,
              fill: "#171717",
              styles: { title: "text-white!", description: "text-white/75!" }
            });
            return;
          } else if (errData.code === 'TERMINAL_ALREADY_OPEN') {
            sileo.error({
              title: "Terminal In Use",
              description: `${errData.existingSession?.staffName} has an open session here. Ask them to close it first.`,
              fill: "#171717",
              styles: { title: "text-white!", description: "text-white/75!" }
            });
            return;
          }
        }

        throw new Error(errData.error || "Failed to open register");
      }
      const data = await res.json();
      setHasActiveSession(true);
      setSessionDetails({
        id: data.session.sessionId,
        cash: data.session.startingCash,
        time: data.session.openedAt,
        number: data.session.shiftNumber,
        businessDayId: data.businessDayId,
        shiftNumber: data.shiftNumber,
      });
      setDrawerCash(floatAmount);

      // 1. Fetch and increment transaction number
      let txNum = '';
      try {
        const storeData = JSON.parse(localStorage.getItem("store_data") || "{}");
        const seriesType = storeData?.series_type || 'WS';
        const wsId = getWorkstationId() || '001';

        const txRes = await fetch('/api/numbers?type=transaction', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ seriesType, workstationId: wsId })
        });
        if (txRes.ok) {
          const txData = await txRes.json();
          txNum = txData.number;
        }
      } catch (err) {
        console.error("Failed to fetch transaction counter", err);
      }
      if (!txNum) {
        txNum = `TXN-${Date.now()}`;
      }

      // ── Print opening fund receipt ────────
      try {
        const ReceiptPrintingModule = await import("../../../src/libs/ReceiptPrinting");
        let printStoreData = JSON.parse(localStorage.getItem("store_data") || "null");

        try {
          const res = await fetch("/api/store");
          if (res.ok) {
            const dbData = await res.json();
            console.log(dbData?.payload)
            printStoreData = dbData?.payload; // Safely unwrap
            localStorage.setItem("store_data", JSON.stringify(printStoreData));
          }
        } catch (fetchErr) {
          console.error("Failed to fetch store data during print fallback:", fetchErr);
        }

        // 3. Absolute Last Resort (If DB is completely down)
        if (!printStoreData) {
            printStoreData = { id: 1, store_id: "store-00001", name: "Dunkin' Pasalubong", address: "Makati City, Metro Manila, Philippines", contact_number: "", merchant_id: "gXPOS-123", receiptFormats: [] };
        }

        let printReceiptFormats = printStoreData?.receiptFormats || [];
        const printSelectedFormatId = "3";
        let printReceiptFormat = printReceiptFormats.find((f: any) => String(f.id) === printSelectedFormatId) || printReceiptFormats[0];

        const receiptText = ReceiptPrintingModule.buildOpenShiftText({
          storeData:    printStoreData,
          cashierName:  staffName,
          shiftNumber:  data.session.shiftNumber,
          receiptFormat: printReceiptFormat,
          sessionId:    data.session.sessionId,
          amount:       floatAmount,
          breakdown,
          fiscal,
          transactionNumber: txNum // <--- Pass the new transaction number to the printer!
        });
        printDirect(receiptText, false);
      } catch (printErr) {
        console.error("[Printer] Opening fund print error:", printErr);
        // non-fatal — shift is already open
      }

      sileo.success({
        title: "Register Opened successfully!",
        fill: "#171717",
        styles: { title: "text-white!", description: "text-white/75!" },
        duration: 1000
      });
    } catch (error: any) {
      sileo.error({
        title: 'Failed to open register',
        description: error.message || 'Please try again.',
        fill: "#171717",
        styles: { title: "text-white!", description: "text-white/75!" }
      });
    }
  };

  const handleCashDrop = async (amount: number, breakdown: Record<number, number>) => {
    try {
      // 1. Fetch counters for the deposit receipt
      let txNum = '';
      let ctrlNum = '';
      try {
        const storeData = JSON.parse(localStorage.getItem("store_data") || "{}");
        const seriesType = storeData?.series_type || 'WS';
        const wsId = getWorkstationId() || '001';

        const txRes = await fetch('/api/numbers?type=transaction', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ seriesType, workstationId: wsId })
        });
        if (txRes.ok) {
          const txData = await txRes.json();
          txNum = txData.number;
        }

        const ctrlRes = await fetch('/api/numbers?type=cashDrop', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ seriesType, workstationId: wsId })
        });
        if (ctrlRes.ok) {
          const ctrlData = await ctrlRes.json();
          ctrlNum = `PD${ctrlData.raw}`;
        }
      } catch (err) {
        console.error("Failed to fetch counters for cash drop", err);
      }

      const res = await fetch('/api/cashier-session', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'add_drop', amount, timestamp: new Date().toISOString(), staffId, staffName }) });
      if (res.ok) {
        setDrawerCash(prev => prev - amount);
        
        openDrawer();
        try {
          const ReceiptPrintingModule = await import("../../../src/libs/ReceiptPrinting");
          let printStoreData = JSON.parse(localStorage.getItem("store_data") || "null");
          if (!printStoreData) printStoreData = { name: "Store Name Not Set" };

          const receiptText = ReceiptPrintingModule.buildCashDropText({
            storeData: printStoreData,
            cashierName: staffName,
            amount: amount,
            breakdown: breakdown,
            fiscal: fiscal,
            width: 48,
            transactionNumber: txNum,
            controlNumber: ctrlNum
          });

          printDirect(receiptText, false); 
        } catch (printErr) {
          console.error("Print drop error:", printErr);
        }

        sileo.success({ title: "Cash Drop Successful", description: `Dropped ${formatMoney(amount)}`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }, duration: 1000 });
        setShowCashDropModal(false);
      } else throw new Error();
    } catch { sileo.error({ title: "Failed to drop cash", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } }); }
  };

  const handleDeleteSelectedInitiate = () => {
    setShowVoidReasonModal(true);
  };

  const handleVoidReasonConfirm = () => {
    setShowVoidReasonModal(false);
    setManagerPinModal({ show: true, action: "delete" });
  };

  const addToCart = async (item: any) => {   // make async
    // SOLO limit pre-check
    if (transactionType === 'SOLO' && customerInfo?.idNum) {
      const modsPrice = 0; // new item, no modifiers selected yet
      const newItemGross = item.price;
      const projectedRaw = rawTotal + newItemGross;
      const projectedDiscount = (projectedRaw / 1.12) * 0.20;
      const ok = await checkSoloLimit(customerInfo.idNum, projectedDiscount);
      if (!ok) return;
    }
    const modifierGroups = (item.modifierGroups || []).filter(
      (g: any) => (g.modifiers || []).length > 0
    );

    if (modifierGroups.length > 0) {
      const isCombo = modifierGroups.some((g: any) => (g.modifiers || []).some((mod: any) => String(mod.id || '').startsWith('MD-')));
      if (!isCombo) {
        const stockId = getInventoryId(item);
        const available = inventoryState[stockId] ?? 0;
        const inCart = getCartDeductions(cart)[stockId] || 0;
        if (inCart + 1 > available) {
          sileo.error({ title: "Out of Stock", description: `Only ${available} amount of stock is available for ${item.name}.`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
          return;
        }
      }
      setPendingItem(item); setModifierSelectionMode(true); setSelectedModifiers(buildDefaultModifiers(item)); setCurrentStep(0); setShowReview(false);
    } else {
      const stockId = getInventoryId(item);
      const isCustom = String(stockId).startsWith('CUSTOM-');
      const available = inventoryState[stockId] ?? 0;
      const currentDeductions = getCartDeductions(cart);
      const inCart = currentDeductions[stockId] || 0;

      if (!isCustom && inCart + 1 > available) {
        sileo.error({ title: "Out of Stock", description: `Only ${available} amount of stock is available.`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }});
        return;
      }

      setCart((prev) => {
        if (isSRPWD(transactionType)) {
          return [...prev, { ...item, qty: 1, modifiers: [] }];
        }
        const existing = prev.find((c) => c.id === item.id && Array.isArray(c.modifiers) && c.modifiers.length === 0);
        if (existing) {
          const idx = prev.indexOf(existing);
          setPopId(`${item.id}-${idx}`);
          setTimeout(() => setPopId(null), 300);
          return prev.map((c) => (c === existing ? { ...c, qty: c.qty + 1 } : c));
        }
        return [...prev, { ...item, qty: 1, modifiers: [] }];
      });
    }

    if (transactionType === 'SOLO' && customerInfo?.idNum) {
      // Recompute discount with the new item included; check asynchronously
      // We use a microtask so cart state has settled
      setTimeout(async () => {
        const newRaw = cart.reduce((sum: number, c: any) => {
          const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
          const modsPrice = mods.reduce((s: number, m: any) => s + ((m.price || 0) * (m.qty || 1)) / 100, 0);
          return sum + (c.price + modsPrice) * c.qty;
        }, 0) + (item.price); // approximate: new item base price
        const pendingAmt = (newRaw / 1.12) * 0.20;
        await checkSoloLimit(customerInfo.idNum!, pendingAmt);
        // Note: we don't block here (item already added) — this is a warning check.
        // To block, move this logic before setCart.
      }, 50);
    }
    
    if (!isSRPWD(transactionType) || !customLineDiscountRef.current) {
      setCustomLineDiscount(null); setTempCustomLineDiscount(null); setCustomSoloDiscountAmt(null);
    }

  };

  const getGroupTotal = useCallback((groupId: string) => {
    const groupSelections = selectedModifiers[groupId] || {};
    return Object.values(groupSelections).reduce((sum: number, item: any) => sum + item.qty, 0);
  }, [selectedModifiers]);

  const openQtyModalOrSelect = useCallback((group: any, mod: any, currentModQty: number) => {
    const currentTotal = getGroupTotal(group.id);
    const maxAllowedOverall = group.selectionRangeMax || 1;

    const isCLMod = String(mod.id || '').startsWith('CL-');

    let alreadyDeductedForThisItem = 0;
    if (pendingItem && pendingItem._editingCartIdx !== undefined) {
      const cartItem = cart[pendingItem._editingCartIdx];
      const existingMod = (Array.isArray(cartItem.modifiers) ? cartItem.modifiers : Object.values(cartItem.modifiers || {})).find((m: any) => String(m.id) === String(mod.id));
      if (existingMod) {
         alreadyDeductedForThisItem = existingMod.qty * cartItem.qty;
      }
    }

    if (!isCLMod) {
      const modStockId = getInventoryId(mod);
      const available = inventoryState[modStockId] ?? 0;
      const inCart = getCartDeductions(cart)[modStockId] || 0;
      const trueAvailable = available - inCart + alreadyDeductedForThisItem;

      if (trueAvailable <= 0 && currentModQty === 0) {
        sileo.error({ title: "Out of Stock", description: `Only ${available} amount of stock is available.`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
        return;
      }
    }

    if (maxAllowedOverall === 1) {
      if (!isCLMod) {
        const modStockId = getInventoryId(mod);
        const available = inventoryState[modStockId] ?? 0;
        const inCart = getCartDeductions(cart)[modStockId] || 0;
        const trueAvailable = available - inCart + alreadyDeductedForThisItem;
        if (trueAvailable < 1) {
          sileo.error({ title: "Out of Stock", description: `Only ${available} amount of stock is available.`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
          return;
        }
      }
      setSelectedModifiers(prev => ({ ...prev, [group.id]: { [mod.id]: { data: mod, qty: 1 } } }));
      return;
    }

    const remainingAllowance = maxAllowedOverall - currentTotal;
    const maxAllowedForThisMod = remainingAllowance + currentModQty;
    const absoluteMax = isCLMod
      ? maxAllowedForThisMod  
      : (() => {
          const modStockId = getInventoryId(mod);
          const available = inventoryState[modStockId] ?? 0;
          const inCart = getCartDeductions(cart)[modStockId] || 0;
          const trueAvailable = available - inCart + alreadyDeductedForThisItem;
          return Math.min(maxAllowedForThisMod, trueAvailable);
        })();

    if (absoluteMax <= 0 && currentModQty === 0) {
      sileo.error({ title: "Limit Reached", description: `You can only select up to ${group.selectionRangeMax} items.`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
      return;
    }

    setQtyModal({ group, mod, qty: currentModQty > 0 ? currentModQty : 1, max: absoluteMax });
  }, [getGroupTotal, inventoryState, cart, getCartDeductions, pendingItem]);
  
  const handleModifierTap = (group: any, mod: any) => {
    const currentModQty = selectedModifiers[group.id]?.[mod.id]?.qty || 0;
    if (currentModQty > 0) {
      if (tapTimerRef.current) {
        clearTimeout(tapTimerRef.current); tapTimerRef.current = null;
        setSelectedModifiers(prev => { const updatedGroup = { ...(prev[group.id] || {}) }; delete updatedGroup[mod.id]; return { ...prev, [group.id]: updatedGroup }; });
      } else {
        tapTimerRef.current = setTimeout(() => { tapTimerRef.current = null; openQtyModalOrSelect(group, mod, currentModQty); }, 250);
      }
    } else { openQtyModalOrSelect(group, mod, 0); }
  };

  const confirmQtySelection = (qty: number) => {
    if (!qtyModal) return;
    setSelectedModifiers(prev => {
      const updatedGroup = { ...(prev[qtyModal.group.id] || {}) };
      if (qty > 0) updatedGroup[qtyModal.mod.id] = { data: qtyModal.mod, qty };
      else delete updatedGroup[qtyModal.mod.id];
      return { ...prev, [qtyModal.group.id]: updatedGroup };
    });
    setQtyModal(null);
  };

  const handleConfirmModifiers = async () => {  // make async
    if (!pendingItem) return;
    // SOLO limit pre-check
    if (transactionType === 'SOLO' && customerInfo?.idNum && pendingItem._editingCartIdx === undefined) {
      const mods = Object.values(selectedModifiers).flatMap(g => Object.values(g));
      const modsPrice = mods.reduce((s: number, m: any) => s + ((m.data.price || 0) * m.qty) / 100, 0);
      const newItemGross = pendingItem.price + modsPrice;
      const projectedRaw = rawTotal + newItemGross;
      const projectedDiscount = (projectedRaw / 1.12) * 0.20;
      const ok = await checkSoloLimit(customerInfo.idNum, projectedDiscount);
      if (!ok) return;
    }
    if (!pendingItem) return;
    const flatModifiers: any[] = [];
    Object.values(selectedModifiers).forEach(groupObj => {
      Object.values(groupObj).forEach(modItem => { if (modItem.qty > 0) flatModifiers.push({ ...modItem.data, qty: modItem.qty }); });
    });

    if (pendingItem._editingCartIdx !== undefined) {
      const idx = pendingItem._editingCartIdx;
      setCart(prev => prev.map((c, i) => i === idx ? { ...c, modifiers: flatModifiers } : c));
      exitModifierMode();
      return;
    }

    setCart((prev) => {
      const key = JSON.stringify(flatModifiers);
      if (isSRPWD(transactionType)) {
        return [...prev, { ...pendingItem, qty: 1, modifiers: flatModifiers }];
      }
      const existing = prev.find((c) => c.id === pendingItem.id && JSON.stringify(Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {})) === key);
      if (existing) return prev.map((c) => (c === existing ? { ...c, qty: c.qty + 1 } : c));
      return [...prev, { ...pendingItem, qty: 1, modifiers: flatModifiers }];
    });
    exitModifierMode();
    if (!isSRPWD(transactionType) || !customLineDiscountRef.current) {
      setCustomLineDiscount(null); setTempCustomLineDiscount(null); setCustomSoloDiscountAmt(null);
    }

  };

  const exitModifierMode = () => { setModifierSelectionMode(false); setPendingItem(null); setSelectedModifiers({}); setCurrentStep(0); setShowReview(false); };

  const changeQty = (cartIdx: number, delta: number) => {
    if (delta > 0) {
      const item = cart[cartIdx];
      const currentDeductions = getCartDeductions(cart);
      const groups = item.modifierGroups || [];
      const isCombo = groups.some((g: any) => (g.modifiers || []).some((mod: any) => String(mod.id || '').startsWith('MD-')));
      const mods = Array.isArray(item.modifiers) ? item.modifiers : Object.values(item.modifiers || {});

      if (!isCombo) {
        const stockId = getInventoryId(item);
        const isCustom = String(stockId).startsWith('CUSTOM-');
        const available = inventoryState[stockId] ?? 0;
        const inCart = currentDeductions[stockId] || 0;
        if (!isCustom && inCart + delta > available) {
          sileo.error({ title: "Out of Stock", description: `Only ${available} amount of stock is available for ${item.name}.`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
          return;
        }
      }
      
      for (const m of mods) {
        if (String(m.id || '').startsWith('CL-')) continue;
        const mStockId = getInventoryId(m);
        const mAvailable = inventoryState[mStockId] ?? 0;
        const mInCart = currentDeductions[mStockId] || 0;
        if (mInCart + (m.qty * delta) > mAvailable) {
          sileo.error({ title: "Out of Stock", description: `Only ${mAvailable} amount of stock is available for ${m.name}.`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
          return;
        }
      }
    }
    if (isSRPWD(transactionType) && delta > 0) {
      setCart(prev => {
        const itemToDuplicate = { ...prev[cartIdx], qty: 1 };
        const newItems = Array.from({length: delta}).map(() => ({ ...itemToDuplicate }));
        return [...prev, ...newItems];
      });
    } else {
      setCart((prev) => prev.map((c, i) => (i === cartIdx ? { ...c, qty: Math.max(1, c.qty + delta) } : c)));
    }
    if (!isSRPWD(transactionType) || !customLineDiscountRef.current) {
      setCustomLineDiscount(null); setTempCustomLineDiscount(null); setCustomSoloDiscountAmt(null);
    }
  };

  const editCartItemModifiers = (cartIdx: number) => {
  const item = cart[cartIdx];
  const modifiersList = Array.isArray(item.modifiers) ? item.modifiers : Object.values(item.modifiers || {});
  if (modifiersList.length === 0) return;

  const prefilled: Record<string, Record<string, { data: any; qty: number }>> = {};
  modifiersList.forEach((m: any) => {
    const group = (item.modifierGroups || []).find((g: any) =>
      (g.modifiers || []).some((gm: any) => gm.id === m.id)
    );
    if (group) {
      if (!prefilled[group.id]) prefilled[group.id] = {};
      prefilled[group.id][m.id] = { data: m, qty: m.qty || 1 };
    }
  });

  setPendingItem({ ...item, _editingCartIdx: cartIdx });
  setSelectedModifiers(prefilled);
  setModifierSelectionMode(true);
  setCurrentStep(0);
  setShowReview(false);
};

  const toggleSelectCartItem = (idx: number) => {
    setSelectedCartItems((prev) => prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]);
  };

  const handleManagerPinConfirm = async (pin: string) => {
    try {
      const manager = await getAssociateByPin(pin);
      if (!manager) { sileo.error({ title: "Invalid PIN!", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } }); return; }
      if (manager.user.role !== 2) { sileo.error({ title: "Managers only!", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } }); return; }
      const action = managerPinModal.action;
      setManagerPinModal({ show: false, action: null });
      if (action === "delete") {
        const voidedItems = cart.filter((_, idx) => selectedCartItems.includes(idx));
        const updatedCart = cart.filter((_, idx) => !selectedCartItems.includes(idx));
        
        fetch('/api/voids', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            items: voidedItems,
            reason: selectedVoidReason,
            managerName: manager.user.name,
            managerId: manager.user.id,
            cashierName: staffName,
            cashierId: staffId,
            staffId,                          // needed for session lookup fallback
            sessionId: sessionDetails?.id,    // primary link
            workstationId,
            timestamp: new Date().toISOString()
          })
        }).catch(console.error);

        setCart(updatedCart);

        if (updatedCart.length === 0) {
          // Cart is now empty — reset everything and unlink Kiosk
          setTransactionType('REGULAR');
          setCustomLineDiscount(null);
          setTempCustomLineDiscount(null);
          setCustomSoloDiscountAmt(null);
          setDiplomatData(null);
          if (kioskOrderNo) {
            setKioskOrderNo(null);
            setKioskOrderId(null);
            localStorage.removeItem('active_kiosk_order');
          }
        } else if (isSRPWD(transactionType)) {
          // Always re-show the item selection modal so the cashier
          // can re-assign the discount after a void. Auto-select top N by value.
          const customers = parseSrpwdCustomers(customerInfo);
          const N = Math.max(1, customers.length);
          const autoKeys = autoSelectSrpwdItemKeys(updatedCart, N);
          setTempCustomLineDiscount(prev => ({
            slotDetails: prev?.slotDetails ?? [{
              name: customerInfo?.name || '',
              idNum: customerInfo?.idNum || '',
              isConfirmed: true,
            }],
            selectedKeys: autoKeys,
          }));
          setSrpwdReassigning(true);
          setPendingTransactionType(transactionType === 'SR' ? 'SR' : 'PWD');
          setShowLineItemDiscountModal(true);
        } else {
          // Non-SRPWD — clear discount state normally
          setCustomLineDiscount(null);
          setTempCustomLineDiscount(null);
          setCustomSoloDiscountAmt(null);
        }

        setSelectedCartItems([]);
        setSelectedVoidReason("");
        
        if (workstationId) {
          if (updatedCart.length === 0) {
            await clearCartFromDatabase(workstationId);
          } else {
            await saveCartToDatabase(workstationId, updatedCart, appliedDiscount);
          }
        }
        
        sileo.success({ title: `Items deleted by ${manager.user.name}`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }, duration: 1000 });
      } else if (action === "transactionType" && pendingTransactionType) {
        setTransactionType(pendingTransactionType);
        const typeConfig = TRANSACTION_TYPES.find(t => t.id === pendingTransactionType);
        if (typeConfig?.autoDiscount) setAppliedDiscount(null);
        
        if (DIPLOMAT_FLOW_TYPES.includes(pendingTransactionType) && tempDiplomatData?.name) {
          setDiplomatData(tempDiplomatData);
          setCustomerInfo(tempDiplomatData);
        } else {
          setDiplomatData(null);
        }

        if (pendingTransactionType === 'CUSTOM') {
          setCustomSoloDiscountAmt(tempCustomSoloDiscountAmt);
        } else {
          setCustomSoloDiscountAmt(null);
        }

        if (isSRPWD(pendingTransactionType) && tempCustomLineDiscount) {
          setCustomLineDiscount(tempCustomLineDiscount);
          const firstSlot = tempCustomLineDiscount.slotDetails[0];
          if (firstSlot && firstSlot.name) {
            setCustomerInfo(prev => ({
              name:    firstSlot.name,
              idNum:   firstSlot.idNum,
              tin:     prev?.tin     || '',
              address: prev?.address || '',  
            }));
          }
        } else {
          setCustomLineDiscount(null);
        }
        const appliedType = pendingTransactionType;
        setPendingTransactionType(null); setTempDiplomatData(null); setTempCustomLineDiscount(null); setTempCustomSoloDiscountAmt(null);
        sileo.success({ title: `${typeConfig?.label} applied by ${manager.user.name}`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }, duration: 1000 });
      } else if (action === "discount" && pendingDiscount !== null) {
        setAppliedDiscount(pendingDiscount); setPendingDiscount(null);
        const discountInfo = getDiscountInfo(pendingDiscount);
        sileo.success({ title: `${discountInfo?.label || 'Discount'} applied by ${manager.user.name}`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }, duration: 1000 });
      }
    } catch { sileo.error({ title: "Error verifying PIN", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } }); }
  };

  const rawTotal = cart.reduce((sum, c, idx) => {
    const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
    const modsPrice = mods.reduce((s: number, m: any) => s + ((m.price || 0) * (m.qty || 1)) / 100, 0);
    let lGross = (c.price + modsPrice) * c.qty;
    
    if (isSRPWD(transactionType) && customLineDiscount?.selectedKeys.includes(`item-${idx}`)) {
      if (c.modifierGroups?.length > 0 && c.udfs?.['UDF-1']?.value) {
        const udfVal = Number(c.udfs['UDF-1'].value);
        if (!isNaN(udfVal)) lGross = udfVal * c.qty;
      }
    }
    return sum + lGross;
  }, 0);
  
  const totalItemsQty = cart.reduce((sum, c) => sum + c.qty, 0);

  const netPrice = rawTotal / 1.12;

  const transactionTypeConfig = TRANSACTION_TYPES.find(t => t.id === transactionType);
  const autoDiscount = transactionTypeConfig?.autoDiscount;
  const effectiveDiscount = autoDiscount || appliedDiscount;
  const discountInfo = getDiscountInfo(effectiveDiscount);

  let discountAmt    = 0;
  let vatableSales   = 0;
  let vatExemptSales = 0;
  let zeroRatedSales = 0;
  let vatAmount      = 0; // VAT from unselected (vatable) items only

  if (isSRPWD(transactionType)) {
    if (customLineDiscount) {
      cart.forEach((c, idx) => {
        const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
        const modsPrice = mods.reduce((s: number, m: any) => s + ((m.price || 0) * (m.qty || 1)) / 100, 0);
        const standardGross = (c.price + modsPrice) * c.qty;

        if (customLineDiscount.selectedKeys.includes(`item-${idx}`)) {
          // Selected: use UDF-1 override if present
          let exemptGross = standardGross;
          if (c.modifierGroups?.length > 0 && c.udfs?.['UDF-1']?.value) {
            const udfVal = Number(c.udfs['UDF-1'].value);
            if (!isNaN(udfVal)) exemptGross = udfVal * c.qty;
          }
          const net = exemptGross / 1.12;
          vatExemptSales += net;
          discountAmt    += net * 0.20;
        } else {
          // Unselected: always standard gross, no UDF-1
          const net = standardGross / 1.12;
          vatableSales += net;
          vatAmount    += standardGross - net;
        }
      });

    } else {
      // No line-item selection made yet — treat full order as vatable
      // until the cashier assigns items. This keeps the totals sane
      // before the discount modal is confirmed.
      vatableSales = rawTotal / 1.12;
      vatAmount    = rawTotal - vatableSales;
    }
  } else if (transactionType === 'ATHLETE') {
    const athleteNet = rawTotal / 1.12;       // 255 / 1.12 = 227.678571
    discountAmt  = athleteNet * 0.20;         // 227.678571 × 0.20 = 45.535714
    vatableSales = athleteNet;                // 227.678571
    vatAmount    = rawTotal - athleteNet;     // 255 - 227.678571 = 27.321429
  } else if (transactionType === 'MEDAL') {
    discountAmt  = (rawTotal / 1.12) * 0.20;
    vatableSales = rawTotal / 1.12;
    vatAmount    = rawTotal - vatableSales;
    } else if (transactionType === 'SOLO') {
    discountAmt  = (rawTotal / 1.12) * 0.20;
    vatableSales = rawTotal / 1.12;
    vatAmount    = rawTotal - vatableSales;
  } else if (transactionType === 'CUSTOM') {
    discountAmt  = customSoloDiscountAmt || 0;
    vatableSales = rawTotal / 1.12;
    vatAmount    = rawTotal - vatableSales;
  } else if (transactionType === 'DIPLOMAT') {
    const rawVat   = rawTotal - netPrice;
    discountAmt    = rawVat;
    zeroRatedSales = netPrice;
    vatAmount      = 0;
  } else if (transactionType === 'PEZA') {
    let taxableGross = 0, nonTaxableGross = 0;
    cart.forEach(c => {
      const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
      const modsPrice = mods.reduce((s: number, m: any) => s + ((m.price || 0) * (m.qty || 1)) / 100, 0);
      const lineTotal = (c.price + modsPrice) * c.qty;
      if (c.taxable !== false) taxableGross += lineTotal;
      else nonTaxableGross += lineTotal;
    });
    discountAmt    = taxableGross - taxableGross / 1.12;
    zeroRatedSales = taxableGross / 1.12 + nonTaxableGross;
    vatAmount      = 0;
  } else {
    // REGULAR
    vatAmount    = rawTotal - netPrice;
    discountAmt  = calculateDiscountAmount(discountInfo, rawTotal, cart, transactionType);
    vatableSales = (rawTotal - discountAmt) / 1.12;
  }

  // actualTax: the VAT that actually appears on the receipt.
  // For REGULAR it's the full VAT; for SRPWD it's only the VAT
  // from unselected (non-exempt) items; for all other special types it's 0.
  const actualTax = (
    transactionType === 'REGULAR' ||
    isSRPWD(transactionType)   ||
    transactionType === 'ATHLETE' ||
    transactionType === 'MEDAL'   ||
    transactionType === 'SOLO'    ||
    transactionType === 'CUSTOM'
  ) ? vatAmount : 0;

  const srpwdSelectedGross = (isSRPWD(transactionType) && customLineDiscount)
    ? cart.reduce((sum, c, idx) => {
        if (!customLineDiscount.selectedKeys.includes(`item-${idx}`)) return sum;
        const mods = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
        const modsPrice = mods.reduce((s: number, m: any) => s + ((m.price || 0) * (m.qty || 1)) / 100, 0);
        let gross = (c.price + modsPrice) * c.qty;
        if (c.modifierGroups?.length > 0 && c.udfs?.['UDF-1']?.value) {
          const udfVal = Number(c.udfs['UDF-1'].value);
          if (!isNaN(udfVal)) gross = udfVal * c.qty;
        }
        return sum + gross;
      }, 0)
    : 0;

    
  const subtotal = (() => {
    if (isSRPWD(transactionType) && customLineDiscount) {
      const unselectedTotal = rawTotal - srpwdSelectedGross;              // unselected: full VAT-inclusive
      const selectedAfterVatAndDiscount = (srpwdSelectedGross / 1.12) * 0.80; // selected: -VAT then -20%
      return unselectedTotal + selectedAfterVatAndDiscount;
    }
    return rawTotal - discountAmt;
  })();

  const finalTotal = (() => {
    if (isSRPWD(transactionType) && customLineDiscount) {
      const unselectedTotal = rawTotal - srpwdSelectedGross;              // unselected: full VAT-inclusive
      const selectedAfterVatAndDiscount = (srpwdSelectedGross / 1.12) * 0.80; // selected: -VAT then -20%
      return unselectedTotal + selectedAfterVatAndDiscount; 
    }
    return rawTotal - discountAmt;
  })();
  // if (isSRPWD(transactionType) || transactionType === 'ATHLETE' || 
  //     transactionType === 'SOLO'  || transactionType === 'MEDAL') {
  //   vatExemptSales = finalTotal;
  // }
  const allSelectableLines = useMemo(() => getSelectableLines(cart, remoteProducts, transactionType), [cart, remoteProducts, transactionType]);
  const isDiscountDisabled = autoDiscount !== null && autoDiscount !== undefined;

  const getTransactionTypeDisabledReason = (typeId: string): string | null => {
    if (transactionType !== 'REGULAR' && transactionType !== typeId) return "Clear active first";
    const scope = discountScopes[typeId];
    if (!scope) return "Not configured";
    if (scope === 'all') return null;
    if (scope === 'dine_in') return orderType === 'DineIn' ? null : "Dine-In only";
    if (scope === 'take_out') return (orderType === 'TakeOut' || orderType === 'Grab' || orderType === 'Panda') ? null : "Take-Out only";
    return "Unavailable";
  };

  const effectiveCategoryData = remoteProducts && activeCategory ? remoteProducts[activeCategory] : undefined;

  useEffect(() => {
    (async () => {
      try {
        setLoadingMenu(true);
        const menuRecord = await getMenuFromCache();
        if (!menuRecord) return;

        // Pre-pass: flatten every item across every category/subcategory so
        // "AD-0|<n>" modifiers can resolve to item "IT-<n>" no matter which
        // category that item actually lives in (e.g. Misc Items vs Beverages).
        const itemsById: Record<string, any> = {};
        const collectItems = (list: any[]) => {
          (list || []).forEach((it: any) => { itemsById[it.id] = it; });
        };
        (menuRecord.categories || []).forEach((cat: any) => {
          collectItems(cat.items);
          (cat.subcategories || []).forEach((s: any) => collectItems(s.items));
        });

        // AD-0|<n>  -> references item "IT-<n>" directly; look up ITS gx_item_code
        // MD-0|<n>  -> "<n>" IS the gx_item_code already (bundle/combo convention)
        // anything else (CL- sizes/addons) -> not stock-tracked, leave untouched
        const resolveModifierItemCode = (mod: any): string | null => {
          const id = String(mod.id || '');
          if (id.startsWith('AD-')) {
            const suffix = id.split('|')[1];
            return itemsById[`IT-${suffix}`]?.gx_item_code || null;
          }
          if (id.startsWith('MD-')) {
            return id.split('|')[1] || null;
          }
          return null;
        };

        const mapModifierGroups = (groups: any[]) => (groups || []).map((mg: any) => ({
          ...mg,
          modifiers: (mg.modifiers || []).map((mod: any) => ({ ...mod, itemCode: resolveModifierItemCode(mod) })),
        }));

        const mapped: Record<string, any> = {};
        const remCats: { key: string; id: string; name: string; img?: string }[] = [];
        (menuRecord.categories || []).forEach((cat: any) => {
          const key = String(cat.id || cat.name).toLowerCase();
          remCats.push({ key, id: String(cat.id || ''), name: cat.name || key, img: cat.image || '' });
          const mapItems = (items: any[]) => (items || []).map((it: any) => {
            const raw = Number(it.gx_price);
            return {
              id: it.id,
              name: it.name,
              barcode: it.barcode,
              itemCode: it.gx_item_code || null,
              price: Number.isFinite(raw) ? raw : 0,
              taxable: it.taxable,
              imgReal: (it.photos?.length) ? it.photos[0] : (it.image || ''),
              modifierGroups: mapModifierGroups(it.modifierGroups),
              upSellItems: it.upSellItems || [],
              udfs: it.udfs || {}
            };
          });
          if (cat.subcategories?.length) {
            mapped[key] = { sections: [{ title: cat.name, items: [] }], subcategories: cat.subcategories.map((s: any) => ({ id: s.id, name: s.name, items: mapItems(s.items) })) };
          } else {
            mapped[key] = { sections: [{ title: cat.name, items: mapItems(cat.items) }] };
          }
        });

        remCats.push({ key: 'open_items', id: 'open_items', name: 'Open Items', img: '' });
        mapped['open_items'] = { 
          sections: [{ 
            title: 'Open Items', 
            items: [
              { id: 'ADD_CUSTOM', name: 'Add Custom Item', price: 0, isAddButton: true }
            ] 
          }] 
        };

        setRemoteProducts(mapped); setRemoteCategories(remCats);
        if (remCats[0]?.key) setActiveCategory(remCats[0].key);
      } finally { setLoadingMenu(false); }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        setLoadingDiscounts(true);
        const refreshedDiscounts = await refreshDiscountsFromAPI();
        setAvailableDiscounts(refreshedDiscounts);
        if (refreshedDiscounts.length === 0) setAvailableDiscounts(await getDiscountsFromCache());
      } catch { setAvailableDiscounts([]); } finally { setLoadingDiscounts(false); }
    })();
  }, []);

  useEffect(() => {
    try {
      const lastLoginStr = localStorage.getItem('lastLogin');
      if (lastLoginStr) {
        const lastLogin = JSON.parse(lastLoginStr);
        if (lastLogin?.user_id) setStaffId(String(lastLogin.user_id));
        if (lastLogin?.name) setStaffName(String(lastLogin.name));
        if (lastLogin?.role !== undefined) setCurrentUserRole(Number(lastLogin.role));
      }
    } catch {}
  }, []); 

  useEffect(() => {
    if (!staffId) return;

    fetch(`/api/cashier-session?staffId=${staffId}`)
      .then(res => res.json())
      .then(data => {
        if (data.active && data.session) {
          setHasActiveSession(true);

          if (data.businessDayDate) {
            setActiveBusinessDate(data.businessDayDate);
          }

          if (currentUserRole !== 2 && data.businessDayDate) {
             const systemDateStr = new Date().toISOString().split('T')[0];
             if (data.businessDayDate !== systemDateStr) {
                setShowShiftDateMismatchModal(true);
             }
          }
          setSessionDetails({ id: data.session.sessionId, cash: data.session.startingCash, time: data.session.openedAt, number: data.session.shiftNumber, businessDayId: data.businessDayId, shiftNumber: data.session.shiftNumber });
          const sCash = parseFloat(data.session.startingCash || "0");
          const drops = data.session.cashDrops || [];
          const droppedTotal = drops.reduce((sum: number, d: any) => sum + parseFloat(d.amount), 0);
          const today = new Date().toISOString().split('T')[0];
          fetch(`/api/transactions?limit=1000&date=${today}`).then(r => r.json()).then(txData => {
            const sessionTx = (txData.transactions || []).filter((tx: any) => new Date(tx.createdAt || tx.date).getTime() >= new Date(data.session.openedAt).getTime());
            let totalCashSales = 0;
            sessionTx.forEach((tx: any) => {
              const isVoid = tx.status === 'voided' || tx.orderState === 'VOIDED';
              const isRefund = tx.status === 'refunded' || tx.orderState === 'REFUNDED';
              if (isVoid || isRefund) return;
              const totalBill = (tx.price?.eaterPayment || tx.total || 0) / 100;
              let nonCash = 0;
              if (tx.payment && Array.isArray(tx.payment) && tx.payment.length > 0) {
                tx.payment.forEach((p: any) => {
                  const m = String(p.PaymentMethod || p.method || 'CASH').toUpperCase();
                  let amt = Number(p.Amount || p.amount || 0);
                  if (p.Amount !== undefined && amt > 1000 && amt > totalBill * 50) amt /= 100;
                  if (m !== 'CASH') nonCash += amt;
                });
              } else {
                const rootMethod = String(tx.paymentMethod || tx.payment_type || tx.PaymentMethod || 'CASH').toUpperCase();
                if (rootMethod !== 'CASH') nonCash = totalBill;
              }
              totalCashSales += Math.max(0, totalBill - nonCash);
            });
            const current = sCash + totalCashSales - droppedTotal;
            setDrawerCash(current);
            if (current >= cashLimits.dropMax) setShowCashDropModal(true);
          });
        } else { 
          setHasActiveSession(false); 
          setSessionDetails(null);
          if (currentUserRole === 2 || currentUserRole === 1) {
            localStorage.setItem("managerBypass", "true");
            router.push('/Report');
            return;
          }
        }
      }).catch(() => { setHasActiveSession(false); });
  }, [staffId, currentUserRole, router]);

  useEffect(() => {
    try {
      const storedKiosk = localStorage.getItem('active_kiosk_order');
      if (storedKiosk) {
        const parsed = JSON.parse(storedKiosk);
        if (parsed.orderNo) setKioskOrderNo(parsed.orderNo);
        if (parsed.orderId) setKioskOrderId(parsed.orderId);
        if (parsed.orderType) {
          const typeMap: Record<string, string> = { 'DINE_IN': 'DineIn', 'TAKE_OUT': 'TakeOut', 'DineIn': 'DineIn', 'TakeOut': 'TakeOut' };
          const mappedType = typeMap[parsed.orderType.replace(/\s+/g, '_').toUpperCase()] || parsed.orderType;
          if (['DineIn', 'TakeOut', 'Grab', 'Panda'].includes(mappedType)) {
            setOrderType(mappedType as any);
          }
        }
      }
    } catch (e) {}
  }, []);

  useEffect(() => {
    (async () => {
      if (!workstationId) return;
      try {
        const savedCart = await loadCartFromDatabase(workstationId);
        if (savedCart?.items?.length > 0) { setCart(savedCart.items); if (savedCart.appliedDiscount) setAppliedDiscount(savedCart.appliedDiscount); }
      } catch {}
    })();
  }, [workstationId]);

  useEffect(() => {
    if (!workstationId || cart.length === 0) return;
    const timer = setTimeout(async () => { try { await saveCartToDatabase(workstationId, cart, appliedDiscount); } catch {} }, 1000);
    return () => clearTimeout(timer);
  }, [cart, appliedDiscount, workstationId]);

  const managerPinSubtitle = () => {
    if (managerPinModal.action === "delete") return `Manager PIN required to delete ${selectedCartItems.length} item(s)`;
    if (managerPinModal.action === "transactionType") return `Manager PIN required to apply ${TRANSACTION_TYPES.find(t => t.id === pendingTransactionType)?.label}`;
    if (managerPinModal.action === "discount") return `Manager PIN required to apply ${getDiscountInfo(pendingDiscount)?.label || 'discount'}`;
    return "";
  };

  const isDrawerFull = drawerCash >= cashLimits.dropMax;

  const handleSuccessfulPayment = (methodLabel: string, amt: number, refCode?: string, tendered?: number) => {
    const newPayments = [...payments, { method: methodLabel, amount: amt, refCode, tendered: tendered ?? amt }];
    setPayments(newPayments);
    const newPaidAmount = newPayments.reduce((s, p) => s + p.amount, 0);
    const newRemaining = finalTotal - newPaidAmount;
    setInputAmount(newRemaining > 0 ? parseFloat(newRemaining.toFixed(2)).toString() : "");
  };



  // transaction save
  const processPayment = async (bypassPrinter = false) => {
    if (isProcessingPayment.current) return;
      isProcessingPayment.current = true;

    if (!bypassPrinter && tillStatus === "OPEN") {
      isProcessingPayment.current = false;
      sileo.error({
        title: "Drawer Open",
        description: "Please close the cash drawer before completing.",
        fill: "#171717",
        styles: { title: "text-white!", description: "text-white/75!" }
      });
      return;
    }

    if (!bypassPrinter && tillStatus === "UNKNOWN") {
      isProcessingPayment.current = false;
      setShowPrinterBypass(true);  // renders the bypass bar above the button
      return;
    }

    setShowPrinterBypass(false);

    const paidAmount = payments.reduce((sum, p) => sum + p.amount, 0);
    if (finalTotal - paidAmount > 0.01) {
      isProcessingPayment.current = false;
      return;
    }

    // ── Stock validation ──────────────────────────────────────────────────────
    const stockCheck = await checkStockBeforePayment();
    if (!stockCheck.ok) {
      isProcessingPayment.current = false;
      // const lines = stockCheck.outOfStock
      //   .map(i => `• ${i.itemName}  (${i.available} available, ${i.requested} needed)`)
      //   .join('<br/>');
      sileo.error({
        title: "Items no longer in stock",
        description: <> 
          <p>
            Please remove the following from the cart before completing:
          </p>
          {
            stockCheck.outOfStock.map((i, x) => <p key={x}>{i.itemName} • {i.available} available - {i.requested} needed</p>)
          }
        </>,
        fill: "#171717",
        styles: { title: "text-white!", description: "text-white/75!" },
      });
      return;
    }

    try {
      const storeData = JSON.parse(localStorage.getItem("store_data") || "{}");
      const seriesType = storeData?.series_type || 'WS';
      
      const res = await fetch('/api/numbers?type=generateAll', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workstationId, seriesType, skipOrderNumber: !!kioskOrderNo })
      });
      if (!res.ok) throw new Error("Failed to fetch counters");
      const counters = await res.json();
      
      // Use local vars for the payload below so we don't depend on state timing
      var _orderNumber  = kioskOrderNo ? kioskOrderNo : String(counters.orderNumber);
      var _salesNumber  = counters.salesNumber;
      var _txnNumber    = counters.transactionNumber;

      setOrderNumber(_orderNumber);
      setSalesNumber(_salesNumber);
      setTransactionNumber(_txnNumber);
    } catch {
      isProcessingPayment.current = false;
      sileo.error({ title: 'Error fetching order numbers', description: 'Please try again.', fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
      return;
    }


    try {
      let guests: any[] = [];
      if (customerInfo) {
        // CustomerInfoModal stores the full multi-customer array as JSON in the address field.
        // Try to expand it; fall back to a single entry if it isn't an array.
        try {
          const parsed = JSON.parse(customerInfo.address || '');
          if (Array.isArray(parsed) && parsed.length > 0) {
            guests = parsed.map((c: any) => ({
              guestName: c.name       || '',
              GuestValidID: c.idNum   || '',
              tin:          c.tin     || '',
              address:      c.address || '',
            }));
          } else {
            throw new Error('not an array');
          }
        } catch {
          // address is a plain string (single customer, old data, or no address entered)
          guests.push({
            guestName:    customerInfo.name   || '',
            GuestValidID: customerInfo.idNum  || '',
            tin:          customerInfo.tin    || '',
            address:      customerInfo.address || '',
          });
        }
      } else if (isSRPWD(transactionType) && customLineDiscount) {
        guests = customLineDiscount.slotDetails.map((slot: any) => ({
          guestName:    slot.name  || '',
          GuestValidID: slot.idNum || '',
        }));
      }
      const storedTransactionType = transactionType === 'SR' ? 'SC' : transactionType;
      
      const cashTenderedCalc = payments.filter(p => p.method.toUpperCase() === 'CASH').reduce((sum, p) => sum + p.amount, 0);
      const calculatedChange = Math.max(0, Math.min(paidAmount - Number(finalTotal.toFixed(2)), cashTenderedCalc));

      const txnPayload: any = formatTransactionPayload({
        orderNumber: _orderNumber, 
        salesNumber: _salesNumber,
        transactionNumber: _txnNumber,          
        cart,
        payments: payments.map(p => ({ method: p.method, amount: p.amount, refCode: p.refCode || '', tendered: p.tendered ?? p.amount })),
        subtotal: rawTotal, 
        tax: actualTax, 
        vatableSales, 
        vatExemptSales, 
        zeroRatedSales,
        transactionType: storedTransactionType, 
        appliedDiscount: effectiveDiscount, 
        discountInfo, 
        discountAmount: discountAmt,
        change: calculatedChange,
        staffId, 
        sessionId: sessionDetails?.id, 
        guests, 
        shiftNo: parseInt(sessionDetails?.number), cashierName: staffName,
        kioskOrderId: kioskOrderId || undefined
      });
      txnPayload.featureFlags = { ...(txnPayload.featureFlags || {}), orderType };

      if (txnPayload.items && Array.isArray(txnPayload.items)) {
        txnPayload.items = txnPayload.items.map((item: any, idx: number) => {
          const cartItem = cart[idx];
          if (!cartItem) return item;

          const mods = Array.isArray(cartItem.modifiers)
            ? cartItem.modifiers
            : Object.values(cartItem.modifiers || {});
          const modsPrice = mods.reduce(
            (s: number, m: any) => s + ((m.price || 0) * (m.qty || 1)) / 100, 0
          );
          let grossPrice = (cartItem.price + modsPrice) * cartItem.qty;

          // SRPWD: honour UDF-1 override for combo items
          if (isSRPWD(transactionType) && customLineDiscount?.selectedKeys.includes(`item-${idx}`)) {
            if (cartItem.modifierGroups?.length > 0 && cartItem.udfs?.['UDF-1']?.value) {
              const udfVal = Number(cartItem.udfs['UDF-1'].value);
              if (!isNaN(udfVal)) grossPrice = udfVal * cartItem.qty;
            }
          }

          let itemDiscountAmount = 0;

          if (isSRPWD(transactionType) && customLineDiscount?.selectedKeys.includes(`item-${idx}`)) {
            itemDiscountAmount = (grossPrice / 1.12) * 0.20;
          } else if (transactionType === 'DIPLOMAT') {
            itemDiscountAmount = grossPrice * (0.12 / 1.12);
          } else if (transactionType === 'PEZA' && cartItem.taxable !== false) {
            itemDiscountAmount = grossPrice * (0.12 / 1.12);
          } else if (transactionType === 'ATHLETE' || transactionType === 'SOLO' || transactionType === 'MEDAL' || (transactionType === 'REGULAR' && appliedDiscount)) {
            // Proportional share of the total discount
            itemDiscountAmount = discountAmt * (grossPrice / (rawTotal || 1));
          }

          // Determine discountID as the actual discount percentage
          let discountID: string | undefined;
          if (isSRPWD(transactionType) && customLineDiscount?.selectedKeys.includes(`item-${idx}`)) {
            discountID = "20";
          } else if (transactionType === 'ATHLETE' || transactionType === 'MEDAL') {
            discountID = "20";
          } else if (transactionType === 'DIPLOMAT') {
            discountID = "12";
          } else if (transactionType === 'PEZA' && cartItem.taxable !== false) {
            discountID = "12";
          } else if (transactionType === 'SOLO') {
            discountID = "20";
          } else if (transactionType === 'CUSTOM' && discountAmt > 0 && rawTotal > 0) {
            discountID = Math.round((discountAmt / (rawTotal / 1.12)) * 100).toString();
          } else if (transactionType === 'REGULAR' && appliedDiscount && discountInfo && discountAmt > 0) {
            discountID = discountInfo.discount_type === 'percentage'
              ? Math.round(discountInfo.discount_value).toString()
              : Math.round((discountAmt / rawTotal) * 100).toString();
          }

          return {
            ...item,
            ...(itemDiscountAmount > 0.005 && { itemDiscount: Math.round(itemDiscountAmount * 100) }),
            ...(discountID !== undefined && { discountID }),
          };
        });
      }

      let receiptTextToPrint = "";
      let accountantReceiptText = "";
      try {
        const ReceiptPrintingModule = await import("../../../src/libs/ReceiptPrinting");
        const { buildReceiptText } = ReceiptPrintingModule;
        
        // 1. Check local storage first (Fastest, synchronous)
        let printStoreData = JSON.parse(localStorage.getItem("store_data") || "null");

        try {
          const res = await fetch("/api/store");
          if (res.ok) {
            const dbData = await res.json();
            console.log(dbData?.payload)
            printStoreData = dbData?.payload; // Safely unwrap
            localStorage.setItem("store_data", JSON.stringify(printStoreData));
          }
        } catch (fetchErr) {
          console.error("Failed to fetch store data during print fallback:", fetchErr);
        }

        // 3. Absolute Last Resort (If DB is completely down)
        if (!printStoreData) {
            printStoreData = { id: 1, store_id: "store-00001", name: "Dunkin' Pasalubong", address: "Makati City, Metro Manila, Philippines", contact_number: "", merchant_id: "gXPOS-123", receiptFormats: [] };
        }

        let printReceiptFormats = printStoreData?.receiptFormats || [];
        const printSelectedFormatId = "3";
        let printReceiptFormat = printReceiptFormats.find((f: any) => String(f.id) === printSelectedFormatId) || printReceiptFormats[0];
        
        if (!printReceiptFormat) {
            printReceiptFormat = { id: 3, name: "Regular Transaction", header: `<p style="margin:0;padding:0;line-height:1.2;" class="ql-align-center"><strong>RECEIPT</strong></p>`, footer: '<p style="margin:0;padding:0;line-height:1.2;" class="ql-align-center">Thank you for your purchase!</p>' };
        }
        const receiptData = {
          orderNumber: parseInt(_orderNumber), salesNumber: _salesNumber, transactionNumber: _txnNumber, staffId, staffName, transactionType, orderType, shiftNo: parseInt(sessionDetails?.shiftNumber || '0'),
          items: cart.map((item: any, idx: number) => {
            let modsTotalPrice = 0;
            const mods = Array.isArray(item.modifiers) ? item.modifiers : Object.values(item.modifiers || {});
            mods.forEach((m: any) => {
                modsTotalPrice += ((m.price || 0) / 100) * (m.qty || 1);
            });
            const standardGross = (item.price * item.qty) + modsTotalPrice;
            let effectiveGross = standardGross;
            let effectiveBasePrice = item.price;
            let effectiveMods = item.modifiers || [];

            if (isSRPWD(transactionType) && customLineDiscount?.selectedKeys.includes(`item-${idx}`)) {
                if (item.modifierGroups?.length > 0 && item.udfs?.['UDF-1']?.value) {
                  const udfVal = Number(item.udfs['UDF-1'].value);
                  if (!isNaN(udfVal)) {
                      effectiveGross = udfVal * item.qty;
                      effectiveBasePrice = udfVal;
                      effectiveMods = [];
                  }
                }
            }

            let itemDiscountAmount = 0;
            if (isSRPWD(transactionType) && customLineDiscount?.selectedKeys.includes(`item-${idx}`)) {
              itemDiscountAmount = (effectiveGross / 1.12) * 0.20;
            } else if (transactionType === 'DIPLOMAT' || (transactionType === 'PEZA' && item.taxable !== false)) {
              itemDiscountAmount = standardGross * (0.12 / 1.12);
            } else if (transactionType === 'ATHLETE' || transactionType === 'SOLO' || transactionType === 'MEDAL' || (transactionType === 'REGULAR' && appliedDiscount)) {
              itemDiscountAmount = discountAmt * (effectiveGross / (rawTotal || 1));
            }
            return { 
              quantity: item.qty, 
              itemName: item.name, 
              price: (isSRPWD(transactionType) && effectiveGross !== standardGross) ? (effectiveGross / item.qty) : item.price, 
              modifiers: effectiveMods, 
              itemDiscount: itemDiscountAmount > 0 ? itemDiscountAmount : undefined 
            };
          }),
          subtotal: rawTotal / 1.12, total: finalTotal, tax: actualTax, discountAmount: discountAmt, discountInfo: getDiscountInfo(effectiveDiscount),
          vatableSales, vatExemptSales, zeroRatedSales,
          payments: payments.map((p: any) => ({ method: p.method, amount: p.amount, refCode: p.refCode, tendered: p.tendered ?? p.amount })),
          change: calculatedChange, guests
        };
        const doublePrintTxKey = transactionType === 'SR' ? 'SC' : transactionType;
        let doublePrintConfig: Record<string, boolean> = {};
        try {
          const stored = localStorage.getItem('double_print_types');
          if (stored) doublePrintConfig = JSON.parse(stored);
        } catch {}
        const needsDoublePrint = transactionType !== 'REGULAR' && !!doublePrintConfig[doublePrintTxKey];

        if(receiptData.transactionType === 'SR') receiptData.transactionType = 'SC';

        if (needsDoublePrint) {
          receiptTextToPrint = buildReceiptText({ storeData: printStoreData, receiptFormat: printReceiptFormat, data: receiptData, copyType: 'customer', fiscal});
          accountantReceiptText = buildReceiptText({ storeData: printStoreData, receiptFormat: printReceiptFormat, data: receiptData, copyType: 'accountant', fiscal });
        } else {
          receiptTextToPrint = buildReceiptText({ storeData: printStoreData, receiptFormat: printReceiptFormat, data: receiptData, fiscal }, );
        }
        txnPayload.receiptText = receiptTextToPrint;
        console.log("Transaction:", txnPayload);
      } catch (err) { console.error("Receipt generation error:", err); }


      await saveTransaction(txnPayload);
      if (receiptTextToPrint && sessionDetails?.businessDayId) {
        logEJournalEntry({
          businessDayId: sessionDetails.businessDayId,
          workstationId: workstationId || '001',
          entryType: 'SALE',
          text: receiptTextToPrint,
        });
      }

      if (kioskOrderId) {
        try {
          // Adjust this URL if your route.ts is located in a different path (e.g., '/api/cms-orders')
          await fetch('/api/kiosk-orders', {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderId: kioskOrderId, salesNumber: _salesNumber, updatedCart: cart })
          });
        } catch (err) {
          console.error("Failed to update CMS order status:", err);
        }
      }


      // ── Record Solo Parent discount usage ─────────────────────────────────────
      if (transactionType === 'SOLO' && discountAmt > 0 && customerInfo?.idNum) {
        fetch('/api/solo-discount-tracker', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            idNum:          customerInfo.idNum,
            customerName:   customerInfo.name || '',
            discountAmount: discountAmt,
          }),
        }).catch(err => console.error('[SoloTracker] record error:', err));
      }

      const stockDeductions = getCartDeductions(cart);

      if (Object.keys(stockDeductions).length > 0) {
          const newInventory = { ...inventoryState };
          Object.entries(stockDeductions).forEach(([id, deductQty]) => {
              newInventory[id] = Math.max(0, (newInventory[id] || 0) - deductQty);
          });
          setInventoryState(newInventory);
          fetch('/api/inventory', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(newInventory)
          }).catch(err => console.error("Failed to update inventory", err));
      }

      const cashTendered = payments.filter(p => p.method.toUpperCase() === 'CASH').reduce((sum, p) => sum + p.amount, 0);
      const change = paidAmount - finalTotal;
      const actualChange = Math.max(0, Math.min(change, cashTendered));
      const netCashAdded = cashTendered > 0 ? cashTendered - actualChange : 0;
      if (netCashAdded > 0) {
        const newDrawerCash = drawerCash + netCashAdded;
        setDrawerCash(newDrawerCash);
        if (newDrawerCash >= cashLimits.dropMax && drawerCash < cashLimits.dropMax) setShowCashDropModal(true);
        else if (newDrawerCash >= cashLimits.dropWarning && drawerCash < cashLimits.dropWarning) setShowLimitWarningModal(true);
      }

      try {
        const hasCashPayment = payments.some(p => p.method.toUpperCase() === 'CASH');
        if (hasCashPayment) {
        }
      } catch (drawerErr) {
        console.error('[Drawer] Failed to open cash drawer:', drawerErr);
      }

      try {
        if (receiptTextToPrint) {
          if (accountantReceiptText) {
            // Double print — print sequentially: customer first, accountant second.
            // printDirect is serialised by the USB queue so no overlap occurs.
            printDirect(receiptTextToPrint, false);
            printDirect(accountantReceiptText, false);
          } else {
            printDirect(receiptTextToPrint, false).catch((err) => {
              console.error("Print error:", err);
              sileo.error({ 
                title: "Print Error", 
                description: "Failed to print receipt.", 
                fill: "#171717", 
                styles: { title: "text-white!", description: "text-white/75!" }
              });
            });
          }
        }
      } catch (err) {
        console.error("Print error:", err);
        sileo.error({ title: "Print Error", description: "Failed to print receipt.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }});
      }


      syncNow();
      sileo.success({ title: `Transaction #${orderNumber} saved!`, fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }, duration: 1000 });

      setShowPaymentModal(false); setCart([]); setAppliedDiscount(null); setDiplomatData(null); setCustomLineDiscount(null); setCustomerInfo(null);
      setPayments([]); setInputAmount(""); setOrderNumber(""); setSalesNumber(""); setTransactionNumber("");
      setPaymentMethod("cash"); setPaymentSubMethod(""); 
      setOrderType(""); setTransactionType("REGULAR");
      setCustomSoloDiscountAmt(null); setTempCustomSoloDiscountAmt(null); setShowSoloDiscountModal(false);
      if (kioskOrderNo) {
        setKioskOrderNo(null);
        localStorage.removeItem('active_kiosk_order');
      }
      if (workstationId) await clearCartFromDatabase(workstationId);
      cfdChannelRef.current?.postMessage({ type: 'CHECKOUT_COMPLETE' });
    } catch {
      sileo.error({ title: 'Failed to save transaction', description: 'Please try again.', fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
    } finally{
      isProcessingPayment.current = false;
    }
  };

  // Display formatter — operates on the raw string directly
  const formatDisplay = (raw:any) => {
    if (!raw || raw === "") return "0";
    const [intPart, decPart] = raw.split(".");
    const formattedInt = (parseInt(intPart) || 0).toLocaleString("en-US");
    if (decPart !== undefined) return formattedInt + "." + decPart; // preserve trailing dot & partial decimals
    return formattedInt;
  };

  // Keystroke handler
  const handleKey = async (k:any) => {
    if (k === "X") {
      setInputAmount(prev => prev.slice(0, -1));
      return;
    }
    if (k === "C") {
      setInputAmount("");
      return;
    }
    else if (k === "Pay") {
      const amt = parseFloat(inputAmount);
      if (!isNaN(amt) && amt > 0) {
        
        if ((paymentMethod === "card" || paymentMethod === "ewallet") && !paymentSubMethod) {
          sileo.error({ title: "Invalid Selection!", description: paymentMethod === "card" ? "Please select Card Debit or Credit" : "Please select Maya or GCash", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
          return;
        }
        
        if (paymentMethod === "voucher" && !paymentSubMethod) {
          sileo.error({ title: "Voucher Required", description: "Please enter the voucher code.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
          return;
        }

        let methodLabel = paymentMethod;
        if (paymentMethod === "card" && paymentSubMethod) methodLabel = paymentSubMethod === "debit" ? "Card Debit" : "Card Credit";
        else if (paymentMethod === "ewallet" && paymentSubMethod) methodLabel = paymentSubMethod === "maya" ? "Maya" : "GCash";
        else if (paymentMethod === "voucher") methodLabel = "Voucher";

        if (paymentMethod === "card" || paymentMethod === "ewallet") {
          let payload: any = {
            amount: amt * 100,
            OrderNo: "817",
            KioskNo: "3",
            storeID: "",
            orderType: "DineIn",
            tenderType: "default",
            customTenderRequestField: "debit",
            payload: {
              StoreID: "1",
              orderTime: "2025-11-25T10:54:26+08:00",
              paymentType: "CASH/MAYA/DEFAULT/GCASH",
              cutlery: false,
              price: {
                subtotal: "45000",
                tax: 0,
                deliveryFee: 0,
                eaterPayment: 0
              },
              featureFlags: {
                orderType: "DineIn"
              },
              items: [
                {
                  id: "IT-30",
                  itemName: "Sichuan Tantan Tsukemen",
                  price: 41000,
                  quantity: 1,
                  tax: 0,
                  notes: null,
                  modifiers: [
                    {
                      id: "MD-1|300653",
                      modifiersName: "Hot",
                      price: 0,
                      quantity: 1,
                      tax: 0
                    },
                    {
                      id: "MD-1|300655",
                      modifiersName: "Large Tsukumen",
                      price: 4000,
                      quantity: 1,
                      tax: 0
                    }
                  ]
                },
                {
                  id: "IT-28",
                  itemName: "Miso Tsukemen",
                  price: 37000,
                  quantity: 1,
                  tax: 0,
                  notes: null,
                  modifiers: [
                    {
                      id: "CL-1|300653",
                      modifiersName: "Hot",
                      price: 0,
                      quantity: 1,
                      tax: 0
                    },
                    {
                      id: "CL-0|300655",
                      modifiersName: "Large Tsukumen",
                      price: 4000,
                      quantity: 1,
                      tax: 0
                    },
                    {
                      id: "MD-0|300633",
                      modifiersName: "Extra Charsiu 3PC",
                      price: 14000,
                      quantity: 3,
                      tax: 0
                    }
                  ]
                }
              ],
              orderState: "NEW"
            }
          };

          if (paymentMethod === "card") {
            payload.tenderType = "default";
            payload.customTenderRequestField = paymentSubMethod === "debit" ? "debit" : "credit";
          } else if (paymentMethod === "ewallet") {
            payload.tenderType = "GenericMerchantQR";
            payload.customTenderRequestField = paymentSubMethod === "maya" ? "qr:maya;" : "qr:qrph;";
          }
          setIsTerminalProcessing(true);
          const paymentPromise = fetch("/api/payment", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          })
            .then(async (res) => {
              if (!res.ok) throw new Error(`Payment server error (${res.status})`);
              const data = await res.json();

              console.log('[Payment API Response]', { charged: 1, actual: amt, data });
              localStorage.setItem('lastPaymentApiResponse', JSON.stringify({
                timestamp: new Date().toISOString(),
                chargedAmount: 1,
                actualAmount: amt,
                method: methodLabel,
                response: data,
              }));

              // Check the new nested structure (data.data.data) as well as the old structure
              const referenceNo  = data.data?.data?.referenceNo || data.response?.data?.referenceNo;
              const messageText  = (data.message || "").toLowerCase();
              const statusText   = (data.status || "").toLowerCase();
              
              const isSuccessful = messageText.includes("success")
                                || messageText.includes("approved")
                                || messageText.includes("completed")
                                || messageText.includes("accepted")
                                || statusText === "completed";

              if (isSuccessful && referenceNo) return { referenceNo };
              if (!referenceNo) throw new Error(data.message ? `Declined: ${data.message}` : "Payment failed — no reference number returned");
              throw new Error(data.message || "Transaction declined by terminal");
            })
            .finally(() => {
              setIsTerminalProcessing(false); // ← always unlock, success or fail
            });

          sileo.promise(paymentPromise, {
            loading: {
              title: "Processing Payment...",
              fill: "#171717",
              styles: { title: "text-white!", description: "text-white/75!" },
            },
            success: (result: any) => {
              handleSuccessfulPayment(methodLabel, amt, result.referenceNo);
              return {
                title: "Payment Approved!",
                description: `Ref: ${result.referenceNo}`,
                fill: "#171717",
                styles: { title: "text-white!", description: "text-white/75!" },
              };
            },
            error: (err: any) => ({
              title: "Payment Failed!",
              description: err.message || "No response from payment terminal.",
              fill: "#171717",
              styles: { title: "text-white!", description: "text-white/75!" },
            }),
          });

        } else { 
          if(paymentMethod === 'cash'){
            openDrawer();
          }
          
          let actualAmt = amt;
          let tenderedAmt = amt;
          
          // Vouchers do not give change, so cap their applied value to the remaining balance
          if (paymentMethod === "voucher") {
             const currentPaid = payments.reduce((s, p) => s + p.amount, 0);
             const remaining = Number((finalTotal - currentPaid).toFixed(2));
             if (actualAmt > remaining) {
                 actualAmt = Math.max(0, remaining);
             }

             setPaymentSubMethod("");
          }
          
          if (actualAmt > 0 || tenderedAmt > 0) {
            handleSuccessfulPayment(methodLabel, actualAmt, paymentMethod === "voucher" ? paymentSubMethod : undefined, tenderedAmt); 
          }
        }
      }
      return; // ← ADDED: Stops "Pay" from falling through and being typed as a digit!
    }
    if (k === ".") {
      setInputAmount(prev => {
        if (prev.includes(".")) return prev; // already has dot
        return (prev || "0") + ".";
      });
      return;
    }
    // Digit
    setInputAmount(prev => {
      if (prev.includes(".")) {
        const decimals = prev.split(".")[1];
        if (decimals.length >= 2) return prev; // max 2 decimal places
      }
      if (prev === "0") return k; // replace leading zero
      return prev + k;
    });
  };

  const setAmount = (val:number) => {
    if (typeof val === "number") {
      // Programmatic set — round to 2 decimals, strip trailing zeros but keep it clean
      const fixed = parseFloat(val.toFixed(2)).toString();
      setInputAmount(fixed);
    } else {
      setInputAmount(val); // raw string from keypad, leave alone
    }
  };


  // --- CFD BROADCASTER ---
  const cfdChannelRef = useRef<BroadcastChannel | null>(null);

  useEffect(() => {
    cfdChannelRef.current = new BroadcastChannel('cfd_channel');
    return () => cfdChannelRef.current?.close();
  }, []);

  useEffect(() => {
    if (cfdChannelRef.current) {
      // Pre-calculate line item discounts to feed directly to the CFD
      const cartWithDiscounts = cart.map((c, idx) => {
        const modifiersList = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
        const modsPrice = modifiersList.reduce((mSum: number, m: any) => mSum + ((m.price || 0) * (m.qty || 1)) / 100, 0);
        let grossPrice = (c.price + modsPrice) * c.qty;

        if (isSRPWD(transactionType) && customLineDiscount?.selectedKeys.includes(`item-${idx}`)) {
          if (c.modifierGroups?.length > 0 && c.udfs?.['UDF-1']?.value) {
            const udfVal = Number(c.udfs['UDF-1'].value);
            if (!isNaN(udfVal)) grossPrice = udfVal * c.qty;
          }
        }

        let itemDiscountAmount = 0;
        if (isSRPWD(transactionType) && customLineDiscount?.selectedKeys.includes(`item-${idx}`)) {
          itemDiscountAmount = grossPrice - (grossPrice / 1.12) * 0.80;
        } else if (transactionType === 'DIPLOMAT') {
          itemDiscountAmount = grossPrice * (0.12 / 1.12);
        } else if (transactionType === 'PEZA' && c.taxable !== false) {
          itemDiscountAmount = grossPrice * (0.12 / 1.12);
        } else if (transactionType === 'ATHLETE' || transactionType === 'SOLO' || transactionType === 'MEDAL' || (transactionType === 'REGULAR' && appliedDiscount)) {
          // Proportional share of the total discount
          itemDiscountAmount = discountAmt * (grossPrice / (rawTotal || 1));
        }

        return {
          ...c,
          grossPrice,
          itemDiscountAmount,
          finalPrice: grossPrice - itemDiscountAmount
        };
      });

      cfdChannelRef.current.postMessage({
        type: 'CART_UPDATE',
        payload: { 
          cart: cartWithDiscounts, 
          subtotal, 
          tax: actualTax, 
          total: finalTotal,
          discountAmt // Pass the total discount as well
        }
      });
    }
  }, [cart, subtotal, actualTax, finalTotal, transactionType, customLineDiscount, appliedDiscount, discountAmt, rawTotal]);
  // -----------------------

  return (
    <>
      <style dangerouslySetInnerHTML={{__html: `
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: rgba(0, 0, 0, 0.05); border-radius: 4px; }
        ::-webkit-scrollbar-thumb { background: rgba(249, 115, 22, 0.6); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(249, 115, 22, 0.9); }
        * { scrollbar-width: thin; scrollbar-color: rgba(249, 115, 22, 0.6) rgba(0, 0, 0, 0.05); }
        @keyframes slideInRightPanel { from { transform: translateX(100%); } to { transform: translateX(0); } }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes scaleIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
        @keyframes slideInLeft { from { opacity: 0; transform: translateX(-30px); } to { opacity: 1; transform: translateX(0); } }
        @keyframes popBounce { 0% { transform: scale(1); } 40% { transform: scale(1.04); } 100% { transform: scale(1); } }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
        .animate-slide-in-right { animation: slideInRightPanel 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        .animate-fade-in { animation: fadeIn 0.3s ease-out forwards; }
        .animate-scale-in { animation: scaleIn 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        .fade-up { animation: fadeUp 0.22s cubic-bezier(.22,.68,0,1.2) both; }
        .hide-scroll::-webkit-scrollbar { display: none; }
        .hide-scroll { -ms-overflow-style: none; scrollbar-width: none; }
      `}} />

      {showShiftDateMismatchModal && activeBusinessDate && (
         <ShiftDateMismatchModal businessDate={activeBusinessDate} onClose={() => setShowShiftDateMismatchModal(false)} />
      )}

      {/* GLOBAL TILL OPEN WARNING */}
      {hasActiveSession && tillStatus === "OPEN" && !showCashDropModal && !showPaymentModal && (
        <DrawerOpenWarningModal />
      )}

      {showEncloseModal && (
        <EncloseModal
          onClose={() => setShowEncloseModal(false)}
          onSave={async (data) => {
            try {
              const finalPrice = Math.abs(data.price);
              
              // 1. Generate ONLY a Transaction Number (No Sales Number, no Order Number)
              const storeDataRaw = JSON.parse(localStorage.getItem("store_data") || "{}");
              const seriesType = storeDataRaw?.series_type || 'WS';
              
              let txNum = '';
              try {
                const txRes = await fetch('/api/numbers?type=transaction', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ seriesType, workstationId: workstationId || '001' })
                });
                if (txRes.ok) {
                  const txData = await txRes.json();
                  txNum = txData.number;
                }
              } catch (err) {
                console.error("Failed to fetch transaction counter", err);
              }

              if (!txNum) {
                txNum = `TXN-${Date.now()}`; // Fallback if counter fails
              }

              // Build a clean payload specifically for Enclose (not a sale)
              const payload = {
                transactionNumber: txNum,
                name: data.name,
                notes: data.notes,
                amount: finalPrice,
                paymentMethod: data.paymentMethod,
                transactionType: 'ENCLOSE',
                staffId,
                staffName,
                cashierName: staffName,
                sessionId: sessionDetails?.id,
                shiftNo: parseInt(sessionDetails?.number || "0"),
                businessDayId: sessionDetails?.businessDayId,
                workstationId: workstationId || '001',
                date: new Date().toISOString(),
                createdAt: new Date().toISOString()
              };

              // 2. Save to a dedicated enclose collection
              const saveRes = await fetch('/api/enclose', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
              });

              if (!saveRes.ok) throw new Error("Failed to save enclose transaction");
              
              // 3. Print Enclose Receipt
              openDrawer();
              try {
                const ReceiptPrintingModule = await import("../../../src/libs/ReceiptPrinting");
                let printStoreData = JSON.parse(localStorage.getItem("store_data") || "null");
                if (!printStoreData) printStoreData = { name: "Store Name Not Set" };

                const receiptText = ReceiptPrintingModule.buildEncloseText({
                  storeData: printStoreData,
                  cashierName: staffName,
                  amount: finalPrice,
                  reason: data.notes || data.name,
                  transactionNumber: txNum
                });

                printDirect(receiptText, false); 
              } catch (printErr) {
                console.error("Print enclose error:", printErr);
              }

              sileo.success({ title: "Saved", description: "Enclose transaction recorded successfully.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
              setShowEncloseModal(false);
            } catch (error) {
              console.error("Failed to save enclose transaction", error);
              sileo.error({ title: "Error", description: "Failed to save enclose transaction.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
            }
          }}
        />
      )}

      {!hasActiveSession && (currentUserRole !== 2 && currentUserRole !== 1) && (
        <OpenRegisterModal onOpenShift={handleOpenShift} openDrawer={openDrawer} fundLimit={cashLimits.fundLimit} businessDate={activeBusinessDate} />
      )}
      {showLimitWarningModal && <CashLimitWarningModal currentCash={drawerCash} onUnderstood={() => setShowLimitWarningModal(false)} onDropCash={() => { setShowLimitWarningModal(false); setShowCashDropModal(true); }} />}
      {showCashDropModal && <CashDropModal currentCash={drawerCash} isForced={isDrawerFull} onClose={() => setShowCashDropModal(false)} onConfirm={handleCashDrop} />}

      {showVoidReasonModal && (
        <VoidReasonModal 
          reasons={voidReasonsList} 
          selectedReason={selectedVoidReason}
          onChangeReason={setSelectedVoidReason}
          onConfirm={handleVoidReasonConfirm}
          onClose={() => { setShowVoidReasonModal(false); setSelectedVoidReason(""); }} 
        />
      )}

      {cartItemQtyModal && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center animate-fade-in" style={{ background: "rgba(15,23,42,0.7)", backdropFilter: "blur(8px)" }}
          onClick={() => setCartItemQtyModal(null)}>
          <div className="bg-white rounded-3xl p-8 w-80 shadow-2xl flex flex-col items-center animate-scale-in relative" onClick={e => e.stopPropagation()}>
            <button onClick={() => setCartItemQtyModal(null)} className="absolute top-5 right-5 text-gray-400 hover:text-gray-600"><FiX size={22} /></button>
            <p className="text-[10px] font-bold uppercase tracking-widest text-orange-500 mb-1" style={{ fontFamily: "Poppins" }}>Set Quantity</p>
            <h3 className="text-lg font-black text-gray-900 text-center mb-6 uppercase leading-tight" style={{ fontFamily: "'DunkinSans Display', Impact, Arial, sans-serif" }}>{cartItemQtyModal.item.name}</h3>

            <div className="flex flex-wrap justify-center gap-3 mb-6">
              {[1,2,3,4,5,6,7,8,9,10].map(n => (
                <button key={n} onClick={() => { changeQty(cartItemQtyModal.idx, n - cartItemQtyModal.currentQty); setCartItemQtyModal(null); }}
                  className={`w-14 h-14 rounded-full text-xl font-black transition-colors ${n === cartItemQtyModal.currentQty ? 'bg-orange-500 text-white shadow-md border-2 border-white' : 'bg-orange-100 text-orange-600 hover:bg-orange-200'}`}
                  style={{ fontFamily: "Poppins" }}>{n}</button>
              ))}
            </div>
            <p className="text-xs text-gray-400 font-medium" style={{ fontFamily: "Poppins" }}>Current qty: {cartItemQtyModal.currentQty}</p>
          </div>
        </div>
      )}
      {itemNoteModal && (
        <ItemNoteModal
          itemName={itemNoteModal.name}
          initialNote={itemNoteModal.currentNote}
          onSave={saveItemNote}
          onClose={() => setItemNoteModal(null)}
        />
      )}
      

      <div 
        className={`flex flex-col overflow-hidden select-none animate-fade-in ${(!hasActiveSession || showCashDropModal || showLimitWarningModal) ? 'blur-md pointer-events-none' : ''}`} 
        style={{ position: "relative", width: "100vw", height: "100%", fontFamily: "'DunkinSans Book', 'DunkinSans Display', Impact, Arial, sans-serif", background: "#F0EFEF" }}
        onTouchStart={handleGlobalTouchStart}
        onTouchMove={handleGlobalTouchMove}
        onTouchEnd={handleGlobalTouchEnd}
        onMouseDown={handleGlobalTouchStart}
        onMouseMove={handleGlobalTouchMove}
        onMouseUp={handleGlobalTouchEnd}
        onClickCapture={handleGlobalClickCapture}
      >
        <div className="flex flex-1 overflow-hidden">

          <div className="flex flex-col shadow-[4px_0_24px_rgba(0,0,0,0.05)] z-10" style={{ width: 500, background: "#F0EFEF", borderRight: "1px solid rgba(0,0,0,0.05)", flexShrink: 0 }}>
            <div className="px-6 py-5 font-bold text-xl flex justify-between items-center" style={{ fontFamily: "Poppins", textTransform: "uppercase", color: "#222", borderBottom: "1px solid rgba(0,0,0,0.05)", background: "rgba(255,255,255,0.3)", backdropFilter: "blur(10px)" }}>
              <span>Order Summary</span>
              
              <div className="flex gap-2">
                {kioskOrderNo && (
                  <button
                    onClick={() => {
                      setKioskOrderNo(null);
                      localStorage.removeItem('active_kiosk_order');
                    }}
                    className="text-[11px] font-bold px-4 py-2 rounded-full transition-all active:scale-95 shadow-sm"
                    style={{
                      fontFamily: "Poppins",
                      letterSpacing: 0.5,
                      background: "rgba(59, 130, 246, 0.15)",
                      color: "#2563eb",
                      border: "1px solid rgba(59, 130, 246, 0.3)"
                    }}
                  >
                    Kiosk #{kioskOrderNo} ✕
                  </button>
                )}
                {cart.length > 0 && (
                <button
                  onClick={() => {
                    if (selectedCartItems.length === cart.length) {
                      setSelectedCartItems([]); 
                    } else {
                      setSelectedCartItems(cart.map((_, i) => i));
                    }
                  }}
                  className="text-[11px] font-bold px-4 py-2 rounded-full transition-all active:scale-95 shadow-sm"
                  style={{
                    fontFamily: "Poppins",
                    letterSpacing: 0.5,
                    background: selectedCartItems.length === cart.length ? "rgba(249,115,22,0.15)" : "rgba(255,255,255,0.6)",
                    color: selectedCartItems.length === cart.length ? "#ea580c" : "#666",
                    border: selectedCartItems.length === cart.length ? "1px solid rgba(249,115,22,0.3)" : "1px solid rgba(0,0,0,0.1)"
                  }}
                >
                  {selectedCartItems.length === cart.length ? "Deselect All" : "Select All"}
                </button>
              )}
              </div>
            </div>

            <div className="px-5 pt-4 pb-1 flex-shrink-0">
              <div className="flex bg-black/5 p-1.5 rounded-2xl w-full relative gap-1" style={{ border: "1px solid rgba(0,0,0,0.05)" }}>
                {[
                  { id: "DineIn",  label: "Dine In",  icon: <Utensils size={16} /> },
                  { id: "TakeOut", label: "Take Out", icon: <ShoppingBag size={16} /> },
                  { id: "Grab",    label: "Grab",     icon: <Grab /> },
                  { id: "Panda",   label: "Panda",    icon: <Panda /> },
                ].map((type, i) => {
                  const isActive = orderType === type.id;
                  return (
                    <button
                      key={type.id}
                      onClick={() => setOrderType(type.id as any)}
                      className="flex-1 py-2 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all duration-300 z-10 flex flex-col items-center gap-0.5"
                      style={{ color: isActive ? "#fff" : "#666", fontFamily: "Poppins", background: isActive ? "linear-gradient(135deg, #f97316 0%, #ea580c 100%)" : "transparent", boxShadow: isActive ? "0 4px 12px rgba(249,115,22,0.3)" : "none" }}
                    >
                      <span style={{ fontSize: 16 }}>{type.icon}</span>
                      {type.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div ref={cartContainerRef} className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-3">
              {cart.length === 0 && <p className="text-center text-sm mt-10" style={{ fontFamily: "Poppins", color: "rgba(0,0,0,0.35)" }}>No items yet.<br />Tap a product to add.</p>}
              {cart.map((c, idx) => {
                const modifiersList = Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {});
                const hasModifiers = modifiersList.length > 0;
                const isSelected = selectedCartItems.includes(idx);
                const cartItemKey = `${c.id}-${idx}`;

                return (
                  <div key={cartItemKey} style={{ animation: "slideInLeft 0.35s cubic-bezier(0.25, 1, 0.5, 1) forwards", opacity: 0 }}>
                    <div
                      className="flex flex-col gap-1 rounded-xl px-4 py-3 w-full text-left transition-all duration-300 ease-out hover:scale-[1.01]"
                      onMouseDown={() => startCartLongPress(c, idx)}
                      onMouseUp={(e) => { cancelCartLongPress(); }}
                      onMouseLeave={cancelCartLongPress}
                      onTouchStart={() => startCartLongPress(c, idx)}
                      onTouchEnd={cancelCartLongPress}
                      onClick={(e) => { if (hasModifiers && !cartLongPressRef.current) editCartItemModifiers(idx); }}
                      style={{ animation: popId === cartItemKey ? "popBounce 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)" : "none", background: isSelected ? "rgba(249,115,22,0.15)" : "rgba(255,255,255,0.45)", backdropFilter: "blur(16px)", WebkitBackdropFilter: "blur(16px)", border: isSelected ? "1px solid #f97316" : "1px solid rgba(255,255,255,0.8)", boxShadow: isSelected ? "0 4px 12px rgba(249,115,22,0.1)" : "0 4px 16px rgba(0,0,0,0.04), inset 0 1px 0 rgba(255,255,255,1)" }}>
                      <div className="flex items-start justify-between gap-1">
                        <div className="flex-1">
                          <p  
                            className="text-sm font-bold leading-tight"
                            style={{ fontFamily: "Poppins", textTransform: "uppercase", color: hasModifiers ? "#f97316" : "#1a1a1a", cursor: hasModifiers ? "pointer" : "default", textDecoration: hasModifiers ? "underline dotted" : "none" }}
                            onClick={(e) => { if (hasModifiers) { e.stopPropagation(); cancelCartLongPress(); editCartItemModifiers(idx); } }}
                            >
                            {c.name}
                          </p>
                          {hasModifiers && (
                            <div className="ml-4 mt-1">
                              {modifiersList.map((m: any, i: number) => (
                                <p key={i} className="text-xs font-medium" style={{ fontFamily: "Poppins", textTransform: "uppercase", color: "#666" }}>
                                  • {m.qty * c.qty}x {m.name}
                                </p>
                              ))}
                            </div>
                          )}
                          {c.notes && (
                            <p className="text-xs italic mt-1 truncate" style={{ fontFamily: "Poppins", color: "#f97316" }}>
                              📝 {c.notes}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center gap-1.5 flex-shrink-0">
                          <button
                            onClick={(e) => { e.stopPropagation(); cancelCartLongPress(); setItemNoteModal({ idx, name: c.name, currentNote: c.notes || '' }); }}
                            className="w-6 h-6 rounded-full flex items-center justify-center transition-all hover:bg-orange-50"
                            style={{ color: c.notes ? "#f97316" : "#999", background: c.notes ? "rgba(249,115,22,0.15)" : "transparent" }}
                          >
                            <FiMessageSquare size={13} />
                          </button>
                          <button onClick={(e) => { e.stopPropagation(); cancelCartLongPress(); toggleSelectCartItem(idx); }} className="text-lg font-bold w-6 h-6 rounded-full flex items-center justify-center transition-all hover:bg-red-50 hover:text-red-500" style={{ color: isSelected ? "#f97316" : "#999", background: isSelected ? "rgba(249,115,22,0.2)" : "transparent" }}>✕</button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center gap-2">
                          <button onClick={(e) => { e.stopPropagation(); cancelCartLongPress(); if (c.qty === 1) { toggleSelectCartItem(idx); } else { changeQty(idx, -1); } }} className="w-7 h-7 rounded-full text-sm font-bold flex items-center justify-center transition-all hover:bg-gray-200 shadow-sm border border-gray-100" style={{ background: "rgba(255,255,255,0.8)", color: "#333", fontFamily: "Poppins" }}>−</button>
                          <span className="text-lg font-black w-8 text-center" style={{ fontFamily: "Poppins", color: "#111" }}>{c.qty}</span>
                          <button onClick={(e) => { e.stopPropagation(); cancelCartLongPress(); changeQty(idx, 1); setPopId(cartItemKey); setTimeout(() => setPopId(null), 300); }} className="w-7 h-7 rounded-full text-sm font-bold flex items-center justify-center transition-all hover:brightness-110 shadow-sm" style={{ background: "linear-gradient(135deg, #f97316 0%, #ea580c 100%)", color: "#fff", fontFamily: "Poppins" }}>+</button>
                        </div>
                        <div className="flex flex-col items-end">
                          {(() => {
                            const modsPrice = modifiersList.reduce((mSum: number, m: any) => mSum + ((m.price || 0) * (m.qty || 1)) / 100, 0);
                            let grossPrice = (c.price + modsPrice) * c.qty;

                            if (isSRPWD(transactionType) && customLineDiscount?.selectedKeys.includes(`item-${idx}`)) {
                              if (c.modifierGroups?.length > 0 && c.udfs?.['UDF-1']?.value) {
                                const udfVal = Number(c.udfs['UDF-1'].value);
                                if (!isNaN(udfVal)) grossPrice = udfVal * c.qty;
                              }
                            }

                            let itemDiscountAmount = 0;

                            if (isSRPWD(transactionType) && customLineDiscount?.selectedKeys.includes(`item-${idx}`)) {
                              itemDiscountAmount = grossPrice - (grossPrice / 1.12) * 0.80;
                            } else if (transactionType === 'DIPLOMAT') {
                              itemDiscountAmount = grossPrice * (0.12 / 1.12);
                            } else if (transactionType === 'PEZA' && c.taxable !== false) {
                              itemDiscountAmount = grossPrice * (0.12 / 1.12);
                            } else if (
                              transactionType === 'ATHLETE' || 
                              transactionType === 'SOLO' || 
                              transactionType === 'MEDAL' ||
                              transactionType === 'CUSTOM' ||
                              (transactionType === 'REGULAR' && appliedDiscount)
                            ) {
                              // Proportional share of the total discount
                              itemDiscountAmount = discountAmt * (grossPrice / (rawTotal || 1));
                            }

                            if (itemDiscountAmount > 0.005) {
                              const isVatExemptType = transactionType === 'DIPLOMAT' || transactionType === 'PEZA';
                              return (
                                <>
                                  {!isVatExemptType && (
                                    <p className="text-xs font-bold line-through text-gray-400" style={{ fontFamily: "Poppins" }}> {formatMoney(grossPrice)}</p>
                                  )}
                                  <p className="text-lg font-black tracking-wide" style={{ fontFamily: "Poppins", color: "#ea6500" }}> {formatMoney(grossPrice - itemDiscountAmount)}</p>
                                </>
                              );
                            }
                            return <p className="text-lg font-black tracking-wide" style={{ fontFamily: "Poppins", color: "#ea6500" }}> {formatMoney(grossPrice)}</p>;
                          })()}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="px-6 py-5 z-20" style={{ borderTop: "1px solid rgba(0,0,0,0.05)", background: "rgba(255,255,255,0.2)", backdropFilter: "blur(10px)" }}>
              <div className="flex justify-between text-xs font-bold mb-1.5" style={{ color: '#888', fontFamily: "Poppins" }}>
                <span>Total Items</span>
                <span>{totalItemsQty}</span>
              </div>
              <div className="flex justify-between text-sm font-bold mb-2" style={{ color: '#666', fontFamily: "Poppins" }}>
                <span>Sub Total</span>
                <span> {formatMoney(transactionType === 'DIPLOMAT' || transactionType === 'PEZA' ? rawTotal : subtotal)}</span>
              </div>
              <div className="flex justify-between text-3xl font-black mt-3 mb-2" style={{ color: "#f97316" }}>
                <span style={{ fontFamily: "Poppins", fontSize: 16, alignSelf: "flex-end", color: "#333", textTransform: "uppercase", letterSpacing: 1 }}>Total</span>
                <span style={{ fontFamily: "Poppins", letterSpacing: "-1px" }}> {formatMoney(finalTotal)}</span>
              </div>
            </div>

            <div className="relative h-[125px] mx-5 mb-6 z-20">
              <div className={`absolute inset-0 flex flex-col justify-end gap-2 transition-all duration-400 ease-[cubic-bezier(0.25,1,0.5,1)] ${selectedCartItems.length > 0 ? "opacity-100 transform translate-y-0 pointer-events-auto z-10" : "opacity-0 transform translate-y-4 pointer-events-none z-0"}`}>
                <div className="text-center text-xs font-bold mb-1" style={{ fontFamily: "Poppins", color: "#f97316" }}>{selectedCartItems.length} item(s) selected</div>
                <button className="w-full rounded-full py-3.5 text-sm font-bold text-white transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-lg active:scale-95 active:translate-y-0" style={{ textTransform: "uppercase", fontFamily: "Poppins", background: "linear-gradient(135deg, #ef4444 0%, #dc2626 100%)", boxShadow: "0 4px 15px rgba(239,68,68,0.3)" }} onClick={handleDeleteSelectedInitiate}>Delete Selected</button>
                <button className="w-full rounded-full py-3 text-sm font-bold transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-md active:scale-95 active:translate-y-0" style={{ fontFamily: "Poppins", background: "rgba(255,255,255,0.6)", backdropFilter: "blur(10px)", color: "#444", border: "1px solid rgba(0,0,0,0.1)" }} onClick={() => setSelectedCartItems([])}>Cancel</button>
              </div>

              <div className={`absolute inset-0 flex flex-col justify-end transition-all duration-400 ease-[cubic-bezier(0.25,1,0.5,1)] ${selectedCartItems.length === 0 ? "opacity-100 transform translate-y-0 pointer-events-auto z-10" : "opacity-0 transform -translate-y-4 pointer-events-none z-0"}`}>
                <div className="grid grid-cols-5 gap-3 mb-3">
                  <button className="col-span-1 rounded-full py-3 text-[11px] font-bold flex items-center justify-center transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-md active:scale-95 active:translate-y-0 shadow-sm"
                    style={{ background: customerInfo ? "rgba(16,185,129,0.15)" : "rgba(255,255,255,0.8)", backdropFilter: "blur(10px)", color: customerInfo ? "#059669" : "#475569", border: customerInfo ? "1px solid rgba(16,185,129,0.3)" : "1px solid rgba(0,0,0,0.1)" }}
                    onClick={() => setShowCustomerInfoModal(true)}>
                    <FiUser size={16} />
                  </button>
                  <button className="col-span-2 rounded-full py-3 text-[11px] font-bold flex items-center justify-center gap-2 transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-md active:scale-95 active:translate-y-0 shadow-sm"
                    style={{ fontFamily: "Poppins", textTransform: "uppercase", letterSpacing: 0.5, background: "rgba(255,255,255,0.8)", backdropFilter: "blur(10px)", color: TRANSACTION_TYPES.find(t => t.id === transactionType)?.color || '#475569', border: `1px solid ${TRANSACTION_TYPES.find(t => t.id === transactionType)?.border || 'rgba(0,0,0,0.1)'}` }}
                    onClick={() => {
                      if (!orderType) {
                        sileo.error({ title: "Select Order Type First", description: "Please select Dine In, Take Out, Grab, or Panda before applying a transaction type.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
                        return;
                      }
                      setShowTransactionTypeModal(true);
                    }}>
                    {TRANSACTION_TYPES.find(t => t.id === transactionType)?.icon} <span style={{ fontFamily: "Poppins", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{TRANSACTION_TYPES.find(t => t.id === transactionType)?.label ?? "DISCOUNTS"}</span>
                  </button>
                  <button className="col-span-2 rounded-full py-3 text-[11px] font-bold flex items-center justify-center gap-2 transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-md active:scale-95 active:translate-y-0 shadow-sm"
                    style={{ fontFamily: "Poppins", textTransform: "uppercase", letterSpacing: 0.5, background: isDiscountDisabled ? "rgba(255,255,255,0.4)" : appliedDiscount ? "rgba(220,252,231,0.8)" : "rgba(255,255,255,0.8)", backdropFilter: "blur(10px)", color: isDiscountDisabled ? "#9ca3af" : appliedDiscount ? "#15803d" : "#f97316", border: isDiscountDisabled ? "1px solid rgba(0,0,0,0.05)" : appliedDiscount ? "1px solid rgba(22,163,74,0.2)" : "1px solid rgba(249,115,22,0.2)", opacity: isDiscountDisabled ? 0.6 : 1 }}
                    onClick={() => {
                      if (!orderType) {
                        sileo.error({ title: "Select Order Type First", description: "Please select Dine In, Take Out, Grab, or Panda before applying a discount.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
                        return;
                      }
                      if (!isDiscountDisabled) setShowDiscountModal(true);
                    }} disabled={isDiscountDisabled}>
                    {isDiscountDisabled
                      ? <span style={{ fontFamily: "Poppins", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>💚 Applied</span>
                      : appliedDiscount
                        ? <><span>{getDiscountInfo(appliedDiscount)?.icon || "🏷️"}</span><span style={{ fontFamily: "Poppins", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{getDiscountInfo(appliedDiscount)?.label}</span></>
                        : <span style={{ fontFamily: "Poppins", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>🏷️ Campaigns</span>}
                  </button>
                </div>

                <button
                  className="w-full rounded-2xl py-5 text-lg font-black text-white transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-xl active:scale-95 active:translate-y-0 disabled:shadow-none disabled:active:scale-100 disabled:hover:translate-y-0"
                  style={{
                    fontFamily: "Poppins", textTransform: "uppercase", letterSpacing: 2,
                    background: isDrawerFull ? "#dc2626" : (cart.length ? "linear-gradient(135deg, #f97316 0%, #c2410c 100%)" : "#cbd5e1"),
                    color: cart.length || isDrawerFull ? "#fff" : "#94a3b8",
                    boxShadow: isDrawerFull ? "0 8px 24px rgba(220,38,38,0.45)" : (cart.length ? "0 8px 24px rgba(249,115,22,0.45), 0 2px 8px rgba(234,88,12,0.3)" : "none"),
                    border: cart.length || isDrawerFull ? "1.5px solid rgba(255,255,255,0.25)" : "none",
                  }}
                  onClick={async () => {
                  if (tillStatus === "OPEN") {
                    sileo.error({ title: "Drawer Open", description: "Please close the cash drawer before starting a transaction.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
                    return;
                  }
                  if (isDrawerFull) { setShowCashDropModal(true); return; }
                  if (!orderType) { 
                    sileo.error({ title: "Order Type Required", description: "Please select Dine In or Take Out first.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } }); 
                    return; 
                  }
                  if (transactionType !== 'REGULAR' && transactionType !== 'PEZA' && transactionType !== 'CUSTOM' && !customerInfo) { 
                    sileo.error({ title: "Customer Info Required", description: "Please provide customer details for this transaction type.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } }); 
                    return; 
                  }

                  // Just open the modal — counters are generated in processPayment
                  setShowPaymentModal(true); 
                  setAmount(finalTotal); 
                  setPayments([]);
                  console.log(cart, "Cart before payment modal");
                }}

                  disabled={!cart.length && !isDrawerFull}>
                  {isDrawerFull ? "⚠️ Cash Drop Required" : `PAY   ${formatMoney(finalTotal)}`}
                </button>
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '12px 8px', gap: 0, width: 120, borderRadius: 24, background: 'rgba(255,255,255,0.5)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)', border: '1px solid rgba(255,255,255,0.8)', boxShadow: '0 8px 32px rgba(0,0,0,0.04), inset 0 1px 0 rgba(255,255,255,1)', flexShrink: 0, marginTop: 16, marginBottom: 16, marginLeft: 16, height: 'calc(100% - 32px)', zIndex: 10 }}>
            <div className="flex-1 w-full overflow-y-auto flex flex-col gap-2 pb-2 hide-scroll pt-2">
              {loadingMenu
                ? Array.from({ length: 6 }).map((_, i) => <div key={i} className="w-full h-24 rounded-2xl animate-pulse" style={{ background: 'rgba(255,255,255,0.4)', margin: '2px 0', flexShrink: 0 }} />)
                : remoteCategories?.length
                  ? remoteCategories.map((cat) => {
                      const isActive = activeCategory === cat.key;
                      return (
                        <button key={cat.key} onClick={() => { setActiveCategory(cat.key); setActiveSubcategory(''); }}
                          style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '12px 6px', gap: 6, width: '100%', cursor: 'pointer', background: isActive ? '#ea580c' : 'transparent', border: 'none', borderRadius: 18, transition: 'all 0.2s ease-in-out', flexShrink: 0, boxShadow: isActive ? '0 8px 20px rgba(234,88,12,0.25)' : 'none' }}>
                          <img
                            src={resolveMenuImageUrl(cat?.img ?? "") || 'images/placeholder.png'}
                            alt={cat.name}
                            onError={(e) => {
                              const el = e.currentTarget;
                              if (el.dataset.stage === 'local') {
                                el.dataset.stage = 'remote';
                                el.src = cat.img || 'images/placeholder.png';
                              } else {
                                el.src = 'images/placeholder.png';
                              }
                            }}
                            data-stage="local"
                            style={{ width: 56, height: 56, objectFit: 'contain', transform: isActive ? 'scale(1.5)' : 'scale(1)', filter: isActive ? '' : 'grayscale(0.6) brightness(1.3)', transition: 'all 0.2s ease-in-out', opacity: isActive ? 1 : .75 }}
                          />
                          <span style={{ textTransform: 'uppercase', fontFamily: "'DunkinSans Display', 'DunkinSans Book', Impact, Arial, sans-serif", fontSize: 10, fontWeight: 800, zIndex: 100, textAlign: 'center', lineHeight: 1.1, letterSpacing: 0.5, color: isActive ? '#fff' : '#ea580c', textShadow: isActive ? '0 1px 3px rgba(0,0,0,0.3)' : 'none' }}>{cat.name}</span>
                        </button>
                      );
                    })
                  : <div style={{ fontSize: 11, textAlign: 'center', color: 'rgba(0,0,0,0.4)', padding: '20px 0', fontFamily: "Poppins" }}>No categories</div>}
            </div>
            <div style={{ width: '70%', height: 1, background: 'rgba(0,0,0,0.08)', margin: '10px 0', flexShrink: 0 }} />
            <div style={{ padding: '4px 0 6px', flexShrink: 0 }}>
              <img src="/images/menux-black.png" alt="POS Logo" style={{ width: 54, height: 54, objectFit: 'contain', cursor: 'pointer', opacity: 0.8, transition: 'opacity 0.2s' }} onMouseEnter={(e) => e.currentTarget.style.opacity = '1'} onMouseLeave={(e) => e.currentTarget.style.opacity = '0.8'} onClick={(e) => { if (e.detail === 3) router.push('/settings'); }} />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto px-8 py-6 relative flex flex-col hide-scroll" style={{ background: "#F0EFEF" }}>

            {qtyModal && (
              <div className="fixed inset-0 z-[250] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm animate-fade-in">
                <div className="bg-white rounded-3xl p-8 w-80 shadow-2xl flex flex-col items-center animate-scale-in relative">
                  <button onClick={() => setQtyModal(null)} className="absolute top-5 right-5 text-gray-400 hover:text-gray-600 transition-colors"><FiX size={24} /></button>
                  <h3 className="text-xl uppercase mb-2 text-center text-gray-800" style={{ fontFamily: "'DunkinSans Display', 'DunkinSans Book', Impact, Arial, sans-serif", fontWeight: 900 }}>{qtyModal.mod.name}</h3>
                  <p className="text-sm text-gray-500 mb-6 text-center font-medium" style={{ fontFamily: "Poppins" }}>Select quantity (Max {qtyModal.max})</p>
                  <div className="flex flex-wrap justify-center gap-3 mb-2">
                    {Array.from({ length: qtyModal.max }).map((_, i) => {
                      const qtyVal = i + 1;
                      const isSelected = qtyModal.qty === qtyVal;
                      return (
                        <button key={qtyVal} onClick={() => confirmQtySelection(qtyVal)} className={`w-14 h-14 rounded-full text-xl font-black transition-colors ${isSelected ? "bg-orange-500 text-white shadow-md border-2 border-white" : "bg-orange-100 text-orange-600 hover:bg-orange-200"}`} style={{ fontFamily: "Poppins" }}>{qtyVal}</button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {modifierSelectionMode && pendingItem ? (
              <div className="flex flex-col flex-1 w-full h-full animate-in fade-in duration-300">
                <div className="mb-6"><button onClick={exitModifierMode} className="px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-colors hover:bg-white/80 bg-white/50 backdrop-blur-md text-gray-700 border border-white/80 shadow-sm" style={{ fontFamily: "Poppins" }}>← Cancel Modifiers</button></div>
                {(() => {
                  const groups = (pendingItem.modifierGroups || []).filter(
                    (g: any) => (g.modifiers || []).length > 0
                  );
                  const isReview = showReview || currentStep >= groups.length;
                  if (isReview) {
                    const flatSelectedMods = Object.values(selectedModifiers).flatMap(g => Object.values(g).filter(m => m.qty > 0));
                    const modsTotal = flatSelectedMods.reduce((sum, m) => sum + ((m.data.price || 0) * m.qty), 0) / 100;
                    return (
                      <div key="review" className="flex flex-col flex-1 animate-in slide-in-from-right-8 fade-in duration-300 ease-out">
                        <div className="mb-6"><h3 className="text-xl font-black uppercase tracking-widest text-gray-800" style={{ fontFamily: "Poppins" }}>Order Details</h3></div>
                        <div className="flex gap-6 flex-1 justify-center items-center">
                          <div className="flex flex-col items-center max-w-75 max-h-75 justify-center flex-1 p-6 rounded-[24px]" style={{ backgroundColor: "#e4e4e4", boxShadow: "inset 2px 2px 4px rgba(255,255,255,0.8), inset -2px -2px 4px rgba(0,0,0,0.05), 0 4px 8px rgba(0,0,0,0.05)" }}>
                            <div className="w-40 h-40 flex items-center justify-center overflow-hidden mb-6">
                              {pendingItem.imgReal ? <img src={pendingItem.imgReal} alt={pendingItem.name} className="w-full h-full object-contain drop-shadow-md" /> : <DonutPlaceholder size={140} />}
                            </div>
                            <h4 className="text-2xl text-center mb-3 uppercase leading-tight" style={{ fontFamily: "'DunkinSans Display', 'DunkinSans Book', Impact, Arial, sans-serif", fontWeight: 900, color: "#4a4a4a" }}>{pendingItem.name}</h4>
                            <p className="text-3xl font-black tracking-tight" style={{ color: "#ff5800", fontFamily: "Poppins" }}> {formatMoney(pendingItem.price)}</p>
                          </div>
                          <div className="flex flex-col flex-1 max-w-100 max-h-120 min-h-120 p-6 rounded-[24px]" style={{ backgroundColor: "#e4e4e4", boxShadow: "inset 2px 2px 4px rgba(255,255,255,0.8), inset -2px -2px 4px rgba(0,0,0,0.05), 0 4px 8px rgba(0,0,0,0.05)" }}>
                            {flatSelectedMods.length > 0 && (
                              <div className="mb-6 flex-1 overflow-y-auto pr-2 hide-scroll">
                                <p className="text-xs mb-4 uppercase tracking-widest" style={{ fontWeight: 900, color: "#9a9a9a", fontFamily: "Poppins" }}>Selected Modifiers</p>
                                <div className="flex flex-col gap-3">
                                  {flatSelectedMods.map((modItem: any, idx) => (
                                    <div key={idx} className="flex items-center justify-between p-3 rounded-[20px]" style={{ backgroundColor: "rgba(255,255,255,0.55)", boxShadow: "inset 1px 1px 3px rgba(255,255,255,0.9), inset -1px -1px 3px rgba(0,0,0,0.05)", border: "1px solid rgba(255,255,255,0.7)" }}>
                                      <span className="uppercase leading-tight" style={{ fontFamily: "'DunkinSans Display', 'DunkinSans Book', Impact, Arial, sans-serif", fontSize: 13, fontWeight: 900, color: "#4a4a4a" }}>
                                        <span style={{ color: "#ff5800", marginRight: 6 }}>{modItem.qty}x</span>{modItem.data.name}
                                      </span>
                                      {modItem.data.price > 0 && <span className="font-black ml-3 shrink-0" style={{ fontSize: 13, color: "#ff5800", fontFamily: "Poppins" }}>+ {formatMoney((modItem.data.price * modItem.qty) / 100)}</span>}
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                            <div className="text-center p-5 rounded-[20px] mt-auto" style={{ backgroundColor: "rgba(255,255,255,0.55)", boxShadow: "inset 1px 1px 3px rgba(255,255,255,0.9), inset -1px -1px 3px rgba(0,0,0,0.05)", border: "1px solid rgba(255,255,255,0.7)" }}>
                              <p className="text-xs font-black uppercase tracking-widest mb-1" style={{ color: "#9a9a9a", fontFamily: "Poppins" }}>Total Price</p>
                              <p className="text-4xl font-black tracking-tighter" style={{ color: "#ff5800", fontFamily: "Poppins" }}> {formatMoney(pendingItem.price + modsTotal)}</p>
                            </div>
                          </div>
                        </div>
                        <div className="flex justify-between mt-6 border-t border-white/40 pt-6">
                          <button onClick={() => setCurrentStep(p => Math.max(0, p - 1))} className="px-8 py-3 rounded-xl text-sm font-black uppercase tracking-widest bg-white/60 hover:bg-white/80 border border-white/80 text-gray-700 shadow-sm transition-colors" style={{ fontFamily: "Poppins" }}>← Back</button>
                          <button onClick={handleConfirmModifiers} className="px-10 py-3 rounded-xl text-sm font-black text-white uppercase tracking-widest bg-orange-500 hover:bg-orange-600 shadow-md transition-colors" style={{ fontFamily: "Poppins" }}>Confirm & Add ✓</button>
                        </div>
                      </div>
                    );
                  }
                  const group = groups[currentStep];
                  const groupTotal = getGroupTotal(group.id);
                  const maxAllowed = group.selectionRangeMax || 1;
                  const canProceed = !group.isRequired || groupTotal === maxAllowed;
                  return (
                    <div key={currentStep} className="flex flex-col flex-1 animate-in slide-in-from-right-8 fade-in duration-300 ease-out">
                      <div className="mb-6 flex items-center justify-between">
                        <h3 className="text-2xl font-black uppercase tracking-widest text-gray-800" style={{ fontFamily: "'DunkinSans Display', 'DunkinSans Book', Impact, Arial, sans-serif" }}>{group.name}</h3>
                        <div className="flex items-center gap-3">
                          <span className="text-sm font-bold text-gray-500 uppercase tracking-widest bg-white/50 px-3 py-1 rounded-lg border border-white/80 shadow-sm" style={{ fontFamily: "Poppins" }}>Step {currentStep + 1} of {groups.length}</span>
                          <span className={`text-sm font-black uppercase tracking-widest px-3 py-1 rounded-lg border shadow-sm transition-colors ${canProceed ? "bg-green-100 text-green-700 border-green-200" : "bg-orange-100 text-orange-600 border-orange-200"}`}>
                            {!group.isRequired && groupTotal === 0
                              ? 'Optional — skip or select'
                              : `${groupTotal} / ${maxAllowed} Selected`}
                          </span>  
                        </div>
                      </div>
                      <div className="grid gap-4 flex-1 overflow-y-auto pr-2 hide-scroll" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", alignContent: 'start' }}>
                        {group.modifiers.map((mod: any) => {
                          const isCLMod = String(mod.id || '').startsWith('CL-');
                          const modStockId = getInventoryId(mod);
                          const modStock = isCLMod ? Infinity : (inventoryState[modStockId] ?? 0);
                          const isOutOfStock = !isCLMod && modStock <= 0;
                          const modQty = selectedModifiers[group.id]?.[mod.id]?.qty || 0;
                          const isSelected = modQty > 0;
                          return (
                            <div key={mod.id} className="relative flex flex-col transition-all duration-200 focus:outline-none active:scale-95">
                              {isOutOfStock && <div className="absolute top-3 left-3 bg-red-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full z-10 shadow-sm tracking-wider" style={{ fontFamily: "Poppins" }}>UNAVAILABLE</div>}
                              <button key={mod.id} onClick={() => { if (!isOutOfStock) handleModifierTap(group, mod); }} disabled={isOutOfStock} className=" rounded-[24px] p-4"
                                style={{ minHeight: 140, backgroundColor: isSelected ? "rgba(255,237,213,0.85)" : "#e4e4e4", backdropFilter: "blur(8px)", WebkitBackdropFilter: "blur(8px)", boxShadow: isSelected ? "inset 2px 2px 4px rgba(255,255,255,0.8), inset -2px -2px 4px rgba(0,0,0,0.05), 0 4px 12px rgba(249,115,22,0.25)" : "inset 2px 2px 4px rgba(255,255,255,0.8), inset -2px -2px 4px rgba(0,0,0,0.05), 0 4px 8px rgba(0,0,0,0.05)", border: isSelected ? "2px solid rgba(249,115,22,0.5)" : "1px solid rgba(255,255,255,0.7)", opacity: isOutOfStock ? 0.5 : 1, cursor: isOutOfStock ? 'not-allowed' : 'pointer' }}>
                                {isSelected && <div className="absolute top-2 right-2 w-7 h-7 bg-orange-500 text-white rounded-full flex items-center justify-center font-black text-xs shadow-sm border-2 border-white" style={{ fontFamily: "Poppins" }}>{modQty}</div>}
                                <span className="text-center uppercase leading-tight line-clamp-2 break-words mb-3" style={{ fontFamily: "'DunkinSans Display', 'DunkinSans Book', Impact, Arial, sans-serif", fontSize: 13, fontWeight: 900, color: isSelected ? "#c2410c" : "#4a4a4a" }}>{mod.name}</span>
                                <span className="px-3 py-1 rounded-xl font-black uppercase text-[10px] tracking-wider" style={{ backgroundColor: isSelected ? "#ff5800" : "rgba(255,255,255,0.75)", color: isSelected ? "#fff" : "#ff5800", boxShadow: isSelected ? "0 2px 6px rgba(255,88,0,0.3)" : "inset 1px 1px 2px rgba(255,255,255,0.9), inset -1px -1px 2px rgba(0,0,0,0.05)", fontFamily: "Poppins" }}>
                                  + {formatMoney((mod.price || 0) / 100)}
                                </span>
                              </button>
                            </div>
                          );
                        })}
                      </div>
                      <div className="flex justify-between mt-6 border-t border-white/40 pt-6">
                        <button onClick={() => { if (currentStep === 0) exitModifierMode(); else setCurrentStep(p => p - 1); }} className="px-8 py-3 rounded-xl font-black text-sm uppercase tracking-widest text-gray-600 bg-white/50 hover:bg-white/80 transition-colors shadow-sm border border-white/50" style={{ fontFamily: "Poppins" }}>← Back</button>
                        <button onClick={() => setCurrentStep(p => p + 1)} disabled={!canProceed} className="px-10 py-3 rounded-xl font-black text-sm uppercase tracking-widest text-white transition-colors shadow-md disabled:opacity-50 disabled:cursor-not-allowed" style={{ background: canProceed ? "linear-gradient(135deg, #f97316 0%, #ea580c 100%)" : "#cbd5e1", fontFamily: "Poppins" }}>Next Step →</button>
                      </div>
                    </div>
                  );
                })()}
              </div>
            ) : loadingMenu ? (
              <div className="flex flex-col gap-6 max-w-5xl mx-auto mt-6 w-full">
                <div className="flex justify-center mb-4"><div className="w-64 h-12 rounded-full bg-white/40 backdrop-blur-md animate-pulse" /></div>
                <div className="grid gap-5 w-full" style={{ gridTemplateColumns: 'repeat(5, 1fr)' }}>{Array.from({ length: 15 }).map((_, i) => (<div key={i} className="rounded-[32px] p-4 bg-white/40 backdrop-blur-md animate-pulse min-h-[160px] border border-white/50" />))}</div>
              </div>
            ) : effectiveCategoryData ? (
              <div className="flex flex-col gap-6 max-w-6xl w-full mx-auto animate-in fade-in duration-500">
                <div className="flex justify-center mt-2 mb-2"><h2 className="text-[44px] font-black uppercase tracking-wider drop-shadow-sm text-center" style={{ fontFamily: "'DunkinSans Book', 'DunkinSans Display', Impact, Arial, sans-serif", color: "#f97316" }}>{effectiveCategoryData.sections[0]?.title}</h2></div>
                {effectiveCategoryData.subcategories && effectiveCategoryData.subcategories.length > 0 && (
                  <div className="flex gap-3 justify-center flex-wrap px-4 mb-4">
                    <button onClick={() => setActiveSubcategory("")} className="px-6 py-2.5 rounded-full text-xs font-black uppercase tracking-widest transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-md active:scale-95 active:translate-y-0"
                      style={{ background: activeSubcategory === "" ? "linear-gradient(135deg, #f97316 0%, #ea580c 100%)" : "rgba(255,255,255,0.45)", backdropFilter: activeSubcategory === "" ? "none" : "blur(12px)", color: activeSubcategory === "" ? "#fff" : "#4b5563", border: activeSubcategory === "" ? "none" : "1px solid rgba(255,255,255,0.8)", boxShadow: activeSubcategory === "" ? "0 6px 16px rgba(234,88,12,0.3)" : "0 4px 12px rgba(0,0,0,0.03)", fontFamily: "Poppins" }}>All</button>
                    {effectiveCategoryData.subcategories.map((s: any) => (
                      <button key={s.id} onClick={() => setActiveSubcategory(s.id)} className="px-6 py-2.5 rounded-full text-xs font-black uppercase tracking-widest transition-all duration-300 ease-out hover:-translate-y-0.5 hover:shadow-md active:scale-95 active:translate-y-0"
                        style={{ background: activeSubcategory === s.id ? "linear-gradient(135deg, #f97316 0%, #ea580c 100%)" : "rgba(255,255,255,0.45)", backdropFilter: activeSubcategory === s.id ? "none" : "blur(12px)", color: activeSubcategory === s.id ? "#fff" : "#4b5563", border: activeSubcategory === s.id ? "none" : "1px solid rgba(255,255,255,0.8)", boxShadow: activeSubcategory === s.id ? "0 6px 16px rgba(234,88,12,0.3)" : "0 4px 12px rgba(0,0,0,0.03)", fontFamily: "Poppins" }}>
                        {s.name}
                      </button>
                    ))}
                  </div>
                )}
                <div className="grid gap-5 pb-8" style={{ gridTemplateColumns: "repeat(5, 1fr)" }}>
                  {(() => {
                    let items: any[] = [];
                    if (effectiveCategoryData.subcategories?.length) {
                      items = activeSubcategory === "" ? effectiveCategoryData.subcategories.flatMap((s: any) => s.items) : (effectiveCategoryData.subcategories.find((s: any) => s.id === activeSubcategory)?.items || []);
                    } else { items = effectiveCategoryData.sections[0]?.items || []; }
                    if (items.length === 0) {
                      return (
                        <div className="col-span-5 flex flex-col items-center justify-center py-20 opacity-60">
                          <span className="text-6xl mb-4 drop-shadow-sm">🍩</span>
                          <p className="text-lg font-bold text-gray-500 uppercase tracking-widest text-center" style={{ fontFamily: "Poppins" }}>No products found</p>
                        </div>
                      );
                    }
                    return items.map((item: any, i: number) => {
                      if (item.isAddButton) {
                        return (
                          <div key="add-custom" className="fade-up col-span-1" style={{ animationDelay: `${i * 30}ms` }}>
                            <button
                              onClick={() => setShowCustomItemModal(true)}
                              className={`flex flex-col items-center justify-center p-3 sm:p-4 rounded-3xl w-full relative focus:outline-none transition-transform duration-200`}
                              style={{ height: "200px", backgroundColor: "#e4e4e4", boxShadow: "inset 2px 2px 4px rgba(255,255,255,0.8), inset -2px -2px 4px rgba(0,0,0,0.05), 0 4px 8px rgba(0,0,0,0.05)", opacity: 1, cursor: 'pointer' }}
                            >
                              <span className="text-4xl text-orange-400 font-black">+</span>
                              <span className="text-[11px] font-bold text-orange-600 font-poppins uppercase tracking-widest text-center px-2">Add Custom<br/>Item</span>
                            </button>
                          </div>
                        );
                      }
                      if (item.isAddEncloseButton) {
                        return (
                          <div key="add-enclose" className="fade-up col-span-1" style={{ animationDelay: `${i * 30}ms` }}>
                            <button
                              onClick={() => setShowEncloseModal(true)}
                              className={`flex flex-col items-center justify-center p-3 sm:p-4 rounded-3xl w-full relative focus:outline-none transition-transform duration-200`}
                              style={{ height: "200px", backgroundColor: "#e4e4e4", boxShadow: "inset 2px 2px 4px rgba(255,255,255,0.8), inset -2px -2px 4px rgba(0,0,0,0.05), 0 4px 8px rgba(0,0,0,0.05)", opacity: 1, cursor: 'pointer' }}
                            >
                              <span className="text-4xl text-blue-400 font-black">⇌</span>
                              <span className="text-[11px] font-bold text-blue-600 font-poppins uppercase tracking-widest text-center px-2">Add Enclose<br/>Transaction</span>
                            </button>
                          </div>
                        );
                      }
                      return (
                      <div key={`${item.id}-${activeSubcategory}-${i}`} className="fade-up" style={{ animationDelay: `${i * 30}ms` }}>
                        <ProductCard 
                          item={item} 
                          stock={calculateItemStock(item, inventoryState)}
                          onAdd={addToCart} 
                          onLongPress={(item) => {
                            const hasAnyModifiers = (item.modifierGroups || []).filter(
                              (g: any) => (g.modifiers || []).length > 0
                            ).length > 0;
                            if (hasAnyModifiers) {
                              addToCart(item);
                            } else {
                              setProductQtyModal(item);
                            }
                          }}
                          showStock={showStock} 
                        />
                      </div>
                      );
                    });
                  })()}
                </div>
              </div>
            ) : null}
          </div>
        </div>

        {managerPinModal.show && (
          <ManagerPinModal title="Enter Manager PIN" subtitle={managerPinSubtitle()} accentColor={managerPinModal.action === "delete" ? "#ef4444" : "#f97316"}
            onConfirm={handleManagerPinConfirm} onClose={() => { 
              setManagerPinModal({ show: false, action: null }); 
              if (pendingTransactionType && isSRPWD(pendingTransactionType) && !customLineDiscount) {
                const newCart: any[] = [];
                cart.forEach((c) => {
                  const modsKey = JSON.stringify(Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {}));
                  const matchIdx = newCart.findIndex((nc) => nc.id === c.id && JSON.stringify(Array.isArray(nc.modifiers) ? nc.modifiers : Object.values(nc.modifiers || {})) === modsKey);
                  if (matchIdx >= 0) newCart[matchIdx] = { ...newCart[matchIdx], qty: newCart[matchIdx].qty + c.qty };
                  else newCart.push({ ...c });
                });
                setCart(newCart);
              }
              setPendingTransactionType(null); 
              setPendingDiscount(null); 
            }} />
        )}
        {showDiscountModal && (
          <DiscountModal cart={cart} subtotal={subtotal} appliedDiscount={appliedDiscount}
            onApply={(type) => { if (!type) { setAppliedDiscount(null); setShowDiscountModal(false); } else { setPendingDiscount(type); setShowDiscountModal(false); setManagerPinModal({ show: true, action: "discount" }); } }}
            onClose={() => setShowDiscountModal(false)} availableDiscounts={availableDiscounts} />
        )}
        {showTransactionTypeModal && (
          <TransactionTypeModal selectedType={transactionType} customerInfo={customerInfo}
            getDisabledReason={getTransactionTypeDisabledReason}
            onClearDiscount={() => {
              setTransactionType('REGULAR');
              setAppliedDiscount(null);
              setDiplomatData(null);
              setCustomLineDiscount(null);
              setCustomSoloDiscountAmt(null);
            }}
            onSelect={async (type) => {
              if (type === transactionType) {
                setShowTransactionTypeModal(false);
                return;
              }
              if (type === 'REGULAR') { setTransactionType(type); setShowTransactionTypeModal(false); setAppliedDiscount(null); setDiplomatData(null); setCustomLineDiscount(null); setCustomSoloDiscountAmt(null); }
              // REPLACE WITH:
              else if (DIPLOMAT_FLOW_TYPES.includes(type)) { 
                setPendingTransactionType(type); setShowTransactionTypeModal(false); 
                if (type === 'CUSTOM') {
                  setTempDiplomatData({ name: '', idNum: '', tin: '', address: '' });
                  setShowSoloDiscountModal(true);
                } else if (type === 'SOLO' && customerInfo?.idNum) {
                  // Already have customer — validate limit with current cart
                  const pendingAmt = computeSoloDiscountAmt(cart, rawTotal);
                  const ok = await checkSoloLimit(customerInfo.idNum, pendingAmt);
                  if (!ok) { setPendingTransactionType(null); return; }
                  setTempDiplomatData(customerInfo);
                  setManagerPinModal({ show: true, action: "transactionType" });
                } else if (customerInfo) {
                  setTempDiplomatData(customerInfo);
                  setManagerPinModal({ show: true, action: "transactionType" });
                } else {
                  setTempDiplomatData({ name: '', idNum: '', tin: '', address: '' }); 
                  setShowDiplomatModal(true); 
                }
              }

              
              else if (isSRPWD(type)) {
                const expandedCart: any[] = [];
                cart.forEach(c => {
                  for (let i = 0; i < c.qty; i++) {
                    expandedCart.push({ ...c, qty: 1 });
                  }
                });
                setCart(expandedCart);
                setPendingTransactionType(type);
                setShowTransactionTypeModal(false);
                setSrpwdFlowActive(true);       
                setShowCustomerInfoModal(true);  
              }

              else { setPendingTransactionType(type); setShowTransactionTypeModal(false); setManagerPinModal({ show: true, action: "transactionType" }); }
            }}
            onClose={() => setShowTransactionTypeModal(false)} />
        )}
        {showDiplomatModal && pendingTransactionType && (
          <DiplomatPromptModal transactionType={pendingTransactionType} initialData={customerInfo} onClose={() => setShowDiplomatModal(false)}
            onNext={async (data) => {
              // SOLO: check limit before proceeding to the discount amount modal
              if (pendingTransactionType === 'SOLO' && data.idNum) {
                const pendingAmt = computeSoloDiscountAmt(cart, rawTotal);
                const ok = await checkSoloLimit(data.idNum, pendingAmt);
                if (!ok) return; // keep DiplomatPromptModal open
              }

              setTempDiplomatData(data);
              setShowDiplomatModal(false);
              if (pendingTransactionType === 'CUSTOM') setShowSoloDiscountModal(true);
              else if (isSRPWD(pendingTransactionType)) {
                const customers = parseSrpwdCustomers(data);
                const N = Math.max(1, customers.length);
                const autoKeys = autoSelectSrpwdItemKeys(cart, N);
                setCustomerInfo(data);
                setTempCustomLineDiscount({
                  slotDetails: customers.length > 0
                    ? customers.map(c => ({ name: c.name || '', idNum: c.idNum || '', isConfirmed: true }))
                    : [{ name: data.name, idNum: data.idNum, isConfirmed: true }],
                  selectedKeys: autoKeys,
                });
                setShowLineItemDiscountModal(true);
              }
              else setManagerPinModal({ show: true, action: "transactionType" });
            }}
            />
        )}
        {showSoloDiscountModal && (
          <SoloDiscountModal
            rawTotal={rawTotal}
            onClose={() => {
              setShowSoloDiscountModal(false);
              setPendingTransactionType(null);
              setTempDiplomatData(null);
            }}
            onApply={async (amt) => {
              // Check limit against the actual calculated discount amount
              const ok = await checkSoloLimit(amt);
              if (!ok) return;

              setTempCustomSoloDiscountAmt(amt);
              setShowSoloDiscountModal(false);
              setManagerPinModal({ show: true, action: "transactionType" });
            }}
          />
        )}
        {showCustomerInfoModal && (
          <CustomerInfoModal
            initialData={customerInfo}
            onClose={() => {
              setShowCustomerInfoModal(false);
              if (srpwdFlowActive) {
                const newCart: any[] = [];
                cart.forEach((c) => {
                  const modsKey = JSON.stringify(Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {}));
                  const matchIdx = newCart.findIndex((nc) => nc.id === c.id && JSON.stringify(Array.isArray(nc.modifiers) ? nc.modifiers : Object.values(nc.modifiers || {})) === modsKey);
                  if (matchIdx >= 0) newCart[matchIdx] = { ...newCart[matchIdx], qty: newCart[matchIdx].qty + c.qty };
                  else newCart.push({ ...c });
                });
                setCart(newCart);
                setSrpwdFlowActive(false);
                setPendingTransactionType(null);
              }
            }}
            onSave={async (data) => {
              // For SOLO transactions, check the ID against the spending limit
              // We don't know the discount amount yet (cart may not be set),
              // so we do a soft check: if they already maxed out, warn early.
              if ((pendingTransactionType === 'SOLO' || transactionType === 'SOLO') && data.idNum) {
                const pendingAmt = computeSoloDiscountAmt(cart, rawTotal);
                const ok = await checkSoloLimit(data.idNum, pendingAmt);
                if (!ok) return; // keep modal open
              }

              setCustomerInfo(data);
              setShowCustomerInfoModal(false);

              if (srpwdFlowActive && pendingTransactionType && isSRPWD(pendingTransactionType)) {
                setSrpwdFlowActive(false);

                const customers = parseSrpwdCustomers(data);
                const N         = Math.max(1, customers.length);
                const slotDetails = customers.map(c => ({
                  name: c.name || '', idNum: c.idNum || '', isConfirmed: true,
                }));

                const autoKeys = autoSelectSrpwdItemKeys(cart, N);
                setTempCustomLineDiscount({ slotDetails, selectedKeys: autoKeys });
                setShowLineItemDiscountModal(true);
              } else {
                sileo.success({
                  title: 'Customer Info Saved',
                  fill: '#171717',
                  styles: { title: 'text-white!', description: 'text-white/75!' },
                  duration: 1000
                });
              }
            }}

          />
        )}
        {showLineItemDiscountModal && pendingTransactionType && (
          <LineItemDiscountModal
            cart={cart}
            type={pendingTransactionType}
            remoteProducts={remoteProducts}
            initialSelectedKeys={tempCustomLineDiscount?.selectedKeys ?? []}
            customerInfo={customerInfo}
            onClose={() => {
              setShowLineItemDiscountModal(false);
              setSrpwdReassigning(false);
              if (!srpwdReassigning) {
                const newCart: any[] = [];
                cart.forEach((c) => {
                  const modsKey = JSON.stringify(Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {}));
                  const matchIdx = newCart.findIndex((nc) => nc.id === c.id && JSON.stringify(Array.isArray(nc.modifiers) ? nc.modifiers : Object.values(nc.modifiers || {})) === modsKey);
                  if (matchIdx >= 0) newCart[matchIdx] = { ...newCart[matchIdx], qty: newCart[matchIdx].qty + c.qty };
                  else newCart.push({ ...c });
                });
                setCart(newCart);
                setPendingTransactionType(null);
                setSrpwdFlowActive(false);
              } else {
                const newCart: any[] = [];
                const newSelectedKeys: string[] = [];
                const keys = customLineDiscount?.selectedKeys || [];
                cart.forEach((c, oldIdx) => {
                  const isSelected = keys.includes(`item-${oldIdx}`);
                  const modsKey = JSON.stringify(Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {}));
                  const matchIdx = newCart.findIndex((nc, ncIdx) => {
                     const ncIsSelected = newSelectedKeys.includes(`item-${ncIdx}`);
                     const ncModsKey = JSON.stringify(Array.isArray(nc.modifiers) ? nc.modifiers : Object.values(nc.modifiers || {}));
                     return nc.id === c.id && ncModsKey === modsKey && isSelected === ncIsSelected;
                  });
                  if (matchIdx >= 0) {
                    newCart[matchIdx] = { ...newCart[matchIdx], qty: newCart[matchIdx].qty + c.qty };
                  } else {
                    newCart.push({ ...c });
                    if (isSelected) newSelectedKeys.push(`item-${newCart.length - 1}`);
                  }
                });
                setCart(newCart);
                if (customLineDiscount) {
                  setCustomLineDiscount({ ...customLineDiscount, selectedKeys: newSelectedKeys });
                }
              }
            }}
            onApply={(slotDetails, keys) => {
              const newCart: any[] = [];
              const newSelectedKeys: string[] = [];
              cart.forEach((c, oldIdx) => {
                const isSelected = keys.includes(`item-${oldIdx}`);
                const modsKey = JSON.stringify(Array.isArray(c.modifiers) ? c.modifiers : Object.values(c.modifiers || {}));
                const matchIdx = newCart.findIndex((nc, ncIdx) => {
                   const ncIsSelected = newSelectedKeys.includes(`item-${ncIdx}`);
                   const ncModsKey = JSON.stringify(Array.isArray(nc.modifiers) ? nc.modifiers : Object.values(nc.modifiers || {}));
                   return nc.id === c.id && ncModsKey === modsKey && isSelected === ncIsSelected;
                });
                if (matchIdx >= 0) {
                  newCart[matchIdx] = { ...newCart[matchIdx], qty: newCart[matchIdx].qty + c.qty };
                } else {
                  newCart.push({ ...c });
                  if (isSelected) newSelectedKeys.push(`item-${newCart.length - 1}`);
                }
              });

              if (srpwdReassigning) {
                setCart(newCart);
                setCustomLineDiscount({ slotDetails, selectedKeys: newSelectedKeys });
                setShowLineItemDiscountModal(false);
                setSrpwdReassigning(false);
                sileo.success({
                  title: 'SR/PWD items updated',
                  fill: '#171717',
                  styles: { title: 'text-white!', description: 'text-white/75!' },
                  duration: 1000
                });
              } else {
                setCart(newCart);
                setTempCustomLineDiscount({ slotDetails, selectedKeys: newSelectedKeys });
                setShowLineItemDiscountModal(false);
                setManagerPinModal({ show: true, action: 'transactionType' });
              }
            }}
          />
        )}

        {productQtyModal && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center animate-fade-in" style={{ background: "rgba(15,23,42,0.7)", backdropFilter: "blur(8px)" }}
            onClick={() => { setProductQtyModal(null); setShowCustomQtyNumpad(false); }}>
            <div className="bg-white rounded-3xl p-8 w-80 shadow-2xl flex flex-col items-center animate-scale-in relative" onClick={e => e.stopPropagation()}>
              <button onClick={() => { setProductQtyModal(null); setShowCustomQtyNumpad(false); }} className="absolute top-5 right-5 text-gray-400 hover:text-gray-600"><FiX size={22} /></button>
              
              <p className="text-[10px] font-bold uppercase tracking-widest text-orange-500 mb-1" style={{ fontFamily: "Poppins" }}>Quick Add</p>
              <h3 className="text-lg font-black text-gray-900 text-center mb-6 uppercase leading-tight" style={{ fontFamily: "'DunkinSans Display', Impact, Arial, sans-serif" }}>{productQtyModal.name}</h3>

              <div className="flex flex-wrap justify-center gap-3 mb-4">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => (
                  <button 
                    key={n} 
                    onClick={() => addBulkToCart(productQtyModal, n)}
                    className="w-14 h-14 rounded-full text-xl font-black bg-orange-100 text-orange-600 hover:bg-orange-500 hover:text-white transition-all active:scale-90 shadow-sm border-2 border-white"
                    style={{ fontFamily: "Poppins" }}
                  >
                    {n}
                  </button>
                ))}
              </div>

              {/* ADD THIS ↓ */}
              <button
                onClick={() => setShowCustomQtyNumpad(true)}
                className="w-full mt-1 py-3 rounded-2xl text-sm font-bold transition-all active:scale-95 border-2 border-dashed border-orange-200 text-orange-400 hover:border-orange-400 hover:text-orange-600 hover:bg-orange-50"
                style={{ fontFamily: "Poppins" }}
              >
                + Custom Quantity
              </button>
              {/* ADD THIS ↑ */}

              <p className="text-xs text-gray-400 font-medium italic mt-3" style={{ fontFamily: "Poppins" }}>Select quantity to add to cart</p>
            </div>
          </div>
        )}

        {productQtyModal && showCustomQtyNumpad && (
          <NumpadModal
            open={showCustomQtyNumpad}
            itemName={productQtyModal.name}
            itemImg={productQtyModal.imgReal || ''}
            initialValue={undefined}
            onConfirm={(qty) => {
              if (qty > 0) addBulkToCart(productQtyModal, qty);
              setShowCustomQtyNumpad(false);
              setProductQtyModal(null);
            }}
            onClose={() => setShowCustomQtyNumpad(false)}
          />
        )}

        {showCustomItemModal && (
          <CustomItemModal
            onClose={() => setShowCustomItemModal(false)}
            onAdd={(name, price) => {
              const customItem = {
                id: `CUSTOM-${Date.now()}`,
                name: name,
                price: price,
                taxable: true,
                modifiers: [],
                modifierGroups: []
              };
              addToCart(customItem);
              setShowCustomItemModal(false);
            }}
          />
        )}
        
        

      </div>
      {/* PRINTER STATUS INDICATOR */}
      {(() => {
        const bothOk      = usbPrinter && isOnline;
        const bothFail    = !usbPrinter && !isOnline;
        const dotColor    = bothOk ? "bg-green-500 animate-pulse" : bothFail ? "bg-red-500" : "bg-yellow-400 animate-pulse";
        const bgColor     = bothOk ? "rgba(22,163,74,0.12)"  : bothFail ? "rgba(239,68,68,0.12)"  : "rgba(234,179,8,0.12)";
        const borderColor = bothOk ? "rgba(22,163,74,0.25)"  : bothFail ? "rgba(239,68,68,0.25)"  : "rgba(234,179,8,0.25)";

        return (
          <div className="fixed bottom-10 right-0 z-[100000] flex items-center">
            
            {/* Peeking tab — small square, always visible */}
            <div
              onClick={togglePrinterExpanded}
              className="flex items-center justify-center cursor-pointer shadow-md backdrop-blur-md shrink-0"
              style={{
                width: 28,
                height: 28,
                borderRadius: "8px 0 0 8px",
                background: bgColor,
                borderTop: `1px solid ${borderColor}`,
                borderBottom: `1px solid ${borderColor}`,
                borderLeft: `1px solid ${borderColor}`,
                borderRight: "none",
                zIndex: 2,
              }}
            >
              <div className={`w-2 h-2 rounded-full ${dotColor}`} />
            </div>

            {/* Expanded card — slides out from behind the tab */}
            <div
              onClick={togglePrinterExpanded}
              className="cursor-pointer shadow-lg backdrop-blur-md overflow-hidden"
              style={{
                borderRadius: "12px",
                background: bgColor,
                borderTop: `1px solid ${borderColor}`,
                borderBottom: `1px solid ${borderColor}`,
                borderRight: `1px solid ${borderColor}`,
                borderLeft: "none",
                maxWidth: isPrinterExpanded ? 200 : 0,
                opacity: isPrinterExpanded ? 1 : 0,
                transition: "max-width 0.35s cubic-bezier(0.16,1,0.3,1), opacity 0.25s ease",
                pointerEvents: isPrinterExpanded ? "auto" : "none",
              }}
            >
              <div className="flex flex-col gap-2 px-4 py-3 whitespace-nowrap">
                {/* Printer row */}
                <div className="flex items-center gap-2">
                  <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${usbPrinter ? "bg-green-500" : "bg-red-500"}`} />
                  <span
                    onClick={(e) => {
                      if (!usbPrinter) { e.stopPropagation(); router.push('/settings'); }
                    }}
                    className="text-xs font-bold tracking-wide"
                    style={{ fontFamily: "Poppins", color: usbPrinter ? "#16a34a" : "#dc2626", textDecoration: !usbPrinter ? "underline dotted" : "none" }}
                  >
                    {usbPrinter ? "Printer Connected" : "Printer Disconnected"}
                  </span>
                </div>

                {/* Internet row */}
                <div className="flex items-center gap-2">
                  <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${isOnline ? "bg-green-500" : "bg-red-500"}`} />
                  <span
                    className="text-xs font-bold tracking-wide"
                    style={{ fontFamily: "Poppins", color: isOnline ? "#16a34a" : "#dc2626" }}
                  >
                    {isOnline ? "Internet Connected" : "No Internet"}
                  </span>
                </div>
                {/* <div className="flex items-center gap-2">
                  <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                    syncStatus === 'syncing' ? 'bg-yellow-400 animate-pulse' :
                    syncStatus === 'error'   ? 'bg-red-500' : 'bg-green-500'
                  }`} />
                  <span className="text-xs font-bold" style={{ fontFamily: "Poppins", color:
                    syncStatus === 'error' ? '#dc2626' : syncStatus === 'syncing' ? '#ca8a04' : '#16a34a'
                  }}>
                    {syncStatus === 'syncing'    ? 'Syncing...'
                    : syncStatus === 'error'   ? 'Sync Failed'
                    : pendingCount             ? `${pendingCount} Pending`
                    : 'All Synced'}
                  </span>
                </div> */}
              </div>
            </div>
          </div>
        );
      })()}
      {showPaymentModal && (
        <>
          <div className="fixed inset-0 z-100001 animate-fade-in"
            style={{ background: "rgba(0,0,0,0.4)", backdropFilter: "blur(3px)" }}
            onClick={() => {
              if (isTerminalProcessing) return; // ← block
              setShowPaymentModal(false);
              setPayments([]); setInputAmount(""); setOrderNumber("");
              setSalesNumber(""); setTransactionNumber("");
              setPaymentMethod("cash"); setPaymentSubMethod("");
            }}
          />
          <div className="fixed right-0 inset-y-0 z-100002 animate-slide-in-right" style={{ width: 500 }} onClick={(e) => e.stopPropagation()}>
            <div className="h-full flex flex-col rounded-l-3xl relative overflow-hidden" style={{ ...glass.panel, border: "2px solid rgba(255,255,255,0.5)", boxShadow: "-10px 0 40px rgba(0,0,0,0.2)" }}>
              {isTerminalProcessing && (
                <div className="absolute inset-0 z-50 flex flex-col items-center justify-center gap-4 rounded-l-3xl"
                  style={{ background: "rgba(255,255,255,0.75)", backdropFilter: "blur(6px)" }}>
                  <div className="w-14 h-14 rounded-full border-4 border-orange-200 border-t-orange-500 animate-spin" />
                  <p className="text-sm font-bold text-gray-700 uppercase tracking-widest"
                    style={{ fontFamily: "Poppins" }}>
                    Waiting for terminal...
                  </p>
                  <p className="text-xs font-medium text-gray-400 text-center px-8"
                    style={{ fontFamily: "Poppins" }}>
                    Do not close or navigate away
                  </p>
                </div>
              )}
              {/* Fixed Header preventing overlap */}
              <div className="flex justify-between items-start shrink-0 p-8 pb-4">
                <div>
                  <h2 className="text-2xl font-bold mb-1" style={{ fontFamily: "Poppins", color: "#1a1a1a" }}>Order Payment</h2>
                  <p className="text-sm" style={{ fontFamily: "Poppins", color: "#666" }}>Review & Pay</p>
                </div>
                <button
                  onClick={() => {
                    if (isTerminalProcessing) return; // ← block
                    setShowPaymentModal(false);
                    setPayments([]); setInputAmount(""); setOrderNumber("");
                    setSalesNumber(""); setTransactionNumber("");
                    setPaymentMethod("cash"); setPaymentSubMethod(""); 
                  }}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-xl font-bold hover:bg-red-100"
                  style={{ color: "#999" }}>✕
                </button>
              </div>

              {/* Scrollable Content */}
              <div className="flex-1 overflow-y-auto px-8 pb-8 hide-scroll">
                <div className="mb-6 p-4 rounded-2xl flex justify-between items-center" style={{ background: "rgba(255,255,255,0.3)", border: "1px solid rgba(255,255,255,0.4)" }}>
                  <span className="text-base font-bold" style={{ fontFamily: "Poppins", color: "#666" }}>Total Amount</span>
                  <span className="text-2xl font-black" style={{ fontFamily: "Poppins", color: "#f97316" }}> {formatMoney(finalTotal)}</span>
                </div>

              {isSRPWD(transactionType) && discountAmt > 0 && (
                <div className="mb-3 px-4 py-2 rounded-xl flex items-center justify-between" style={{ background: transactionType === 'SR' ? "rgba(37,99,235,0.09)" : "rgba(124,58,237,0.09)", border: transactionType === 'SR' ? "1px solid rgba(37,99,235,0.2)" : "1px solid rgba(124,58,237,0.2)" }}>
                  <span style={{ fontFamily: "Poppins", fontSize: 13, color: transactionType === 'SR' ? "#2563eb" : "#7c3aed", fontWeight: 700 }}>
                    {transactionType === 'SR' ? '👴 SC (Senior Citizen)' : '♿ PWD'} — 20% Discount{customLineDiscount ? ` (${[...new Set(customLineDiscount.selectedKeys)].length} item(s))` : ''}
                  </span>
                  <span style={{ fontFamily: "Poppins", color: transactionType === 'SR' ? "#2563eb" : "#7c3aed", fontWeight: 900 }}>−{formatMoney(discountAmt)}</span>
                </div>
              )}
              {(transactionType === 'SOLO' || transactionType === 'MEDAL') && discountAmt > 0 && (
                <div className="mb-3 px-4 py-2 rounded-xl flex items-center justify-between" style={{ background: "rgba(22,163,74,0.09)", border: "1px solid rgba(22,163,74,0.2)" }}>
                  <span style={{ fontFamily: "Poppins", fontSize: 13, color: "#16a34a", fontWeight: 700 }}>
                    {transactionType === 'SOLO' ? '👨‍👦 Solo Parent — 20% Discount' : '🎖️ Medal of Valor — 20% Discount'}
                  </span>
                  <span style={{ fontFamily: "Poppins", color: "#16a34a", fontWeight: 900 }}>−{formatMoney(discountAmt)}</span>
                </div>
              )}
              {transactionType === 'CUSTOM' && discountAmt > 0 && (
                <div className="mb-3 px-4 py-2 rounded-xl flex items-center justify-between" style={{ background: "rgba(8,145,178,0.09)", border: "1px solid rgba(8,145,178,0.2)" }}>
                  <span style={{ fontFamily: "Poppins", fontSize: 13, color: "#0891b2", fontWeight: 700 }}>✏️ Custom Discount</span>
                  <span style={{ fontFamily: "Poppins", color: "#0891b2", fontWeight: 900 }}>−{formatMoney(discountAmt)}</span>
                </div>
              )}
              {(transactionType === 'ATHLETE') && discountAmt > 0 && (() => {
                const cfg = TRANSACTION_TYPES.find(t => t.id === transactionType)!;
                return (
                  <div className="mb-3 px-4 py-2 rounded-xl flex items-center justify-between" style={{ background: `${cfg.color}15`, border: `1px solid ${cfg.border}` }}>
                    <span style={{ fontFamily: "Poppins", fontSize: 13, color: cfg.color, fontWeight: 700 }}>{cfg.icon} {cfg.label} — 20% Discount</span>
                    <span style={{ fontFamily: "Poppins", color: cfg.color, fontWeight: 900 }}>−{formatMoney(discountAmt)}</span>
                  </div>
                );
              })()}
              {(transactionType === 'DIPLOMAT' || transactionType === 'PEZA') && discountAmt > 0 && (
                <div className="mb-3 px-4 py-2 rounded-xl flex items-center justify-between" style={{ background: "rgba(139,92,246,0.09)", border: "1px solid rgba(139,92,246,0.2)" }}>
                  <span style={{ fontFamily: "Poppins", fontSize: 13, color: "#8b5cf6", fontWeight: 700 }}>{transactionType === 'DIPLOMAT' ? '🏛️' : '🏢'} {TRANSACTION_TYPES.find(t => t.id === transactionType)?.label} — VAT Removed</span>
                  <span style={{ fontFamily: "Poppins", color: "#8b5cf6", fontWeight: 900 }}>−{formatMoney(discountAmt)}</span>
                </div>
              )}
              {transactionType === 'REGULAR' && appliedDiscount && (
                <div className="mb-4 px-4 py-2 rounded-xl flex items-center justify-between" style={{ background: "rgba(22,163,74,0.09)", border: "1px solid rgba(22,163,74,0.2)" }}>
                  <span style={{ fontFamily: "Poppins", fontSize: 13, color: "#16a34a", fontWeight: 700 }}>{getDiscountInfo(appliedDiscount)?.icon || "🏷️"} {getDiscountInfo(appliedDiscount)?.label}</span>
                  <span style={{ fontFamily: "Poppins", color: "#16a34a", fontWeight: 900 }}>−{formatMoney(discountAmt)}</span>
                </div>
              )}

              {payments.length > 0 && (
                <div className="mb-4 p-3 rounded-xl" style={{ background: "rgba(249,115,22,0.15)", border: "1px solid rgba(249,115,22,0.3)" }}>
                  <p className="mb-1" style={{ fontFamily: "Poppins", color: "#333", fontSize: 13 }}>Split Payments Added</p>
                  {payments.map((payment, idx) => (
                    <div key={idx} className="flex items-center justify-between mb-2">
                      <span style={{ fontFamily: "Poppins", fontSize: 13, color: "#000", fontWeight: 700 }}>
                        {payment.method.toUpperCase()}{payment.refCode ? `: ${payment.refCode}` : ""}
                        {payment.tendered && payment.tendered > payment.amount ? <span className="text-gray-500 font-normal ml-2">(Val: {formatMoney(payment.tendered)})</span> : null}
                      </span>
                      <div className="flex gap-2 items-center">
                        <span style={{ fontFamily: "Poppins", fontSize: 13, color: "#000", fontWeight: 900 }}>{formatMoney(payment.amount)}</span>
                        <button onClick={() => {
                          const newPayments = payments.filter((_, i) => i !== idx);
                          setPayments(newPayments);
                          const newPaid = newPayments.reduce((s, p) => s + p.amount, 0);
                          const remaining = finalTotal - newPaid;
                          setInputAmount(remaining > 0 ? parseFloat(remaining.toFixed(2)).toString() : "");
                        }} className="text-red-500 font-bold hover:text-red-700">✕</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {(() => {
                const paidAmount = payments.reduce((sum, p) => sum + p.amount, 0);
                const cashTendered = payments.filter(p => p.method.toUpperCase() === 'CASH').reduce((sum, p) => sum + p.amount, 0);
                const remaining = finalTotal - paidAmount;
                const isChange = remaining < 0;
                
                const actualChange = Math.max(0, Math.min(Math.abs(remaining), cashTendered));
                const displayAmount = isChange ? actualChange : Math.max(0, remaining);
                
                return (
                  <div className="mb-6 p-3 rounded-xl" style={{ background: remaining <= 0 ? "rgba(22,163,74,0.09)" : "rgba(249,115,22,0.09)", border: remaining <= 0 ? "1px solid rgba(22,163,74,0.2)" : "1px solid rgba(249,115,22,0.2)" }}>
                    <div className="flex justify-between items-center mb-1">
                      <span style={{ fontFamily: "Poppins", fontSize: 12, color: "#000", fontWeight: 700 }}>Total Paid</span>
                      <span style={{ fontFamily: "Poppins", fontSize: 14, color: "#000", fontWeight: 900 }}>{formatMoney(paidAmount)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span style={{ fontFamily: "Poppins", fontSize: 12, color: "#000", fontWeight: 700 }}>{isChange ? "Change" : "Remaining Balance"}</span>
                      <span style={{ fontFamily: "Poppins", fontSize: 14, color: "#000", fontWeight: 900 }}>{formatMoney(displayAmount)}</span>
                    </div>
                  </div>
                );
              })()}

              {(() => {
                const paidAmount = payments.reduce((sum, p) => sum + p.amount, 0);
                const remaining = finalTotal - paidAmount;
                if (remaining <= 0.01) return null;
                return (
                  <>
                    <div className="mb-6">
                      <p className="text-sm font-bold mb-3" style={{ fontFamily: "Poppins", color: "#333" }}>Payment method</p>
                      <div className="grid grid-cols-4 gap-3">
                        {[{ id: "cash", label: "CASH" }, { id: "card", label: "CARD" }, { id: "ewallet", label: "EWallet" }, { id: "voucher", label: "Voucher" }].map((m) => (
                          <button key={m.id} onClick={() => { setPaymentMethod(m.id); setPaymentSubMethod(""); }} className="p-4 rounded-2xl font-bold" style={{ background: paymentMethod === m.id ? "rgba(255,255,255,0.5)" : "rgba(255,255,255,0.2)", border: paymentMethod === m.id ? "2px solid #f97316" : "1px solid rgba(255,255,255,0.3)", color: "#333", fontSize: 12, fontFamily: "Poppins" }}>
                            {m.label}
                          </button>
                        ))}
                      </div>
                    </div>
                    {paymentMethod === "card" && (
                      <div className="mb-6">
                        <p className="text-sm font-bold mb-3" style={{ fontFamily: "Poppins", color: "#333" }}>Card Type</p>
                        <div className="grid grid-cols-2 gap-3">
                          {[{ id: "debit", label: "Card Debit" }, { id: "credit", label: "Card Credit" }].map((c) => (
                            <button key={c.id} onClick={() => setPaymentSubMethod(c.id)} className="p-3 rounded-2xl font-bold" style={{ background: paymentSubMethod === c.id ? "rgba(249,115,22,0.3)" : "rgba(255,255,255,0.2)", border: paymentSubMethod === c.id ? "2px solid #f97316" : "1px solid rgba(255,255,255,0.3)", color: "#333", fontSize: 12, fontFamily: "Poppins" }}>{c.label}</button>
                          ))}
                        </div>
                      </div>
                    )}
                    {paymentMethod === "ewallet" && (
                      <div className="mb-6">
                        <p className="text-sm font-bold mb-3" style={{ fontFamily: "Poppins", color: "#333" }}>E-Wallet Provider</p>
                        <div className="grid grid-cols-2 gap-3">
                          {[{ id: "maya", label: "Maya" }, { id: "gcash", label: "GCash" }].map((e) => (
                            <button key={e.id} onClick={() => setPaymentSubMethod(e.id)} className="p-3 rounded-2xl font-bold" style={{ background: paymentSubMethod === e.id ? "rgba(249,115,22,0.3)" : "rgba(255,255,255,0.2)", border: paymentSubMethod === e.id ? "2px solid #f97316" : "1px solid rgba(255,255,255,0.3)", color: "#333", fontSize: 12, fontFamily: "Poppins" }}>{e.label}</button>
                          ))}
                        </div>
                      </div>
                    )}
                    {paymentMethod === "voucher" && (
                      <div className="mb-6 animate-fade-in">
                        <p className="text-sm font-bold mb-3" style={{ fontFamily: "Poppins", color: "#333" }}>Voucher Code</p>
                        <KeyboardInput 
                          keyboardLayout="default" 
                          value={paymentSubMethod} 
                          onChange={val => setPaymentSubMethod(val)} 
                          className="w-full p-4 rounded-2xl font-bold border-2 focus:border-orange-500 outline-none transition-all shadow-sm" 
                          placeholder="Tap to enter voucher code..." 
                          style={{ background: "rgba(255,255,255,0.8)", color: "#111", fontSize: 14, fontFamily: "Poppins", borderColor: paymentSubMethod ? "#f97316" : "rgba(249,115,22,0.2)" }} 
                        />
                      </div>
                    )}
                    <div className="mb-3">
                      <input type="text" value={formatDisplay(inputAmount)}
                        readOnly placeholder="Input amount" className="w-full p-3 rounded-2xl border-0 text-center text-xl font-bold mb-3" style={{ fontFamily: "Poppins", background: "rgba(255,255,255,0.4)", color: "#333" }} />
                      <div className="grid grid-cols-4 gap-2">
                        {["1","2","3","10","4","5","6","20","7","8","9","X","C","0",".","Pay"].map((k) => (
                          <button key={k} 
                            onClick={() => handleKey(k)}
                            className={`p-3 rounded-xl font-bold text-base transition-all hover:brightness-110 active:scale-95 ${k === 'Pay' ? 'shadow-[0_4px_14px_rgba(22,163,74,0.4)] text-xl tracking-wider' : ''}`}
                            style={{ 
                              fontFamily: "Poppins", 
                              background: k === "X" ? "rgba(241,100,100,0.3)" : k === "C" ? "rgba(255,200,100,0.3)" : k === "Pay" ? "linear-gradient(135deg, #22c55e 0%, #15803d 100%)" : "rgba(255,255,255,0.3)", 
                              border: k === "Pay" ? "none" : "1px solid rgba(255,255,255,0.4)", 
                              color: k === "X" ? "#e74c3c" : k === "Pay" ? "#ffffff" : "#333" 
                            }}>
                            {k === "Pay" ? "PAY" : k}
                          </button>
                        ))}
                      </div>
                    </div>
                  </>
                );
              })()}

              <div className="mt-auto pt-4">
                {showPrinterBypass && (
                  <div
                    className="mb-3 px-4 py-3 rounded-2xl flex items-center justify-between gap-3 animate-fade-in"
                    style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)" }}
                  >
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <span style={{ fontSize: 18 }}><ImWarning color="red" /></span>
                      <span className="text-xs font-bold text-red-600 leading-tight" style={{ fontFamily: "Poppins" }}>
                        Printer status unknown. Proceed without drawer verification?
                      </span>
                    </div>
                    <div className="flex gap-2 flex-shrink-0">
                      <button
                        onClick={() => setShowPrinterBypass(false)}
                        className="px-3 py-1.5 rounded-lg text-xs font-bold bg-white text-gray-600 hover:bg-gray-100 transition-colors border border-gray-200"
                        style={{ fontFamily: "Poppins" }}
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => {
                          setShowPrinterBypass(false);
                          processPayment(true);
                        }}
                        className="px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-red-500 hover:bg-red-600 transition-colors shadow-sm"
                        style={{ fontFamily: "Poppins" }}
                      >
                        Bypass & Pay
                      </button>
                    </div>
                  </div>
                )}

                {finalTotal - payments.reduce((s, p) => s + p.amount, 0) <= 0.01 &&
                  <button
                    onClick={() => processPayment(false)}
                    className="w-full rounded-2xl py-5 text-xl font-black text-white transition-all hover:brightness-110 active:scale-95 disabled:cursor-not-allowed"
                    style={{
                      fontFamily: "Poppins", textTransform: "uppercase", letterSpacing: 2,
                      background: (() => { const p = payments.reduce((s, p) => s + p.amount, 0); return finalTotal - p <= 0.01 ? "linear-gradient(135deg, #f97316 0%, #c2410c 100%)" : "rgba(0,0,0,0.15)"; })(),
                      color: (() => { const p = payments.reduce((s, p) => s + p.amount, 0); return finalTotal - p <= 0.01 ? "#fff" : "rgba(0,0,0,0.3)"; })(),
                      cursor: (() => { const p = payments.reduce((s, p) => s + p.amount, 0); return finalTotal - p <= 0.01 ? "pointer" : "not-allowed"; })(),
                      boxShadow: (() => { const p = payments.reduce((s, p) => s + p.amount, 0); return finalTotal - p <= 0.01 ? "0 8px 24px rgba(249,115,22,0.4), 0 2px 8px rgba(234,88,12,0.3)" : "none"; })(),
                    }}>
                    {(() => {
                      const p = payments.reduce((s, p) => s + p.amount, 0);
                      return finalTotal - p <= 0.01 ? `✓ Complete Transaction` : `Awaiting Payment`;
                    })()}
                  </button>
                }
              </div>
            </div>
            </div>
          </div>
        </>
      )}
    </>
  );
}