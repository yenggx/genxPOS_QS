// app/(pos)/reports/page.tsx
/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';
import { useRouter } from "next/navigation";
import { useState, useEffect, useMemo } from "react";
import { FiPrinter, FiFileText } from 'react-icons/fi';
import { BarChart2, X, ChevronRight, FileSpreadsheet, TrendingUp, Download, AlertCircle } from "lucide-react";
import { sileo } from "sileo";
import { usePrinter } from "@/app/context/PrinterContext";
import { PinModal } from "@/app/components/pos/PinModal";
import { getAssociateByPin } from '../../../src/api/associates';
import {
  contentToStats,
  generateZOrYReadingText,
  generateXReadingText,
  generateEShiftText,
  fmtAmt,
  fmtSI,
  padRight,
  padLeft,
  centerText,
  divider,
  formatHtmlToText,
  type ReportStats,
} from "../../../src/lib/report-builders";
import { getWorkstationId } from "@/src/lib/workstation";

function fmtSILocal(val: number, pad = 8) { return fmtSI(val, pad); }
function divW(width = 48) { return divider(width); }

function buildStats(
  txList: any[],
  sessions: any[],
  catMapData: { catMap: Record<string, string>; itemPriceMap: Record<string, number> },
  voidLogList: any[] = []
): ReportStats {
  let grossSales = 0, totalDiscount = 0, netSales = 0,
      vatableSales = 0, vatExemptSales = 0, zeroRatedSales = 0, totalTax = 0,
      totalCashSales = 0, totalNonCashSales = 0,
      totalVoided = 0, totalRefunded = 0,
      cashTxCount = 0, nonCashTxCount = 0,
      voidCount = 0, refundCount = 0, guestCount = 0;

  const pCounts = { CARD: 0, MAYA: 0, GCASH: 0, QRPH: 0, LANDERS: 0 };
  const pSums   = { CARD: 0, MAYA: 0, GCASH: 0, QRPH: 0, LANDERS: 0 };
  const dCounts = { ATHLETE: 0, SRC: 0, PWD: 0, SOLO: 0, MEDAL: 0, CUSTOM: 0 };
  const dSums   = { ATHLETE: 0, SRC: 0, PWD: 0, SOLO: 0, MEDAL: 0, CUSTOM: 0 };
  const revenueByCategory: Record<string, number> = {};
  const txTypeSummary: Record<string, { count: number; amount: number }> = {};

  let minSi = Infinity, maxSi = -Infinity, totalSi = 0,
      minVoidSi = Infinity, maxVoidSi = -Infinity,
      minRefundSi = Infinity, maxRefundSi = -Infinity;

  let minVoidSeries = '', maxVoidSeries = '',
      minRefundSeries = '', maxRefundSeries = '';

  const seriesVal = (s: string) =>
    parseInt(s.replace(/[^0-9]/g, '').slice(-8) || '0', 10);

  txList.forEach(tx => {
    const isVoid   = tx.status === 'voided'   || tx.orderState === 'VOIDED';
    const isRefund = tx.status === 'refunded' || tx.orderState === 'REFUNDED';
    const txType   = (tx.transactionType || 'REGULAR').toUpperCase();

    const siMatch = tx.salesNumber?.match(/\d+$/);
    if (siMatch) {
      const siNum = parseInt(siMatch[0], 10);
      if (!isVoid) { minSi = Math.min(minSi, siNum); maxSi = Math.max(maxSi, siNum); totalSi++; }
      if (isVoid)   { minVoidSi   = Math.min(minVoidSi, siNum);   maxVoidSi   = Math.max(maxVoidSi, siNum); }
      if (isRefund) { minRefundSi = Math.min(minRefundSi, siNum); maxRefundSi = Math.max(maxRefundSi, siNum); }
    }

    const gross    = (tx.price?.subtotal    || 0) / 100;
    const discount = (tx.discountAmount     || 0) / 100;
    const tax      = (tx.price?.VatAmount   || tx.price?.tax || 0) / 100;
    const vatable  = (tx.price?.VATSale     || 0) / 100;
    const exempt   = (tx.price?.VatExSales || 0) / 100;
    const zero     = (tx.price?.ZeroRated  || 0) / 100;
    const net      = gross - discount - (isVoid || isRefund ? 0 : (exempt > 0 ? tax : 0));

    if (isRefund) {
      totalRefunded += gross; refundCount++;
      if (tx.refundSeriesNo) {
        if (!minRefundSeries || seriesVal(tx.refundSeriesNo) < seriesVal(minRefundSeries)) minRefundSeries = tx.refundSeriesNo;
        if (!maxRefundSeries || seriesVal(tx.refundSeriesNo) > seriesVal(maxRefundSeries)) maxRefundSeries = tx.refundSeriesNo;
      }
      return;
    }

    grossSales += gross;
    totalDiscount += discount;
    totalTax += tax;
    vatableSales += vatable;
    vatExemptSales += exempt;
    zeroRatedSales += zero;
    netSales += net;

    if (!txTypeSummary[txType]) txTypeSummary[txType] = { count: 0, amount: 0 };
    txTypeSummary[txType].count++;
    txTypeSummary[txType].amount += net;

    if (discount > 0) {
      if      (txType === 'SRC')     { dCounts.SRC++;     dSums.SRC     += discount; }
      else if (txType === 'PWD')     { dCounts.PWD++;     dSums.PWD     += discount; }
      else if (txType === 'ATHLETE') { dCounts.ATHLETE++; dSums.ATHLETE += discount; }
      else if (txType === 'SOLO')    { dCounts.SOLO++;    dSums.SOLO    += discount; }
      else if (txType === 'MEDAL')   { dCounts.MEDAL++;   dSums.MEDAL   += discount; }
      else if (txType === 'CUSTOM')  { dCounts.CUSTOM++;  dSums.CUSTOM  += discount; }
    }

    const guests = tx.guest || tx.guests || [];
    if (guests.length > 0) guestCount += guests.length;

    let cashCollected = 0, nonCashCollected = 0;
    if (Array.isArray(tx.payment) && tx.payment.length > 0) {
      tx.payment.forEach((p: any) => {
        const methodStr = String(p.PaymentMethod || p.method || 'CASH').toUpperCase();
        let amt = Number(p.Amount ?? p.amount ?? 0);
        if (p.Amount !== undefined && amt > 1000 && amt > gross * 50) amt /= 100;

        if (methodStr === 'CASH') {
          cashCollected += amt;
        } else {
          nonCashCollected += amt;
          let mapMethod = 'CARD';
          if      (methodStr.includes('MAYA'))    mapMethod = 'MAYA';
          else if (methodStr.includes('GCASH'))   mapMethod = 'GCASH';
          else if (methodStr.includes('QRPH'))    mapMethod = 'QRPH';
          else if (methodStr.includes('LANDERS')) mapMethod = 'LANDERS';
          if (pCounts[mapMethod as keyof typeof pCounts] !== undefined) {
            pCounts[mapMethod as keyof typeof pCounts]++;
            pSums[mapMethod   as keyof typeof pSums] += amt;
          }
        }
      });
    } else {
      const rootMethod = String(tx.paymentMethod || tx.PaymentMethod || 'CASH').toUpperCase();
      if (rootMethod !== 'CASH') nonCashCollected = net;
      else cashCollected = net;
    }

    if (cashCollected > 0)    { totalCashSales    += cashCollected;    cashTxCount++; }
    if (nonCashCollected > 0) { totalNonCashSales += nonCashCollected; nonCashTxCount++; }

    const items = tx.items || tx.cart || [];
    items.forEach((item: any) => {
      const qty      = item.quantity || item.qty || 1;
      const rawPrice = item.price || 0;
      const price    = rawPrice > 1000 ? rawPrice / 100 : rawPrice;
      const catId    = item.id || item.itemId || '';
      const catName  = catMapData.catMap[catId] || item.category || 'OTHER';
      const itemDiscount = item.itemDiscount ? item.itemDiscount / 100 : 0;
      revenueByCategory[catName] = (revenueByCategory[catName] || 0) + (price * qty) - itemDiscount;
    });
  });

  voidLogList.forEach(log => {
    voidCount++;
    (log.items || []).forEach((item: any) => {
      const qty      = item.qty || item.quantity || 1;
      const price    = (item.price || 0); 
      let lineTotal  = price * qty;

      (item.modifiers || []).forEach((m: any) => {
        const mQty   = m.qty || m.quantity || 1;
        const mPrice = (m.price || 0) / 100;
        lineTotal   += mPrice * mQty;
      });

      totalVoided += lineTotal;
    });
  });

  let cashFund = 0, totalDropped = 0;
  sessions.forEach(s => {
    cashFund     += parseFloat(s.startingCash || '0');
    totalDropped += (s.cashDrops || []).reduce(
      (sum: number, d: any) => sum + parseFloat(d.amount), 0
    );
  });
  const expectedTotal = cashFund + totalCashSales - totalDropped;

  return {
    grossSales, totalDiscount, netSales, totalTax,
    totalCashSales, totalNonCashSales, totalVoided, totalRefunded,
    cashFund, expectedTotal, totalDropped,
    vatableSales, vatExemptSales, zeroRatedSales,
    cashTxCount, nonCashTxCount, voidCount, refundCount, guestCount,
    pCounts, pSums, dCounts, dSums,
    revenueByCategory, txTypeSummary,
    si: { minSi, maxSi, totalSi, minVoidSi, maxVoidSi, minRefundSi, maxRefundSi },
    voidSeriesRange:   { min: minVoidSeries   || '-', max: maxVoidSeries   || '-' },
    refundSeriesRange: { min: minRefundSeries || '-', max: maxRefundSeries || '-' },
    denominations: {},
    actualCashCount: 0,
    cashDrops: [],
  } as ReportStats;
}

const glass = {
  modal: {
    background: "rgba(255,255,255,0.95)",
    backdropFilter: "blur(32px)",
    WebkitBackdropFilter: "blur(32px)",
    border: "1.5px solid rgba(255,255,255,1)",
    boxShadow: "0 32px 80px rgba(0,0,0,0.16)",
  } as React.CSSProperties,
  button: {
    background: "rgba(255,255,255,0.38)",
    backdropFilter: "blur(14px)",
    WebkitBackdropFilter: "blur(14px)",
    border: "1px solid rgba(255,255,255,0.75)",
    boxShadow: "0 4px 16px rgba(0,0,0,0.07), inset 0 1px 0 rgba(255,255,255,0.8)",
  } as React.CSSProperties,
  buttonHover: {
    background: "rgba(249,115,22,0.13)",
    border: "1.5px solid rgba(249,115,22,0.55)",
    boxShadow: "0 8px 28px rgba(249,115,22,0.18), inset 0 1px 0 rgba(255,255,255,0.7)",
  } as React.CSSProperties,
};

type ReportDefinition = { id: number; label: string; Icon: any; desc: string; };

const REGULAR_REPORTS: ReportDefinition[] = [
  { id: 1, label: "Z-Reading",     Icon: BarChart2,       desc: "End-of-day aggregate"       },
  { id: 5, label: "Y-Reading",     Icon: BarChart2,       desc: "Per-terminal shift summary" },
  { id: 3, label: "X-Reading",     Icon: BarChart2,       desc: "Per-shift & turnover"       },
  { id: 7, label: "E-Shift",       Icon: FileSpreadsheet, desc: "E-Shift Cash Report reprint"},
  { id: 6, label: "Void Summary",  Icon: AlertCircle,     desc: "Voided transaction records" },
  { id: 2, label: "ESF Reports",   Icon: FileSpreadsheet, desc: "Electronic Sales File"      },
];

const BIR_REPORTS: ReportDefinition[] = [
  { id: 4, label: "Sales Summary",     Icon: TrendingUp,      desc: "BIR daily sales summary"     },
  { id: 8, label: "Detailed Sales",    Icon: TrendingUp,      desc: "Per-terminal detailed sales" },
  { id: 9, label: "Senior Report",     Icon: FileSpreadsheet, desc: "SC discount report"          },
  { id: 10, label: "PWD Report",       Icon: FileSpreadsheet, desc: "PWD discount report"         },
  { id: 11, label: "Athlete Report",   Icon: FileSpreadsheet, desc: "Nat'l Athlete report"        },
  { id: 12, label: "Zero-Rated Report",Icon: FileSpreadsheet, desc: "Diplomat & PEZA sales"       },
];

const BIR_CONFIG: Record<number, any> = {
  4: {
    title: "BIR SALES SUMMARY REPORT", csvTitle: "Sales_Summary",
    cols: [
      { label: 'DATE', key: 'DATE', align: 'center' }, { label: 'FROM', key: 'FROM', align: 'center' },
      { label: 'TO', key: 'TO', align: 'center' }, { label: 'BEGINNING', key: 'BEGINNING', align: 'right' },
      { label: 'ENDING', key: 'ENDING', align: 'right' }, { label: 'NET AMOUNT', key: 'NET_AMOUNT', align: 'right' },
      { label: 'DISCOUNTS', key: 'DISCOUNTS', align: 'right' }, { label: 'DEDUCTIONS', key: 'DEDUCTIONS', align: 'right' },
      { label: 'RETURNS', key: 'RETURNS', align: 'right' }, { label: 'VOIDS', key: 'VOIDS', align: 'right' },
      { label: 'OTHER CHARGES', key: 'OTHER_CHARGES', align: 'right' }, { label: 'GROSS AMOUNT', key: 'GROSS_AMOUNT', align: 'right' },
      { label: 'VATABLE SALES', key: 'VATABLE_SALES', align: 'right' }, { label: 'VAT AMOUNT', key: 'VAT_AMOUNT', align: 'right' },
      { label: 'VAT-EXEMPT SALES', key: 'VAT_EXEMPT_SALES', align: 'right' }, { label: 'ZERO RATED SALES', key: 'ZERO_RATED_SALES', align: 'right' },
      { label: 'SALES OVERRUN', key: 'SALES_OVERRUN', align: 'right' }, { label: 'Z-COUNT', key: 'Z_COUNT', align: 'center' },
      { label: 'REMARKS', key: 'REMARKS', align: 'left' }
    ]
  },
  8: {
    title: "DETAILED SALES SUMMARY", csvTitle: "Detailed_Sales",
    cols: [
      { label: 'DATE', key: 'DATE', align: 'center' }, { label: 'TERMINAL NO', key: 'TERMINAL_NO', align: 'center' },
      { label: 'TRANSACTION NO', key: 'TRANSACTION_NO', align: 'center' }, { label: 'REFUND SERIES', key: 'REFUND_SERIES', align: 'center' },
      { label: 'GROSS', key: 'GROSS', align: 'right' }, { label: 'OTHER CHARGES', key: 'OTHER_CHARGES', align: 'right' },
      { label: 'DISCOUNTS', key: 'DISCOUNTS', align: 'right' }, { label: 'VAT AMOUNT', key: 'VAT_AMOUNT', align: 'right' },
      { label: 'VAT EXEMPT SALES', key: 'VAT_EXEMPT_SALES', align: 'right' }, { label: 'NET SALES', key: 'NET_SALES', align: 'right' },
      { label: 'STATUS', key: 'STATUS', align: 'center' }
    ]
  },
  9: {
    title: "SENIOR CITIZEN SALES REPORT", csvTitle: "Senior_Report",
    cols: [
      { label: 'DATE', key: 'DATE', align: 'center' }, { label: 'SALES NUMBER', key: 'SALES_NUMBER', align: 'center' },
      { label: 'CUSTOMER NAME', key: 'CUSTOMER_NAME', align: 'left' }, { label: 'CUSTOMER ID', key: 'CUSTOMER_ID', align: 'left' },
      { label: 'GROSS', key: 'GROSS', align: 'right' }, { label: 'OTHER CHARGES', key: 'OTHER_CHARGES', align: 'right' },
      { label: 'DISCOUNTS', key: 'DISCOUNTS', align: 'right' }, { label: 'VAT ADJ', key: 'VAT_ADJ', align: 'right' },
      { label: 'NET SALES', key: 'NET_SALES', align: 'right' }, { label: 'VAT EXEMPT SALES', key: 'VAT_EXEMPT_SALES', align: 'right' },
      { label: 'CASH', key: 'CASH', align: 'right' }, { label: 'CREDIT CARD', key: 'CREDIT_CARD', align: 'right' },
      { label: 'OTHER', key: 'OTHER', align: 'right' }, { label: 'REMARKS', key: 'REMARKS', align: 'left' }
    ]
  },
  10: {
    title: "PERSONS WITH DISABILITY (PWD) SALES REPORT", csvTitle: "PWD_Report",
    cols: [
      { label: 'DATE', key: 'DATE', align: 'center' }, { label: 'SALES NUMBER', key: 'SALES_NUMBER', align: 'center' },
      { label: 'CUSTOMER NAME', key: 'CUSTOMER_NAME', align: 'left' }, { label: 'CUSTOMER ID', key: 'CUSTOMER_ID', align: 'left' },
      { label: 'GROSS', key: 'GROSS', align: 'right' }, { label: 'OTHER CHARGES', key: 'OTHER_CHARGES', align: 'right' },
      { label: 'DISCOUNTS', key: 'DISCOUNTS', align: 'right' }, { label: 'VAT ADJ', key: 'VAT_ADJ', align: 'right' },
      { label: 'NET SALES', key: 'NET_SALES', align: 'right' }, { label: 'VAT EXEMPT SALES', key: 'VAT_EXEMPT_SALES', align: 'right' },
      { label: 'CASH', key: 'CASH', align: 'right' }, { label: 'CREDIT CARD', key: 'CREDIT_CARD', align: 'right' },
      { label: 'OTHER', key: 'OTHER', align: 'right' }, { label: 'REMARKS', key: 'REMARKS', align: 'left' }
    ]
  },
  11: {
    title: "NATIONAL ATHLETE SALES REPORT", csvTitle: "Athlete_Report",
    cols: [
      { label: 'DATE', key: 'DATE', align: 'center' }, { label: 'SALES NUMBER', key: 'SALES_NUMBER', align: 'center' },
      { label: 'CUSTOMER NAME', key: 'CUSTOMER_NAME', align: 'left' }, { label: 'CUSTOMER ID', key: 'CUSTOMER_ID', align: 'left' },
      { label: 'GROSS', key: 'GROSS', align: 'right' }, { label: 'OTHER CHARGES', key: 'OTHER_CHARGES', align: 'right' },
      { label: 'DISCOUNTS', key: 'DISCOUNTS', align: 'right' }, { label: 'VAT ADJ', key: 'VAT_ADJ', align: 'right' },
      { label: 'NET SALES', key: 'NET_SALES', align: 'right' }, { label: 'VAT EXEMPT SALES', key: 'VAT_EXEMPT_SALES', align: 'right' },
      { label: 'CASH', key: 'CASH', align: 'right' }, { label: 'CREDIT CARD', key: 'CREDIT_CARD', align: 'right' },
      { label: 'OTHER', key: 'OTHER', align: 'right' }, { label: 'REMARKS', key: 'REMARKS', align: 'left' }
    ]
  },
  12: {
    title: "ZERO-RATED SALES REPORT", csvTitle: "Zero_Rated_Report",
    cols: [
      { label: 'DATE', key: 'DATE', align: 'center' }, { label: 'SALES NUMBER', key: 'SALES_NUMBER', align: 'center' },
      { label: 'CUSTOMER NAME', key: 'CUSTOMER_NAME', align: 'left' }, { label: 'GROSS', key: 'GROSS', align: 'right' },
      { label: 'OTHER CHARGES', key: 'OTHER_CHARGES', align: 'right' }, { label: 'DISCOUNTS', key: 'DISCOUNTS', align: 'right' },
      { label: 'VAT ADJ', key: 'VAT_ADJ', align: 'right' }, { label: 'NET SALES', key: 'NET_SALES', align: 'right' },
      { label: 'VAT EXEMPT SALES', key: 'VAT_EXEMPT_SALES', align: 'right' }, { label: 'CASH', key: 'CASH', align: 'right' },
      { label: 'CREDIT CARD', key: 'CREDIT_CARD', align: 'right' }, { label: 'OTHER', key: 'OTHER', align: 'right' },
      { label: 'REMARKS', key: 'REMARKS', align: 'left' }
    ]
  }
};

function ReportButton({ report, onClick }: { report: ReportDefinition; onClick: (r: ReportDefinition) => void }) {
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);
  const { Icon } = report;
  return (
    <button
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => { setHovered(false); setPressed(false); }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onClick={() => onClick(report)}
      className="flex items-center gap-3 w-full text-left rounded-2xl px-5 py-4 focus:outline-none"
      style={{
        ...(hovered ? { ...glass.button, ...glass.buttonHover } : glass.button),
        transform: pressed ? "scale(0.97)" : hovered ? "translateY(-2px) scale(1.01)" : "scale(1)",
        transition: "all 0.2s cubic-bezier(0.25, 1, 0.5, 1)",
      }}
    >
      <span
        className="flex-shrink-0 w-8 h-8 rounded-xl flex items-center justify-center font-black"
        style={{ background: hovered ? "linear-gradient(135deg, #f97316, #ea580c)" : "rgba(249,115,22,0.13)", color: hovered ? "#fff" : "#f97316", border: hovered ? "1px solid rgba(249,115,22,0.25)" : '', boxShadow: hovered ? "0 2px 10px rgba(249,115,22,0.30)" : "none", transition: "all 0.2s ease", fontFamily: "Impact, Arial Black, sans-serif", fontSize: 13 }}
      >
        {report.id}
      </span>
      <span
        className="flex-shrink-0 flex items-center justify-center w-7 h-7 rounded-lg"
        style={{ background: hovered ? "rgba(249,115,22,0.12)" : "rgba(255,255,255,0.55)", border: hovered ? "1px solid rgba(249,115,22,0.30)" : "1px solid rgba(255,255,255,0.65)", transition: "all 0.2s ease" }}
      >
        <Icon size={15} strokeWidth={2.2} color={hovered ? "#f97316" : "#888"} style={{ transition: "color 0.2s ease" }} />
      </span>
      <div className="flex-1 min-w-0">
        <span className="block" style={{ fontFamily: "Poppins", fontSize: 14, fontWeight: 900, letterSpacing: 0.5, color: hovered ? "#ea580c" : "#1a1a1a", transition: "color 0.2s ease" }}>
          {report.label}
        </span>
        <span className="block" style={{ fontFamily: "Poppins", fontSize: 10, color: hovered ? "#f97316" : "#aaa", fontWeight: 600, transition: "color 0.2s ease" }}>
          {report.desc}
        </span>
      </div>
      <ChevronRight size={16} strokeWidth={2.5} color={hovered ? "#f97316" : "rgba(0,0,0,0.18)"} style={{ flexShrink: 0, transition: "all 0.2s ease", transform: hovered ? "translateX(3px)" : "translateX(0)" }} />
    </button>
  );
}

function ReceiptPreview({ text, empty = "No Report Selected" }: { text: string; empty?: string }) {
  return (
    <div className="flex-1 overflow-y-auto bg-gray-100 p-6 flex flex-col">
      {text ? (
        <div className="bg-white p-6 w-full max-w-[360px] shadow-sm border border-gray-200 mx-auto animate-fade-in">
          <pre style={{ fontFamily: "'Courier New', Courier, monospace", fontSize: 11, lineHeight: 1.3, whiteSpace: 'pre', color: '#000' }}>
            {text}
          </pre>
        </div>
      ) : (
        <div className="m-auto text-center opacity-50 animate-fade-in">
          <FiFileText size={48} className="mx-auto mb-3 text-gray-400" />
          <p className="text-sm font-bold text-gray-500 uppercase tracking-widest">{empty}</p>
        </div>
      )}
    </div>
  );
}

function WidePreviewArea({ html, loading = false }: { html: string; loading?: boolean }) {
  const [zoom, setZoom] = useState(0.75);

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-gray-100">
      {html && (
        <div className="flex items-center gap-2 px-4 py-2 bg-white border-b border-gray-200 flex-shrink-0">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Zoom</span>
          <button
            onClick={() => setZoom(z => Math.max(0.4, parseFloat((z - 0.1).toFixed(1))))}
            className="w-7 h-7 rounded-lg bg-gray-100 hover:bg-gray-200 font-bold text-gray-600 flex items-center justify-center transition-colors text-base"
          >−</button>
          <span className="text-xs font-bold text-gray-600 w-10 text-center" style={{ fontFamily: "Poppins" }}>
            {Math.round(zoom * 100)}%
          </span>
          <button
            onClick={() => setZoom(z => Math.min(2, parseFloat((z + 0.1).toFixed(1))))}
            className="w-7 h-7 rounded-lg bg-gray-100 hover:bg-gray-200 font-bold text-gray-600 flex items-center justify-center transition-colors text-base"
          >+</button>
          <button
            onClick={() => setZoom(1)}
            className="ml-1 px-3 h-7 rounded-lg bg-gray-100 hover:bg-gray-200 text-[10px] font-bold text-gray-500 transition-colors"
          >Reset</button>
          <button
            onClick={() => setZoom(0.75)}
            className="px-3 h-7 rounded-lg bg-orange-50 hover:bg-orange-100 text-[10px] font-bold text-orange-500 transition-colors border border-orange-200"
          >Fit</button>
        </div>
      )}

      <div className="flex-1 overflow-auto p-6">
        {html ? (
          <div
            className="bg-white shadow-sm border border-gray-200 animate-fade-in origin-top-left"
            style={{
              transform: `scale(${zoom})`,
              transformOrigin: 'top left',
              width: `${100 / zoom}%`,
              minWidth: 'max-content',
            }}
          >
            <div dangerouslySetInnerHTML={{ __html: html }} />
          </div>
        ) : (
          <div className="flex items-center justify-center h-full opacity-50">
            <div className="text-center">
              <FiFileText size={48} className="mx-auto mb-3 text-gray-400" />
              <p className="text-sm font-bold text-gray-500 uppercase tracking-widest">
                {loading ? "Loading..." : "No data for this date"}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Minimal utility to save HTML to PDF using the browser's native print engine
const handleExportPDF = (htmlContent: string, title: string) => {
  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    sileo.error({ title: "Pop-up Blocked", description: "Please allow pop-ups to generate PDF." });
    return;
  }
  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>${title}</title>
        <style>
          @media print {
            @page { size: landscape; margin: 10mm; }
            body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          }
          body { font-family: 'Courier New', monospace; background: white; margin: 0; padding: 20px; }
          table { width: 100%; border-collapse: collapse; }
        </style>
      </head>
      <body>
        ${htmlContent}
        <script>
          window.onload = () => {
            setTimeout(() => {
              window.print();
              window.close();
            }, 250);
          };
        </script>
      </body>
    </html>
  `);
  printWindow.document.close();
};

export default function ReportsPage() {
  const router = useRouter();
  const { printDirect } = usePrinter();

  const [activeReport,      setActiveReport]      = useState<ReportDefinition | null>(null);
  
  // Base date for Regular Reports
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  
  // Date Range for BIR Reports
  const [birStartDate, setBirStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [birEndDate,   setBirEndDate]   = useState<string>(new Date().toISOString().split('T')[0]);
  const [actualBirStartDate, setActualBirStartDate] = useState<string>('');
  const [actualBirEndDate,   setActualBirEndDate]   = useState<string>('');
  const [birData,      setBirData]      = useState<any[]>([]);
  const [birLoading,   setBirLoading]   = useState(false);
  const [birTerminalFilter, setBirTerminalFilter] = useState<string>(getWorkstationId() || '001'); // Default to current terminal

  const [businessDayDate, setBusinessDayDate] = useState<string | null>(null);
  const [selectedSessionId, setSelectedSessionId] = useState<string>("");
  const [loading,           setLoading]           = useState(false);
  const [esfData,           setEsfData]           = useState<any>(null);
  const [esfLoading,        setEsfLoading]        = useState(false);
  const [fiscalSettings,    setFiscalSettings]    = useState({ vatNumber: "", tinNumber: "", minNumber: "", ptuNumber: "", snNumber: "" });
  const [storeData,         setStoreData]         = useState<any>(null);
  const [allSessions,       setAllSessions]       = useState<any[]>([]);
  const [yTerminals,        setYTerminals]        = useState<string[]>([]);
  const [selectedYTerminal, setSelectedYTerminal] = useState<string>("");
  const [yReadingLoading,   setYReadingLoading]   = useState(false);
  
  const [savedYReport,   setSavedYReport]   = useState<any>(null);
  const [yReportLoading, setYReportLoading] = useState(false);

  const [savedZReport,  setSavedZReport]  = useState<any>(null);
  const [savedXReports, setSavedXReports] = useState<Record<string, any>>({});
  const [savedEShifts,  setSavedEShifts]  = useState<Record<string, any>>({});
  const [zReportLoading, setZReportLoading] = useState(false);
  const [xReportLoading, setXReportLoading] = useState(false);
  const [savedZReports,     setSavedZReports]     = useState<any[]>([]);
  const [selectedZReportId, setSelectedZReportId] = useState<string>('');

  const [voidData,         setVoidData]        = useState<any[]>([]);
  const [voidLoading,      setVoidLoading]     = useState(false);

  const terminalId = getWorkstationId() || '001';

  const [esfDocs,          setEsfDocs]          = useState<any[]>([]);
  const [selectedEsfId,    setSelectedEsfId]    = useState<string>('');

  const [voidSessions,       setVoidSessions]       = useState<any[]>([]);
  const [voidSessionsLoading,setVoidSessionsLoading] = useState(false);
  const [selectedVoidTerminal, setSelectedVoidTerminal] = useState<string>('ALL');
  const [calendarDates,      setCalendarDates]      = useState<Set<string>>(new Set());
  const [calendarLoading,    setCalendarLoading]    = useState(false);

  const [showPinModal, setShowPinModal] = useState(false);
  const [pinModalExiting, setPinModalExiting] = useState(false);
  const [currentXReadingPreview, setCurrentXReadingPreview] = useState<string>('');
  const [currentYReadingPreview, setCurrentYReadingPreview] = useState<string>('');
  const [previewTarget, setPreviewTarget] = useState<'X' | 'Y' | null>(null);
  const [livePreviewLoading, setLivePreviewLoading] = useState(false);
  const [menuCategoryMap, setMenuCategoryMap] = useState<{ catMap: Record<string, string>; itemPriceMap: Record<string, number> }>({ catMap: {}, itemPriceMap: {} });

  const isBirReport = [4, 8, 9, 10, 11, 12].includes(activeReport?.id || 0);

  // Derived Filtered BIR Data (Applies Terminal Filter for all BIR Reports)
  const filteredBirData = useMemo(() => {
    if (isBirReport && birTerminalFilter !== 'ALL') {
      return birData.filter(r => {
        // Use the injected workstationId from the database document, fallback to row column
        const term = r._docWorkstationId || r.TERMINAL_NO;
        if (term === undefined || term === null || term === '') return true;
        return String(term) === String(birTerminalFilter);
      });
    }
    return birData;
  }, [birData, isBirReport, birTerminalFilter]);

  useEffect(() => {
    fetch('/api/menu')
      .then(r => r.json())
      .then(menuData => {
        let categories: any[] = [];
        if (Array.isArray(menuData)) {
          categories = menuData[0]?.payload?.categories || menuData[0]?.categories || [];
        } else {
          categories = menuData?.payload?.categories || menuData?.categories || [];
        }

        const catMap: Record<string, string>       = {};
        const itemPriceMap: Record<string, number> = {};
        const getInitials = (name: string) =>
          name.replace(/[^a-zA-Z ]/g, '').trim().split(/\s+/).map(w => w[0]).join('').toUpperCase();

        categories.forEach((cat: any) => {
          const rawName = (cat.name || 'OTHER').toUpperCase();
          const catName = rawName.endsWith('S') && rawName !== 'GLASS' ? rawName.slice(0, -1) : rawName;

          const processItems = (items: any[], subName: string | null) => {
            const label = subName ? `${catName}: ${getInitials(subName)}` : catName;
            (items || []).forEach(item => {
              const stockId = (item.barcode && item.barcode !== 'GTIN') ? `IT-${item.barcode}` : item.id;
              catMap[stockId]       = label;
              catMap[item.id]       = label;
              itemPriceMap[stockId] = item.price || 0;
              itemPriceMap[item.id] = item.price || 0;
            });
          };

          processItems(cat.items, null);
          (cat.subcategories || []).forEach((sub: any) => processItems(sub.items, sub.name));
        });

        setMenuCategoryMap({ catMap, itemPriceMap });
      })
      .catch(console.error);
  }, []);

  useEffect(() => {
    fetch(`/api/settings?workstationId=${terminalId}`)
      .then(r => r.json())
      .then(d => setFiscalSettings({ vatNumber: d.vatNumber || "", tinNumber: d.tinNumber || "", minNumber: d.minNumber || "", ptuNumber: d.ptuNumber || "", snNumber: d.snNumber || "" }))
      .catch(() => {});
    try { const sd = JSON.parse(localStorage.getItem("store_data") || "null"); if (sd) setStoreData(sd); } catch {}
    fetch("/api/store")
      .then(r => r.json())
      .then(d => { if (d?.payload) { setStoreData(d.payload); localStorage.setItem("store_data", JSON.stringify(d.payload)); } })
      .catch(() => {});
  }, []);

  useEffect(() => {
    fetch('/api/business-day')
      .then(r => r.json())
      .then(d => {
        const bd = d.businessDay;
        if (bd?.date) {
          setDate(bd.date);
          setBusinessDayDate(bd.date);
          setBirStartDate(bd.date);
          setBirEndDate(bd.date);
        }
      })
      .catch(() => {});
  }, []);

  // --- BIR REPORTS EFFECT ---
  useEffect(() => {
    if (!isBirReport) return;
    
    setBirTerminalFilter(getWorkstationId() || '001'); // Reset to its own terminal by default
    
    const birReportMap: Record<number, string> = {
      4: 'SALES-SUMMARY',
      8: 'DETAILED-SALES-SUMMARY',
      9: 'SENIOR-REPORT',
      10: 'PWD-REPORT',
      11: 'ATHLETE-REPORT',
      12: 'ZERO-RATED-REPORT'
    };
    
    const type = birReportMap[activeReport!.id];
    if (!type) return;

    setBirLoading(true);
    setBirData([]);
    setActualBirStartDate('');
    setActualBirEndDate('');
    
    // Fetch using from/to parameters to grab the full range
    fetch(`/api/reports?type=${type}&from=${birStartDate}&to=${birEndDate}`)
      .then(r => r.json())
      .then(d => {
         const reports = d.reports || (d.report ? [d.report] : []);
         let allRows: any[] = [];
         
         const sorted = reports
           .filter((r: any) => r.date >= birStartDate && r.date <= birEndDate)
           .sort((a: any, b: any) => a.date.localeCompare(b.date));

         // Calculate the real bounding dates of the reports we actually got
         const validDates = sorted.map((r: any) => r.date).filter(Boolean);
         if (validDates.length > 0) {
           setActualBirStartDate(validDates[0]);
           setActualBirEndDate(validDates[validDates.length - 1]);
         } else {
           setActualBirStartDate(birStartDate);
           setActualBirEndDate(birEndDate);
         }

         sorted.forEach((r: any) => {
           if (r.content && r.content.rows) {
             // Intelligently extract the terminal ID from the row data (FROM or SALES_NUMBER)
             // Fallback to the document's workstationId if the row doesn't specify one
             const rowsWithTerminal = r.content.rows.map((row: any) => {
               let inferredTerminal = row.TERMINAL_NO;
               
               // Sales Summary uses 'FROM' (e.g., "WS1-000000000000172")
               if (!inferredTerminal && row.FROM && typeof row.FROM === 'string' && row.FROM.includes('-')) {
                 inferredTerminal = row.FROM.split('-')[0];
               }
               // Other BIR reports use 'SALES_NUMBER' (e.g., "WS2-000000000000185")
               if (!inferredTerminal && row.SALES_NUMBER && typeof row.SALES_NUMBER === 'string' && row.SALES_NUMBER.includes('-')) {
                 inferredTerminal = row.SALES_NUMBER.split('-')[0];
               }

               return {
                 ...row,
                 _docWorkstationId: inferredTerminal || r.workstationId || 'UNKNOWN'
               };
             });
             allRows = allRows.concat(rowsWithTerminal);
           }
         });
         setBirData(allRows);
      })
      .catch(() => setBirData([]))
      .finally(() => setBirLoading(false));
  }, [activeReport, birStartDate, birEndDate, isBirReport]);


  // --- REGULAR REPORTS EFFECTS ---
  useEffect(() => {
    if (activeReport?.id !== 2) return;
    setEsfLoading(true);
    setEsfData(null);
    setEsfDocs([]);
    setSelectedEsfId('');

    fetch(`/api/reports/esf?date=${date}`)
      .then(r => r.json())
      .then(d => {
        if (d.success) setEsfDocs([d]); 
        else setEsfDocs([]);
      })
      .catch(() => setEsfDocs([]))
      .finally(() => setEsfLoading(false));
  }, [date, activeReport]);

  useEffect(() => {
    if (activeReport?.id !== 6) return;
    setVoidSessionsLoading(true);
    setVoidSessions([]);
    setVoidData([]);
    setSelectedVoidTerminal('ALL');

    fetch(`/api/voids?date=${date}`)
    .then(r => r.json())
    .then(d => {
      const voids = d.voids || [];
      setVoidData(voids);
      const terminals = [...new Set(voids.map((v: any) => v.workstationId || 'UNKNOWN'))] as string[];
      setVoidSessions(terminals.map(t => ({ openedAtTerminal: t })));
    })
    .catch(() => { setVoidData([]); setVoidSessions([]); })
    .finally(() => setVoidSessionsLoading(false));
  }, [date, activeReport]);

  useEffect(() => {
  if (activeReport?.id !== 1) return;
    setSavedZReports([]);
    setSavedZReport(null);
    setSelectedZReportId('');
    setZReportLoading(true);
    fetch(`/api/reports?type=Z-READING&date=${date}`)
      .then(r => r.json())
      .then(d => {
        const list = d.reports || (d.report ? [d.report] : []);
        setSavedZReports(list);
        if (list.length > 0) {
          const first = list[0];
          const id = String(first._id);
          setSelectedZReportId(id);
          setSavedZReport(first);
        }
      })
      .catch(() => { setSavedZReports([]); setSavedZReport(null); })
      .finally(() => setZReportLoading(false));
  }, [date, activeReport]);

  useEffect(() => {
    if (activeReport?.id !== 3) return;
    setXReportLoading(true); 
    setSelectedSessionId("");
    setSavedXReports({});
    setCurrentXReadingPreview('');
    fetch(`/api/reports?type=X-READING&date=${date}&workstationId=${terminalId}`)
      .then(r => r.json())
      .then(d => setSavedXReports(
        d.reports.reduce((acc: any, rep: any) => {
          const id = rep.sessionId || String(rep._id); 
          acc[id] = rep;
          return acc;
        }, {})
      ))
      .catch(() => setSavedXReports({}))
      .finally(() => setXReportLoading(false)); 
  }, [date, activeReport, terminalId]);

  useEffect(() => {
    if (activeReport?.id !== 7) return;
    setLoading(true);
    setSelectedSessionId("");
    setSavedEShifts({});
    fetch(`/api/reports?type=E-SHIFT&date=${date}&workstationId=${terminalId}`)
    .then(r => r.json())
    .then(d => setSavedEShifts(
      d.reports.reduce((acc: any, rep: any) => {
        const id = rep.sessionId || String(rep._id);
        acc[id] = rep;
        return acc;
      }, {})
    ))
    .catch(() => setSavedEShifts({}))
    .finally(() => setLoading(false));

  }, [date, activeReport, terminalId]);

  useEffect(() => {
    if (activeReport?.id !== 5) return;
    setYReadingLoading(true);
    setSelectedYTerminal('');
    setSavedYReport(null);
    fetch(`/api/reports?type=Y-READING&date=${date}`)
      .then(r => r.json())
      .then(d => {
        const list: any[] = d.reports || (d.report ? [d.report] : []);
        setAllSessions(list);
        const terminals = [...new Set(list.map((r: any) => r.workstationId).filter(Boolean))] as string[];
        setYTerminals(terminals);
      })
      .catch(() => { setAllSessions([]); setYTerminals([]); })
      .finally(() => setYReadingLoading(false));
  }, [date, activeReport]);

  useEffect(() => {
    if (!selectedYTerminal || activeReport?.id !== 5) return;
    setSavedYReport(null);
    setYReportLoading(true);
    fetch(`/api/reports?type=Y-READING&date=${date}&workstationId=${selectedYTerminal}`)
      .then(r => r.json())
      .then(d => {
        const list: any[] = d.reports || (d.report ? [d.report] : []);
        const match = list.find((r: any) => r.workstationId === selectedYTerminal) || list[0] || null;
        setSavedYReport(match);
      })
      .catch(() => setSavedYReport(null))
      .finally(() => setYReportLoading(false));
  }, [selectedYTerminal, date, activeReport]);

  useEffect(() => {
    if (!activeReport) return;

    const CALENDAR_REPORT_IDS = [1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
    if (!CALENDAR_REPORT_IDS.includes(activeReport.id)) return;

    setCalendarLoading(true);
    setCalendarDates(new Set());

    const d    = new Date(date);
    const from = new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
    const to   = new Date(d.getFullYear(), d.getMonth() + 1, 0).toISOString().slice(0, 10);

    const typeMap: Record<number, string> = {
      1: 'Z-READING', 3: 'X-READING', 4: 'SALES-SUMMARY', 5: 'Y-READING', 7: 'E-SHIFT',
      8: 'DETAILED-SALES-SUMMARY', 9: 'SENIOR-REPORT', 10: 'PWD-REPORT', 11: 'ATHLETE-REPORT', 12: 'ZERO-RATED-REPORT'
    };

   const fetchPromise = activeReport.id === 6
      ? fetch(`/api/voids?from=${from}&to=${to}`)
          .then(r => r.json())
          .then(d => {
            return new Set<string>(
              (d.voids || []).map((v: any) => (v.businessDate || '').slice(0, 10))
            );
          })

      : fetch(`/api/reports?type=${typeMap[activeReport.id]}&from=${from}&to=${to}`)
          .then(r => r.json())
          .then(d => {
            return new Set<string>(
              (d.reports || []).map((rep: any) => (rep.date || '').slice(0, 10))
            );
          });

    fetchPromise
      .then((days: Set<string>) => {
        setCalendarDates(days);
        
        // Auto-adjust BIR date range based on data availability
        const isBir = [4, 8, 9, 10, 11, 12].includes(activeReport!.id);
        if (isBir && days.size > 0) {
          const targetDate = businessDayDate || date || new Date().toISOString().split('T')[0];
          
          if (!days.has(targetDate)) {
            // No report for today/business day -> default to outermost bounds of available data for the month
            const sortedDays = Array.from(days).sort();
            setBirStartDate(sortedDays[0]);
            setBirEndDate(sortedDays[sortedDays.length - 1]);
          } else {
            // Report exists for today/business day -> explicitly default to it
            setBirStartDate(targetDate);
            setBirEndDate(targetDate);
          }
        }
      })
      .catch(() => setCalendarDates(new Set()))
      .finally(() => setCalendarLoading(false));
  }, [activeReport?.id, date.slice(0, 7)]);


  const handleGenerateLiveXReadingPreview = async (pin: string) => {
    try {
      setLivePreviewLoading(true);
      const associate = await getAssociateByPin(pin);
      if (!associate || associate.user?.role !== 2) {
        sileo.error({ title: "Access Denied", description: "Manager PIN required to generate live preview.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
        setLivePreviewLoading(false);
        return;
      }

      setPinModalExiting(true);
      setTimeout(async () => {
        setShowPinModal(false);
        setPinModalExiting(false);

        try {
          const sessionsRes = await fetch('/api/cashier-session?status=all_open');
          const sessionsData = await sessionsRes.json();
          const activeSessionsList: any[] = sessionsData.sessions || [];
          const session = activeSessionsList.find(s => s.openedAtTerminal === terminalId) || activeSessionsList[0];

          if (!session) {
            sileo.error({ title: "No Open Shift", description: "No active shift found to preview." });
            setLivePreviewLoading(false);
            return;
          }

          const txRes = await fetch(`/api/transactions?limit=5000&sessionId=${session.sessionId}`);
          const txData = await txRes.json();
          const transactions = txData.transactions || [];

          let voidLogs = [];
          try {
            const voidRes = await fetch(`/api/voids?sessionIds=${session.sessionId}`);
            const voidData = await voidRes.json();
            voidLogs = voidData.voids || [];
          } catch {
            voidLogs = [];
          }

          const stats = buildStats(transactions, [session], menuCategoryMap, voidLogs);

          const livePreviewText = generateXReadingText(stats, {
            type: 'X_SHIFT',
            terminalId: session.openedAtTerminal || terminalId,
            readBy: session.staffName || 'UNKNOWN',
            storeData,
            session: {
              staffName: session.staffName || 'UNKNOWN',
              shiftNumber: session.shiftNumber || '-',
              actualCash: 0,
              cashDrops: session.cashDrops || [],
              closingBreakdown: {},
            },
            isReprint: false,
          }, fiscalSettings);

          setCurrentXReadingPreview(livePreviewText);
          setSelectedSessionId('');

        } catch (err) {
          sileo.error({ title: "Error", description: "Failed to load live preview data." });
        } finally {
          setLivePreviewLoading(false);
        }
      }, 260);

    } catch {
      sileo.error({ title: "Access Denied", description: "Manager PIN required.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
      setLivePreviewLoading(false);
    }
  };

  const handleGenerateLiveYReadingPreview = async (pin: string) => {
    try {
      setLivePreviewLoading(true);
      const associate = await getAssociateByPin(pin);
      if (!associate || associate.user?.role !== 2) {
        sileo.error({ title: "Access Denied", description: "Manager PIN required to generate live preview.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
        setLivePreviewLoading(false);
        return;
      }

      setPinModalExiting(true);
      setTimeout(async () => {
        setShowPinModal(false);
        setPinModalExiting(false);

        try {
          const targetTerminal = selectedYTerminal || terminalId;
          
          const openSessionsRes = await fetch('/api/cashier-session?status=all_open');
          const openData = await openSessionsRes.json();
          
          const closedSessionsRes = await fetch(`/api/cashier-session?status=closed&date=${date}`);
          const closedData = await closedSessionsRes.json();

          const allSessionsForTerminal = [
            ...(openData.sessions || []),
            ...(closedData.sessions || [])
          ].filter(s => (s.openedAtTerminal || s.terminalId || terminalId) === targetTerminal);

          if (allSessionsForTerminal.length === 0) {
            sileo.error({ title: "No Data", description: "No shifts found for this terminal today." });
            setLivePreviewLoading(false);
            return;
          }

          const sessionIds = allSessionsForTerminal.map(s => s.sessionId).join(',');
          const txRes = await fetch(`/api/transactions?limit=5000&sessionIds=${sessionIds}`);
          const txData = await txRes.json();
          
          let voidLogs = [];
          try {
            const voidRes = await fetch(`/api/voids?sessionIds=${sessionIds}`);
            const voidData = await voidRes.json();
            voidLogs = voidData.voids || [];
          } catch {
            voidLogs = [];
          }

          const stats = buildStats(txData.transactions || [], allSessionsForTerminal, menuCategoryMap, voidLogs);

          let oldGT = 0;
          try {
            const gtRes = await fetch(`/api/reports?type=Y-READING&workstationId=${targetTerminal}`);
            const gtData = await gtRes.json();
            const latest = Array.isArray(gtData?.reports) ? gtData.reports[0] : gtData?.report;
            oldGT = Number(latest?.content?.grandTotals?.newGrandTTL ?? 0);
          } catch {}

          const livePreviewText = generateZOrYReadingText(stats, {
            type: 'Y',
            terminalId: targetTerminal,
            termSessions: allSessionsForTerminal.length,
            yTermSessions: allSessionsForTerminal,
            readBy: associate.user?.name || 'MANAGER',
            storeData,
            oldGT: oldGT,
            isReprint: false
          }, fiscalSettings);

          setCurrentYReadingPreview(livePreviewText);
          setSelectedYTerminal(targetTerminal); 

        } catch (err) {
          sileo.error({ title: "Error", description: "Failed to load live preview data." });
        } finally {
          setLivePreviewLoading(false);
        }
      }, 260);

    } catch {
      sileo.error({ title: "Access Denied", description: "Manager PIN required.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
      setLivePreviewLoading(false);
    }
  };


  const storeName = storeData?.name || storeData?.data?.name || "STORE";

  const zReadingText = useMemo((): string => {
    if (!savedZReport) return '';
    const stats    = contentToStats(savedZReport.content);
    const zCounter = savedZReport.content?.zCounter || savedZReport.zCounter || '----';
    const readBy   = savedZReport.staffName || storeName || 'SYSTEM';
    return generateZOrYReadingText(stats, {
      type: 'Z',
      zCounter,
      readBy,
      storeData,
      oldGT: savedZReport.content?.grandTotals?.oldGT ?? 0,
      isReprint: true,
    }, fiscalSettings);
  }, [savedZReport, storeData, storeName]);

  const xReadingText = useMemo((): string => {
    if (!selectedSessionId) return '';
    const savedReport = savedXReports[selectedSessionId];
    if (!savedReport) return '';

    const stats: ReportStats = contentToStats(savedReport.content);
    const content = savedReport.content;

    return generateXReadingText(stats, {
      type: 'X_SHIFT',
      terminalId,
      readBy: savedReport.generatedBy?.staffName || 'UNKNOWN',
      storeData,
      session: {
        staffName:   savedReport.generatedBy?.staffName || 'UNKNOWN',
        shiftNumber: content?.eShiftDetails?.shiftNumber || '-',
        actualCash:  content?.cashierBankOut?.actualCount ?? 0,
        cashDrops:   content?.cashierBankOut?.cashDrops   || [],
      },
      isReprint: true,
    }, fiscalSettings);
  }, [selectedSessionId, savedXReports, storeData, terminalId]);

  const eShiftText = useMemo((): string => {
    if (!selectedSessionId) return '';
    const savedReport = savedEShifts[selectedSessionId];
    if (!savedReport) return '';

    const stats: ReportStats = contentToStats(savedReport.content);
    const content = savedReport.content;

    return generateEShiftText(stats, {
      terminalId: savedReport.workstationId || terminalId,
      readBy: savedReport.generatedBy?.staffName || 'UNKNOWN',
      storeData,
      oldGT: content?.eShiftDetails?.accountability?.oldGT || 0,
      denominations: content?.eShiftDetails?.denominations || {},
      session: {
        staffName: savedReport.generatedBy?.staffName || 'UNKNOWN',
        shiftNumber: content?.eShiftDetails?.shiftNumber || '-',
        cashDrops: content?.eShiftDetails?.cashDrops || []
      },
      isReprint: true,
    }, fiscalSettings);
  }, [selectedSessionId, savedEShifts, storeData, terminalId, fiscalSettings]);
  
  const yReadingText = useMemo((): string => {
    if (!savedYReport) return '';
    const stats = contentToStats(savedYReport.content);
    const termSessions = savedYReport.content?.yReadingDetails?.sessionCount ?? 0;
    const readBy = savedYReport.generatedBy?.staffName || 'SYSTEM';
    return generateZOrYReadingText(stats, {
      type: 'Y',
      terminalId: selectedYTerminal,
      termSessions,
      readBy,
      storeData,
      oldGT: savedYReport.content?.grandTotals?.oldGT ?? 0,
      isReprint: true
    }, fiscalSettings);
  }, [savedYReport, selectedYTerminal, storeData, fiscalSettings]);

  const generateEsfTableHtml = () => {
    if (!esfData?.rows || esfData.rows.length === 0) return "";

    const groupHeaderStyle = (bg: string) =>
      `text-align:center;padding:4px 6px;font-size:9px;font-weight:900;border:1px solid #e2e8f0;color:#fff;background:${bg};letter-spacing:0.5px;text-transform:uppercase;`;

    const colHeaderStyle = (bg: string, color = '#fff') =>
      `padding:3px 5px;font-size:8px;font-weight:700;border:1px solid #e2e8f0;white-space:nowrap;background:${bg};color:${color};text-align:center;`;

    const td = (v: any, align = 'left') =>
      `<td style="padding:2px 6px;font-size:8px;border:1px solid #e2e8f0;white-space:nowrap;text-align:${align};">${v !== null && v !== undefined ? v : ''}</td>`;

    const formatZero = (val: any) => {
      const num = Number(val || 0);
      return num === 0 ? '' : num.toFixed(4);
    };

    const rowsHtml = esfData.rows.map((r: any, i: number) => `
      <tr style="background:${i % 2 === 0 ? '#fff' : '#fafafa'};">
        ${td(r.TERMINAL_NO, 'center')}
        ${td(r.SHIFT_NO, 'center')}
        ${td(r.CASHIER_NAME)}
        ${td(r.ITEM_CODE)}
        ${td(r.ITEM_DESCRIPTION)}
        ${td(Number(r.SELLING_PRICE || 0).toFixed(4), 'right')}
        ${td(r.QTY, 'center')}
        ${td(Number(r.DISCOUNT_W_VAT || 0).toFixed(4), 'right')}
        ${td(Number(r.DISCOUNT_WO_VAT || 0).toFixed(4), 'right')}
        ${td(r.PCT_DISCOUNT, 'center')}
        ${td(Number(r.VAT_EXEMPT_AMT || 0).toFixed(4), 'right')}
        ${td(r.DELIVERY_CHARGE || '', 'center')}
        ${td(Number(r.AMOUNT_DUE || 0).toFixed(4), 'right')}
        ${td(r.TRANSACTION_NO)}
        ${td(Number(r.VAT_AMOUNT || 0).toFixed(4), 'right')}
        ${td(Number(r.NET_PRICE || 0).toFixed(4), 'right')}
        ${td(r.MEAL_TYPE, 'center')}
        ${td(r.DISCOUNT_TYPE, 'center')}
        ${td(r.DELIVERY_TYPE, 'center')}
        ${td(r.ORDER_REF_NO)}
        ${td(r.TENDER_TYPE, 'center')}
        ${td(r.WHTAX_RATE, 'center')}
        ${td(formatZero(r.TENDERED_AMOUNT), 'right')}
        ${td(r.REF_NO)}
        ${td(r.CHARGE_TO)}
        ${td(r.CUSTOMER_NAME)}
        ${td(r.APPROVAL_NO)}
        ${td(r.MERCHANT_ID)}
        ${td(r.CARD_BANK)}
        ${td(r.CARD_NO)}
        ${td(r.CHECK_NO)}
        ${td(r.CHECK_DATE)}
        ${td(r.DATE_SOLD, 'center')}
        ${td(r.TIME_SOLD, 'center')}
        ${td(r.CATEGORY)}
        ${td(r.OUTLET_NAME)}
        ${td(r.TRANSACTION_COUNT, 'center')}
        ${td(r.SALES_DATE, 'center')}
      </tr>
    `).join('');

    const C = {
      base:        '#374151',
      pricing:     '#92400e',
      txType:      '#1e40af',
      txTypeCols:  '#1d4ed8',
      tender:      '#065f46',
      payInfo:     '#6b21a8',
      payInfoCols: '#7c3aed',
      meta:        '#be123c',
    };

    return `
      <div style="font-family:'Courier New',monospace;font-size:9px;color:#000;padding:12px;">
        <div style="text-align:center;font-weight:900;font-size:14px;margin-bottom:2px;font-family:sans-serif;">${storeName}</div>
        <div style="text-align:center;font-weight:700;font-size:11px;margin-bottom:8px;font-family:sans-serif;">ELECTRONIC SALES FILE (ESF)</div>
        <div style="text-align:center;margin-bottom:12px;font-size:9px;color:#666;">Date: ${esfData.date || date} &nbsp;|&nbsp; Records: ${esfData.rows.length} line items</div>

        <div style="overflow-x:auto;">
          <table style="border-collapse:collapse;min-width:max-content;width:100%;">
            <thead>

              <tr>
                <th colspan="3" style="${groupHeaderStyle(C.base)}">Transaction Info</th>
                <th colspan="3" style="${groupHeaderStyle('#4b5563')}">Item</th>
                <th colspan="10" style="${groupHeaderStyle(C.pricing)}">Pricing &amp; Discounts</th>
                <th colspan="4" style="${groupHeaderStyle(C.txType)}">Transaction Type</th>
                <th colspan="2" style="${groupHeaderStyle(C.tender)}">Tender</th>
                <th colspan="10" style="${groupHeaderStyle(C.payInfo)}">Payment Info</th>
                <th colspan="6" style="${groupHeaderStyle(C.meta)}">Date / Reference</th>
              </tr>

              <tr>
                <th style="${colHeaderStyle(C.base)}">Terminal No.</th>
                <th style="${colHeaderStyle(C.base)}">Shift No.</th>
                <th style="${colHeaderStyle(C.base)}">Cashier Name</th>
                <th style="${colHeaderStyle('#4b5563')}">Item Code</th>
                <th style="${colHeaderStyle('#4b5563')}">Item Description</th>
                <th style="${colHeaderStyle('#4b5563')}">Selling Price</th>
                <th style="${colHeaderStyle(C.pricing)}">Qty</th>
                <th style="${colHeaderStyle(C.pricing)}">Discount w/ VAT</th>
                <th style="${colHeaderStyle(C.pricing)}">Discount w/o VAT</th>
                <th style="${colHeaderStyle(C.pricing)}">% Discount</th>
                <th style="${colHeaderStyle(C.pricing)}">VAT Exempt Amt</th>
                <th style="${colHeaderStyle(C.pricing)}">Delivery Charge</th>
                <th style="${colHeaderStyle(C.pricing)}">Amount Due</th>
                <th style="${colHeaderStyle(C.pricing)}">Transaction No.</th>
                <th style="${colHeaderStyle(C.pricing)}">VAT Amount</th>
                <th style="${colHeaderStyle(C.pricing)}">Net Price</th>
                <th style="${colHeaderStyle(C.txTypeCols)}">Meal Type</th>
                <th style="${colHeaderStyle(C.txTypeCols)}">Discount Type</th>
                <th style="${colHeaderStyle(C.txTypeCols)}">Delivery Type</th>
                <th style="${colHeaderStyle(C.txTypeCols)}">Order Ref. No.</th>
                <th style="${colHeaderStyle(C.tender)}">Tender Type</th>
                <th style="${colHeaderStyle(C.tender)}">WHtax Rate</th>
                <th style="${colHeaderStyle(C.payInfoCols)}">Tendered Amount</th>
                <th style="${colHeaderStyle(C.payInfoCols)}">Ref. No.</th>
                <th style="${colHeaderStyle(C.payInfoCols)}">Charge To / Swipe To</th>
                <th style="${colHeaderStyle(C.payInfoCols)}">Customer Name</th>
                <th style="${colHeaderStyle(C.payInfoCols)}">Approval #</th>
                <th style="${colHeaderStyle(C.payInfoCols)}">Merchant ID</th>
                <th style="${colHeaderStyle(C.payInfoCols)}">Card / Bank</th>
                <th style="${colHeaderStyle(C.payInfoCols)}">Card #</th>
                <th style="${colHeaderStyle(C.payInfoCols)}">Check #</th>
                <th style="${colHeaderStyle(C.payInfoCols)}">Check Date</th>
                <th style="${colHeaderStyle(C.meta)}">Date Sold</th>
                <th style="${colHeaderStyle(C.meta)}">Time Sold</th>
                <th style="${colHeaderStyle(C.meta)}">Category</th>
                <th style="${colHeaderStyle(C.meta)}">Outlet Name</th>
                <th style="${colHeaderStyle(C.meta)}">Tx Count</th>
                <th style="${colHeaderStyle(C.meta)}">Sales Date</th>
              </tr>
            </thead>

            <tbody>${rowsHtml}</tbody>
          </table>
        </div>

        <div style="margin-top:10px;font-size:8px;color:#999;text-align:right;">
          Generated: ${new Date().toLocaleString('en-PH')} &nbsp;|&nbsp; ${esfData.rows.length} rows
        </div>
      </div>
    `;
  };

  const generateGenericTableHtml = () => {
    const config = BIR_CONFIG[activeReport!.id];
    if (!config || filteredBirData.length === 0) return "";
    
    const th = (label: string) => `<th style="padding:4px 6px;font-size:8px;font-weight:700;border:1px solid #e2e8f0;white-space:nowrap;background:#374151;color:#fff;text-align:center;">${label}</th>`;
    const td = (v: any, align = 'left') => {
      return `<td style="padding:3px 6px;font-size:8px;border:1px solid #e2e8f0;white-space:nowrap;text-align:${align};">${v !== null && v !== undefined ? v : ''}</td>`;
    };

    const headerHtml = config.cols.map((c: any) => th(c.label)).join('');
    const rowsHtml = filteredBirData.map((r, i) => `
      <tr style="background:${i % 2 === 0 ? '#fff' : '#fafafa'};">
        ${config.cols.map((c: any) => td(r[c.key], c.align || 'left')).join('')}
      </tr>
    `).join('');

    const terminalFilterText = (isBirReport && birTerminalFilter !== 'ALL') ? ` | Terminal: ${birTerminalFilter}` : '';
    const displayStart = actualBirStartDate || birStartDate;
    const displayEnd = actualBirEndDate || birEndDate;

    return `
      <div style="font-family:'Courier New',monospace;font-size:9px;color:#000;padding:12px;">
        <div style="text-align:center;font-weight:900;font-size:14px;margin-bottom:2px;font-family:sans-serif;">${storeName}</div>
        <div style="text-align:center;font-weight:700;font-size:11px;margin-bottom:8px;font-family:sans-serif;">${config.title}</div>
        <div style="text-align:center;margin-bottom:12px;font-size:9px;color:#666;">Date Range: ${displayStart} to ${displayEnd} &nbsp;|&nbsp; TIN: ${fiscalSettings.tinNumber || '-'}${terminalFilterText}</div>

        <div style="overflow-x:auto;">
          <table style="border-collapse:collapse;min-width:max-content;width:100%;">
            <thead><tr>${headerHtml}</tr></thead>
            <tbody>${rowsHtml}</tbody>
          </table>
        </div>
        <div style="margin-top:10px;font-size:8px;color:#999;text-align:right;">
          Generated: ${new Date().toLocaleString('en-PH')} &nbsp;|&nbsp; ${filteredBirData.length} rows
        </div>
      </div>
    `;
  };

  const handleDownloadCSV = () => {
    const config = BIR_CONFIG[activeReport!.id];
    const headers = config.cols.map((c: any) => c.label).join(',');
    const rowsCsv = filteredBirData.map(row => 
      config.cols.map((c: any) => {
        const val = row[c.key] ?? '';
        const str = String(val);
        if (str.includes(',') || str.includes('"') || str.includes('\n')) {
           return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
      }).join(',')
    ).join('\r\n');
    
    const terminalFilterText = (isBirReport && birTerminalFilter !== 'ALL') ? ` | Terminal: ${birTerminalFilter}` : '';
    const displayStart = actualBirStartDate || birStartDate;
    const displayEnd = actualBirEndDate || birEndDate;
    
    const titleLine = `${config.title},${','.repeat(config.cols.length - 1)}`;
    const dateLine  = `From: ${displayStart} To: ${displayEnd}${terminalFilterText},${','.repeat(config.cols.length - 1)}`;
    const emptyLine = ','.repeat(config.cols.length - 1);
    
    const finalCsv = [titleLine, dateLine, emptyLine, headers, rowsCsv].join('\r\n');
    
    const blob = new Blob([finalCsv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${config.csvTitle}_${displayStart}_to_${displayEnd}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const generateVoidSummaryHtml = (data: any[] = voidData): string => {
    if (!data.length) return '';

    const rows: Array<{
      cashier: string; manager: string; date: string; time: string;
      termNo: string; transNo: string; description: string; qty: number;
      amount: number; reason: string;
    }> = [];

    data.forEach(log => {
      const dt       = new Date(log.createdAt || log.timestamp || '');
      const dateStr  = dt.toLocaleDateString('en-PH', { month: '2-digit', day: '2-digit', year: 'numeric' });
      const timeStr  = dt.toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
      const termNo   = log.workstationId || log.terminalId || '-';
      const rawTrans = log.voidTransactionNumber || '-';
      const transNo  = rawTrans.includes('-') ? rawTrans.split('-').pop() || '-' : rawTrans;
      const cashier  = (log.cashierName || 'UNKNOWN').toUpperCase();
      const manager  = (log.managerName || 'UNKNOWN').toUpperCase();
      const reason   = (log.reason || '').toUpperCase();

      (log.items || []).forEach((item: any) => {
        const mods       = Array.isArray(item.modifiers) ? item.modifiers : Object.values(item.modifiers || {});
        const modsPrice  = mods.reduce((s: number, m: any) => s + ((m.price || 0) * (m.qty || 1)) / 100, 0);
        const unitAmt    = (item.price || 0) + modsPrice;
        rows.push({
          cashier, manager, date: dateStr, time: timeStr, termNo, transNo,
          description: (item.name || '-').toUpperCase(),
          qty:    item.qty || 1,
          amount: unitAmt * (item.qty || 1),
          reason,
        });
      });
    });

    const totalQty    = rows.reduce((s, r) => s + r.qty, 0);
    const totalAmount = rows.reduce((s, r) => s + r.amount, 0);

    const thStyle = `
      padding: 4px 8px;
      font-size: 9px;
      font-weight: 900;
      text-align: left;
      border-bottom: 2px solid #333;
      border-top: 1px solid #333;
      white-space: nowrap;
      font-family: 'Courier New', monospace;
      background: #f8f8f8;
    `;
    const tdStyle = (align = 'left') => `
      padding: 3px 8px;
      font-size: 9px;
      border-bottom: 1px solid #e5e7eb;
      white-space: nowrap;
      font-family: 'Courier New', monospace;
      text-align: ${align};
    `;

    const rowsHtml = rows.map((r, i) => `
      <tr style="background:${i % 2 === 0 ? '#fff' : '#fafafa'};">
        <td style="${tdStyle()}">${r.cashier}</td>
        <td style="${tdStyle()}">${r.manager}</td>
        <td style="${tdStyle('center')}">${r.date}</td>
        <td style="${tdStyle('center')}">${r.time}</td>
        <td style="${tdStyle('center')}">${r.termNo}</td>
        <td style="${tdStyle()}">${r.transNo}</td>
        <td style="${tdStyle()}">${r.description}</td>
        <td style="${tdStyle('center')}">${r.qty}</td>
        <td style="${tdStyle('right')}">${r.amount.toFixed(2)}</td>
        <td style="${tdStyle()}">${r.reason}</td>
      </tr>
    `).join('');

    return `
      <div style="font-family:'Courier New',monospace;padding:24px;color:#000;max-width:1000px;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:4px;">
          <div>
            <div style="font-size:16px;font-weight:900;font-family:sans-serif;text-transform:uppercase;">
              ${storeName}
            </div>
            <div style="font-size:13px;font-weight:700;margin-top:2px;">Void/Cancel Report</div>
            <div style="font-size:10px;margin-top:2px;">From: ${date} &nbsp; To: ${date}</div>
            <div style="font-size:10px;margin-top:1px;">
              Printed: ${new Date().toLocaleDateString('en-PH')} ${new Date().toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit', hour12: false })}
            </div>
          </div>
          <div style="font-size:10px;color:#666;">Page 1</div>
        </div>

        <div style="border-top:2px solid #333;margin:10px 0 0;"></div>

        <table style="width:100%;border-collapse:collapse;margin-top:0;">
          <thead>
            <tr>
              <th style="${thStyle}">Cashier</th>
              <th style="${thStyle}">Manager</th>
              <th style="${thStyle}">Date</th>
              <th style="${thStyle}">Time</th>
              <th style="${thStyle}">Term. No.</th>
              <th style="${thStyle}">Trans. No.</th>
              <th style="${thStyle}">Description</th>
              <th style="${thStyle}">Qty</th>
              <th style="${thStyle};text-align:right;">Amount</th>
              <th style="${thStyle}">Reason</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
          <tfoot>
            <tr>
              <td colspan="7" style="${tdStyle('right')};font-weight:900;border-top:2px solid #333;border-bottom:none;"></td>
              <td style="${tdStyle('center')};font-weight:900;border-top:2px solid #333;border-bottom:none;">${totalQty}</td>
              <td style="${tdStyle('right')};font-weight:900;border-top:2px solid #333;border-bottom:none;">${totalAmount.toFixed(2)}</td>
              <td style="${tdStyle()};border-top:2px solid #333;border-bottom:none;"></td>
            </tr>
          </tfoot>
        </table>

        <div style="margin-top:10px;font-size:9px;color:#666;font-family:sans-serif;">
          ${rows.length} line item(s) · ${data.length} void transaction(s)
        </div>
      </div>
    `;
  };

  const ModalHeader = ({ title, subtitle, onClose }: { title: string; subtitle: string; onClose: () => void }) => (
    <div className="bg-[#f97316] text-white py-4 px-6 flex justify-between items-center flex-shrink-0">
      <div>
        <h2 className="text-xl font-bold" style={{ fontFamily: "Poppins" }}>{title}</h2>
        <p className="text-xs opacity-80 mt-0.5">{subtitle}</p>
      </div>
      <button onClick={onClose} className="p-2 rounded-full hover:bg-white/20 transition-colors"><X size={20} /></button>
    </div>
  );

  const DatePicker = () => {
    const selected   = new Date(date);
    const year       = selected.getFullYear();
    const month      = selected.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDow   = new Date(year, month, 1).getDay();

    const monthLabel = selected.toLocaleDateString('en-PH', { month: 'long', year: 'numeric' });

    const prevMonth = () => {
      const d = new Date(year, month - 1, 1);
      setDate(d.toISOString().slice(0, 10));
      setSelectedSessionId('');
      setCurrentXReadingPreview('');
      setCurrentYReadingPreview('');
    };
    const nextMonth = () => {
      const d = new Date(year, month + 1, 1);
      setDate(d.toISOString().slice(0, 10));
      setSelectedSessionId('');
      setCurrentXReadingPreview('');
      setCurrentYReadingPreview('');
    };

    return (
      <div className="mb-4">
        <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Date</label>

        <input
          type="date" value={date}
          onChange={e => { setDate(e.target.value); setSelectedSessionId(''); setCurrentXReadingPreview(''); setCurrentYReadingPreview(''); }}
          className="w-full p-2.5 rounded-xl border border-gray-300 font-poppins text-gray-700 outline-none focus:border-[#f97316] text-sm transition-colors mb-3"
        />

        <div className="bg-white rounded-xl border border-gray-200 p-2 select-none">
          <div className="flex items-center justify-between mb-2 px-1">
            <button
              onClick={prevMonth}
              className="w-6 h-6 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-500 font-bold text-xs transition-colors"
            >‹</button>
            <span className="text-[10px] font-bold text-gray-600 uppercase tracking-wide">
              {calendarLoading ? '...' : monthLabel}
            </span>
            <button
              onClick={nextMonth}
              className="w-6 h-6 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-500 font-bold text-xs transition-colors"
            >›</button>
          </div>

          <div className="grid grid-cols-7 mb-1">
            {['S','M','T','W','T','F','S'].map((d, i) => (
              <div key={i} className="text-center text-[8px] font-bold text-gray-400">{d}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-y-0.5">
            {Array.from({ length: firstDow }).map((_, i) => <div key={`e${i}`} />)}

            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day     = i + 1;
              const dayStr  = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
              const isBusinessDay = dayStr === businessDayDate;
              const isSelected = dayStr === date;
              const hasData = calendarDates.has(dayStr);

              return (
                <button
                  key={day}
                  onClick={() => { setDate(dayStr); setSelectedSessionId(''); setCurrentXReadingPreview(''); setCurrentYReadingPreview(''); }}
                  className="relative flex flex-col items-center justify-center h-7 rounded-lg transition-all text-[10px] font-bold"
                  style={{
                    background: isSelected
                      ? 'linear-gradient(135deg, #f97316, #ea580c)'
                      : isBusinessDay
                        ? 'rgba(249,115,22,0.08)'
                        : 'transparent',
                    color: isSelected ? '#fff' : isBusinessDay ? '#f97316' : '#374151',
                    fontWeight: isSelected || isBusinessDay ? 900 : 600,
                  }}
                >
                  {day}
                  {hasData && (
                    <div
                      className="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full"
                      style={{ background: isSelected ? 'rgba(255,255,255,0.85)' : '#f97316' }}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  const FooterBar = ({ onCancel, onPrint, enabled }: { onCancel: () => void; onPrint: () => void; enabled: boolean }) => (
    <div className="p-4 bg-white flex gap-3 border-t border-gray-100 flex-shrink-0 justify-end">
      <button onClick={onCancel} className="px-6 py-2.5 rounded-xl font-bold bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors text-sm">Cancel</button>
      <button
        onClick={onPrint}
        disabled={!enabled}
        className="px-8 py-2.5 rounded-xl font-bold text-white transition-colors flex items-center gap-2 text-sm disabled:opacity-40 disabled:cursor-not-allowed"
        style={{ background: enabled ? "#f97316" : "#cbd5e1" }}
      >
        <FiPrinter size={16} /> Print Report
      </button>
    </div>
  );

  const closeModal = () => {
    setActiveReport(null);
    setSelectedSessionId("");
    setCurrentXReadingPreview("");
    setCurrentYReadingPreview("");
    setPreviewTarget(null);
    setShowPinModal(false);
    setEsfData(null);
    setSelectedYTerminal("");
    setYTerminals([]);
    setAllSessions([]);
    setSavedZReport(null);
    setSavedXReports({});
    setSavedEShifts({});
    setVoidData([]);       
    setSavedZReports([]);
    setSelectedZReportId('');   
    setEsfDocs([]);
    setSelectedEsfId('');
    setVoidSessions([]);
    setSelectedVoidTerminal('ALL');
    setCalendarDates(new Set());
    
    // Clear BIR state
    setBirData([]);
    setBirLoading(false);
    setBirTerminalFilter('ALL');
  };

  return (
    <>
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes slideUpFade { from { opacity:0; transform:translateY(15px); } to { opacity:1; transform:translateY(0); } }
        @keyframes fadeIn { from { opacity:0; } to { opacity:1; } }
        @keyframes scaleIn { from { opacity:0; transform:scale(0.97); } to { opacity:1; transform:scale(1); } }
        .animate-slide-up { animation: slideUpFade 0.4s cubic-bezier(0.16,1,0.3,1) forwards; }
        .animate-fade-in  { animation: fadeIn 0.3s ease-out forwards; }
        .animate-scale-in { animation: scaleIn 0.3s cubic-bezier(0.16,1,0.3,1) forwards; }
        ::-webkit-scrollbar { width:8px; height:8px; }
        ::-webkit-scrollbar-track { background:rgba(0,0,0,0.05); border-radius:4px; }
        ::-webkit-scrollbar-thumb { background:rgba(249,115,22,0.6); border-radius:4px; }
        ::-webkit-scrollbar-thumb:hover { background:rgba(249,115,22,0.9); }
      `}} />

      {showPinModal && (
        <PinModal
          title="Verify Your PIN"
          subtitle="Enter manager PIN to generate a live preview."
          accentColor="#f97316"
          stripColor="linear-gradient(90deg, #f97316 0%, #fb923c 60%, #fdba74 100%)"
          isExiting={pinModalExiting}
          onConfirm={previewTarget === 'Y' ? handleGenerateLiveYReadingPreview : handleGenerateLiveXReadingPreview}
          onClose={() => {
            setPinModalExiting(true);
            setTimeout(() => {
              setPinModalExiting(false);
              setShowPinModal(false);
              setPreviewTarget(null);
            }, 260);
          }}
        />
      )}

      <div className="flex flex-col h-full w-full overflow-hidden select-none animate-fade-in" style={{ fontFamily: "Poppins" }}>
        <div className="flex-1 flex items-center justify-center p-6 overflow-hidden">
          <div className="w-full max-w-6xl rounded-3xl overflow-hidden flex flex-col" style={glass.modal}>
            <div style={{ height: 5, background: "linear-gradient(90deg, #f97316 0%, #fb923c 60%, #fed7aa 100%)" }} />
            <div className="p-8 flex flex-col h-full overflow-hidden">
              <div className="flex items-center justify-between mb-8 flex-shrink-0">
                <div className="flex items-center gap-4 animate-slide-up" style={{ animationDelay: '0.05s', opacity: 0, animationFillMode: "forwards" }}>
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
                    style={{ background: "linear-gradient(135deg, #fff7ed, #ffedd5)", border: "1.5px solid rgba(249,115,22,0.18)", boxShadow: "0 2px 10px rgba(249,115,22,0.10)" }}>
                    <BarChart2 size={24} color="#f97316" strokeWidth={2} />
                  </div>
                  <div>
                    <p style={{ fontSize: 10, color: "#ccc", fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 2 }}>Management</p>
                    <h1 style={{ fontFamily: "Poppins", fontSize: 28, fontWeight: 900, color: "#1a1a1a", lineHeight: 1 }}>
                      <span style={{ color: "#f97316" }}>Report</span> Center
                    </h1>
                  </div>
                </div>
                <button
                  onClick={() => router.push("/dashboard")}
                  className="w-9 h-9 rounded-full flex items-center justify-center transition-all hover:bg-black/5 animate-slide-up"
                  style={{ animationDelay: '0.1s', opacity: 0, animationFillMode: "forwards", background: "rgba(0,0,0,0.05)", border: "1px solid rgba(0,0,0,0.07)" }}
                >
                  <X size={16} color="#bbb" strokeWidth={2.5} />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-8 flex-1 overflow-y-auto pr-2 pb-2">
                <div className="flex flex-col gap-3">
                  <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest pl-2">Regular Reports</h3>
                  <div className="flex flex-col gap-2">
                    {REGULAR_REPORTS.map((report, idx) => (
                      <div key={report.id} className="animate-slide-up" style={{ animationDelay: `${0.1 + idx * 0.05}s`, opacity: 0, animationFillMode: 'forwards' }}>
                        <ReportButton report={report} onClick={setActiveReport} />
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest pl-2">BIR Reports</h3>
                  <div className="flex flex-col gap-2">
                    {BIR_REPORTS.map((report, idx) => (
                      <div key={report.id} className="animate-slide-up" style={{ animationDelay: `${0.15 + idx * 0.05}s`, opacity: 0, animationFillMode: 'forwards' }}>
                        <ReportButton report={report} onClick={setActiveReport} />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* BIR REPORTS MODAL */}
        {isBirReport && (
          <div className="fixed inset-0 flex items-center justify-center z-[150] animate-fade-in"
            style={{ background: "rgba(15,23,42,0.8)", backdropFilter: "blur(8px)" }}>
            <div className="rounded-3xl w-full max-w-6xl mx-4 relative flex flex-col bg-white overflow-hidden shadow-2xl h-[85vh] animate-scale-in"
              style={{ animationDelay: '0.05s', opacity: 0, animationFillMode: 'forwards' }}>
              
              <ModalHeader title={BIR_CONFIG[activeReport!.id]?.title} subtitle="Consolidated BIR format report" onClose={closeModal} />
              
              <div className="flex flex-1 overflow-hidden">
                <div className="w-64 bg-gray-50 border-r border-gray-200 flex flex-col p-5 flex-shrink-0">
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-4">Date Range</label>
                  
                  <div className="flex flex-col gap-4 mb-6">
                    <div>
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">From</span>
                      <input
                        type="date" value={birStartDate}
                        onChange={e => setBirStartDate(e.target.value)}
                        className="w-full p-2.5 mt-1 rounded-xl border border-gray-300 font-poppins text-gray-700 outline-none focus:border-[#f97316] text-sm"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">To</span>
                      <input
                        type="date" value={birEndDate}
                        onChange={e => setBirEndDate(e.target.value)}
                        className="w-full p-2.5 mt-1 rounded-xl border border-gray-300 font-poppins text-gray-700 outline-none focus:border-[#f97316] text-sm"
                      />
                    </div>
                  </div>

                  {/* Terminal Filter for BIR Reports */}
                  {isBirReport && birData.length > 0 && (() => {
                    const terminals = Array.from(new Set(birData.map(r => r._docWorkstationId || r.TERMINAL_NO).filter(t => t && t !== '')));
                    if (terminals.length === 0) return null;
                    return (
                      <div className="mb-6">
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-2">Terminal Filter</span>
                        <select
                          value={birTerminalFilter}
                          onChange={e => setBirTerminalFilter(e.target.value)}
                          className="w-full p-2.5 rounded-xl border border-gray-300 font-poppins text-gray-700 outline-none focus:border-[#f97316] text-sm"
                        >
                          <option value="ALL">All Terminals</option>
                          {terminals.map(t => <option key={t as string} value={t as string}>Terminal {t}</option>)}
                        </select>
                      </div>
                    );
                  })()}

                  <div className="flex-1 overflow-y-auto">
                    {!birLoading && (
                      <div className="p-4 rounded-xl bg-blue-50 border border-blue-100">
                        <p className="text-[10px] font-bold text-blue-500 uppercase tracking-widest mb-1">Results</p>
                        <p className="text-xl font-black text-blue-700">{filteredBirData.length} Rows</p>
                        <p className="text-[10px] text-gray-500 mt-1">Across selected date range</p>
                      </div>
                    )}
                  </div>
                </div>

                <WidePreviewArea html={generateGenericTableHtml()} loading={birLoading} />
              </div>

              <div className="p-4 bg-white flex gap-3 border-t border-gray-100 flex-shrink-0 justify-end">
                <button onClick={closeModal} className="px-6 py-2.5 rounded-xl font-bold bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors text-sm mr-auto">Close</button>
                <button
                  onClick={() => handleExportPDF(generateGenericTableHtml(), BIR_CONFIG[activeReport!.id]?.title || 'Report')}
                  disabled={filteredBirData.length === 0}
                  className={`px-6 py-2.5 rounded-xl font-bold text-white transition-colors flex items-center gap-2 text-sm ${filteredBirData.length === 0 ? 'opacity-40 cursor-not-allowed bg-gray-400' : 'bg-blue-600 hover:bg-blue-700'}`}
                >
                  <FiPrinter size={16} /> Save as PDF
                </button>
                <button
                  onClick={handleDownloadCSV}
                  disabled={filteredBirData.length === 0}
                  className={`px-6 py-2.5 rounded-xl font-bold text-white transition-colors flex items-center gap-2 text-sm ${filteredBirData.length === 0 ? 'opacity-40 cursor-not-allowed bg-gray-400' : 'bg-[#16a34a] hover:bg-green-700'}`}
                >
                  <Download size={16} /> Download CSV
                </button>
              </div>
            </div>
          </div>
        )}

        {/* REGULAR REPORTS MODALS */}
        {activeReport?.id === 1 && (
          <div className="fixed inset-0 flex items-center justify-center z-[150] animate-fade-in"
            style={{ background: "rgba(15,23,42,0.8)", backdropFilter: "blur(8px)" }}>
            <div className="rounded-3xl w-full max-w-3xl mx-4 relative flex flex-col bg-white overflow-hidden shadow-2xl h-[85vh] animate-scale-in"
              style={{ animationDelay: '0.05s', opacity: 0, animationFillMode: 'forwards' }}>

              <ModalHeader title="Z-Reading Archive" subtitle="End-of-day aggregate reprint — sourced from saved report" onClose={closeModal} />

              <div className="flex flex-1 overflow-hidden">
                <div className="w-64 bg-gray-50 border-r border-gray-200 flex flex-col p-4">
                  <DatePicker />

                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">
                    Z-Readings ({savedZReports.length})
                  </label>

                  <div className="flex-1 overflow-y-auto flex flex-col gap-2">
                    {zReportLoading ? (
                      <p className="text-xs text-gray-400 mt-4 text-center">Searching...</p>
                    ) : savedZReports.length === 0 ? (
                      <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-[10px] text-amber-700 leading-relaxed">
                        No Z-Reading was saved for this date. Run the EOD process to generate one.
                      </div>
                    ) : (
                      savedZReports.map((rep: any, idx: number) => {
                        const repId = rep.sessionId || String(rep._id);
                        const isSelected = selectedZReportId === repId;
                        const generatedAt = rep.generatedAt
                          ? new Date(rep.generatedAt).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
                          : '--:--';
                        return (
                          <button
                            key={repId}
                            onClick={() => { setSelectedZReportId(repId); setSavedZReport(rep); }}
                            className="text-left p-3 rounded-xl transition-all active:scale-95 focus:outline-none flex flex-col gap-1"
                            style={{
                              background: isSelected ? 'rgba(249,115,22,0.1)' : '#fff',
                              border: isSelected ? '1px solid rgba(249,115,22,0.4)' : '1px solid #e2e8f0',
                            }}
                          >
                            <span className="font-black text-sm font-mono" style={{ color: isSelected ? '#f97316' : '#334155' }}>
                              Z-{rep.content?.zCounter || '----'}
                            </span>
                            <span className="text-[10px] text-gray-400">Generated: {generatedAt}</span>
                            <span className="text-[10px] text-gray-500">{rep.staffName || rep.generatedBy?.staffName || 'SYSTEM'}</span>
                          </button>
                        );
                      })
                    )}
                  </div>
                </div>

                <ReceiptPreview
                  text={zReadingText}
                  empty={zReportLoading ? "Loading saved report..." : "No saved report for this date"}
                />
              </div>

              <FooterBar
                onCancel={closeModal}
                enabled={!!zReadingText}
                onPrint={() => {
                  if (zReadingText)
                    printDirect(zReadingText, false).catch(console.error);
                }}
              />
            </div>
          </div>
        )}

        {activeReport?.id === 2 && (
          <div className="fixed inset-0 flex items-center justify-center z-[150] animate-fade-in"
            style={{ background: "rgba(15,23,42,0.8)", backdropFilter: "blur(8px)" }}>
            <div className="rounded-3xl w-full max-w-6xl mx-4 relative flex flex-col bg-white overflow-hidden shadow-2xl h-[85vh] animate-scale-in"
              style={{ animationDelay: '0.05s', opacity: 0, animationFillMode: 'forwards' }}>
              <ModalHeader title="ESF Reports" subtitle="Electronic Sales File — item-level transaction records" onClose={closeModal} />
              <div className="flex flex-1 overflow-hidden">
                <div className="w-52 bg-gray-50 border-r border-gray-200 flex flex-col p-4 flex-shrink-0">
                  <DatePicker />
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">
                    ESF Reports ({esfDocs.length})
                  </label>
                  <div className="flex-1 overflow-y-auto flex flex-col gap-2">
                    {esfLoading ? (
                      <p className="text-xs text-gray-400 mt-4 text-center">Loading...</p>
                    ) : esfDocs.length === 0 ? (
                      <div className="mt-2 p-3 rounded-xl bg-gray-100 border border-gray-200">
                        <p className="text-[10px] text-gray-400 text-center">
                          No ESF for this date.<br />Generate via Z-Reading.
                        </p>
                      </div>
                    ) : (
                      esfDocs.map((doc: any, idx: number) => {
                        const docId = String(doc._id ?? doc.date ?? idx);
                        const isSelected = selectedEsfId === docId;
                        return (
                          <button
                            key={docId}
                            onClick={() => { setSelectedEsfId(docId); setEsfData(doc); }}
                            className="text-left p-3 rounded-xl transition-all active:scale-95 focus:outline-none flex flex-col gap-1"
                            style={{
                              background: isSelected ? 'rgba(249,115,22,0.1)' : '#fff',
                              border: isSelected ? '1px solid rgba(249,115,22,0.4)' : '1px solid #e2e8f0',
                            }}
                          >
                            <span className="font-black text-sm font-mono" style={{ color: isSelected ? '#f97316' : '#334155' }}>
                              {doc.zCounter ? `Z-${doc.zCounter}` : `ESF`}
                            </span>
                            <span className="text-[10px] text-gray-500">{doc.rows?.length ?? doc.rowCount ?? 0} rows</span>
                            <span className="text-[10px] text-gray-400">{doc.date || date}</span>
                          </button>
                        );
                      })
                    )}
                  </div>
                </div>
                <WidePreviewArea html={esfData?.rows?.length > 0 ? generateEsfTableHtml() : ""} loading={esfLoading} />
              </div>
              <div className="p-4 bg-white flex gap-3 border-t border-gray-100 flex-shrink-0 justify-end">
                <button onClick={closeModal} className="px-6 py-2.5 rounded-xl font-bold bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors text-sm mr-auto">Close</button>
                <button
                  onClick={() => handleExportPDF(generateEsfTableHtml(), 'ESF Report')}
                  disabled={!esfData?.rows || esfData.rows.length === 0}
                  className={`px-6 py-2.5 rounded-xl font-bold text-white transition-colors flex items-center gap-2 text-sm ${(!esfData?.rows || esfData.rows.length === 0) ? 'opacity-40 cursor-not-allowed bg-gray-400' : 'bg-blue-600 hover:bg-blue-700'}`}
                >
                  <FiPrinter size={16} /> Save as PDF
                </button>
              </div>
            </div>
          </div>
        )}

        {activeReport?.id === 3 && (
          <div className="fixed inset-0 flex items-center justify-center z-[150] animate-fade-in"
            style={{ background: "rgba(15,23,42,0.8)", backdropFilter: "blur(8px)" }}>
            <div className="rounded-3xl w-full max-w-3xl mx-4 relative flex flex-col bg-white overflow-hidden shadow-2xl h-[85vh] animate-scale-in"
              style={{ animationDelay: '0.05s', opacity: 0, animationFillMode: 'forwards' }}>

              <ModalHeader title="X-Reading Archive" subtitle="Per-shift X-reading and cashier turnover — sourced from saved report" onClose={closeModal} />

              <div className="flex flex-1 overflow-hidden">
                <div className="w-64 bg-gray-50 border-r border-gray-200 flex flex-col p-4">
                  <DatePicker />
                  
                  {date === businessDayDate && (
                    <button
                      onClick={() => { setPreviewTarget('X'); setShowPinModal(true); }}
                      disabled={livePreviewLoading}
                      className="w-full py-3 mb-4 rounded-xl text-orange-600 font-bold text-sm flex items-center justify-center gap-2 transition-all bg-orange-50 hover:bg-orange-100 border border-orange-200 shadow-sm active:scale-95 disabled:opacity-50"
                    >
                      <BarChart2 size={16} /> Preview X-Reading
                    </button>
                  )}

                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">
                    Saved Shifts ({Object.keys(savedXReports).length})
                  </label>
                  <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-2">
                    {loading
                      ? <p className="text-xs text-gray-400 mt-4 text-center">Loading...</p>
                      : Object.keys(savedXReports).length === 0
                        ? <p className="text-xs text-gray-400 mt-4 text-center">No shifts for this date.</p>
                        : Object.values(savedXReports).map((rep: any, idx: number) => {
                              const repId = rep.sessionId || String(rep._id);
                              const isSelected = selectedSessionId === repId;
                              const closedAt = rep.generatedAt
                                ? new Date(rep.generatedAt).toLocaleTimeString("en-US", { hour: '2-digit', minute: '2-digit' })
                                : '--:--';
                              return (
                                <button
                                  key={repId}
                                  onClick={() => {
                                    setSelectedSessionId(repId);
                                    setCurrentXReadingPreview('');
                                  }}
                                  className="text-left p-3 rounded-xl transition-all active:scale-95 focus:outline-none flex flex-col gap-1 animate-slide-up"
                                  style={{
                                    animationDelay: `${0.1 + idx * 0.04}s`, opacity: 0, animationFillMode: 'forwards',
                                    background: isSelected ? "rgba(249,115,22,0.1)" : "#fff",
                                    border: isSelected ? "1px solid rgba(249,115,22,0.4)" : "1px solid #e2e8f0",
                                  }}
                                >
                                  <span className="font-bold text-sm" style={{ color: isSelected ? "#f97316" : "#334155" }}>
                                    {rep.generatedBy?.staffName || 'UNKNOWN'}
                                  </span>
                                  <span className="text-[10px] text-gray-400">Closed: {closedAt}</span>
                                </button>
                              );
                            })
                    }
                  </div>
                </div>

                <div className="flex-1 flex flex-col overflow-hidden">
                  {xReportLoading && selectedSessionId && (
                    <div className="px-4 py-2 bg-orange-50 border-b border-orange-100 text-xs text-orange-600 font-semibold flex-shrink-0">
                      Loading saved report...
                    </div>
                  )}
                  {selectedSessionId && !xReportLoading && savedXReports[selectedSessionId] && (
                    <div className="px-4 py-2 bg-green-50 border-b border-green-100 text-xs text-green-700 font-semibold flex-shrink-0">
                      Showing exact saved report
                    </div>
                  )}
                  {currentXReadingPreview && !selectedSessionId && (
                    <div className="px-4 py-2 bg-blue-50 border-b border-blue-100 text-xs text-blue-700 font-semibold flex-shrink-0">
                      Live Preview
                    </div>
                  )}
                  <ReceiptPreview text={currentXReadingPreview || xReadingText} empty="Select a Shift or Preview Current" />
                </div>
              </div>

              <FooterBar
                onCancel={closeModal}
                enabled={!!(xReadingText || currentXReadingPreview)}
                onPrint={() => {
                  if (currentXReadingPreview) {
                    printDirect(currentXReadingPreview, false).catch(console.error);
                  } else if (xReadingText) {
                    printDirect(xReadingText, false).catch(console.error);
                  }
                }}
              />
            </div>
          </div>
        )}

        {activeReport?.id === 5 && (
          <div className="fixed inset-0 flex items-center justify-center z-[150] animate-fade-in"
            style={{ background: "rgba(15,23,42,0.8)", backdropFilter: "blur(8px)" }}>
            <div className="rounded-3xl w-full max-w-3xl mx-4 relative flex flex-col bg-white overflow-hidden shadow-2xl h-[85vh] animate-scale-in"
              style={{ animationDelay: '0.05s', opacity: 0, animationFillMode: 'forwards' }}>
              <ModalHeader title="Y-Reading Archive" subtitle="Per-terminal shift summary — all terminals" onClose={closeModal} />
              <div className="flex flex-1 overflow-hidden">
                <div className="w-64 bg-gray-50 border-r border-gray-200 flex flex-col p-4">
                  <DatePicker />
                  {date === businessDayDate && (
                    <button
                      onClick={() => { setPreviewTarget('Y'); setShowPinModal(true); }}
                      disabled={livePreviewLoading}
                      className="w-full py-3 mb-4 rounded-xl text-blue-600 font-bold text-sm flex items-center justify-center gap-2 transition-all bg-blue-50 hover:bg-blue-100 border border-blue-200 shadow-sm active:scale-95 disabled:opacity-50"
                    >
                      <BarChart2 size={16} /> Preview Y-Reading
                    </button>
                  )}

                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">
                    Terminals ({yTerminals.length})
                  </label>
                  <div className="flex-1 overflow-y-auto flex flex-col gap-2">
                    {yReadingLoading
                      ? <p className="text-xs text-gray-400 mt-4 text-center">Loading...</p>
                      : yTerminals.length === 0
                        ? <p className="text-xs text-gray-400 mt-4 text-center">No closed shifts for this date.</p>
                        : yTerminals.map((tid, idx) => {
                            const repForTerminal = allSessions.find((r: any) => r.workstationId === tid);
                            const sessionCount = repForTerminal?.content?.yReadingDetails?.sessionCount ?? '-';
                            const isSelected = selectedYTerminal === tid;
                            return (
                              <button
                                key={tid}
                                onClick={() => { setSelectedYTerminal(tid); setCurrentYReadingPreview(''); }}
                                className="text-left p-3 rounded-xl transition-all active:scale-95 focus:outline-none flex flex-col gap-1 animate-slide-up"
                                style={{
                                  animationDelay: `${0.05 + idx * 0.04}s`, opacity: 0, animationFillMode: 'forwards',
                                  background: isSelected ? "rgba(59,130,246,0.08)" : "#fff",
                                  border: isSelected ? "1px solid rgba(59,130,246,0.4)" : "1px solid #e2e8f0",
                                }}
                              >
                                <span className="font-bold text-sm" style={{ color: isSelected ? "#2563eb" : "#334155" }}>Terminal {tid}</span>
                                <span className="text-[10px] text-gray-400">{sessionCount} shift(s)</span>
                                <span className="text-[10px] text-gray-500">
                                  {repForTerminal?.generatedBy?.staffName || 'SYSTEM'}
                                </span>
                              </button>
                            );
                          })
                    }
                  </div>
                </div>
                <div className="flex-1 flex flex-col overflow-hidden">
                  {yReportLoading && selectedYTerminal && (
                    <div className="px-4 py-2 bg-orange-50 border-b border-orange-100 text-xs text-orange-600 font-semibold flex-shrink-0">
                      Loading saved report...
                    </div>
                  )}
                  {selectedYTerminal && !yReportLoading && savedYReport && !currentYReadingPreview && (
                    <div className="px-4 py-2 bg-green-50 border-b border-green-100 text-xs text-green-700 font-semibold flex-shrink-0">
                      Showing exact saved report
                    </div>
                  )}
                  {currentYReadingPreview && !selectedYTerminal && (
                    <div className="px-4 py-2 bg-blue-50 border-b border-blue-100 text-xs text-blue-700 font-semibold flex-shrink-0">
                      Live Preview (Default Terminal)
                    </div>
                  )}
                  {currentYReadingPreview && selectedYTerminal && (
                    <div className="px-4 py-2 bg-blue-50 border-b border-blue-100 text-xs text-blue-700 font-semibold flex-shrink-0">
                      Live Preview
                    </div>
                  )}
                  <ReceiptPreview
                    text={currentYReadingPreview || yReadingText}
                    empty={
                      yReportLoading ? "Loading saved report..." :
                      !selectedYTerminal ? "Select a Terminal or Preview Current" :
                      "No saved Y-Reading for this terminal/date"
                    }
                  />
                </div>
              </div>
              <FooterBar
                onCancel={closeModal}
                enabled={!!(yReadingText || currentYReadingPreview)}
                onPrint={() => {
                  if (currentYReadingPreview) printDirect(currentYReadingPreview, false).catch(console.error);
                  else if (yReadingText) printDirect(yReadingText, false).catch(console.error);
                }}
              />
            </div>
          </div>
        )}

        {activeReport?.id === 6 && (
          <div className="fixed inset-0 flex items-center justify-center z-[150] animate-fade-in"
            style={{ background: "rgba(15,23,42,0.8)", backdropFilter: "blur(8px)" }}>
            <div className="rounded-3xl w-full max-w-6xl mx-4 relative flex flex-col bg-white overflow-hidden shadow-2xl h-[85vh] animate-scale-in"
              style={{ animationDelay: '0.05s', opacity: 0, animationFillMode: 'forwards' }}>

              <ModalHeader
                title="Void Summary"
                subtitle="Voided & cancelled transaction records — linked to cashier session"
                onClose={closeModal}
              />

              <div className="flex flex-1 overflow-hidden">
                <div className="w-56 bg-gray-50 border-r border-gray-200 flex flex-col p-4 flex-shrink-0">
                  <DatePicker />

                  {voidSessions.length > 0 && (() => {
                    const terminals = ['ALL', ...new Set(
                      voidSessions.map((s: any) => s.openedAtTerminal || s.terminalId || s.workstationId || 'UNKNOWN')
                    )] as string[];
                    return (
                      <div className="mb-4">
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">
                          Terminal
                        </label>
                        <div className="flex flex-col gap-1">
                          {terminals.map(tid => (
                            <button
                              key={tid}
                              onClick={() => setSelectedVoidTerminal(tid)}
                              className="text-left px-3 py-2 rounded-lg text-xs font-bold transition-all"
                              style={{
                                background: selectedVoidTerminal === tid
                                  ? 'rgba(239,68,68,0.1)' : '#fff',
                                border: selectedVoidTerminal === tid
                                  ? '1px solid rgba(239,68,68,0.3)' : '1px solid #e2e8f0',
                                color: selectedVoidTerminal === tid ? '#dc2626' : '#374151',
                              }}
                            >
                              {tid === 'ALL' ? 'All Terminals' : `Terminal ${tid}`}
                            </button>
                          ))}
                        </div>
                      </div>
                    );
                  })()}

                  {!voidSessionsLoading && voidData.length > 0 && (() => {
                    const filtered = selectedVoidTerminal === 'ALL'
                      ? voidData
                      : voidData.filter(v =>
                          (v.workstationId || v.terminalId || 'UNKNOWN') === selectedVoidTerminal
                        );
                    return (
                      <div className="p-3 rounded-xl bg-red-50 border border-red-100">
                        <p className="text-[10px] font-bold text-red-500 uppercase tracking-widest mb-1">Found</p>
                        <p className="text-sm font-black text-red-700">
                          {filtered.reduce((s: number, v: any) => s + (v.items?.length || 0), 0)} item(s)
                        </p>
                        <p className="text-[10px] text-gray-500 mt-0.5">
                          {filtered.length} void transaction(s)
                        </p>
                      </div>
                    );
                  })()}

                  {voidSessionsLoading && (
                    <div className="p-3 rounded-xl bg-gray-50 border border-gray-200">
                      <p className="text-[10px] text-gray-400 text-center animate-pulse">Loading sessions...</p>
                    </div>
                  )}

                  {!voidSessionsLoading && voidSessions.length === 0 && (
                    <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
                      <p className="text-[10px] text-amber-700 text-center">No closed sessions for this date.</p>
                    </div>
                  )}
                </div>

                <WidePreviewArea
                  html={(() => {
                    if (voidSessionsLoading) return '';
                    const filtered = selectedVoidTerminal === 'ALL'
                      ? voidData
                      : voidData.filter(v =>
                          (v.workstationId || v.terminalId || 'UNKNOWN') === selectedVoidTerminal
                        );
                    return filtered.length > 0 ? generateVoidSummaryHtml(filtered) : '';
                  })()}
                  loading={voidSessionsLoading}
                />
              </div>

              <div className="p-4 bg-white border-t border-gray-100 flex justify-end flex-shrink-0 gap-3">
                <button
                  onClick={closeModal}
                  className="px-6 py-2.5 rounded-xl font-bold bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors text-sm mr-auto"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const filtered = selectedVoidTerminal === 'ALL' ? voidData : voidData.filter(v => (v.workstationId || v.terminalId || 'UNKNOWN') === selectedVoidTerminal);
                    handleExportPDF(generateVoidSummaryHtml(filtered), 'Void Summary');
                  }}
                  disabled={voidData.length === 0}
                  className={`px-6 py-2.5 rounded-xl font-bold text-white transition-colors flex items-center gap-2 text-sm ${voidData.length === 0 ? 'opacity-40 cursor-not-allowed bg-gray-400' : 'bg-blue-600 hover:bg-blue-700'}`}
                >
                  <FiPrinter size={16} /> Save as PDF
                </button>
              </div>
            </div>
          </div>
        )}

        {activeReport?.id === 7 && (
          <div className="fixed inset-0 flex items-center justify-center z-[150] animate-fade-in"
            style={{ background: "rgba(15,23,42,0.8)", backdropFilter: "blur(8px)" }}>
            <div className="rounded-3xl w-full max-w-3xl mx-4 relative flex flex-col bg-white overflow-hidden shadow-2xl h-[85vh] animate-scale-in"
              style={{ animationDelay: '0.05s', opacity: 0, animationFillMode: 'forwards' }}>

              <ModalHeader title="E-Shift Archive" subtitle="E-Shift Cash Report — sourced from saved report" onClose={closeModal} />

              <div className="flex flex-1 overflow-hidden">
                <div className="w-64 bg-gray-50 border-r border-gray-200 flex flex-col p-4">
                  <DatePicker />
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">
                    E-Shifts ({Object.keys(savedEShifts).length})
                  </label>
                  <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-2">
                    {loading
                      ? <p className="text-xs text-gray-400 mt-4 text-center">Loading...</p>
                      : Object.keys(savedEShifts).length === 0
                        ? <p className="text-xs text-gray-400 mt-4 text-center">No E-Shifts for this date.</p>
                        : Object.values(savedEShifts).map((rep: any, idx: number) => {
                              const repId = rep.sessionId || String(rep._id);
                              const isSelected = selectedSessionId === repId;
                              const closedAt = rep.generatedAt
                                ? new Date(rep.generatedAt).toLocaleTimeString("en-US", { hour: '2-digit', minute: '2-digit' })
                                : '--:--';
                              return (
                                <button
                                  key={repId}
                                  onClick={() => setSelectedSessionId(repId)}
                                  className="text-left p-3 rounded-xl transition-all active:scale-95 focus:outline-none flex flex-col gap-1 animate-slide-up"
                                  style={{
                                    animationDelay: `${0.1 + idx * 0.04}s`, opacity: 0, animationFillMode: 'forwards',
                                    background: isSelected ? "rgba(249,115,22,0.1)" : "#fff",
                                    border: isSelected ? "1px solid rgba(249,115,22,0.4)" : "1px solid #e2e8f0",
                                  }}
                                >
                                  <span className="font-bold text-sm" style={{ color: isSelected ? "#f97316" : "#334155" }}>
                                    {rep.generatedBy?.staffName || 'UNKNOWN'}
                                  </span>
                                  <span className="text-[10px] text-gray-400">Closed: {closedAt}</span>
                                </button>
                              );
                            })
                    }
                  </div>
                </div>

                <div className="flex-1 flex flex-col overflow-hidden">
                  {xReportLoading && selectedSessionId && (
                    <div className="px-4 py-2 bg-orange-50 border-b border-orange-100 text-xs text-orange-600 font-semibold flex-shrink-0">
                      Loading saved report...
                    </div>
                  )}
                  {selectedSessionId && !xReportLoading && savedEShifts[selectedSessionId] && (
                    <div className="px-4 py-2 bg-green-50 border-b border-green-100 text-xs text-green-700 font-semibold flex-shrink-0">
                      Showing exact saved report
                    </div>
                  )}
                  <ReceiptPreview text={eShiftText} empty="Select an E-Shift" />
                </div>
              </div>

              <FooterBar
                onCancel={closeModal}
                enabled={!!eShiftText}
                onPrint={() => {
                  if (eShiftText)
                    printDirect(eShiftText, false).catch(console.error);
                }}
              />
            </div>
          </div>
        )}
      </div>
    </>
  );
}