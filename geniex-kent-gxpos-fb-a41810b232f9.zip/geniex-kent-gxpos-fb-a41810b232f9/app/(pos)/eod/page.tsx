// app/(pos)/eod/page.tsx
/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';
import { useEffect, useState, useMemo, Suspense, useRef } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { FiPrinter, FiX, FiCheckCircle, FiAlertTriangle } from 'react-icons/fi';
import { AlertCircle, Lock, Unlock, HelpCircle } from "lucide-react";
import { sileo } from 'sileo';
import { formatMoney } from "@/app/components/pos/ProductCard";
import { usePrinter } from "@/app/context/PrinterContext";
import { PinModal } from "@/app/components/pos/PinModal";
import { getAssociateByPin } from '../../../src/api/associates';
import { getWorkstationId } from "@/src/lib/workstation";
import {
  generateZOrYReadingText,
  generateXReadingText,
  generateEShiftText,
  generateReportContentPayload,
  type ReportStats
} from "../../../src/lib/report-builders";
import { logEJournalEntry } from '@/src/lib/ejournal-client';

type SessionData = {
  _id: string;
  sessionId: string;
  shiftNumber?: number;
  startingCash: string;
  openedAt: string;
  closedAt?: string;
  staffId: string;
  staffName: string;
  status: string;
  openedAtTerminal?: string | null;
  closedAtTerminal?: string | null;
  cashDrops?: Array<{ amount: number; timestamp: string; staffId?: string; staffName?: string }>;
  stats?: any;
};

type YReadingQueueItem = {
  terminalId: string;
  sessions: SessionData[];
  transactions: any[];
  voidLogs: any[];
  oldGT: number;
};

function buildStats(
  txList: any[],
  sessions: SessionData[],
  catMapData: { catMap: Record<string, string>; itemPriceMap: Record<string, number> },
  voidLogList: any[] = []
): ReportStats {
  let grossSales = 0, totalDiscount = 0, netSales = 0,
      vatableSales = 0, vatExemptSales = 0, zeroRatedSales = 0, totalTax = 0,
      totalCashSales = 0, totalNonCashSales = 0, totalVoucherSales = 0,
      totalVoided = 0, totalRefunded = 0,
      cashTxCount = 0, nonCashTxCount = 0, voucherTxCount = 0,
      voidCount = 0, refundCount = 0, guestCount = 0;

  const pCounts = { CARD: 0, MAYA: 0, GCASH: 0, QRPH: 0, LANDERS: 0, VOUCHER: 0 };
  const pSums   = { CARD: 0, MAYA: 0, GCASH: 0, QRPH: 0, LANDERS: 0, VOUCHER: 0 };
  const dCounts = { ATHLETE: 0, SRC: 0, PWD: 0, SOLO: 0, MEDAL: 0, CUSTOM: 0 };
  const dSums   = { ATHLETE: 0, SRC: 0, PWD: 0, SOLO: 0, MEDAL: 0, CUSTOM: 0 };
  const revenueByCategory: Record<string, number> = {};
  const txTypeSummary: Record<string, { count: number; amount: number }> = {};

  let minSi = Infinity, maxSi = -Infinity, totalSi = 0,
      minVoidSi = Infinity, maxVoidSi = -Infinity,
      minRefundSi = Infinity, maxRefundSi = -Infinity;

  let minVoidSeries = '', maxVoidSeries = '',
      minRefundSeries = '', maxRefundSeries = '';

  const seriesVal = (s: string) =>
    parseInt(s.replace(/[^0-9]/g, '').slice(-8) || '0', 10);

  txList.forEach(tx => {
    const isVoid   = tx.status === 'voided'   || tx.orderState === 'VOIDED';
    const isRefund = tx.status === 'refunded' || tx.orderState === 'REFUNDED';
    const txType   = (tx.transactionType || 'REGULAR').toUpperCase();

    const siMatch = tx.salesNumber?.match(/\d+$/);
    if (siMatch) {
      const siNum = parseInt(siMatch[0], 10);
      if (!isVoid) { minSi = Math.min(minSi, siNum); maxSi = Math.max(maxSi, siNum); totalSi++; }
      if (isVoid)   { minVoidSi   = Math.min(minVoidSi, siNum);   maxVoidSi   = Math.max(maxVoidSi, siNum); }
      if (isRefund) { minRefundSi = Math.min(minRefundSi, siNum); maxRefundSi = Math.max(maxRefundSi, siNum); }
    }

    const gross    = (tx.price?.subtotal    || 0) / 100;
    const discount = (tx.discountAmount     || 0) / 100;
    const tax      = (tx.price?.VatAmount   || tx.price?.tax || 0) / 100;
    const vatable  = (tx.price?.VATSale     || 0) / 100;
    const exempt   = (tx.price?.VatExSales || 0) / 100;
    const zero     = (tx.price?.ZeroRated  || 0) / 100;
    const net      = gross - discount - (isVoid || isRefund ? 0 : (exempt > 0 ? tax : 0));

    if (isRefund) {
      totalRefunded += gross; refundCount++;
      if (tx.refundSeriesNo) {
        if (!minRefundSeries || seriesVal(tx.refundSeriesNo) < seriesVal(minRefundSeries)) minRefundSeries = tx.refundSeriesNo;
        if (!maxRefundSeries || seriesVal(tx.refundSeriesNo) > seriesVal(maxRefundSeries)) maxRefundSeries = tx.refundSeriesNo;
      }
      return;
    }

    grossSales += gross;
    totalDiscount += discount;
    totalTax += tax;
    vatableSales += vatable;
    vatExemptSales += exempt;
    zeroRatedSales += zero;
    netSales += net;

    if (!txTypeSummary[txType]) txTypeSummary[txType] = { count: 0, amount: 0 };
    txTypeSummary[txType].count++;
    txTypeSummary[txType].amount += net;

    if (discount > 0) {
      if      (txType === 'SRC')     { dCounts.SRC++;     dSums.SRC     += discount; }
      else if (txType === 'PWD')     { dCounts.PWD++;     dSums.PWD     += discount; }
      else if (txType === 'ATHLETE') { dCounts.ATHLETE++; dSums.ATHLETE += discount; }
      else if (txType === 'SOLO')    { dCounts.SOLO++;    dSums.SOLO    += discount; }
      else if (txType === 'MEDAL')   { dCounts.MEDAL++;   dSums.MEDAL   += discount; }
      else if (txType === 'CUSTOM')  { dCounts.CUSTOM++;  dSums.CUSTOM  += discount; }
    }

    const guests = tx.guest || tx.guests || [];
    if (guests.length > 0) guestCount += guests.length;

    let cashCollected = 0, nonCashCollected = 0, voucherCollected = 0;
    if (Array.isArray(tx.payment) && tx.payment.length > 0) {
      tx.payment.forEach((p: any) => {
        const methodStr = String(p.PaymentMethod || p.method || 'CASH').toUpperCase();
        // Unconditionally divide DB backend cents by 100, otherwise use frontend pesos
        const amt = p.Amount !== undefined ? Number(p.Amount) / 100 : Number(p.amount ?? 0);
        const tenderedAmt = p.Tendered !== undefined ? Number(p.Tendered) / 100 : (p.tendered !== undefined ? Number(p.tendered) / 100 : amt);

        if (methodStr === 'CASH') {
          cashCollected += amt;
        } else if (methodStr.includes('VOUCHER')) {
          voucherCollected += tenderedAmt; // Extracted face value instead of the clamped actual amount!
          pCounts.VOUCHER++;
          pSums.VOUCHER += tenderedAmt;
        } else {
          nonCashCollected += amt;
          let mapMethod = 'CARD';
          if      (methodStr.includes('MAYA'))    mapMethod = 'MAYA';
          else if (methodStr.includes('GCASH'))   mapMethod = 'GCASH';
          else if (methodStr.includes('QRPH'))    mapMethod = 'QRPH';
          else if (methodStr.includes('LANDERS')) mapMethod = 'LANDERS';
          
          if (pCounts[mapMethod as keyof typeof pCounts] !== undefined) {
            pCounts[mapMethod as keyof typeof pCounts]++;
            pSums[mapMethod   as keyof typeof pSums] += amt;
          }
        }
      });
    } else {
      const rootMethod = String(tx.paymentMethod || tx.PaymentMethod || 'CASH').toUpperCase();
      if (rootMethod.includes('VOUCHER')) voucherCollected = net;
      else if (rootMethod !== 'CASH') nonCashCollected = net;
      else cashCollected = net;
    }

    if (cashCollected > 0)    { totalCashSales    += cashCollected;    cashTxCount++; }
    if (nonCashCollected > 0) { totalNonCashSales += nonCashCollected; nonCashTxCount++; }
    if (voucherCollected > 0) { totalVoucherSales += voucherCollected; voucherTxCount++; }

    const items = tx.items || tx.cart || [];
    items.forEach((item: any) => {
      const qty      = item.quantity || item.qty || 1;
      const rawPrice = item.price || 0;
      const price    = rawPrice > 1000 ? rawPrice / 100 : rawPrice;
      const catId    = item.id || item.itemId || '';
      const catName  = catMapData.catMap[catId] || item.category || 'OTHER';
      const itemDiscount = item.itemDiscount ? item.itemDiscount / 100 : 0;
      revenueByCategory[catName] = (revenueByCategory[catName] || 0) + (price * qty) - itemDiscount;
    });
  });

  voidLogList.forEach(log => {
    voidCount++;
    (log.items || []).forEach((item: any) => {
      const qty      = item.qty || item.quantity || 1;
      const price    = (item.price || 0);
      let lineTotal  = price * qty;

      (item.modifiers || []).forEach((m: any) => {
        const mQty   = m.qty || m.quantity || 1;
        const mPrice = (m.price || 0) / 100;
        lineTotal   += mPrice * mQty;
      });

      totalVoided += lineTotal;
    });
  });

  let cashFund = 0, totalDropped = 0;
  sessions.forEach(s => {
    cashFund     += parseFloat(s.startingCash || '0');
    totalDropped += (s.cashDrops || []).reduce(
      (sum: number, d: any) => sum + parseFloat(d.amount), 0
    );
  });
  const expectedTotal = cashFund + totalCashSales - totalDropped;

  return {
    grossSales, totalDiscount, netSales, totalTax,
    totalCashSales, totalNonCashSales, totalVoucherSales, totalVoided, totalRefunded,
    cashFund, expectedTotal, totalDropped,
    vatableSales, vatExemptSales, zeroRatedSales,
    cashTxCount, nonCashTxCount, voucherTxCount, voidCount, refundCount, guestCount,
    pCounts, pSums, dCounts, dSums,
    revenueByCategory, txTypeSummary,
    si: { minSi, maxSi, totalSi, minVoidSi, maxVoidSi, minRefundSi, maxRefundSi },
    voidSeriesRange:   { min: minVoidSeries   || '-', max: maxVoidSeries   || '-' },
    refundSeriesRange: { min: minRefundSeries || '-', max: maxRefundSeries || '-' },
    denominations: {},
    actualCashCount: 0,
    cashDrops: [],
  } as ReportStats;
}

function DrawerOpenWarningModal() {
  return (
    <div className="fixed inset-0 flex items-center justify-center z-[9999] animate-fade-in" style={{ background: "rgba(15, 23, 42, 0.8)", backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)" }}>
      <div className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden flex flex-col p-8 animate-scale-in shadow-2xl" style={{ background: "#ffffff" }}>
        <div className="w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto" style={{ background: "rgba(239, 68, 68, 0.1)", color: "#ef4444" }}>
          <FiAlertTriangle size={32} />
        </div>
        <h2 className="text-2xl font-black text-gray-900 mb-2 text-center font-poppins">Cash Drawer Open</h2>
        <p className="text-sm text-gray-500 font-medium mb-8 text-center leading-relaxed">
          The cash drawer is currently open. You must close and secure the drawer to proceed with closing the shift.
        </p>
        <div className="w-full py-4 rounded-xl font-bold text-center text-red-500 bg-red-50 border border-red-100 animate-pulse" style={{ fontFamily: "Poppins" }}>
          Awaiting drawer closure...
        </div>
      </div>
    </div>
  );
}

function EODContent() {
  const router       = useRouter();
  const searchParams = useSearchParams();

  const isEodIntent = searchParams.get('mode') !== 'turnover';

  const { tillStatus, openDrawer, printDirect } = usePrinter();

  const [businessDayId, setBusinessDayId] = useState<string | null>(null);
  const [activeSession,        setActiveSession]        = useState<SessionData | null>(null);
  const [allOpenSessions,      setAllOpenSessions]      = useState<SessionData[]>([]);
  const [zReadingType, setZReadingType] = useState<'Consolidated' | 'Per Terminal' | 'Both'>('Consolidated');
  const [completedTerminals, setCompletedTerminals] = useState<string[]>([]);
  const [activeTerminalsToday, setActiveTerminalsToday] = useState<string[]>([]);
  const [advanceBusinessDay, setAdvanceBusinessDay] = useState(false);
  const [closedSessions,       setClosedSessions]       = useState<SessionData[]>([]);
  const [transactions,         setTransactions]         = useState<any[]>([]);
  const [loading,              setLoading]              = useState(true);
  const [isGeneratingEJ,       setIsGeneratingEJ]       = useState(false);
  const [businessDayDate, setBusinessDayDate] = useState<string | null>(null);
  const [isGettingBusinessDay, setIsGettingBusinessDay] = useState<boolean>(true);
  const [currentStaffId,       setCurrentStaffId]       = useState<string>('');
  const [currentUserRole,      setCurrentUserRole]      = useState<number>(3);

  const [flowState, setFlowState] = useState<'CHECK_SHIFTS' | 'X_READING' | 'Z_READING'>('CHECK_SHIFTS');

  const [mode, setMode] = useState<'add' | 'subtract'>('add');
  const [denominations, setDenominations] = useState<Record<number, number>>({
    1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0,
  });

  const [oldGTForReport, setOldGTForReport] = useState<number>(0);

  const [pinGateState, setPinGateState] = useState<'idle' | 'pending' | 'verified' | 'rejected'>(isEodIntent ? 'pending' : 'idle');
  const [pendingTurnoverSession, setPendingTurnoverSession] = useState<SessionData | null>(null);
  const [pinModalExiting, setPinModalExiting] = useState(false);

  const [eodLockStatus, setEodLockStatus] = useState<{
    locked: boolean;
    lockedBy: string | null;
  }>({ locked: false, lockedBy: null });
  const [isProceedingEOD, setIsProceedingEOD] = useState(false);
  const [showEODConfirmPrompt, setShowEODConfirmPrompt] = useState(false);
  const [zReadingStats, setZReadingStats] = useState<ReturnType<typeof buildStats> | null>(null);

  const [pendingResetCtr, setPendingResetCtr] = useState<string>('0000');
  const [pendingZCounter, setPendingZCounter] = useState<string>('0001');

  const isLockedOut = zReadingType !== 'Per Terminal' && eodLockStatus.locked && eodLockStatus.lockedBy !== getWorkstationId();
  const zReadingDataRef = useRef<{
    closedSessions: SessionData[];
    allTransactions: any[];
  } | null>(null);

  const [voidLogs, setVoidLogs] = useState<any[]>([]);

  useEffect(()=>{
    async function getBusinessDate(){
      setIsGettingBusinessDay(true);
      const res  = await fetch('/api/cashier-session?status=all_open');
      const data = await res.json();
      if (data.businessDayDate) setBusinessDayDate(data.businessDayDate);
      if (data.businessDayId) setBusinessDayId(data.businessDayId);
      setIsGettingBusinessDay(false);
    }
    getBusinessDate();
  }, [])

  const handlePinGateConfirm = async (pin: string) => {
    try {
      const associate = await getAssociateByPin(pin);
      if (!associate) {
        sileo.error({ title: "Access Denied", description: "Only manager can proceed.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
        return;
      }
      const isManager   = associate.user?.role === 2;

      if (!isManager) {
        sileo.error({ title: "Access Denied", description: "Only manager can proceed.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
        return;
      }

      setPinModalExiting(true);
      setTimeout(() => {
        setPinGateState('verified');
        setPinModalExiting(false);

        if (!isEodIntent) {
          setFlowState('X_READING');
        } else if (pendingTurnoverSession) {
          startTurnoverForSession(pendingTurnoverSession);
        }

      }, 260);
    } catch {
      sileo.error({ title: "Access Denied", description: "Only manager can proceed.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
    }
  };

  const [menuCategoryMap, setMenuCategoryMap] = useState<{
    catMap: Record<string, string>;
    itemPriceMap: Record<string, number>;
  }>({ catMap: {}, itemPriceMap: {} });

  const [readByStaff,    setReadByStaff]    = useState<string>('');
  const [fiscalSettings, setFiscalSettings] = useState({
    vatNumber: '', tinNumber: '', minNumber: '', ptuNumber: '', snNumber: '',
  });
  const [storeData,       setStoreData]       = useState<any>(null);

  const terminalId = getWorkstationId() || '001';

  const fetchOldGT = async (): Promise<number> => {
    try {
      const res  = await fetch('/api/reports?type=Z-READING');
      const data = await res.json();
      const latest = Array.isArray(data?.reports) ? data.reports[0] : data?.report;
      const val  = Number(latest?.content?.grandTotals?.newGrandTTL ?? 0);
      setOldGTForReport(val);
      return val;
    } catch {
      return 0;
    }
  };

  const fetchEShiftOldGT = async (currentTerminalId: string): Promise<number> => {
    try {
      const dateToQuery = businessDayDate ?? new Date().toISOString().split('T')[0];

      const res = await fetch(
        `/api/reports?type=E-SHIFT&date=${dateToQuery}&workstationId=${currentTerminalId}`
      );
      const data = await res.json();
      const priorEShifts: any[] = data?.reports ?? [];

      return priorEShifts
        .filter((r: any) => 
          // Exclude the current session, but strictly INCLUDE only the active cashier's prior shifts
          r.sessionId !== activeSession?.sessionId &&
          (r.staffId === activeSession?.staffId || r.generatedBy?.staffId === activeSession?.staffId)
        )
        .reduce((sum: number, r: any) => {
          const newGT = Number(r?.content?.eShiftDetails?.accountability?.newGT ?? 0);
          const oldGT = Number(r?.content?.eShiftDetails?.accountability?.oldGT ?? 0);
          return sum + (newGT - oldGT);
        }, 0);
    } catch {
      return 0;
    }
  };

  const fetchYOldGT = async (tid: string): Promise<number> => {
    try {
      const res  = await fetch(`/api/reports?type=Y-READING&workstationId=${tid}`);
      const data = await res.json();
      const latest = Array.isArray(data?.reports) ? data.reports[0] : data?.report;
      return Number(latest?.content?.grandTotals?.newGrandTTL ?? 0);
    } catch {
      return 0;
    }
  };

  const handleTurnoverAction = async () => {
    setLoading(true);
    try {
      const sessionsRes = await fetch('/api/cashier-session?status=all_open');
      const sessionsData = await sessionsRes.json();
      const activeSessionsList: SessionData[] = sessionsData.sessions || [];

      const login = JSON.parse(localStorage.getItem('lastLogin') || '{}');
      const staffId = String(login?.staffId || login?.id || currentStaffId);

      const session = activeSessionsList.find(s => String(s.staffId) === staffId) || 
                      activeSessionsList.find(s => s.openedAtTerminal === terminalId) || 
                      activeSessionsList[0];

      if (!session) {
        sileo.error({ title: "No Open Shift", description: "No active shift found to perform turnover." });
        return;
      }

      setActiveSession(session);
      const txRes = await fetch(`/api/transactions?limit=5000&sessionId=${session.sessionId}`);
      const txData = await txRes.json();
      setTransactions(txData.transactions || []);
      setDenominations({ 1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0 });
      
      try {
        const voidRes = await fetch(`/api/voids?sessionIds=${session.sessionId}`);
        const voidData = await voidRes.json();
        setVoidLogs(voidData.voids || []);
      } catch {
        setVoidLogs([]);
      }
      
      setPinGateState('pending');
    } catch (err) {
      console.error(err);
      sileo.error({ title: "Error", description: "Failed to load shift turnover data." });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    try {
      const login = JSON.parse(localStorage.getItem('lastLogin') || '{}');
      setReadByStaff(login?.name || 'UNKNOWN');
      if (login?.staffId || login?.id) setCurrentStaffId(String(login.staffId || login.id));
      if (login?.role !== undefined) setCurrentUserRole(Number(login.role));
    } catch {}

    if (!isEodIntent) {
      handleTurnoverAction();
    } else {
      loadOpenShifts();
    }

    fetch('/api/menu')
      .then(r => r.json())
      .then(menuData => {
        let categories: any[] = [];
        if (Array.isArray(menuData)) {
          categories = menuData[0]?.payload?.categories || menuData[0]?.categories || [];
        } else {
          categories = menuData?.payload?.categories || menuData?.categories || [];
        }

        const catMap: Record<string, string>       = {};
        const itemPriceMap: Record<string, number> = {};
        const getInitials = (name: string) =>
          name.replace(/[^a-zA-Z ]/g, '').trim().split(/\s+/).map(w => w[0]).join('').toUpperCase();

        categories.forEach((cat: any) => {
          const rawName = (cat.name || 'OTHER').toUpperCase();
          const catName = rawName.endsWith('S') && rawName !== 'GLASS' ? rawName.slice(0, -1) : rawName;

          const processItems = (items: any[], subName: string | null) => {
            const label = subName ? `${catName}: ${getInitials(subName)}` : catName;
            (items || []).forEach(item => {
              const stockId = (item.barcode && item.barcode !== 'GTIN') ? `IT-${item.barcode}` : item.id;
              catMap[stockId]       = label;
              catMap[item.id]       = label;
              itemPriceMap[stockId] = item.price || 0;
              itemPriceMap[item.id] = item.price || 0;
            });
          };

          processItems(cat.items, null);
          (cat.subcategories || []).forEach((sub: any) => processItems(sub.items, sub.name));
        });

        setMenuCategoryMap({ catMap, itemPriceMap });
      })
      .catch(console.error);
      
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const WORKSTATION_ID = getWorkstationId() || '001';
    fetch(`/api/settings?workstationId=${WORKSTATION_ID}`)
    .then(res => res.json()).then(data => {
      setFiscalSettings(data);
      if (data.zReadingType) setZReadingType(data.zReadingType);
    }).catch(console.error);
  }, []);

  useEffect(() => {
    const fetchStoreData = async () => {
      try {
        const res = await fetch('/api/store');
        if (res.ok) {
          const dbData = await res.json();
          setStoreData(dbData.payload);
          localStorage.setItem('store_data', JSON.stringify(dbData.payload));
        }
      } catch (error) {
        console.error('Failed to load store data', error);
      }
    };
    fetchStoreData();
  }, []);

  const loadOpenShifts = async () => {
    setLoading(true);
    try {
      const res  = await fetch('/api/cashier-session?status=all_open');
      const data = await res.json();
      setAllOpenSessions(data.sessions || []);
      setCompletedTerminals(data.completedTerminals || []);
      if (data.activeTerminalsToday) setActiveTerminalsToday(data.activeTerminalsToday);
      setEodLockStatus({
        locked:   data.eodLocked  || false,
        lockedBy: data.lockedBy   || null,
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (flowState !== 'CHECK_SHIFTS') return;

    const poll = async () => {
      try {
        const res  = await fetch('/api/cashier-session?status=all_open');
        const data = await res.json();
        setAllOpenSessions(data.sessions || []);                   
        setCompletedTerminals(data.completedTerminals || []);
        if (data.activeTerminalsToday) setActiveTerminalsToday(data.activeTerminalsToday);
        setEodLockStatus({
          locked:   data.eodLocked  || false,
          lockedBy: data.lockedBy   || null,
        });
      } catch { }
    };

    const interval = setInterval(poll, 4000);
    return () => clearInterval(interval);
  }, [flowState]);

  const startTurnoverForSession = async (session: SessionData) => {
    setLoading(true);
    try {
      setActiveSession(session);
      
      const txRes = await fetch(`/api/transactions?limit=5000&sessionId=${session.sessionId}`);
      const txData = await txRes.json();
      
      setTransactions(txData.transactions || []);
      setDenominations({ 1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0 });
      try {
        const voidRes = await fetch(`/api/voids?sessionIds=${session.sessionId}`);
        const voidData = await voidRes.json();
        setVoidLogs(voidData.voids || []);
      } catch {
        setVoidLogs([]);
      }
      setFlowState('X_READING');
      await openDrawer();
    } catch (err) {
      console.error('Failed to start turnover', err);
    } finally {
      setLoading(false);
    }
  };

  const loadZReadingData = async (): Promise<{
    closedSessions: SessionData[];
    allTransactions: any[];
    voidLogs: any[];
  } | null> => {
    setLoading(true);
    try {
      if (!businessDayId) throw new Error('No active business day found');
      
      const closedRes = await fetch(zReadingType === 'Per Terminal' 
        ? `/api/cashier-session?status=closed&businessDayId=${businessDayId}&terminalId=${terminalId}`
        : `/api/cashier-session?status=closed&businessDayId=${businessDayId}`
      );
      const closedData = await closedRes.json();
      const fetchedClosedSessions = closedData.sessions || [];
      const closedSessionIds = fetchedClosedSessions.map((s: SessionData) => s.sessionId);

      let activeTx: any[] = [];
      if (closedSessionIds.length > 0) {
        const txRes = await fetch(
          `/api/transactions?limit=10000&sessionIds=${closedSessionIds.join(',')}`
        );
        const txData = await txRes.json();
        activeTx = txData.transactions || [];
      }

      setClosedSessions(fetchedClosedSessions);
      setTransactions(activeTx);

      let fetchedVoidLogs: any[] = [];
      try {
        const voidRes  = await fetch(`/api/voids?date=${businessDayDate ?? new Date().toISOString().slice(0, 10)}`);
        const voidData = await voidRes.json();
        fetchedVoidLogs = voidData.voids || [];
        setVoidLogs(fetchedVoidLogs);
      } catch {
        setVoidLogs([]);
      }

      try {
        const zcRes  = await fetch(`/api/numbers?type=getZCounter&workstationId=${terminalId}`);
        const zcData = await zcRes.json();
        setPendingZCounter(zcData.nextZCounter || '0001');
        setPendingResetCtr(zcData.nextResetCtr || '0000'); 
      } catch {
        setPendingZCounter('0001');
        setPendingResetCtr('0000');
      }

      setFlowState('Z_READING');

      return {
        closedSessions: fetchedClosedSessions,
        allTransactions: activeTx,
        voidLogs: fetchedVoidLogs,
      };
    } catch (err) {
      console.error(err);
      return null;
    } finally {
      setLoading(false);
    }
  };

  const handleProceed = async () => {
    if (isProceedingEOD) return;
    setIsProceedingEOD(true);

    try {
      if (zReadingType !== 'Per Terminal') {
        const lockRes  = await fetch('/api/business-day', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'acquireLock', terminalId }),
        });
        const lockData = await lockRes.json();

        if (!lockData.acquired) {
          sileo.error({
            title: 'EOD Already In Progress',
            description: `Terminal ${lockData.lockedBy} is already running End of Day. Please wait.`,
            fill: '#171717',
            styles: { title: 'text-white!', description: 'text-white/75!' },
          });
          setEodLockStatus({ locked: true, lockedBy: lockData.lockedBy });
          setIsProceedingEOD(false);
          return;
        }
      }

      const zData = await loadZReadingData();
      if (!zData) {
        sileo.error({ title: 'Error', description: 'Failed to load EOD data. Please try again.' });
        if (zReadingType !== 'Per Terminal') {
          await fetch('/api/business-day', {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'releaseLock', terminalId }),
          }).catch(() => {});
        }
        setIsProceedingEOD(false);
        return;
      }
      zReadingDataRef.current = zData;
      const aggregateZStats = buildStats(zData.allTransactions, zData.closedSessions, menuCategoryMap, zData.voidLogs);
      setZReadingStats(aggregateZStats);

      const oldGT = await fetchOldGT();

      const sessionsByTerminal = new Map<string, SessionData[]>();
      for (const session of zData.closedSessions) {
        const tid = session.openedAtTerminal || 'UNKNOWN';
        if (!sessionsByTerminal.has(tid)) sessionsByTerminal.set(tid, []);
        sessionsByTerminal.get(tid)!.push(session);
      }

      const terminalEntries = Array.from(sessionsByTerminal.entries()).sort(([a], [b]) => a.localeCompare(b));
      const yOldGTs = await Promise.all(
        terminalEntries.map(([tid]) => fetchYOldGT(tid))
      );

      const queue: YReadingQueueItem[] = terminalEntries.map(([tid, terminalSessions], idx) => {
        const terminalSessionIds = terminalSessions.map(s => s.sessionId);
        const txForTerminal = zData.allTransactions.filter((tx: any) =>
          terminalSessionIds.includes(tx.sessionId)
        );
        const voidsForTerminal = zData.voidLogs.filter((v: any) =>
          terminalSessionIds.includes(v.sessionId) || v.workstationId === tid
        );
        return {
          terminalId: tid,
          sessions:   terminalSessions,
          transactions: txForTerminal,
          voidLogs: voidsForTerminal,
          oldGT: yOldGTs[idx],
        };
      });

      const dateStr = businessDayDate ?? new Date().toISOString().split('T')[0];

      setIsProceedingEOD(false);
      setIsGeneratingEJ(true);

      try {
        const workstationId = localStorage.getItem('workstationId') || terminalId;
        let actualZCounter = pendingZCounter;
        let actualResetCtr = pendingResetCtr;

        try {
          const zcRes = await fetch('/api/numbers?type=zCounter', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ workstationId: terminalId }),
          });
          const zcData = await zcRes.json();
          actualZCounter = zcData.zCounter || pendingZCounter;
          actualResetCtr = zcData.resetCtr || pendingResetCtr;
          await fetch('/api/numbers?type=saveZRecord', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ workstationId: terminalId, date: dateStr, zCounter: actualZCounter }),
          }).catch(err => console.error('saveZRecord failed:', err));
        } catch (zcErr) {
          console.error('Z-counter increment failed:', zcErr);
        }

        const seriesType = storeData?.series_type || 'WS';

        // PRE-FETCH TRANSACTION NUMBERS TO PREVENT PREVIEW TAB SPLITTING/BLOCKING
        const fetchedTxNums: Record<string, { yTxNum: string; termZTxNum?: string }> = {};
        for (const item of queue) {
          let yTxNum = '';
          try {
            const txRes = await fetch('/api/numbers?type=transaction', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ seriesType, workstationId: item.terminalId }) });
            if (txRes.ok) { const txData = await txRes.json(); yTxNum = txData.number; }
          } catch(err) { console.error(err); }
          if (!yTxNum) yTxNum = `TXN-${Date.now()}`;

          let termZTxNum = '';
          if (zReadingType === 'Both') {
            try {
              const txRes = await fetch('/api/numbers?type=transaction', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ seriesType, workstationId: item.terminalId }) });
              if (txRes.ok) { const txData = await txRes.json(); termZTxNum = txData.number; }
            } catch(err) { console.error(err); }
            if (!termZTxNum) termZTxNum = `TXN-${Date.now()}`;
          }
          fetchedTxNums[item.terminalId] = { yTxNum, termZTxNum };
        }

        let zTxNum = '';
        try {
          const txRes = await fetch('/api/numbers?type=transaction', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ seriesType, workstationId: workstationId }) });
          if (txRes.ok) { const txData = await txRes.json(); zTxNum = txData.number; }
        } catch(err) { console.error(err); }
        if (!zTxNum) zTxNum = `TXN-${Date.now()}`;

        // NOW EXECUTE PRINT GENERATION (Without delay between printDirect calls)
        for (const item of queue) {
          const yStats = buildStats(item.transactions, item.sessions, menuCategoryMap, item.voidLogs);
          const { yTxNum, termZTxNum } = fetchedTxNums[item.terminalId];
          
          const yText = generateZOrYReadingText(
            { ...yStats, denominations: {}, actualCashCount: 0, cashDrops: [] } as ReportStats,
            {
              type:          'Y',
              terminalId:    item.terminalId,
              termSessions:  item.sessions.length,
              yTermSessions: item.sessions,
              readBy:        readByStaff,
              storeData,
              oldGT:         item.oldGT,
              resetCtr:      actualResetCtr,
              transactionNumber: yTxNum
            },
            fiscalSettings
          );
          const nestedYContent = generateReportContentPayload(
            { ...yStats, denominations: {}, actualCashCount: 0, cashDrops: [] } as ReportStats,
            { transactionNumber: yTxNum, yReadingDetails: { terminalId: item.terminalId, sessionCount: item.sessions.length, oldGT: item.oldGT } }
          );
          
          fetch('/api/reports', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              reportType:    'Y-READING',
              date:          dateStr,
              workstationId: item.terminalId,
              staffId:       'TERMINAL',
              staffName:     readByStaff || 'SYSTEM',
              content:       nestedYContent,
              textContent:   yText,
            }),
          }).catch(console.error);
          
          await printDirect(yText, false).catch(console.error);
          logEJournalEntry({
            businessDayId:  businessDayId!,
            workstationId:  item.terminalId,
            entryType:      'Y-READING',
            text:           yText,
          });

          if (zReadingType === 'Both' && termZTxNum) {
            const termZText = generateZOrYReadingText(
              { ...yStats, denominations: {}, actualCashCount: 0, cashDrops: [] } as ReportStats,
              {
                type:     'Z',
                terminalId: item.terminalId,
                zCounter: actualZCounter,
                resetCtr: actualResetCtr,
                readBy:   readByStaff,
                storeData,
                oldGT:    item.oldGT,
                transactionNumber: termZTxNum
              },
              fiscalSettings
            );
            await printDirect(termZText, false).catch(console.error);
          }
        }

        const nestedZContent = generateReportContentPayload(
          { ...aggregateZStats, denominations, actualCashCount: actualCount, cashDrops: [] } as ReportStats,
          { transactionNumber: zTxNum, accountability: { oldGT, newGT: aggregateZStats.netSales }, zCounter: actualZCounter }
        );

        const zText = generateZOrYReadingText(
          { ...aggregateZStats, denominations, actualCashCount: actualCount, cashDrops: [] } as ReportStats,
          {
            type:     'Z',
            zCounter: actualZCounter,
            resetCtr: actualResetCtr,
            readBy:   readByStaff,
            storeData,
            oldGT,
            terminalId: zReadingType === 'Per Terminal' ? terminalId : undefined,
            transactionNumber: zTxNum
          },
          fiscalSettings
        );

        logEJournalEntry({
          businessDayId:  businessDayId!,
          workstationId:  workstationId,
          entryType:      'Z-READING',
          text:           zText,
        });
        await printDirect(zText, false).catch(console.error);

        await new Promise(res => setTimeout(res, 150));
        
        const ejRes = await fetch('/api/reports', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            reportType:    'Z-READING',
            date:          dateStr,
            workstationId,
            staffId:       'AGGREGATE',
            staffName:     readByStaff || 'SYSTEM',
            content:       nestedZContent,
            textContent:   zText,
          }),
        });
        const ejData = await ejRes.json();
        if (!ejData.success) throw new Error(ejData.error || 'E-Journal generation failed');

        if (advanceBusinessDay) {
          let consolidatedTx = zData.allTransactions;
          let consolidatedSessions = zData.closedSessions;

          if (zReadingType === 'Per Terminal') {
            const allClosedRes = await fetch(`/api/cashier-session?status=closed&businessDayId=${businessDayId}`);
            const allClosedData = await allClosedRes.json();
            consolidatedSessions = allClosedData.sessions || [];
            const allClosedIds = consolidatedSessions.map((s: SessionData) => s.sessionId);
            
            if (allClosedIds.length > 0) {
              const allTxRes = await fetch(`/api/transactions?limit=10000&sessionIds=${allClosedIds.join(',')}`);
              const allTxData = await allTxRes.json();
              consolidatedTx = allTxData.transactions || [];
            }
          }

          const { buildSeniorReportRows, seniorReportToCsv } = await import('@/src/libs/SeniorReportGenerator');
          const { buildPwdReportRows, pwdReportToCsv }       = await import('@/src/libs/PwdReportGenerator');
          const { buildAthleteReportRows, athleteReportToCsv } = await import('@/src/libs/AthleteReportGenerator');
          const { buildZeroRatedReportRows, zeroRatedReportToCsv } = await import('@/src/libs/ZeroRatedReportGenerator');
          const { buildDetailedSalesSummary, detailedSalesSummaryToCsv } = await import('@/src/libs/DetailedSalesSummaryGenerator');

          const seniorRows    = buildSeniorReportRows(consolidatedTx);
          const pwdRows       = buildPwdReportRows(consolidatedTx);
          const athleteRows   = buildAthleteReportRows(consolidatedTx);
          const zeroRatedRows = buildZeroRatedReportRows(consolidatedTx);
          const detailedRows  = buildDetailedSalesSummary(consolidatedTx, consolidatedSessions);

          await Promise.allSettled([
            fetch('/api/reports', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                reportType:    'SENIOR-REPORT',
                date:          dateStr,
                workstationId,
                staffId:       'AGGREGATE',
                staffName:     readByStaff || 'SYSTEM',
                businessDayId: ejData.businessDayId ?? undefined,
                content: {
                  rowCount: seniorRows.length,
                  rows: seniorRows,
                  csv: seniorReportToCsv(seniorRows)
                }
              }),
            }),
            fetch('/api/reports', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                reportType:    'PWD-REPORT',
                date:          dateStr,
                workstationId,
                staffId:       'AGGREGATE',
                staffName:     readByStaff || 'SYSTEM',
                businessDayId: ejData.businessDayId ?? undefined,
                content: {
                  rowCount: pwdRows.length,
                  rows: pwdRows,
                  csv: pwdReportToCsv(pwdRows)
                }
              }),
            }),
            fetch('/api/reports', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                reportType:    'ATHLETE-REPORT',
                date:          dateStr,
                workstationId,
                staffId:       'AGGREGATE',
                staffName:     readByStaff || 'SYSTEM',
                businessDayId: ejData.businessDayId ?? undefined,
                content: {
                  rowCount: athleteRows.length,
                  rows: athleteRows,
                  csv: athleteReportToCsv(athleteRows)
                }
              }),
            }),
            fetch('/api/reports', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                reportType:    'ZERO-RATED-REPORT',
                date:          dateStr,
                workstationId,
                staffId:       'AGGREGATE',
                staffName:     readByStaff || 'SYSTEM',
                businessDayId: ejData.businessDayId ?? undefined,
                content: {
                  rowCount: zeroRatedRows.length,
                  rows: zeroRatedRows,
                  csv: zeroRatedReportToCsv(zeroRatedRows)
                }
              }),
            }),
            fetch('/api/reports/esf', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                date:            dateStr,
                businessDayId:   ejData.businessDayId ?? undefined,
                workstationId,
                transactions:    consolidatedTx,
                closedSessions:  consolidatedSessions,
                outletName:      storeData?.data?.name || storeData?.name || '',
                catMap:          menuCategoryMap.catMap,
                zCounter:        actualZCounter,
              }),
            }),
            fetch('/api/reports', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                reportType:    'DETAILED-SALES-SUMMARY',
                date:          dateStr,
                workstationId,
                staffId:       'AGGREGATE',
                staffName:     readByStaff || 'SYSTEM',
                businessDayId: ejData.businessDayId ?? undefined,
                content: {
                  rowCount: detailedRows.length,
                  rows: detailedRows,
                  csv: detailedSalesSummaryToCsv(detailedRows)
                }
              }),
            }),
            fetch('/api/reports/sales-summary', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                date:            dateStr,
                businessDayId:   ejData.businessDayId ?? undefined,
                workstationId,
                staffId:         'AGGREGATE',
                staffName:       readByStaff || 'SYSTEM',
                transactions:    consolidatedTx,
                closedSessions:  consolidatedSessions,
              }),
            })
          ]);
        }

        if (zReadingType === 'Per Terminal') {
          await fetch('/api/business-day', { 
            method: 'PATCH', 
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'completeTerminalEOD', terminalId })
          });
        }

        if (advanceBusinessDay) {
          await fetch('/api/business-day', { method: 'PATCH' });
        }

        fetch('/api/numbers?type=resetOrder', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
        }).catch(err => console.error('Order reset failed:', err));

        sileo.success({ title: 'Z-Reading Finished', description: 'End of day completed & E-Journal saved.', duration: 1000 });
        localStorage.removeItem('lastLogin');
        router.push('/logs');
      } catch (error) {
        console.error('[Z-READING INNER ERROR]', error);
        sileo.error({ title: 'Error', description: 'Failed to close business day or generate E-Journal.' });
      } finally {
        setIsGeneratingEJ(false);
      }
    } catch (err) {
      console.error('[EOD OUTER ERROR]', err);
      sileo.error({ title: 'Error', description: 'Failed to start EOD. Please try again.' });
      if (zReadingType !== 'Per Terminal') {
        await fetch('/api/business-day', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'releaseLock', terminalId }),
        }).catch(() => {});
      }
      setIsProceedingEOD(false);
    }
  };

  const stats = useMemo(() => {
    const sessionList =
      flowState === 'Z_READING'
        ? closedSessions
        : activeSession
          ? [activeSession]
          : [];
    return buildStats(transactions, sessionList, menuCategoryMap, voidLogs);
  }, [transactions, activeSession, flowState, closedSessions, menuCategoryMap, voidLogs]);

  const handleTap = (value: number) => {
    setDenominations(prev => {
      const current = prev[value] || 0;
      return { ...prev, [value]: mode === 'add' ? current + 1 : Math.max(0, current - 1) };
    });
  };

  const clearCount = () => {
    setDenominations({ 1000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 1: 0, 0.25: 0 });
  };

  const actualCount = Object.entries(denominations).reduce(
    (sum, [val, count]) => sum + parseFloat(val) * count, 0
  );

  const generateXReadingTextWrapper = (txNum: string): string => {
    return generateXReadingText(
      { ...stats, denominations, actualCashCount: actualCount, cashDrops: activeSession?.cashDrops || [] } as ReportStats,
      {
        type: isEodIntent ? 'X_SHIFT' : 'TURNOVER',
        terminalId: activeSession?.openedAtTerminal || terminalId,
        readBy: readByStaff || activeSession?.staffName || 'UNKNOWN',
        storeData,
        transactionNumber: txNum,
        session: {
          staffName: activeSession?.staffName,
          shiftNumber: activeSession?.shiftNumber,
          actualCash: actualCount,
          cashDrops: activeSession?.cashDrops || [],
          closingBreakdown: denominations,
        },
        isReprint: false,
      },
      fiscalSettings
    );
  };

  const generateEShiftTextWrapper = (oldGTValue: number, txNum: string): string => {
    return generateEShiftText(
      { ...stats, denominations, actualCashCount: actualCount, cashDrops: activeSession?.cashDrops || [] } as ReportStats,
      {
        terminalId: activeSession?.openedAtTerminal || terminalId,
        readBy: readByStaff || activeSession?.staffName || 'UNKNOWN',
        storeData,
        oldGT: oldGTValue,
        denominations,
        transactionNumber: txNum,
        session: {
          staffName: activeSession?.staffName,
          shiftNumber: activeSession?.shiftNumber,
          cashDrops: activeSession?.cashDrops || [],
        }
      },
      fiscalSettings
    );
  };

  const handleCloseShift = async () => {
    if (flowState !== 'X_READING') return;
    const dateStr = businessDayDate ?? new Date().toISOString().split('T')[0];

    try {
      await fetch('/api/cashier-session', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status:           'closed',
          sessionId:        activeSession?.sessionId,
          closedAt:         new Date().toISOString(),
          actualCash:       actualCount,
          closingBreakdown: denominations,
          stats,
          closedAtTerminal: terminalId,
        }),
      });

      const seriesType = storeData?.series_type || 'WS';
      
      // Fetch TXN No for X-Reading
      let xTxNum = '';
      try {
        const txRes = await fetch('/api/numbers?type=transaction', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ seriesType, workstationId: activeSession?.openedAtTerminal || terminalId }) });
        if (txRes.ok) { const txData = await txRes.json(); xTxNum = txData.number; }
      } catch(err) { console.error(err); }
      if (!xTxNum) xTxNum = `TXN-${Date.now()}`;

      const nestedXContent = generateReportContentPayload(
        { ...stats, denominations, actualCashCount: actualCount, cashDrops: activeSession?.cashDrops || [] } as ReportStats,
        {
          transactionNumber: xTxNum,
          cashierBankOut: {
            actualCount:   actualCount,
            changeFund:    stats.cashFund,
            denominations,
            cashDrops:     activeSession?.cashDrops || [],
          },
        }
      );
      
      const xText = generateXReadingTextWrapper(xTxNum);

      await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reportType:    'X-READING',
          date:          dateStr,
          workstationId: activeSession?.openedAtTerminal || terminalId,
          sessionId:     activeSession?.sessionId,
          staffId:       activeSession?.staffId,
          staffName:     activeSession?.staffName,
          content:       nestedXContent,
          textContent:   xText,
        }),
      });

      // Fetch TXN No for E-Shift
      let eTxNum = '';
      try {
        const txRes = await fetch('/api/numbers?type=transaction', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ seriesType, workstationId: activeSession?.openedAtTerminal || terminalId }) });
        if (txRes.ok) { const txData = await txRes.json(); eTxNum = txData.number; }
      } catch(err) { console.error(err); }
      if (!eTxNum) eTxNum = `TXN-${Date.now()}`;

      const fetchedOldGT = await fetchEShiftOldGT(activeSession?.openedAtTerminal || terminalId);
      setOldGTForReport(fetchedOldGT);
      const eShiftText = generateEShiftTextWrapper(fetchedOldGT, eTxNum);

      const nestedEContent = generateReportContentPayload(
        { ...stats, denominations, actualCashCount: actualCount, cashDrops: activeSession?.cashDrops || [] } as ReportStats,
        {
          transactionNumber: eTxNum,
          eShiftDetails: {
            shiftNumber:    activeSession?.shiftNumber || '-',
            denominations,
            actualCount,
            totalDropped:   stats.totalDropped,
            cashDrops:      activeSession?.cashDrops || [],
            cashFund:       stats.cashFund,
            accountability: { oldGT: fetchedOldGT, newGT: fetchedOldGT + stats.netSales },
          },
        }
      ); 
      

      await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reportType:    'E-SHIFT',
          date:          dateStr,
          workstationId: activeSession?.openedAtTerminal || terminalId,
          sessionId:     activeSession?.sessionId,
          staffId:       activeSession?.staffId,
          staffName:     activeSession?.staffName,
          content:       nestedEContent,
          textContent:   eShiftText,
        }),
      });

      printDirect(eShiftText, false);
      printDirect(xText, false);
      
      logEJournalEntry({
        businessDayId:  businessDayId!,
        workstationId:  activeSession?.openedAtTerminal || terminalId,
        entryType:      'X-READING',
        text:           xText,
        sessionId:      activeSession?.sessionId,
      });

      if (isEodIntent) {
        sileo.success({ title: 'Shift Closed', description: 'Returning to shifts list...', duration: 1000 });
        await loadOpenShifts();
        setFlowState('CHECK_SHIFTS');
      } else {
        sileo.success({ title: 'Shift Closed', description: 'Turnover successful. Logging out.', duration: 1000 });
        localStorage.removeItem('lastLogin');
        router.push('/');
      }

    } catch (error) {
      sileo.error({ title: 'Error', description: 'Failed to close shift.', fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
    }
  };

  const getBillColor = (val: number) => {
    switch (val) {
      case 1000: return { bg: 'rgba(59, 130, 246, 0.08)',  border: 'rgba(59, 130, 246, 0.3)',  text: '#2563eb' };
      case 500:  return { bg: 'rgba(234, 179, 8, 0.08)',   border: 'rgba(234, 179, 8, 0.3)',   text: '#ca8a04' };
      case 200:  return { bg: 'rgba(34, 197, 94, 0.08)',   border: 'rgba(34, 197, 94, 0.3)',   text: '#16a34a' };
      case 100:  return { bg: 'rgba(168, 85, 247, 0.08)',  border: 'rgba(168, 85, 247, 0.3)',  text: '#9333ea' };
      case 50:   return { bg: 'rgba(239, 68, 68, 0.08)',   border: 'rgba(239, 68, 68, 0.3)',   text: '#dc2626' };
      default:   return { bg: 'linear-gradient(135deg, #f8fafc, #e2e8f0)', border: 'rgba(148, 163, 184, 0.4)', text: '#475569' };
    }
  };

  const now       = new Date();
  const dateBadge = now.toLocaleDateString('en-US', {
    weekday: 'short', month: 'short', day: 'numeric', year: 'numeric',
  }).toUpperCase();

  const isCurrentlyCountingCash = flowState === 'X_READING';

  if (loading || isGettingBusinessDay) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/80 backdrop-blur-xl">
        <div className="flex flex-col items-center justify-center gap-4 animate-fade-in">
          <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin" />
          <p className="text-white font-bold tracking-widest uppercase text-sm">Gathering Data...</p>
        </div>
      </div>
    );
  }

  return (
    <>
    <style dangerouslySetInnerHTML={{__html: `
      @keyframes scaleIn  { from { opacity: 0; transform: scale(0.94) translateY(6px); } to { opacity: 1; transform: scale(1) translateY(0); } }
      @keyframes scaleOut { from { opacity: 1; transform: scale(1) translateY(0); }      to { opacity: 0; transform: scale(0.94) translateY(6px); } }
      @keyframes fadeIn   { from { opacity: 0; }  to { opacity: 1; } }
      @keyframes fadeOut  { from { opacity: 1; }  to { opacity: 0; } }
      .animate-scale-in  { animation: scaleIn  0.28s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
      .animate-scale-out { animation: scaleOut 0.22s cubic-bezier(0.4, 0, 1, 1)    forwards; }
      .animate-fade-in   { animation: fadeIn   0.28s ease-out forwards; }
      .animate-fade-out  { animation: fadeOut  0.22s ease-in  forwards; }
      .modal-btn { transition: background 120ms, transform 120ms, opacity 120ms; }
      .modal-btn:active { transform: scale(0.97); }
    `}} />

    
    
    {showEODConfirmPrompt && (
      <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-900/80 backdrop-blur-sm animate-fade-in">
        <div className="bg-white rounded-3xl p-8 max-w-md w-full mx-4 shadow-2xl animate-scale-in text-center">
          <div className="w-16 h-16 bg-orange-100 text-orange-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <FiAlertTriangle size={32} />
          </div>
          <h2 className="text-2xl font-black text-gray-900 mb-2 font-poppins">Confirm End of Day</h2>
          <p className="text-gray-500 mb-8 font-medium">
            {advanceBusinessDay 
              ? "Are you sure you want to perform End of Day? This action will generate the Z-Reading and close the current business day." 
              : `Are you sure you want to perform End of Day for Terminal ${terminalId}? This will generate the Z-Reading for this terminal and block new shifts on it.`}
          </p>
          <div className="flex gap-4">
            <button
              onClick={() => setShowEODConfirmPrompt(false)}
              className="flex-1 py-3 rounded-xl font-bold text-gray-700 bg-gray-100 hover:bg-gray-200 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                setShowEODConfirmPrompt(false);
                handleProceed();
              }}
              className="flex-1 py-3 rounded-xl font-bold text-white bg-[#f97316] hover:bg-[#ea580c] transition-colors"
            >
              Yes, Perform EOD
            </button>
          </div>
        </div>
      </div>
    )}

    {pinGateState === 'pending' && (
      <PinModal
        title="Verify Your PIN"
        subtitle="Enter manager PIN to authorize this turnover action."
        accentColor="#f97316"
        stripColor="linear-gradient(90deg, #f97316 0%, #fb923c 60%, #fdba74 100%)"
        isExiting={pinModalExiting}
        onConfirm={handlePinGateConfirm}
        onClose={() => {
          setPinModalExiting(true);
          setTimeout(() => {
            setPinModalExiting(false);
            router.push('/dashboard');
          }, 260);
        }}
      />
    )}

    {pinGateState === 'verified' && (
      <>
        {tillStatus === 'OPEN' && !isCurrentlyCountingCash && <DrawerOpenWarningModal />}

        <div
          className="fixed inset-0 flex items-center justify-center z-[100] animate-fade-in"
          style={{ background: 'rgba(15, 23, 42, 0.75)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)' }}
        >
          <div className="absolute top-6 right-6 z-[200]">
            <div className="flex items-center gap-2 px-4 py-2 rounded-full border bg-white shadow-md">
              {tillStatus === 'OPEN'   ? <Unlock    size={16} className="text-red-500"   /> :
              tillStatus === 'CLOSED' ? <Lock       size={16} className="text-green-500" /> :
                                        <HelpCircle size={16} className="text-gray-400" />}
              <span className="text-sm font-bold font-poppins text-gray-700">Till: {tillStatus}</span>
            </div>
          </div>

          {flowState === 'CHECK_SHIFTS' && (
            <div className="rounded-3xl w-full max-w-3xl mx-4 relative overflow-hidden flex flex-col shadow-2xl animate-scale-in bg-white h-[75vh]">
              <div className="p-12 flex flex-col items-center text-center bg-gray-50 flex-1 overflow-y-auto">
                {!businessDayDate && (
                  <div className="w-full max-w-xl mb-6 flex items-start gap-3 px-4 py-3 rounded-2xl border border-red-200 bg-red-50 text-left shrink-0">
                    <AlertCircle size={18} className="text-red-500 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-sm font-bold text-red-700">No Active Business Day</p>
                      <p className="text-xs text-red-500 mt-0.5 leading-relaxed">
                        There is no open business day on record.
                      </p>
                    </div>
                  </div>
                )}

                {completedTerminals.includes(terminalId) ? (
                  <div className="flex flex-col items-center justify-center h-full">
                    <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6 shadow-inner">
                      <FiCheckCircle size={48} />
                    </div>
                    <h2 className="text-3xl font-black text-gray-900 mb-3 font-poppins">Terminal EOD Completed</h2>
                    <p className="text-gray-500 max-w-md font-medium mb-4 leading-relaxed">
                      This terminal has already completed its End of Day. Waiting for the business day to be advanced.
                    </p>
                  </div>
                ) : (() => {
                  const relevantOpenSessions = zReadingType === 'Per Terminal'
                    ? allOpenSessions.filter(s => s.openedAtTerminal === terminalId)
                    : allOpenSessions;
                  
                  return relevantOpenSessions.length > 0 ? (
                  <>
                    <div className="w-24 h-24 bg-orange-100 text-orange-500 rounded-full flex items-center justify-center mb-6 shadow-inner shrink-0">
                      <FiAlertTriangle size={48} />
                    </div>
                    <h2 className="text-3xl font-black text-gray-900 mb-3 font-poppins shrink-0">Open Shifts Detected</h2>
                    <p className="text-gray-500 max-w-md font-medium mb-8 leading-relaxed shrink-0">
                      There are {allOpenSessions.length} register(s) currently open across all terminals. All shifts must be closed before End of Day.
                    </p>
                    <div className="w-full max-w-xl flex flex-col gap-3">
                      {relevantOpenSessions.map(session => {
                        const isMyShift = String(session.staffId) === currentStaffId;
                        const isManager = currentUserRole === 2;
                        const canClose  = isMyShift || isManager;

                        return (
                          <div
                            key={session.sessionId}
                            className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm flex justify-between items-center text-left hover:border-orange-300 transition-colors"
                          >
                            <div>
                              <p className="font-bold text-gray-900 text-lg">{session.staffName}</p>
                              <p className="text-xs text-gray-500 font-medium mt-1">
                                Shift {session.shiftNumber} • Opened at{' '}
                                {new Date(session.openedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                {session.openedAtTerminal && (
                                  <span className="ml-2 px-1.5 py-0.5 bg-blue-50 text-blue-600 rounded text-[10px] font-bold">
                                    Terminal {session.openedAtTerminal}
                                  </span>
                                )}
                              </p>
                            </div>
                            <button
                              disabled={!canClose}
                              onClick={() => startTurnoverForSession(session)}
                              className={`px-5 py-2.5 font-bold text-sm rounded-xl transition-colors ${
                                canClose
                                  ? isManager && !isMyShift
                                    ? 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                                    : 'bg-orange-100 text-orange-700 hover:bg-orange-200'
                                  : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                              }`}
                            >
                              {canClose
                                ? isManager && !isMyShift ? 'Close (Manager)' : 'Close Shift'
                                : 'Not Your Shift'}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full">
                    <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6 shadow-inner">
                      <FiCheckCircle size={48} />
                    </div>
                    <h2 className="text-3xl font-black text-gray-900 mb-3 font-poppins">All Shifts Closed</h2>
                    <p className="text-gray-500 max-w-md font-medium mb-4 leading-relaxed">
                      {zReadingType === 'Per Terminal' 
                        ? 'Your terminal is closed. Proceeding will print your Y and Z Readings and mark this terminal as completed.' 
                        : 'All terminals are closed. Proceeding will print Y-Readings for each terminal, then the final Z-Reading.'}
                    </p>
                  </div>
                );})()}
              </div>

              {isLockedOut && (
                <div className="px-6 py-3 bg-amber-50 border-t border-amber-200 flex items-center gap-2 text-sm text-amber-800 font-medium">
                  <FiAlertTriangle className="text-amber-500 shrink-0" size={16} />
                  End of Day is being processed by Terminal {eodLockStatus.lockedBy}. Please wait…
                </div>
              )}

              <div className="px-8 py-6 border-t border-gray-100 flex justify-end gap-3 bg-white shrink-0">
                <button
                  onClick={() => router.push('/dashboard')}
                  className="px-6 py-3 rounded-xl font-bold text-gray-700 transition-all bg-white border border-gray-300 hover:bg-gray-50 shadow-sm"
                >
                  Cancel
                </button>

                <button
                  disabled={
                    completedTerminals.includes(terminalId) ||
                    (zReadingType === 'Per Terminal' ? allOpenSessions.filter(s => s.openedAtTerminal === terminalId).length > 0 : allOpenSessions.length > 0) ||
                    loading ||
                    isProceedingEOD ||
                    isLockedOut
                  }
                  onClick={() => {
                    const otherOpenShifts = allOpenSessions.filter(s => s.openedAtTerminal !== terminalId);
                    
                    const willAdvance = zReadingType !== 'Per Terminal' || 
                      (completedTerminals.length + 1 >= activeTerminalsToday.length && otherOpenShifts.length === 0);
                    
                    setAdvanceBusinessDay(willAdvance);
                    setShowEODConfirmPrompt(true);
                  }}
                  className={`px-6 py-3 rounded-xl font-bold text-white transition-all flex items-center gap-3 shadow-md ${
                    completedTerminals.includes(terminalId) ||
                    (zReadingType === 'Per Terminal' ? allOpenSessions.filter(s => s.openedAtTerminal === terminalId).length > 0 : allOpenSessions.length > 0) ||
                    loading ||
                    isProceedingEOD ||
                    isLockedOut
                      ? 'bg-gray-300 cursor-not-allowed'
                      : 'bg-[#f97316] hover:bg-[#ea580c]'
                  }`}
                >
                  {isProceedingEOD ? (
                    <>
                      <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                      Starting EOD…
                    </>
                  ) : loading ? (
                    'Loading…'
                  ) : (
                    'Proceed to End of Day →'
                  )}
                </button>
              </div>
            </div>
          )}

          {flowState === 'X_READING' && (
            <div
              className="rounded-3xl w-full max-w-5xl mx-4 relative overflow-hidden flex flex-col shadow-2xl animate-scale-in"
              style={{ background: '#ffffff', height: '85vh' }}
            >
              <div className={`px-8 py-6 flex items-center justify-between border-b flex-shrink-0 ${isEodIntent ? 'border-gray-100 bg-white' : 'border-orange-100 bg-orange-50'}`}>
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <h2 className={`text-3xl font-black font-poppins ${isEodIntent ? 'text-gray-900' : 'text-orange-900'}`}>
                      {isEodIntent ? 'Close Cashier Shift' : 'Cashier Turnover'}
                    </h2>
                    <span className={`px-3 py-1 rounded-md text-xs font-bold tracking-wider ${isEodIntent ? 'bg-orange-100 text-orange-600' : 'bg-orange-200 text-orange-700'}`}>
                      {dateBadge}
                    </span>
                  </div>
                  {activeSession && (
                    <div className={`flex items-center gap-2 mt-2 text-sm font-bold ${isEodIntent ? 'text-gray-600' : 'text-orange-800'}`}>
                      <span className="px-2 py-1 bg-gray-100 rounded-md border border-black/5">Shift {activeSession.shiftNumber || '-'}</span>
                      <span>•</span>
                      <span>{activeSession.staffName}</span>
                      <span>•</span>
                      <span className="font-medium">Opened {new Date(activeSession.openedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      <span>•</span>
                      <span className="px-2 py-1 bg-blue-50 text-blue-600 rounded-md border border-blue-100 text-xs">Terminal {terminalId}</span>
                    </div>
                  )}
                </div>
                <button
                  onClick={() => isEodIntent ? loadOpenShifts().then(() => setFlowState('CHECK_SHIFTS')) : router.push('/dashboard')}
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-colors ${isEodIntent ? 'bg-gray-100 hover:bg-gray-200 text-gray-600' : 'bg-orange-100 hover:bg-orange-200 text-orange-600'}`}
                >
                  <FiX size={22} />
                </button>
              </div>

              <div className="flex flex-1 p-8 bg-gray-50 overflow-y-auto justify-center">
                <div className="w-full max-w-3xl flex flex-col">
                  <div className="flex items-center justify-between mb-8">
                    <div>
                      <h3 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'Poppins' }}>Tap to Count</h3>
                      <p className="text-xs text-gray-500 font-medium mt-1">Select mode and tap bills/coins to adjust quantity.</p>
                    </div>
                    <div className="flex bg-gray-200 p-1 rounded-xl">
                      <button onClick={() => setMode('add')} className="px-6 py-2 rounded-lg text-sm font-bold transition-all shadow-sm" style={{ background: mode === 'add' ? '#ffffff' : 'transparent', color: mode === 'add' ? '#1a1a1a' : '#64748b' }}>+ Add</button>
                      <button onClick={() => setMode('subtract')} className="px-6 py-2 rounded-lg text-sm font-bold transition-all" style={{ background: mode === 'subtract' ? '#ffffff' : 'transparent', color: mode === 'subtract' ? '#1a1a1a' : '#64748b' }}>− Subtract</button>
                    </div>
                  </div>

                  <h4 className="text-[10px] font-bold text-gray-400 tracking-widest uppercase mb-3">Paper Bills</h4>
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-4 mb-8">
                    {[1000, 500, 200, 100, 50].map(val => {
                      const colors = getBillColor(val);
                      const count  = denominations[val] || 0;
                      return (
                        <button
                          key={val}
                          onClick={() => handleTap(val)}
                          className="relative h-20 rounded-2xl flex items-center justify-center font-black text-xl transition-transform active:scale-95 bg-white shadow-sm hover:shadow-md"
                          style={{ border: `2px solid ${colors.border}`, color: colors.text }}
                        >
                          {val}
                          {count > 0 && (
                            <span className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-gray-900 text-white text-xs flex items-center justify-center border-2 border-white shadow-sm">
                              {count}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <h4 className="text-[10px] font-bold text-gray-400 tracking-widest uppercase mb-3">Coins</h4>
                  <div className="flex flex-wrap gap-4 mb-8">
                    {[20, 10, 5, 1, 0.25].map(val => {
                      const colors = getBillColor(val);
                      const count  = denominations[val] || 0;
                      return (
                        <button
                          key={val}
                          onClick={() => handleTap(val)}
                          className="relative w-16 h-16 rounded-full flex items-center justify-center font-bold text-sm transition-transform active:scale-95 bg-white shadow-sm hover:shadow-md"
                          style={{ border: `2px solid ${colors.border}`, color: colors.text }}
                        >
                          {val}
                          {count > 0 && (
                            <span className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-gray-900 text-white text-[10px] flex items-center justify-center border-2 border-white">
                              {count}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <div className="mt-auto pt-6 border-t border-gray-200 flex flex-col gap-4">
                    <div className="p-6 flex justify-between items-center bg-orange-50 border-2 border-orange-100 rounded-2xl">
                      <span className="text-sm font-bold tracking-widest uppercase text-orange-600">Total Count</span>
                      <span className="text-3xl font-black text-orange-600">{formatMoney(actualCount)}</span>
                    </div>
                    <button onClick={clearCount} className="w-full py-4 rounded-xl bg-gray-200 text-gray-600 font-bold text-sm transition-colors hover:bg-gray-300">
                      Clear Count
                    </button>
                  </div>
                </div>
              </div>

              <div className="px-8 py-5 border-t border-gray-100 flex justify-end gap-4 flex-shrink-0">
                <button
                  onClick={() => isEodIntent ? loadOpenShifts().then(() => setFlowState('CHECK_SHIFTS')) : router.push('/dashboard')}
                  className="px-8 py-3 rounded-xl font-bold text-gray-700 transition-all bg-white border border-gray-300 hover:bg-gray-50 shadow-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCloseShift}
                  className={`px-8 py-3 rounded-xl font-bold text-white transition-all flex items-center gap-3 shadow-md ${isEodIntent ? 'bg-[#111827] hover:bg-gray-800' : 'bg-orange-600 hover:bg-orange-700'}`}
                >
                  <FiPrinter /> Close Shift →
                </button>
              </div>
            </div>
          )}
        </div>

        {isGeneratingEJ && (
          <div className="fixed inset-0 z-[500] bg-slate-900/80 backdrop-blur-md flex flex-col items-center justify-center">
            <div className="bg-white p-12 rounded-[50px] shadow-2xl flex flex-col items-center text-center max-w-md animate-scale-in">
              <div className="w-24 h-24 border-8 border-[#f97316] border-t-transparent rounded-full animate-spin mb-8"></div>
              <h3 className="text-3xl font-black text-gray-900 mb-3 font-poppins tracking-tighter">Finalizing Day</h3>
              <p className="text-gray-500 font-medium leading-relaxed font-poppins">
                Please do not turn off the machine. We are calculating daily totals and writing the Electronic Journal to your local storage.
              </p>
            </div>
          </div>
        )}
      </>
    )}
    </>
  );
}

export default function EODPage() {
  return (
    <Suspense fallback={
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/80 backdrop-blur-xl">
        <div className="flex flex-col items-center justify-center gap-4 animate-fade-in">
          <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin" />
          <p className="text-white font-bold tracking-widest uppercase text-sm">Gathering Data...</p>
        </div>
      </div>
    }>
      <EODContent />
    </Suspense>
  );
}