export default function Loading() {
  return (
    <div className="flex flex-1 items-center justify-center" style={{ background: "#F0EFEF" }}>
      <div className="w-8 h-8 rounded-full border-4 border-orange-200 border-t-orange-500 animate-spin" />
    </div>
  );
}