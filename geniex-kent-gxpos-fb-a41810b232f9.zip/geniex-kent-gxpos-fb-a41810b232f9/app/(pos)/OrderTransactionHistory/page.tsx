'use client';
import { useState, useMemo, useEffect } from "react";
import { useRouter } from "next/navigation";
import { FiCreditCard, FiSmartphone, FiGrid, FiList, FiRotateCcw, FiPrinter, FiXCircle, FiFileText, FiCopy, FiAlertTriangle } from 'react-icons/fi';
import { getCachedVoidReasons } from '../../../src/api/void-reason';
import { getCachedRefundReasons } from '../../../src/api/refund-reasons';
import { getAssociateByPin } from '../../../src/api/associates';
import { sileo } from "sileo";

import { getMenuFromCache } from '../../../src/api/menu';
import { saveCartToDatabase } from '../../../src/api/cart';
import { usePrinter } from '../../context/PrinterContext';
import { useSyncContext } from "@/app/context/SyncContext";
import { getWorkstationId } from "@/src/lib/workstation";
import { getNextTransactionNumber } from "@/src/api/transactionNumbers";
import { logEJournalEntry } from "@/src/lib/ejournal-client";

const glass = {
  card: {
    background: "rgba(255, 255, 255, 0.25)",
    backdropFilter: "blur(14px)",
    WebkitBackdropFilter: "blur(14px)",
    border: "1px solid rgba(255, 255, 255, 0.45)",
    boxShadow: "0 4px 20px rgba(0,0,0,0.10), inset 0 1px 0 rgba(255,255,255,0.6)",
  } as React.CSSProperties,

  modal: {
    background: "rgba(255, 255, 255, 0.85)",
    backdropFilter: "blur(32px)",
    WebkitBackdropFilter: "blur(32px)",
    border: "1.5px solid rgba(255, 255, 255, 0.95)",
    boxShadow: "0 32px 80px rgba(0,0,0,0.16), inset 0 1px 0 rgba(255,255,255,1), inset 0 -1px 0 rgba(0,0,0,0.03)",
  } as React.CSSProperties,
};

type Order = {
  _id?: string;
  dbId?: string;
  id: string;
  salesNumber: string; 
  items: number;
  total: number;
  date: string;
  dateISO: string;
  paymentMethod: string | string[];
  cardLast4: string | null;
  status: string;
  platform?: string;
  kioskNo?: string;
  businessDayId?: string | null;
};

function ManagerPinModal({
  subtitle,
  onConfirm,
  onClose,
}: {
  subtitle: string;
  onConfirm: (pin: string) => void;
  onClose: () => void;
}) {
  const [pin, setPin] = useState("");

  return (
    <div
      className="fixed inset-0 flex items-center justify-center z-[300] animate-fade-in"
      style={{ background: "rgba(15,23,42,0.82)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)" }}
      onClick={onClose}
    >
      <div
        className="rounded-3xl w-full max-w-sm mx-4 relative overflow-hidden animate-slide-up shadow-2xl"
        style={{ background: "#ffffff", animationDelay: "0.03s", opacity: 0, animationFillMode: "forwards" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ height: 6, background: "linear-gradient(90deg, #ef4444 0%, #f87171 60%, #fca5a5 100%)" }} />
        <div className="p-7">
          <button
            onClick={onClose}
            className="absolute top-7 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-base transition-all hover:bg-black/5"
            style={{ background: "rgba(0,0,0,0.05)", color: "#bbb", border: "1px solid rgba(0,0,0,0.07)" }}
          >
            ✕
          </button>

          <div className="flex items-center gap-3 mb-4">
            <div
              className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(239,68,68,0.10)", border: "1.5px solid rgba(239,68,68,0.18)" }}
            >
              <span style={{ fontSize: 22 }}>🔐</span>
            </div>
            <div>
              <p style={{ fontFamily: "Poppins", fontSize: 10, color: "#ccc", fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 2 }}>
                Manager Verification
              </p>
              <h2 style={{ fontFamily: "Poppins", fontSize: 18, fontWeight: 900, color: "#1a1a1a", lineHeight: 1 }}>
                Enter Manager <span style={{ color: "#f97316" }}>PIN</span>
              </h2>
            </div>
          </div>

          <p style={{ fontFamily: "Poppins", fontSize: 13, color: "#666", marginBottom: 12, textAlign: "center" }}>{subtitle}</p>

          <div
            className="text-2xl font-bold tracking-widest text-center rounded-xl px-6 py-4 mb-5"
            style={{
              fontFamily: "Poppins",
              background: "rgba(239,68,68,0.05)",
              border: "1.5px solid rgba(239,68,68,0.15)",
              color: "#ef4444",
              minHeight: 72,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            {pin.length > 0
              ? "•".repeat(pin.length)
              : <span style={{ color: "#ddd", fontSize: 14, fontWeight: 500 }}>Enter 4-digit PIN</span>}
          </div>

          <div className="flex gap-4 items-start">
            <div className="grid grid-cols-3 gap-2.5 flex-1">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                <button
                  key={num}
                  onClick={() => { if (pin.length < 4) setPin((p) => p + String(num)); }}
                  className="h-14 rounded-xl text-xl font-bold transition-all hover:bg-gray-100 active:scale-95"
                  style={{ background: "rgba(0,0,0,0.04)", fontFamily: "Poppins", color: "#1a1a1a", border: "1px solid rgba(0,0,0,0.07)" }}
                >
                  {num}
                </button>
              ))}
              <button
                onClick={() => { if (pin.length < 4) setPin((p) => p + "0"); }}
                className="col-span-2 h-14 rounded-xl text-xl font-bold transition-all hover:bg-gray-100 active:scale-95"
                style={{ background: "rgba(0,0,0,0.04)", fontFamily: "Poppins", color: "#1a1a1a", border: "1px solid rgba(0,0,0,0.07)" }}
              >
                0
              </button>
              <button
                onClick={() => setPin((p) => p.slice(0, -1))}
                className="h-14 rounded-xl text-xl font-bold transition-all hover:bg-red-50 active:scale-95"
                style={{ background: "rgba(239,68,68,0.06)", color: "#ef4444", fontFamily: "Poppins", border: "1px solid rgba(239,68,68,0.15)" }}
              >
                ⌫
              </button>
            </div>
            <div className="flex flex-col gap-2.5">
              <button
                onClick={() => onConfirm(pin)}
                className="w-16 rounded-xl font-bold transition-all hover:brightness-110 active:scale-95 flex items-center justify-center"
                style={{ height: 122, background: "#4ade80", border: "1px solid rgba(255,255,255,0.5)", color: "#fff", fontSize: 32 }}
              >
                ✓
              </button>
              <button
                onClick={onClose}
                className="w-16 h-12 rounded-xl text-sm font-bold transition-all hover:bg-gray-100"
                style={{ background: "rgba(0,0,0,0.04)", color: "#666", fontFamily: "Poppins", border: "1px solid rgba(0,0,0,0.07)" }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function PaymentBadge({ method, large = false }: { method: string | string[]; large?: boolean }) {
  if (Array.isArray(method)) {
    return (
      <div className="flex flex-wrap gap-1">
        {method.map((m, idx) => <PaymentBadge key={idx} method={m} large={large} />)}
      </div>
    );
  }

  const getPaymentIcon = (m: string) => {
    const up = String(m).toUpperCase();
    if (['VISA', 'MASTERCARD', 'AMEX', 'CARD'].includes(up)) return <FiCreditCard size={14} />;
    if (['APPLE PAY', 'MAYA', 'GCASH', 'EWALLET'].includes(up)) return <FiSmartphone size={14} />;
    return null;
  };

  const map: Record<string, { color: string; bg: string; border: string }> = {
    VISA:        { color: "#1a1aff", bg: "rgba(26,26,255,0.07)",  border: "rgba(26,26,255,0.18)"  },
    MASTERCARD:  { color: "#c0000d", bg: "rgba(235,0,27,0.07)",  border: "rgba(235,0,27,0.18)"   },
    AMEX:        { color: "#007bc1", bg: "rgba(0,123,193,0.07)",  border: "rgba(0,123,193,0.18)"  },
    "APPLE PAY": { color: "#1a1a1a", bg: "rgba(0,0,0,0.05)",      border: "rgba(0,0,0,0.12)"      },
    CASH:        { color: "#16a34a", bg: "rgba(22,163,74,0.08)",  border: "rgba(22,163,74,0.22)"  },
    CARD:        { color: "#1a1aff", bg: "rgba(26,26,255,0.07)",  border: "rgba(26,26,255,0.18)"  },
    MAYA:        { color: "#16a34a", bg: "rgba(22,163,74,0.08)",  border: "rgba(22,163,74,0.22)"  },
    GCASH:       { color: "#2563eb", bg: "rgba(37,99,235,0.08)",  border: "rgba(37,99,235,0.22)"  },
  };

  const normalized = String(method).toUpperCase();
  const s = map[normalized] ?? { color: "#555", bg: "rgba(0,0,0,0.05)", border: "rgba(0,0,0,0.12)" };

  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full font-bold"
      style={{
        background: s.bg,
        color: s.color,
        border: `1px solid ${s.border}`,
        padding: large ? "6px 14px" : "3px 10px",
        fontSize: large ? 13 : 11,
      }}
    >
      {getPaymentIcon(method) && <span>{getPaymentIcon(method)}</span>} {normalized}
    </span>
  );
}

function OrderCard({ order, onClick, index, isClosed }: { order: Order; onClick: () => void; index: number; isClosed?: boolean }) {
  const [hovered, setHovered] = useState(false);

  const getPlatformBadgeColor = (platform?: string) => {
    const p = String(platform || 'POS').toLowerCase();
    switch (p) {
      case 'grab':   return { bg: 'rgba(34,197,94,0.15)',   color: '#22c55e', border: 'rgba(34,197,94,0.35)'   };
      case 'mobile': return { bg: 'rgba(6,182,212,0.15)',   color: '#06b6d4', border: 'rgba(6,182,212,0.35)'   };
      case 'sok':    return { bg: 'rgba(249,115,22,0.15)',   color: '#f97316', border: 'rgba(249,115,22,0.35)'  };
      case 'pos':    return { bg: 'rgba(168,85,247,0.15)',   color: '#a855f7', border: 'rgba(168,85,247,0.35)'  };
      default:       return { bg: 'rgba(107,114,128,0.15)', color: '#6b7280', border: 'rgba(107,114,128,0.35)' };
    }
  };

  const platformColor = getPlatformBadgeColor(order.platform);

  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="flex flex-col rounded-2xl p-5 text-left w-full focus:outline-none relative animate-slide-up"
      style={{
        animationDelay: `${index * 0.04}s`,
        opacity: 0,
        animationFillMode: "forwards",
        fontFamily: "Poppins",
        textTransform: "uppercase",
        ...glass.card,
        transition: "all 0.2s ease",
        ...(hovered ? {
          background: "rgba(255,255,255,0.42)",
          border: "1px solid rgba(249,115,22,0.50)",
          boxShadow: "0 8px 28px rgba(249,115,22,0.16), inset 0 1px 0 rgba(255,255,255,0.8)",
          transform: "translateY(-3px)",
        } : {}),
      }}
    >
      {isClosed && (
        <div style={{
          position: 'absolute', top: 8, left: 8, padding: '4px 10px', borderRadius: '12px',
          fontSize: 9, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5,
          background: 'rgba(107,114,128,0.15)', color: '#4b5563', border: '1px solid rgba(107,114,128,0.35)'
        }}>
          Closed
        </div>
      )}
      
      {order.platform && (
        <div style={{
          position: 'absolute', top: 8, right: 8, padding: '4px 10px', borderRadius: '12px',
          fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5,
          background: platformColor.bg, color: platformColor.color, border: `1px solid ${platformColor.border}`,
        }}>
          {order.platform}
        </div>
      )}
      {order.status === 'Refunded' && (
        <div style={{
          position: 'absolute', top: 8, right: 60, padding: '4px 10px', borderRadius: '12px',
          fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5,
          background: 'rgba(239, 68, 68, 0.15)',
          color: '#ef4444',
          border: '1px solid rgba(239, 68, 68, 0.35)',
        }}>
          {order.status}
        </div>
      )}
      <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 17, fontWeight: 900, color: "#1a1a1a", letterSpacing: 0.5, marginBottom: 4, textAlign: "center" }}>
        Ord# {order.id}
      </p>
      <p style={{ fontFamily: "Poppins", fontSize: 9, fontWeight: 700, color: "#aaa", letterSpacing: 0.8, textAlign: "center", textTransform: "uppercase", marginBottom: 2 }}>
        SI# {order.salesNumber}
      </p>
      <p style={{ color: '#a855f7', fontFamily: "Poppins", fontSize: 9, fontWeight: 700, letterSpacing: 0.8, textAlign: "center", textTransform: "uppercase", marginBottom: 10 }}>
        T{order.kioskNo ?? '???'}
      </p>
      <p style={{ fontSize: 13, color: "#f97316", fontWeight: 900, marginBottom: 10, textAlign: "center" }}>
        {order.total.toFixed(2)}
      </p>
      <p style={{ fontSize: 12, color: "#777", marginBottom: 12, textAlign: "center" }}>{order.date}</p>
      <p style={{ fontSize: 13, color: "#1a1a1a", fontWeight: 700, textAlign: "center" }}>
        {order.items} Item{order.items !== 1 ? "s" : ""}
      </p>
    </button>
  );
}

const ReasonInput = ({
  reasonsList,
  selectedReason,
  onSelectReason,
  additionalRemarks,
  onChangeAdditional,
  accentColor = "#4b5563",
}: {
  reasonsList: any[];
  selectedReason: string;
  onSelectReason: (v: string) => void;
  additionalRemarks: string;
  onChangeAdditional: (v: string) => void;
  accentColor?: string;
}) => (
  <div className="mb-6">
    <label style={{ fontFamily: "Poppins", fontSize: 10, color: "#ccc", fontWeight: 700, letterSpacing: 1.1, textTransform: "uppercase", marginBottom: 8, display: "block" }}>
      Reason
    </label>
    <select
      className="w-full rounded-xl p-3 text-sm outline-none border border-gray-200 mb-3 transition-colors"
      style={{ fontFamily: "Poppins", background: "rgba(255,255,255,0.70)", color: "#1a1a1a" }}
      value={selectedReason}
      onChange={(e) => onSelectReason(e.target.value)}
    >
      <option value="" disabled>— Select a reason —</option>
      {reasonsList.map((r, i) => {
        const val = r.reason || r.name || (typeof r === 'string' ? r : String(r));
        return <option key={i} value={val}>{val}</option>;
      })}
    </select>

    {selectedReason && (
      <div
        className="flex items-center gap-2 rounded-xl px-4 py-2.5 mb-3"
        style={{ background: `${accentColor}12`, border: `1.5px solid ${accentColor}30` }}
      >
        <span style={{ fontSize: 14 }}>📌</span>
        <span style={{ fontFamily: "Poppins", fontSize: 12, fontWeight: 700, color: accentColor, flex: 1 }}>
          {selectedReason}
        </span>
        <button
          onClick={() => onSelectReason("")}
          style={{ color: "#bbb", fontSize: 16, lineHeight: 1 }}
          className="hover:text-gray-600 transition-colors"
        >
          ×
        </button>
      </div>
    )}

    <label style={{ fontFamily: "Poppins", fontSize: 10, color: "#ccc", fontWeight: 700, letterSpacing: 1.1, textTransform: "uppercase", marginBottom: 8, display: "block" }}>
      Additional Details (Optional)
    </label>
    <textarea
      value={additionalRemarks}
      onChange={(e) => onChangeAdditional(e.target.value)}
      placeholder="Enter additional details..."
      className="w-full rounded-xl p-3 text-sm outline-none resize-none"
      rows={3}
      style={{ fontFamily: "Poppins", background: "rgba(255,255,255,0.60)", border: "1px solid rgba(0,0,0,0.08)", color: "#1a1a1a" }}
    />
  </div>
);

const getInventoryId = (modOrItem: any) => {
  if (!modOrItem) return "";
  if (modOrItem.gx_item_code) {
    return `IT-${modOrItem.gx_item_code}`;
  }
  if (modOrItem.itemCode) {
    return `IT-${modOrItem.itemCode}`;
  }
  if (modOrItem.id && String(modOrItem.id).startsWith('MD-0|')) {
    return `IT-${modOrItem.id.split('|')[1]}`;
  }
  if (modOrItem.id && String(modOrItem.id).startsWith('AD-0|')) {
    return `IT-${modOrItem.id.split('|')[1]}`;
  }
  return modOrItem.stockId || modOrItem.id;
};

async function fetchSeriesNumber(type: 'voidSeries' | 'refundSeries'): Promise<string> {
  try {
    const storeData = JSON.parse(localStorage.getItem('store_data') || '{}');
    const seriesType = storeData?.series_type || 'WS';
    const wsId = localStorage.getItem('workstationId') || '001';

    const res = await fetch(`/api/numbers?type=${type}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ workstationId: wsId, seriesType }),
    });

    if (!res.ok) throw new Error('Counter fetch failed');
    const data = await res.json();
    return data.voidNumber || data.refundNumber || '-';
  } catch (err) {
    console.warn(`[fetchSeriesNumber] ${type} error:`, err);
    return '-';
  }
}

function OrderDetailModal({
  order,
  onClose,
  transactionData,
  onRefundProcessed,
  onVoidProcessed,
  currentShiftOpenedAt,
  currentBusinessDayId,
  onRecall,
  setSelectedOrder,
}: {
  order: Order;
  onClose: () => void;
  transactionData?: any;
  onRefundProcessed?: (salesNumber: string) => void;
  onVoidProcessed?: (salesNumber: string) => void;
  currentShiftOpenedAt?: string;
  currentBusinessDayId?: string;
  onRecall?: () => void;
  setSelectedOrder: (order: Order | null) => void;
}) {
  const { syncNow } = useSyncContext(); 
  const { printDirect, openDrawer } = usePrinter();
  const txType = transactionData?.transactionType || 'REGULAR';
  const [successAction, setSuccessAction] = useState<string | null>(null);

  const [showVoidModal, setShowVoidModal]                     = useState(false);
  const [voidReasonsList, setVoidReasonsList]                 = useState<any[]>([]);
  const [voidSelectedReason, setVoidSelectedReason]           = useState("");
  const [voidAdditionalRemarks, setVoidAdditionalRemarks]     = useState("");

  const [showRefundModal, setShowRefundModal]                     = useState(false);
  const [refundReasonsList, setRefundReasonsList]                 = useState<any[]>([]);
  const [refundSelectedReason, setRefundSelectedReason]           = useState("");
  const [refundAdditionalRemarks, setRefundAdditionalRemarks]     = useState("");

  const [showManagerPin, setShowManagerPin] = useState(false);
  const [pendingAction, setPendingAction]   = useState<'void' | 'refund' | null>(null);
  const [pinError, setPinError]             = useState("");
  const [timeLimitState, setTimeLimitState] = useState({ isWithinLimit: true, hours: 24 });
  const [fiscal, setFiscal] = useState<any>(null)

  
  useEffect(() => {
    getCachedVoidReasons().then((reasons) => {
      if (reasons) setVoidReasonsList(reasons);
    });
  }, []);
  useEffect(() => {
    getCachedRefundReasons().then((reasons) => {
      if (reasons) setRefundReasonsList(reasons);
    });
  }, []);

  useEffect(() => {
    const WORKSTATION_ID = getWorkstationId() || '001';
    fetch(`/api/settings?workstationId=${WORKSTATION_ID}`)
      .then(r => r.json())
      .then(data => setFiscal(data))
      .catch(console.warn);
  }, []);

  const isInCurrentShift = useMemo(() => {
    if (!currentShiftOpenedAt) return true;
    try {
      return new Date(order.dateISO).getTime() >= new Date(currentShiftOpenedAt).getTime();
    } catch { return false; }
  }, [order.dateISO, currentShiftOpenedAt]);

  useEffect(() => {
    const calculateTimeLimit = async () => {
      let allowableHours = 24;
      try {
        let allowable = JSON.parse(localStorage.getItem("allowable_void_refund_hours") || "{}");
        if (allowable.allowable_void_refund_hours === undefined) {
          const WORKSTATION_ID = getWorkstationId() || '001';
          const res = await fetch(`/api/settings?workstationId=${WORKSTATION_ID}`)
          if (res.ok) {
            const data = await res.json();
            allowableHours = Number(data.allowable_void_refund_hours) || 24;
            allowable = { ...allowable, allowable_void_refund_hours: allowableHours };
            localStorage.setItem("allowable_void_refund_hours", JSON.stringify(allowable));
          }
        } else {
          allowableHours = Number(allowable.allowable_void_refund_hours);
        }
      } catch (error) {
        console.warn("Error determining allowable hours:", error);
      }
      const orderTime = new Date(order.dateISO).getTime();
      const now = new Date().getTime();
      const diffHours = (now - orderTime) / (1000 * 60 * 60);
      setTimeLimitState({ isWithinLimit: diffHours <= allowableHours, hours: allowableHours });
    };
    calculateTimeLimit();
  }, [order.dateISO]);

  // Check terminal identity
  const currentTerminalId = getWorkstationId() || 'Unknown';
  const txTerminal = transactionData?.KioskNo || 'Unknown';
  const isSameTerminal = String(txTerminal) === String(currentTerminalId);
  if(txTerminal === 'Unknown') {
    console.log("Transaction terminal unknown, allowing action but showing warning");
  }
  const isInCurrentBusinessDay = !currentBusinessDayId
    || order.businessDayId === currentBusinessDayId;

  const canActionOrder = isInCurrentShift 
    && timeLimitState.isWithinLimit 
    && isSameTerminal 
    && isInCurrentBusinessDay;

  let disabledTitle = undefined;
  if (!isInCurrentBusinessDay) {
    disabledTitle = `This transaction belongs to a previous business day and cannot be modified`;
  } else if (!isSameTerminal) {
    disabledTitle = `Cannot modify transactions created on another terminal (T${txTerminal})`;
  } else if (!isInCurrentShift) {
    disabledTitle = "Only transactions from the current open shift can be voided or refunded";
  } else if (!timeLimitState.isWithinLimit) {
    disabledTitle = `Cannot modify transactions older than ${timeLimitState.hours} hour(s)`;
  }

  const printTransactionAs = async (type: 'VOID' | 'REFUND', seriesNo?: string) => {
    try {
      const { buildReceiptText, normalizeTransactionForReceipt } = 
        await import("../../../src/libs/ReceiptPrinting");

      let storeData = JSON.parse(localStorage.getItem("store_data") || "{}") || {
        name: "Store", address: "", receiptFormats: [],
      };
      try {
        const res = await fetch("/api/store");
        if (res.ok) {
          const dbData = await res.json();
          storeData = dbData?.payload;
          localStorage.setItem("store_data", JSON.stringify(storeData));
        }
      } catch (fetchErr) {
        console.warn("Failed to fetch store data during print fallback:", fetchErr);
      }
      
      const seriesType = storeData?.series_type || 'WS';
      const workstationId = getWorkstationId();
             
      // Fetch the incremented number upfront, before normalization
      const nextTxNumber = (await getNextTransactionNumber(seriesType, workstationId)).toString();
      const receiptFormats   = storeData?.receiptFormats || [];
      const selectedFormatId = '3';
      const receiptFormat    = receiptFormats.find((f: any) => String(f.id) === selectedFormatId)
        || receiptFormats[0]
        || { header: storeData.name || '', footer: 'Thank you!' };

      const receiptData = {
        ...await normalizeTransactionForReceipt(
          transactionData,
          { isVoided: type === 'VOID', isRefunded: type === 'REFUND' },
          nextTxNumber
        ),
        isVoided:   type === 'VOID',
        isRefunded: type === 'REFUND',
        isReprint:  false,
        ...(type === 'REFUND' && seriesNo ? { refundSeriesNo: seriesNo } : {}),
        ...(type === 'VOID' && seriesNo ? { voidSeriesNo: seriesNo } : {}),
      };

      // console.log(receiptData)
      const text = buildReceiptText({ storeData, receiptFormat, data: receiptData, fiscal });
      printDirect(text, false);
      return text;
    } catch (err) {
      console.warn(`[Print ${type}] Error:`, err);
      return '';
    }
  };

  const handlePrintReceipt = async () => {
    try {
      const { buildReceiptText, normalizeTransactionForReceipt } = await import("@/src/libs/ReceiptPrinting");
      // Fetch the incremented number upfront, before normalization
      const storeData = JSON.parse(localStorage.getItem("store_data") || "null") || {
        name: "Store", address: "", receiptFormats: [],
      };
      const receiptFormats   = storeData?.receiptFormats || [];
      const selectedFormatId = '3';
      const receiptFormat    = receiptFormats.find((f: any) => String(f.id) === selectedFormatId)
        || receiptFormats[0]
        || { header: storeData.name || '', footer: 'Thank you!' };

      const receiptData = await normalizeTransactionForReceipt(transactionData, {isReprint: true}, );


      const text = buildReceiptText({ storeData, receiptFormat, data: receiptData, fiscal});
      printDirect(text, false);
      if (text && currentBusinessDayId) {
        logEJournalEntry({
          businessDayId: currentBusinessDayId,
          workstationId: getWorkstationId() || '001',
          entryType: 'REPRINT',
          text,
          transactionId: order.dbId,
        });
      }

      setSuccessAction('Print');
    } catch (err) {
      console.warn("[PrintReceipt] error:", err);
    }
  };

  const handleManagerPinConfirm = async (pin: string) => {
    setPinError("");
    try {
      const manager = await getAssociateByPin(pin);
      if (!manager) { setPinError("Invalid PIN. Please try again."); return; }
      if (manager.user.role !== 2) { setPinError("Manager role required."); return; }
      setShowManagerPin(false);
      if (pendingAction === 'void')   await executeVoid(manager.user.name);
      if (pendingAction === 'refund') await executeRefund(manager.user.name);
      setPendingAction(null);
    } catch {
      setPinError("Error verifying PIN. Please try again.");
    }
  };

  const executeVoid = async (approvedBy: string) => {
    const combinedRemarks = voidSelectedReason
      ? `${voidSelectedReason}${voidAdditionalRemarks ? ` — ${voidAdditionalRemarks}` : ''}`
      : (voidAdditionalRemarks || 'No remarks');
    try {
      const voidSeriesNumber = await fetchSeriesNumber('voidSeries');
      const specialId = transactionData?.cmsSpecialID || transactionData?.specialID;
      const apiTxId   = specialId || order.dbId;

      await fetch('/api/transactions', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: apiTxId, status: 'voided', orderState: 'VOIDED', voidRemarks: combinedRemarks, voidSeriesNo: voidSeriesNumber, approvedBy }),
      });

      syncNow(); 
      onVoidProcessed?.(order.salesNumber);
      const text = await printTransactionAs('VOID', voidSeriesNumber);
      if (text && currentBusinessDayId) {
        logEJournalEntry({
          businessDayId: currentBusinessDayId,
          workstationId: getWorkstationId() || '001',
          entryType: 'VOID',
          text,
          transactionId: order.dbId,
        });
      }

      setSuccessAction('Void');
      setShowVoidModal(false);
      setVoidSelectedReason("");
      setVoidAdditionalRemarks("");
    } catch (error) {
      console.warn('[Void] Error:', error);
    }
  };

  const executeRefund = async (approvedBy: string) => {
    const combinedRemarks = refundSelectedReason
      ? `${refundSelectedReason}${refundAdditionalRemarks ? ` — ${refundAdditionalRemarks}` : ''}`
      : (refundAdditionalRemarks || 'No remarks');
    try {
      const refundSeriesNumber = await fetchSeriesNumber('refundSeries');
      const specialId = transactionData?.cmsSpecialID || transactionData?.specialID;
      const apiTxId   = specialId || order.dbId;

      await fetch('/api/transactions', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: apiTxId, status: 'refunded', orderState: 'REFUNDED', refundRemarks: combinedRemarks, refundSeriesNo: refundSeriesNumber, approvedBy }),
      });

      syncNow(); 
      onRefundProcessed?.(order.salesNumber);
      const text = await printTransactionAs('REFUND', refundSeriesNumber);
      if (text && currentBusinessDayId) {
        logEJournalEntry({
          businessDayId: currentBusinessDayId,
          workstationId: getWorkstationId() || '001',
          entryType: 'REFUND',
          text,
          transactionId: order.dbId,
        });
      }

      setSuccessAction('Refund');
      setShowRefundModal(false);
      setRefundSelectedReason("");
      setRefundAdditionalRemarks("");
      openDrawer();
    } catch (error) {
      console.warn('[Refund] Error:', error);
    }
  };

  let items: any[] = [];
  try {
    if (transactionData) {
      if (transactionData.orderDetailJSON) {
        const detailJSON = typeof transactionData.orderDetailJSON === 'string'
          ? JSON.parse(transactionData.orderDetailJSON)
          : transactionData.orderDetailJSON;
        if (detailJSON.items) items = detailJSON.items;
      }
      if (!items.length && Array.isArray(transactionData.items)) items = transactionData.items;
    }
  } catch (e) { console.warn('Error parsing items:', e); }

  const isPOS = order.platform?.toLowerCase() === 'pos';

  return (
    <div
      className="fixed inset-0 flex items-center justify-center z-50 animate-fade-in"
      style={{ background: "rgba(160,150,145,0.30)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)" }}
      onClick={onClose}
    >
      <div
        className="flex items-stretch gap-3 mx-4 animate-slide-up"
        style={{ maxWidth: 680, width: "100%", animationDelay: "0.05s", opacity: 0, animationFillMode: "forwards", maxHeight: "85vh" }}
        onClick={(e) => e.stopPropagation()}
      >

        <div className="flex flex-col gap-2.5 justify-center" style={{ minWidth: 112 }}>

          <ActionSideButton
            onClick={() => onRecall && onRecall()}
            icon={<FiCopy size={17} />}
            label="Recall"
            gradient="linear-gradient(160deg, #3b82f6 0%, #2563eb 100%)"
            shadow="rgba(37,99,235,0.40)"
          />

          {isPOS && (
            <ActionSideButton
              onClick={() => setShowVoidModal(true)}
              disabled={!canActionOrder}
              title={disabledTitle}
              icon={<FiXCircle size={17} />}
              label="Void"
              gradient="linear-gradient(160deg, #4b5563 0%, #374151 100%)"
              shadow="rgba(75,85,99,0.40)"
            />
          )}

          {isPOS && (
            <ActionSideButton
              onClick={() => setShowRefundModal(true)}
              disabled={!canActionOrder}
              title={disabledTitle}
              icon={<FiRotateCcw size={17} />}
              label="Refund"
              gradient="linear-gradient(160deg, #dc2626 0%, #b91c1c 100%)"
              shadow="rgba(220,38,38,0.40)"
            />
          )}

          <ActionSideButton
            onClick={handlePrintReceipt}
            icon={<FiPrinter size={17} />}
            label="Print"
            gradient="linear-gradient(160deg, #f97316 0%, #ea580c 100%)"
            shadow="rgba(249,115,22,0.40)"
          />

        </div>

        <div
          className="rounded-3xl flex-1 relative overflow-hidden flex flex-col shadow-2xl"
          style={{ ...glass.modal, maxHeight: "85vh" }}
        >
          <div style={{ height: 6, flexShrink: 0, background: "linear-gradient(90deg, #f97316 0%, #fb923c 60%, #fed7aa 100%)" }} />

          <div className="px-6 pt-5 pb-4" style={{ flexShrink: 0, borderBottom: "1px solid rgba(0,0,0,0.06)" }}>
            <button
              onClick={onClose}
              className="absolute top-7 right-6 w-8 h-8 rounded-full flex items-center justify-center font-bold text-base transition-all hover:bg-black/5"
              style={{ background: "rgba(0,0,0,0.05)", color: "#bbb", border: "1px solid rgba(0,0,0,0.07)" }}
            >
              ✕
            </button>

            <div className="flex items-center gap-3">
              <div
                className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
                style={{ background: "linear-gradient(135deg, #fff7ed, #ffedd5)", border: "1.5px solid rgba(249,115,22,0.18)", boxShadow: "0 2px 10px rgba(249,115,22,0.10)" }}
              >
                <FiFileText size={24} color="#f97316" />
              </div>
              <div>
                <p style={{ fontSize: 10, color: "#ccc", fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 1 }}>Transaction</p>
                <h2 style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 22, fontWeight: 900, color: "#1a1a1a", lineHeight: 1 }}>
                  Order <span style={{ color: "#f97316" }}>#{order.id}</span>
                </h2>
                <p style={{ fontFamily: "Poppins", fontSize: 10, fontWeight: 700, color: "#bbb", marginTop: 3, letterSpacing: 0.5 }}>
                  SI# {order.salesNumber} &nbsp;·&nbsp;
                  <span style={{
                    fontFamily: "Poppins",
                    fontSize: 10,
                    fontWeight: 900,
                    letterSpacing: 0.5,
                    padding: '3px 10px',
                    borderRadius: 8,
                    background: 'rgba(168,85,247,0.12)',
                    color: '#a855f7',
                    border: '1px solid rgba(168,85,247,0.30)',
                  }}>
                    T{order.kioskNo ?? '???'}
                  </span>
                </p>
                <p style={{ fontSize: 11, color: "#bbb", marginTop: 2 }}>{order.date}</p>
              </div>
            </div>

            {!canActionOrder && (
              <div className="mt-3 rounded-xl px-3 py-2 flex items-center gap-2" style={{ background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.25)" }}>
                <span style={{ fontSize: 15 }}>⚠️</span>
                <p style={{ fontFamily: "Poppins", fontSize: 11, color: "#b45309", fontWeight: 600 }}>{disabledTitle}</p>
              </div>
            )}
          </div>

          <div className="px-6 py-4 overflow-y-auto flex-1" style={{ minHeight: 0 }}>
            <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 10, color: "#ccc", marginBottom: 10, letterSpacing: 1.1, fontWeight: 700 }}>Items Ordered</p>
            {items.length > 0 ? (
              <div className="space-y-3">
                {items.map((item: any, idx: number) => {
                  const rawPrice = (Number(item.price) || 0) / 100;
                  const qty        = item.quantity || 1;
                  const grossPrice = rawPrice * qty;

                  let itemDiscount = 0;
                  if (item.itemDiscount) {
                    // Per-item discount stored directly (PWD, SC, SRC, etc.)
                    itemDiscount = Number(item.itemDiscount) / 100;
                  } else {
                    // Only spread tx-level discountAmount proportionally when NO item in the
                    // transaction has a per-item itemDiscount. If any item has itemDiscount,
                    // this is a targeted SC/PWD/SRC discount — items without it get 0.
                    const allItems: any[] = transactionData?.items || [];
                    const anyItemHasDiscount = allItems.some(
                      (it: any) => it.itemDiscount != null && Number(it.itemDiscount) > 0
                    );
                    if (!anyItemHasDiscount) {
                      const txDiscountPesos = (transactionData?.discountAmount || 0) / 100;
                      if (txDiscountPesos > 0) {
                        const totalGross = allItems.reduce((sum: number, it: any) => {
                          return sum + ((Number(it.price) || 0) / 100) * (it.quantity || 1);
                        }, 0);
                        const proportion = totalGross > 0 ? grossPrice / totalGross : 0;
                        itemDiscount = txDiscountPesos * proportion;
                      }
                    }
                  }



                  let netPrice = grossPrice - itemDiscount;
                  if(txType === 'PWD' || txType === 'SRC') {
                    netPrice =  (grossPrice / 1.12)  - (itemDiscount); // For PWD/SRC, show discounted price as 20% of gross
                  }

                  return (
                    <div
                      key={idx}
                      className="flex justify-between items-start gap-2"
                      style={{ paddingBottom: 10, borderBottom: idx < items.length - 1 ? "1px solid rgba(0,0,0,0.07)" : "none" }}
                    >
                      <div className="flex-1">
                        <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 13, fontWeight: 700, color: "#1a1a1a", marginBottom: 3 }}>
                          {item.itemName || item.name || 'Unknown Item'}
                        </p>
                        <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 12, color: "#f97316", fontWeight: 600 }}>
                          {itemDiscount > 0.005 ? (
                            <>
                              <span style={{ textDecoration: "line-through", color: "#aaa", marginRight: 6 }}>
                                {grossPrice.toFixed(2)}
                              </span>
                              {netPrice.toFixed(2)}
                            </>
                          ) : (
                            `${grossPrice.toFixed(2)}`
                          )}
                        </p>
                        {itemDiscount > 0.005 && (
                          <p style={{ fontFamily: "Poppins", fontSize: 11, color: "#16a34a", fontWeight: 700, marginTop: 2 }}>
                            − {
                                txType === 'PWD' || txType === 'SRC'?
                                  ((grossPrice - grossPrice / 1.12)  + (itemDiscount)).toFixed(2):
                                  itemDiscount.toFixed(2)
                              } discount
                          </p>
                        )}
                        {itemDiscount > 0.005 && transactionData?.discountInfo?.label && (
                          <p style={{ fontFamily: "Poppins", fontSize: 10, color: "#9ca3af", fontWeight: 600, marginTop: 1 }}>
                            {transactionData.discountInfo.label}
                            {item.discountID ? ` (${item.discountID}%)` : ''}
                          </p>
                        )}
                      </div>
                      <div className="px-3 py-1 rounded-lg text-center flex-shrink-0"
                        style={{ background: "rgba(249,115,22,0.10)", border: "1px solid rgba(249,115,22,0.20)", minWidth: 46 }}>
                        <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 12, fontWeight: 700, color: "#f97316" }}>
                          x{qty}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 12, color: "#f97316", fontWeight: 600, textAlign: "center" }}>
                {order.items} item{order.items !== 1 ? "s" : ""} ordered
              </p>
            )}
          </div>

          <div
            className="px-6 pb-6 pt-4 flex flex-col gap-3"
            style={{ flexShrink: 0, borderTop: "1px solid rgba(0,0,0,0.06)" }}
          >
            <div
              className="rounded-2xl px-4 py-3 flex items-center justify-between"
              style={{ background: "rgba(255,255,255,0.60)", border: "1px solid rgba(0,0,0,0.055)", boxShadow: "0 1px 4px rgba(0,0,0,0.04)" }}
            >
              <div className="flex items-center gap-3">
                <PaymentBadge method={order.paymentMethod} large />
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-bold" style={{ background: "rgba(22,163,74,0.10)", color: "#16a34a", border: "1px solid rgba(22,163,74,0.20)" }}>
                Settled ✓
              </span>
            </div>

            <div
              className="rounded-2xl px-5 py-4 flex items-center justify-between"
              style={{ background: "linear-gradient(135deg, rgba(249,115,22,0.07) 0%, rgba(253,186,116,0.09) 100%)", border: "1.5px solid rgba(249,115,22,0.16)" }}
            >
              <div>
                <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 10, color: "#f97316", fontWeight: 700, letterSpacing: 1, opacity: 0.7 }}>Order Total</p>
                <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 12, color: "#aaa", marginTop: 1 }}>
                  {order.items} item{order.items !== 1 ? "s" : ""}
                </p>
              </div>
              <span style={{ fontFamily: "Impact, Arial Black, sans-serif", fontSize: 30, fontWeight: 900, color: "#f97316", letterSpacing: 0.5 }}>
                {order.total.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {showVoidModal && (
        <div
          className="fixed inset-0 flex items-center justify-center z-[100] overflow-y-auto"
          style={{ background: "rgba(160,150,145,0.30)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)" }}
          onClick={() => setShowVoidModal(false)}
        >
          <div
            className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden my-8"
            style={glass.modal}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ height: 6, background: "linear-gradient(90deg, #4b5563 0%, #6b7280 60%, #9ca3af 100%)" }} />
            <div className="p-7">
              <button
                onClick={() => setShowVoidModal(false)}
                className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-base transition-all hover:bg-black/5"
                style={{ background: "rgba(0,0,0,0.05)", color: "#bbb", border: "1px solid rgba(0,0,0,0.07)" }}
              >
                ✕
              </button>
              <div className="mb-5">
                <p style={{ fontSize: 11, color: "#ccc", fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 2 }}>Void Order</p>
                <h2 style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 24, fontWeight: 900, color: "#1a1a1a", lineHeight: 1, marginBottom: 4 }}>
                  Order <span style={{ color: "#4b5563" }}>#{order.id}</span>
                </h2>
                <p style={{ fontSize: 13, fontWeight: 700, color: "#4b5563" }}>{order.total.toFixed(2)}</p>
              </div>
              <ReasonInput
                reasonsList={voidReasonsList}
                selectedReason={voidSelectedReason}
                onSelectReason={setVoidSelectedReason}
                additionalRemarks={voidAdditionalRemarks}
                onChangeAdditional={setVoidAdditionalRemarks}
                accentColor="#4b5563"
              />
              <div className="flex gap-3">
                <button
                  onClick={() => setShowVoidModal(false)}
                  className="flex-1 rounded-full py-3 text-sm font-bold transition-all hover:brightness-95"
                  style={{ fontFamily: "Poppins", textTransform: "uppercase", background: "rgba(0,0,0,0.05)", color: "#888", border: "1px solid rgba(0,0,0,0.08)" }}
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!voidSelectedReason && !voidAdditionalRemarks.trim()) {
                      sileo.error({ title: "Reason is required", description: "Please select a reason or enter remarks before proceeding.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
                      return;
                    }
                    setPendingAction('void');
                    setPinError("");
                    setShowManagerPin(true);
                  }}
                  className="flex-1 rounded-full py-3 text-sm font-bold text-white transition-all hover:brightness-110 active:scale-95 flex items-center justify-center gap-2"
                  style={{ fontFamily: "Poppins", textTransform: "uppercase", background: "linear-gradient(135deg, #4b5563 0%, #374151 100%)", border: "1px solid rgba(255,255,255,0.25)", boxShadow: "0 4px 18px rgba(75,85,99,0.35)" }}
                >
                  <FiXCircle size={16} /> Process Void
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showRefundModal && (
        <div
          className="fixed inset-0 flex items-center justify-center z-[100] overflow-y-auto"
          style={{ background: "rgba(160,150,145,0.30)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)" }}
          onClick={() => setShowRefundModal(false)}
        >
          <div
            className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden my-8"
            style={glass.modal}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ height: 6, background: "linear-gradient(90deg, #dc2626 0%, #ef4444 60%, #fca5a5 100%)" }} />
            <div className="p-7">
              <button
                onClick={() => setShowRefundModal(false)}
                className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-base transition-all hover:bg-black/5"
                style={{ background: "rgba(0,0,0,0.05)", color: "#bbb", border: "1px solid rgba(0,0,0,0.07)" }}
              >
                ✕
              </button>
              <div className="mb-5">
                <p style={{ fontSize: 11, color: "#ccc", fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 2 }}>Refund Order</p>
                <h2 style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 24, fontWeight: 900, color: "#1a1a1a", lineHeight: 1, marginBottom: 4 }}>
                  Order <span style={{ color: "#dc2626" }}>#{order.id}</span>
                </h2>
                <p style={{ fontSize: 13, fontWeight: 700, color: "#dc2626" }}>{order.total.toFixed(2)}</p>
              </div>
              <ReasonInput
                reasonsList={refundReasonsList}
                selectedReason={refundSelectedReason}
                onSelectReason={setRefundSelectedReason}
                additionalRemarks={refundAdditionalRemarks}
                onChangeAdditional={setRefundAdditionalRemarks}
                accentColor="#dc2626"
              />
              <div className="flex gap-3">
                <button
                  onClick={() => setShowRefundModal(false)}
                  className="flex-1 rounded-full py-3 text-sm font-bold transition-all hover:brightness-95"
                  style={{ fontFamily: "Poppins", textTransform: "uppercase", background: "rgba(0,0,0,0.05)", color: "#888", border: "1px solid rgba(0,0,0,0.08)" }}
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!refundSelectedReason && !refundAdditionalRemarks.trim()) {
                      sileo.error({ title: "Reason is required", description: "Please select a reason or enter remarks before proceeding.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
                      return;
                    }
                    setPendingAction('refund');
                    setPinError("");
                    setShowManagerPin(true);
                  }}
                  className="flex-1 rounded-full py-3 text-sm font-bold text-white transition-all hover:brightness-110 active:scale-95 flex items-center justify-center gap-2"
                  style={{ fontFamily: "Poppins", textTransform: "uppercase", background: "linear-gradient(135deg, #dc2626 0%, #b91c1c 100%)", border: "1px solid rgba(255,255,255,0.25)", boxShadow: "0 4px 18px rgba(220,38,38,0.35)" }}
                >
                  <FiRotateCcw size={16} /> Process Refund
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showManagerPin && (
        <>
          <ManagerPinModal
            subtitle={
              pendingAction === 'void'
                ? `Manager approval required to void Order #${order.id}`
                : `Manager approval required to refund Order #${order.id}`
            }
            onConfirm={(pin) => handleManagerPinConfirm(pin)}
            onClose={() => { setShowManagerPin(false); setPendingAction(null); setPinError(""); }}
          />
          {pinError && (
            <div
              className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[400] px-6 py-3 rounded-2xl shadow-xl"
              style={{ background: "#dc2626", color: "#fff", fontFamily: "Poppins", fontSize: 13, fontWeight: 700 }}
            >
              {pinError}
            </div>
          )}
        </>
      )}
      {successAction && (
        <SuccessModal
          action={successAction}
          onClose={() => {
            setSuccessAction(null);
            setSelectedOrder(null);
          }}
        />
      )}
    </div>
  );
}


function ActionSideButton({
  onClick,
  icon,
  label,
  gradient,
  shadow,
  disabled,
  title,
}: {
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  gradient: string;
  shadow: string;
  disabled?: boolean;
  title?: string;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      className="flex flex-col items-center justify-center gap-1.5 rounded-2xl py-4 px-2 text-white font-bold transition-all hover:brightness-110 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed"
      style={{
        fontFamily: "Poppins",
        textTransform: "uppercase",
        fontSize: 10,
        letterSpacing: 0.8,
        background: gradient,
        border: "1px solid rgba(255,255,255,0.22)",
        boxShadow: `0 4px 18px ${shadow}`,
        width: "100%",
        minHeight: 72,
      }}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

function SuccessModal({ action, onClose }: { action: string; onClose: () => void }) {
  useEffect(() => {
    const t = setTimeout(onClose, 3200);
    return () => clearTimeout(t);
  }, [onClose]);

  const config: Record<string, { icon: string; color: string; gradient: string; shadow: string }> = {
    Void:    { icon: "🚫", color: "#4b5563", gradient: "linear-gradient(135deg,#4b5563,#374151)", shadow: "rgba(75,85,99,0.35)"   },
    Refund:  { icon: "↩️", color: "#dc2626", gradient: "linear-gradient(135deg,#dc2626,#b91c1c)", shadow: "rgba(220,38,38,0.35)"  },
    Print:   { icon: "🖨️", color: "#f97316", gradient: "linear-gradient(135deg,#f97316,#ea580c)", shadow: "rgba(249,115,22,0.35)" },
  };
  const c = config[action] ?? config.Print;

  return (
    <div
      className="fixed inset-0 flex items-center justify-center z-[500] animate-fade-in"
      style={{ background: "rgba(15,23,42,0.72)", backdropFilter: "blur(18px)", WebkitBackdropFilter: "blur(18px)" }}
      onClick={onClose}
    >
      <div
        className="rounded-3xl w-full max-w-xs mx-4 overflow-hidden animate-scale-in shadow-2xl"
        style={{ background: "#fff", animationDelay: "0.03s", opacity: 0, animationFillMode: "forwards" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ height: 5, background: c.gradient }} />

        <div className="flex flex-col items-center px-8 py-8 gap-4">
          <div className="relative flex items-center justify-center" style={{ width: 88, height: 88 }}>
            <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", transform: "rotate(-90deg)" }}>
              <circle cx="44" cy="44" r="40" fill="none" stroke={`${c.color}22`} strokeWidth="4" />
              <circle
                cx="44" cy="44" r="40" fill="none" stroke={c.color} strokeWidth="4"
                strokeDasharray={`${2 * Math.PI * 40}`}
                strokeDashoffset={`${2 * Math.PI * 40}`}
                strokeLinecap="round"
                style={{ animation: "successRing 0.7s cubic-bezier(0.16,1,0.3,1) 0.1s forwards" }}
              />
            </svg>
            <span style={{ fontSize: 36, lineHeight: 1 }}>{c.icon}</span>
          </div>

          <div className="text-center">
            <p style={{ fontFamily: "Poppins", fontSize: 10, color: "#ccc", fontWeight: 700, letterSpacing: 1.4, textTransform: "uppercase", marginBottom: 4 }}>
              Successful
            </p>
            <h2 style={{ fontFamily: "Poppins", fontSize: 26, fontWeight: 900, color: "#1a1a1a", lineHeight: 1.1 }}>
              {action} <span style={{ color: c.color }}>Complete</span>
            </h2>
          </div>

          <button
            onClick={onClose}
            className="w-full py-3 rounded-2xl font-bold text-white text-sm transition-all hover:brightness-110 active:scale-95"
            style={{ fontFamily: "Poppins", textTransform: "uppercase", letterSpacing: 0.8, background: c.gradient, boxShadow: `0 4px 18px ${c.shadow}` }}
          >
            Done
          </button>
        </div>
      </div>

      <style>{`
        @keyframes successRing {
          to { stroke-dashoffset: 0; }
        }
      `}</style>
    </div>
  );
}


function saveVoidLocally(voidData: any) {
  const pendingVoids = JSON.parse(localStorage.getItem('pendingVoids') || '[]');
  pendingVoids.push({ ...voidData, retryCount: 0 });
  localStorage.setItem('pendingVoids', JSON.stringify(pendingVoids));
}


function saveRefundLocally(refundData: any) {
  const pending = JSON.parse(localStorage.getItem('pendingRefunds') || '[]');
  pending.push({ ...refundData, retryCount: 0 });
  localStorage.setItem('pendingRefunds', JSON.stringify(pending));
}

export default function OrderTransactionHistoryPage() {
  const router = useRouter();
  const [orders, setOrders]                   = useState<Order[]>([]);
  const [transactionDataMap, setTransactionDataMap] = useState<Record<string, any>>({});
  const [search, setSearch]                   = useState("");
  const [platform, setPlatform]               = useState<'All' | 'POS' | 'Grab' | 'Mobile' | 'SOK'>('All');
  const [selectedOrder, setSelectedOrder]     = useState<Order | null>(null);
  const [loading, setLoading]                 = useState(true);
  const [viewMode, setViewMode]               = useState<'card' | 'table'>('card');
  const [currentShiftOpenedAt, setCurrentShiftOpenedAt] = useState<string | undefined>(undefined);
  const [stockValidation, setStockValidation] = useState<{ show: boolean, issues: any[], adjustedCart: any[] } | null>(null);
  const [terminalFilter, setTerminalFilter] = useState<'All' | 'ThisTerminal'>('ThisTerminal');
  type SortMode = 'order_desc' | 'order_asc' | 'si_desc' | 'si_asc';
  const [sortMode, setSortMode] = useState<SortMode>('order_desc');
  const { syncNow } = useSyncContext();
  const [currentBusinessDayId, setCurrentBusinessDayId] = useState<string | undefined>(undefined);
  const [selectedDateBusinessDayId, setSelectedDateBusinessDayId] = useState<string | null>(null);
  const [isSelectedBusinessDayActive, setIsSelectedBusinessDayActive] = useState(false);





  const [selectedDate, setSelectedDate] = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  });

  const executeRecall = async (cartToSave: any[]) => {
    try {
      const workstationId = localStorage.getItem('workstationId') || "001";
      await saveCartToDatabase(workstationId, cartToSave, null);
      sileo.success({ title: "Order Recalled", description: "Items copied to cart. Redirecting...", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }, duration: 1000 });
      setTimeout(() => { router.push('/dashboard'); }, 500);
    } catch (error) {
      console.warn("Recall save error:", error);
      sileo.error({ title: "Recall Failed", description: "Could not save items to cart.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
    }
  };

  const handleRecallOrder = async (orderId: string, transactionData: any) => {
    try {
      let items: any[] = [];
      if (transactionData?.orderDetailJSON) {
        const detail = typeof transactionData.orderDetailJSON === 'string' ? JSON.parse(transactionData.orderDetailJSON) : transactionData.orderDetailJSON;
        if (detail?.items) items = detail.items;
      }
      if (!items.length && Array.isArray(transactionData?.items)) items = transactionData.items;

      if (!items || items.length === 0) {
        sileo.error({ title: "Recall Failed", description: "No items found in this order.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
        return;
      }

      const menuRecord = await getMenuFromCache();
      let flatMenu: any[] = [];
      if (menuRecord?.categories) {
        menuRecord.categories.forEach((cat: any) => {
          flatMenu = flatMenu.concat(cat.items || []);
          (cat.subcategories || []).forEach((sub: any) => { flatMenu = flatMenu.concat(sub.items || []); });
        });
      }

      const recalledCart = items.map((item: any) => {
        const blueprint = flatMenu.find(m => m.id === (item.id || item.itemId)) || {};
        const itemPrice = (typeof item.price === 'number' ? item.price : Number(item.price || 0)) / 100;

        const modsList = Array.isArray(item.modifiers) ? item.modifiers : Object.values(item.modifiers || {});
        const mappedMods = modsList.map((mod: any) => {
          let exactMod = null;
          if (blueprint.modifierGroups) {
            for (const group of blueprint.modifierGroups) {
              if (group.modifiers) {
                for (const gm of group.modifiers) {
                  if (gm.id === mod.id || gm.name === mod.name || String(gm.id).endsWith(`|${mod.id}`)) {
                    exactMod = gm;
                    break;
                  }
                }
              }
              if (exactMod) break;
            }
          }

          const activeMod = exactMod || mod;
          const rModPrice = (typeof activeMod.price === 'number' ? activeMod.price : Number(activeMod.price || 0)) / 100;
          
          const finalMod = { 
            ...activeMod, 
            qty: mod.quantity || mod.qty || 1, 
            price: rModPrice 
          };

          if (!finalMod.gx_item_code) {
            let baseId = finalMod.id;
            if (String(baseId).startsWith('AD-0|') || String(baseId).startsWith('MD-0|')) {
               baseId = `IT-${String(baseId).split('|')[1]}`;
            } else if (!String(baseId).startsWith('IT-') && !String(baseId).startsWith('CL-')) {
               baseId = `IT-${baseId}`;
            }
            const modBlueprint = flatMenu.find((m: any) => m.id === baseId);
            if (modBlueprint && modBlueprint.gx_item_code) {
               finalMod.gx_item_code = modBlueprint.gx_item_code;
            }
          }

          if (finalMod.gx_item_code) {
             finalMod.itemCode = finalMod.gx_item_code;
          }

          return finalMod;
        });

        return {
          ...blueprint,
          id: item.id || item.itemId,
          itemCode: blueprint.gx_item_code || blueprint.itemCode || item.itemCode,
          name: item.itemName || item.name || blueprint.name,
          price: itemPrice > 0 ? itemPrice : (Number(blueprint.price) > 1000 ? Number(blueprint.price)/100 : Number(blueprint.price) || 0),
          qty: item.quantity || item.qty || 1,
          modifiers: mappedMods,
          taxable: item.taxable !== undefined ? item.taxable : (blueprint.taxable !== false),
          imgReal: item.image || item.imgReal || (blueprint.photos?.length ? blueprint.photos[0] : '')
        };
      });

      const invRes = await fetch('/api/inventory');
      let currentInventory: Record<string, number> = {};
      if (invRes.ok) {
        const invData = await invRes.json();
        if (invData && typeof invData === 'object' && !Array.isArray(invData)) currentInventory = invData;
        else if (Array.isArray(invData)) currentInventory = invData.reduce((acc: any, it: any) => ({ ...acc, [it.itemId || it.id]: it.quantity }), {});
      }

      let hasIssues = false;
      const validationList: any[] = [];
      const adjustedCart: any[] = [];
      const workingInv = { ...currentInventory };

      for (const item of recalledCart) {
        const groups = item.modifierGroups || [];
        const isCombo = groups.some((g: any) => (g.modifiers || []).some((mod: any) => String(mod.id || '').startsWith('MD-')));
        const mods = item.modifiers || [];

        let baseMaxQty = item.qty;
        if (!isCombo) {
            const sId = getInventoryId(item);
            const avail = workingInv[sId] || 0;
            if (avail < baseMaxQty) {
                baseMaxQty = Math.max(0, avail);
            }
        }

        let finalMaxQty = baseMaxQty;
        const modIssues: any[] = [];

        for (const m of mods) {
            const mIdStr = String(m.id || '');
            if (!mIdStr.startsWith('MD-') && !mIdStr.startsWith('AD-')) continue;

            const msId = getInventoryId(m);
            const mAvail = workingInv[msId] || 0;
            const requiredPerItem = m.qty || 1;
            const totalNeeded = requiredPerItem * item.qty;
            
            if (mAvail < totalNeeded) {
                modIssues.push({ name: `${item.name} — ${m.name}`, requested: totalNeeded, available: mAvail });
                const maxCombos = Math.floor(mAvail / requiredPerItem);
                if (maxCombos < finalMaxQty) {
                    finalMaxQty = Math.max(0, maxCombos);
                }
            }
        }

        if (finalMaxQty < item.qty) {
            hasIssues = true;
            if (!isCombo) {
                const sId = getInventoryId(item);
                const avail = workingInv[sId] || 0;
                if (avail < item.qty) {
                    validationList.push({ name: item.name, requested: item.qty, available: avail });
                }
            }
            modIssues.forEach(issue => validationList.push(issue));
        }

        if (finalMaxQty > 0) {
            if (!isCombo) workingInv[getInventoryId(item)] -= finalMaxQty;
            mods.forEach((m: any) => {
              const mIdStr = String(m.id || '');
              if (mIdStr.startsWith('MD-') || mIdStr.startsWith('AD-')) {
                 workingInv[getInventoryId(m)] -= (m.qty || 1) * finalMaxQty;
              }
            });
            adjustedCart.push({ ...item, qty: finalMaxQty });
        }
      }

      if (hasIssues) {
        setStockValidation({ show: true, issues: validationList, adjustedCart });
      } else {
        await executeRecall(recalledCart);
      }

    } catch (error) {
      console.warn("Recall error:", error);
      sileo.error({ title: "Recall Failed", description: "Could not recall order items.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
    }
  };

  useEffect(() => {
    fetch('/api/cashier-session')
      .then(r => r.json())
      .then(data => {
        if (data.active && data.session?.openedAt) {
          setCurrentShiftOpenedAt(data.session.openedAt);
          // NEW
          if (data.session.businessDayId) {
            setCurrentBusinessDayId(data.session.businessDayId);
          }
        }
      })
      .catch(() => {});
  }, []);
  
  useEffect(() => {
    fetch('/api/business-day')
      .then(r => r.json())
      .then(d => {
        const bd = d.businessDay;
        if (bd?.date) setSelectedDate(bd.date);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!selectedOrder) return;
    const updated = orders.find(o => 
      o.salesNumber === selectedOrder.salesNumber && 
      o.kioskNo === selectedOrder.kioskNo
    );

    if (updated) setSelectedOrder(updated);
  }, [orders]);

  useEffect(() => {
    const saved = localStorage.getItem('order_history_show_type');
    if (saved === 'card' || saved === 'table') setViewMode(saved);
  }, []);

  const handleViewModeChange = (mode: 'card' | 'table') => {
    setViewMode(mode);
    localStorage.setItem('order_history_show_type', mode);
  };

  useEffect(() => {
    let isMounted = true;
    let abortController = new AbortController();

    const fetchOrders = async () => {
      try {
        if (abortController.signal.aborted) abortController = new AbortController();
        setLoading(true);

        // ── Step 1: find the business day for the selected date ──────────────
        let businessDayId: string | null = null;
        let isSelectedDateActive = false;

        try {
          const bdRes = await fetch(`/api/business-day?date=${selectedDate}`, {
            signal: abortController.signal,
          });
          if (bdRes.ok) {
            const bdData = await bdRes.json();
            const bd = bdData?.businessDay;
            if (bd?.businessDayId) {
              businessDayId = bd.businessDayId;
              isSelectedDateActive = bd.status === 'open';
            }
          }
        } catch (e) {
          console.warn('[fetchOrders] business-day fetch error:', e);
        }

        if (!businessDayId) {
          // No business day found for this date — nothing to show
          if (isMounted) {
            setOrders([]);
            setTransactionDataMap({});
            setSelectedDateBusinessDayId(null);
            setIsSelectedBusinessDayActive(false);
            setLoading(false);
          }
          return;
        }

        // ── Step 2: get ALL sessions under this business day ─────────────────
        let allSessionIds: string[] = [];

        try {
          const [closedRes, openRes] = await Promise.all([
            fetch(`/api/cashier-session?status=closed&businessDayId=${businessDayId}`, {
              signal: abortController.signal,
            }),
            fetch(`/api/cashier-session?status=all_open`, {
              signal: abortController.signal,
            }),
          ]);

          const closedSessions: any[] = closedRes.ok
            ? (await closedRes.json()).sessions || []
            : [];

          const openJson = openRes.ok ? await openRes.json() : {};
          const openSessions: any[] = (openJson.sessions || []).filter(
            (s: any) => s.businessDayId === businessDayId
          );

          const allSessions = [...closedSessions, ...openSessions];
          allSessionIds = allSessions.map((s: any) => s.sessionId).filter(Boolean);
        } catch (e) {
          if (e instanceof Error && e.name === 'AbortError') return; // ← add this
          console.warn('[fetchOrders] session fetch error:', e);
        }

        if (allSessionIds.length === 0) {
          // Business day exists but no sessions yet
          if (isMounted) {
            setOrders([]);
            setTransactionDataMap({});
            setSelectedDateBusinessDayId(businessDayId);
            setIsSelectedBusinessDayActive(isSelectedDateActive);
            setLoading(false);
          }
          return;
        }

        // ── Step 3: fetch transactions by sessionId ───────────────────────────
        // Pass all session IDs as a query param so the API can filter server-side.
        // Falls back to fetching all and filtering client-side if the API
        // doesn't support the sessionIds param yet.
        let allTransactions: any[] = [];

        if (platform === 'POS' || platform === 'All') {
          try {
            const sessionParam = allSessionIds.join(',');
            const res = await fetch(
              `/api/transactions?limit=1000&sessionIds=${encodeURIComponent(sessionParam)}`,
              { signal: abortController.signal }
            );
            if (res.ok) {
              const data = await res.json();
              const txList: any[] = Array.isArray(data.transactions)
                ? data.transactions
                : Array.isArray(data)
                ? data
                : [];

              // Filter client-side too — belt and suspenders
              const sessionSet = new Set(allSessionIds);
              allTransactions = allTransactions.concat(
                txList
                  .filter((tx: any) => sessionSet.has(tx.sessionId))
                  .map((tx: any) => ({ ...tx, platform: 'POS' }))
              );
            }
          } catch (e) {
            if (e instanceof Error && e.name !== 'AbortError') console.warn(e);
          }
        }

        // Non-POS platforms (Grab, Mobile, SOK) don't have sessionIds,
        // so they stay on date-based filtering
        if (platform !== 'POS') {
          try {
            const res = await fetch(
              `/api/order-transactions?limit=500&offset=0`,
              { signal: abortController.signal }
            );
            if (res.ok) {
              const data = await res.json();
              let txList: any[] = Array.isArray(data.transactions)
                ? data.transactions
                : Array.isArray(data)
                ? data
                : [];

              // Use PHT for date comparison
              txList = txList.filter((tx: any) => {
                try {
                  const d = new Date(tx.created_at || tx.createdAt || tx.orderTime || new Date());
                  return d.toLocaleDateString('en-CA', { timeZone: 'Asia/Manila' }) === selectedDate;
                } catch { return false; }
              });

              if (platform !== 'All') {
                txList = txList.filter(
                  (tx: any) =>
                    String(tx.order_from || '').toLowerCase() === platform.toLowerCase()
                );
              }

              allTransactions = allTransactions.concat(
                txList.map((tx: any) => ({ ...tx, platform: tx.order_from || 'Unknown' }))
              );
            }
          } catch (e) {
            if (e instanceof Error && e.name !== 'AbortError') console.warn(e);
          }
        }

        if (!isMounted) return;

        if (allTransactions.length === 0) {
          setOrders([]);
          setTransactionDataMap({});
          setSelectedDateBusinessDayId(businessDayId);
          setIsSelectedBusinessDayActive(isSelectedDateActive);
          setLoading(false);
          return;
        }

        // ── Step 4: transform into Order objects ─────────────────────────────
        const transformedOrders: Order[] = allTransactions.map((tx: any) => {
          const itemsCount = Array.isArray(tx.items)
            ? tx.items.reduce((s: number, i: any) => s + (Number(i.quantity) || 1), 0)
            : 0;

          let totalAmount = 0;
          if (tx.total_amount) {
            totalAmount = Number(tx.total_amount) || 0;
          } else if (Array.isArray(tx.payment) && tx.payment.length > 0) {
            const paySum = tx.payment.reduce(
              (s: number, p: any) => s + (Number(p.Amount || p.amount) || 0),
              0
            );
            totalAmount = paySum > 0 ? paySum : (tx.price?.eaterPayment || 0);
          } else if (typeof tx.price?.eaterPayment === 'number') {
            totalAmount = tx.price.eaterPayment;
          } else if (typeof tx.totalAmount === 'number') {
            totalAmount = tx.totalAmount;
          } else if (typeof tx.total === 'number') {
            totalAmount = tx.total * 100;
          }

          const dateObj = new Date(
            tx.created_at || tx.createdAt || tx.orderTime || new Date()
          );

          const dateStr =
            dateObj.toLocaleDateString('en-PH', {
              timeZone: 'Asia/Manila',
              year: 'numeric',
              month: 'short',
              day: 'numeric',
            }) +
            ' ' +
            dateObj.toLocaleTimeString('en-PH', {
              timeZone: 'Asia/Manila',
              hour: '2-digit',
              minute: '2-digit',
            });

          const orderId = String(
            tx.order_number || tx.OrderNo || tx.orderNumber || tx.id || 'UNK'
          ).padStart(4, '0');

          const salesNumber =
            tx.salesNumber || tx.specialID || String(tx._id || tx.id);

          const status =
            tx.status === 'voided' || tx.voidStatus === 'voided'
              ? 'Voided'
              : tx.status === 'refunded' || tx.refundStatus === 'refunded'
              ? 'Refunded'
              : tx.order_status === 'DELIVERED' ||
                tx.isSyncedFromCMS === true ||
                tx.isSynced === true
              ? 'Completed'
              : 'Pending';

          const parsedPaymentMethods: string[] =
            Array.isArray(tx.payment) && tx.payment.length > 0
              ? tx.payment.map((p: any) => p.PaymentMethod || p.method || 'Cash')
              : [tx.payment_type || tx.PaymentMethod || tx.paymentMethod || 'Cash'];

          return {
            _id:           String(tx._id || tx.id),
            dbId:          String(tx._id || tx.id),
            id:            orderId,
            salesNumber,
            items:         itemsCount,
            total:         totalAmount / 100,
            date:          dateStr,
            dateISO:       dateObj.toISOString(),
            paymentMethod: parsedPaymentMethods,
            cardLast4:     null,
            status,
            platform:      tx.order_id !== null? 'SOK' : tx.platform || tx.order_from || 'POS',
            kioskNo:       String(tx.KioskNo || tx.terminalId || tx.workstationId || '???'),
            businessDayId: businessDayId
          };
        });

        // ── Step 5: sort + deduplicate ────────────────────────────────────────
        transformedOrders.sort(
          (a, b) => new Date(b.dateISO).getTime() - new Date(a.dateISO).getTime()
        );

        const uniqueOrders: Order[] = [];
        const seenIds = new Set<string>();
        for (const o of transformedOrders) {
          const dedupeKey = `${o.kioskNo ?? ''}::${o.salesNumber}`;
          if (!seenIds.has(dedupeKey)) {
            seenIds.add(dedupeKey);
            uniqueOrders.push(o);
          }
        }

        // ── Step 6: build transaction data map ───────────────────────────────
        const dataMap: Record<string, any> = {};
        allTransactions.forEach((tx: any) => {
          const sn = tx.salesNumber || tx.specialID || String(tx._id || tx.id);
          const key = `${tx.KioskNo ?? '???'}::${sn}`;
          dataMap[key] = tx;
        });

        if (isMounted) {
          console.log(uniqueOrders)
          setOrders(uniqueOrders);
          setTransactionDataMap(dataMap);
          setSelectedDateBusinessDayId(businessDayId);
          setIsSelectedBusinessDayActive(isSelectedDateActive);
          setLoading(false);
        }
      } catch (error) {
        if (
          error instanceof Error && error.name === 'AbortError' ||
          (error as any) === 'unmount'
        ) return;
        console.warn('[fetchOrders] unexpected error:', error);
        if (isMounted) setLoading(false);
      }
    };

    fetchOrders();
    const interval = setInterval(fetchOrders, 30000);

    return () => {
      isMounted = false;
      abortController.abort('unmount');
      clearInterval(interval);
    };
  }, [platform, selectedDate]);


  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const currentTerminalId = getWorkstationId() || '001';
 
    const target = orders.filter((o) => {
      try {
        
        if (o.status === 'Voided') return false;

        if (terminalFilter === 'ThisTerminal') {
          const txData = transactionDataMap[`${o.kioskNo ?? '???'}::${o.salesNumber}`];
          const txTerminal = txData?.KioskNo || txData?.terminalId || txData?.workstationId;
          if (txTerminal && String(txTerminal) !== String(currentTerminalId)) {
            return false;
          }
        }

        return true;
      } catch { return false; }
    });

    const searched = !q ? target : target.filter((o) => {
      const payStr = Array.isArray(o.paymentMethod) ? o.paymentMethod.join(' ').toLowerCase() : String(o.paymentMethod).toLowerCase();
      return o.id.toLowerCase().includes(q) || o.date.toLowerCase().includes(q) || payStr.includes(q) || String(o.total).includes(q) || o.salesNumber.toLowerCase().includes(q);
    });

    return [...searched].sort((a, b) => {
      switch (sortMode) {
        case 'order_asc':  return a.id.localeCompare(b.id, undefined, { numeric: true });
        case 'order_desc': return b.id.localeCompare(a.id, undefined, { numeric: true });
        case 'si_asc':     return a.salesNumber.localeCompare(b.salesNumber, undefined, { numeric: true });
        case 'si_desc':    return b.salesNumber.localeCompare(a.salesNumber, undefined, { numeric: true });
        default:           return 0;
      }
    });
  }, [search, orders, selectedDate, terminalFilter, transactionDataMap, sortMode]);

  return (
    <div className="flex flex-col w-full h-full overflow-hidden select-none p-6 animate-fade-in" style={{ fontFamily: "'Poppins', Impact, Arial, sans-serif" }}>
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes slideUpFade { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes scaleIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
        .animate-slide-up  { animation: slideUpFade 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        .animate-fade-in   { animation: fadeIn 0.3s ease-out forwards; }
        .animate-scale-in  { animation: scaleIn 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
      ` }} />

      <div className="flex flex-col xl:flex-row items-start xl:items-center justify-between gap-4 mb-6 flex-shrink-0 animate-slide-up" style={{ animationDelay: '0.05s', opacity: 0, animationFillMode: "forwards" }}>
        <div className="flex items-center gap-4">
          <h1 style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 32, fontWeight: 900, color: "#1a1a1a", letterSpacing: 1.5, textShadow: "0 2px 4px rgba(255,255,255,0.5)", lineHeight: 1 }}>
            Order History
          </h1>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/60 border border-white/40 shadow-sm" style={{ backdropFilter: "blur(10px)" }}>
            <span className="flex items-center justify-center min-w-[24px] h-6 px-1.5 rounded-full bg-orange-100 text-orange-600 text-xs font-black">{filtered.length}</span>
            <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Records</span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/60 border border-white/50 shadow-sm backdrop-blur-md transition-all focus-within:bg-white focus-within:border-orange-300">
            <select
              value={terminalFilter}
              onChange={(e) => setTerminalFilter(e.target.value as 'All' | 'ThisTerminal')}
              className="bg-transparent outline-none text-sm font-bold text-gray-700 cursor-pointer"
              style={{ fontFamily: "Poppins", color: "#f97316" }}
            >
              <option value="All">All Terminals</option>
              <option value="ThisTerminal">This Terminal Only</option>
            </select>
          </div>

          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/60 border border-white/50 shadow-sm backdrop-blur-md transition-all focus-within:bg-white focus-within:border-orange-300">
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent outline-none text-sm font-bold text-gray-700"
              style={{ fontFamily: "Poppins", color: "#f97316" }}
            />
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/60 border border-white/50 shadow-sm backdrop-blur-md">
            <select
              value={sortMode}
              onChange={(e) => setSortMode(e.target.value as SortMode)}
              className="bg-transparent outline-none text-sm font-bold cursor-pointer"
              style={{ fontFamily: "Poppins", color: "#f97316" }}
            >
              <option value="order_desc">Sort By Order No ↓</option>
              <option value="order_asc">Sort By Order No ↑</option>
              <option value="si_desc">Sort By SI No ↓</option>
              <option value="si_asc">Sort By SI No ↑</option>
            </select>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full w-full sm:w-64 bg-white/60 border border-white/50 shadow-sm backdrop-blur-md transition-all focus-within:w-80 focus-within:bg-white focus-within:border-orange-300">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#aaa" strokeWidth="2.5">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
            </svg>
            <input
              type="text"
              placeholder="Search Order #, Date..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-1 bg-transparent outline-none text-sm font-medium text-gray-700 placeholder-gray-400"
            />
            {search && <button onClick={() => setSearch("")} className="text-gray-400 hover:text-gray-700 transition-colors">✕</button>}
          </div>

          <div className="flex items-center p-1 rounded-full bg-white/50 border border-white/40 shadow-sm backdrop-blur-md">
            <button onClick={() => handleViewModeChange('card')} className="flex items-center justify-center w-10 h-8 rounded-full transition-all"
              style={{ background: viewMode === 'card' ? "#f97316" : "transparent", color: viewMode === 'card' ? "#fff" : "#64748b", boxShadow: viewMode === 'card' ? "0 2px 8px rgba(249,115,22,0.3)" : "none" }}>
              <FiGrid size={16} />
            </button>
            <button onClick={() => handleViewModeChange('table')} className="flex items-center justify-center w-10 h-8 rounded-full transition-all"
              style={{ background: viewMode === 'table' ? "#f97316" : "transparent", color: viewMode === 'table' ? "#fff" : "#64748b", boxShadow: viewMode === 'table' ? "0 2px 8px rgba(249,115,22,0.3)" : "none" }}>
              <FiList size={16} />
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto pr-2" style={{ scrollbarWidth: "thin" }}>
          {loading ? (
            <div className="flex flex-col items-center justify-center h-64 gap-4 animate-fade-in">
              <div className="w-10 h-10 border-4 border-orange-200 border-t-orange-500 rounded-full animate-spin" />
              <p className="text-gray-500 font-bold text-xs tracking-widest uppercase">Syncing Transactions...</p>
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 gap-4 animate-fade-in">
              <span style={{ fontSize: 32, opacity: 0.5 }}>🔍</span>
              <p className="text-gray-500 font-bold text-sm tracking-wide uppercase">No orders found{search ? ` for "${search}"` : ""}</p>
            </div>
          ) : viewMode === 'card' ? (
            <div className="grid gap-4 pb-4" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", alignContent: "start" }}>
              {filtered.map((order, idx) => {
                console.log(order);
                const isClosed = currentShiftOpenedAt ? new Date(order.dateISO).getTime() < new Date(currentShiftOpenedAt).getTime() : false;
                return (
                  <OrderCard key={order.kioskNo + order.salesNumber} order={order} index={idx} isClosed={isClosed} onClick={() => setSelectedOrder(order)} />
                );
              })}
            </div>
          ) : (
            <div className="w-full pb-4">
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr className="animate-slide-up" style={{ borderBottom: "2px solid rgba(249,115,22,0.3)", opacity: 0, animationFillMode: "forwards" }}>
                    {["Order #", "SI No.", "Terminal", "Platform", "Items", "Total", "Date", "Payment", "Status", "Action"].map((h, i) => (
                      <th key={i} style={{ fontFamily: "Poppins", textTransform: "uppercase", padding: "12px 8px", textAlign: i >= 7 ? "center" : "left", fontWeight: 900, color: "#f97316", fontSize: 13 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((order, idx) => {
                    const pc = (() => {
                      const p = String(order.platform || 'POS').toLowerCase();
                      switch (p) {
                        case 'grab':   return { bg: 'rgba(34,197,94,0.15)',   color: '#22c55e', border: 'rgba(34,197,94,0.35)'   };
                        case 'mobile': return { bg: 'rgba(6,182,212,0.15)',   color: '#06b6d4', border: 'rgba(6,182,212,0.35)'   };
                        case 'sok':    return { bg: 'rgba(249,115,22,0.15)',   color: '#f97316', border: 'rgba(249,115,22,0.35)'  };
                        case 'pos':    return { bg: 'rgba(168,85,247,0.15)',   color: '#a855f7', border: 'rgba(168,85,247,0.35)'  };
                        default:       return { bg: 'rgba(107,114,128,0.15)', color: '#6b7280', border: 'rgba(107,114,128,0.35)' };
                      }
                    })();
                    return (
                      <tr key={order.salesNumber} className="animate-slide-up"
                        style={{ animationDelay: `${idx * 0.03}s`, opacity: 0, animationFillMode: "forwards", borderBottom: "1px solid rgba(0,0,0,0.07)", background: idx % 2 === 0 ? "rgba(255,255,255,0.05)" : "transparent", transition: "background 0.2s" }}
                        onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(249,115,22,0.1)")}
                        onMouseLeave={(e) => (e.currentTarget.style.background = idx % 2 === 0 ? "rgba(255,255,255,0.05)" : "transparent")}
                      >
                        <td style={{ padding: "12px 8px", fontWeight: 700, color: "#1a1a1a", fontSize: 13 }}>#{order.id}</td>
                        <td style={{ padding: "12px 8px", fontSize: 11, color: "#aaa", fontWeight: 600, fontFamily: "Poppins" }}>{order.salesNumber}</td>
                        <td style={{ padding: "12px 8px" }}>
                          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 10 }}>
                            <span style={{
                              fontFamily: "Poppins",
                              fontSize: 10,
                              fontWeight: 900,
                              letterSpacing: 0.5,
                              padding: '3px 10px',
                              borderRadius: 8,
                              background: 'rgba(168,85,247,0.12)',
                              color: '#a855f7',
                              border: '1px solid rgba(168,85,247,0.30)',
                            }}>
                              T{order.kioskNo ?? '???'}
                            </span>
                          </div>
                        </td>
                        <td style={{ padding: "12px 8px", fontSize: 12 }}>
                          {order.platform && (
                            <span style={{ display: 'inline-block', padding: '4px 10px', borderRadius: '6px', fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, background: pc.bg, color: pc.color, border: `1px solid ${pc.border}` }}>
                              {order.platform}
                            </span>
                          )}
                        </td>
                        <td style={{ padding: "12px 8px", color: "#666", fontSize: 13 }}>{order.items} item{order.items !== 1 ? "s" : ""}</td>
                        <td style={{ padding: "12px 8px", fontWeight: 700, color: "#f97316", fontSize: 13 }}>{order.total.toFixed(2)}</td>
                        <td style={{ padding: "12px 8px", color: "#666", fontSize: 13 }}>{order.date}</td>
                        <td style={{ padding: "12px 8px", fontSize: 12 }}><PaymentBadge method={order.paymentMethod} /></td>
                        <td style={{ padding: "12px 8px", textAlign: "center" }}>
                          <span style={{ display: "inline-block", padding: "4px 8px", borderRadius: "6px", fontSize: 11, fontWeight: 700, color: order.status === 'Completed' ? "#16a34a" : "#ff8c00", background: order.status === 'Completed' ? "rgba(22,163,74,0.12)" : "rgba(255,140,0,0.12)", border: order.status === 'Completed' ? "1px solid rgba(22,163,74,0.25)" : "1px solid rgba(255,140,0,0.25)" }}>
                            {order.status}
                          </span>
                        </td>
                        <td style={{ padding: "12px 8px", textAlign: "center" }}>
                          <button onClick={() => setSelectedOrder(order)}
                            style={{ padding: "6px 12px", borderRadius: "6px", background: "rgba(249,115,22,0.2)", color: "#f97316", border: "1px solid rgba(249,115,22,0.4)", fontSize: 12, fontWeight: 600, cursor: "pointer", transition: "all 0.2s" }}
                            onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(249,115,22,0.3)")}
                            onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(249,115,22,0.2)")}
                          >
                            View
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {selectedOrder && (
        <OrderDetailModal
          order={selectedOrder}
          onClose={() => setSelectedOrder(null)}
          transactionData={transactionDataMap[`${selectedOrder.kioskNo ?? '???'}::${selectedOrder.salesNumber}`]}
          currentShiftOpenedAt={currentShiftOpenedAt}
          currentBusinessDayId={currentBusinessDayId}
          onRefundProcessed={(salesNo) => setOrders(orders.map((o) => o.salesNumber === salesNo ? { ...o, status: 'Refunded' } : o))}
          onVoidProcessed={(salesNo)   => setOrders(orders.map((o) => o.salesNumber === salesNo ? { ...o, status: 'Voided'   } : o))}
          onRecall={() => handleRecallOrder(selectedOrder.id, transactionDataMap[`${selectedOrder.kioskNo ?? '???'}::${selectedOrder.salesNumber}`])}
          setSelectedOrder={setSelectedOrder}
        />
      )}
      {stockValidation?.show && (
        <div className="fixed inset-0 flex items-center justify-center z-[300] animate-fade-in" style={{ background: "rgba(15,23,42,0.82)", backdropFilter: "blur(14px)" }}>
          <div className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden animate-scale-in bg-white shadow-2xl p-7">
            <div className="flex items-center gap-4 mb-5">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center bg-orange-100 text-orange-600 shadow-inner shrink-0">
                <FiAlertTriangle size={24} />
              </div>
              <div>
                <h2 className="text-xl font-bold font-poppins text-gray-900 leading-tight">Stock Limitations</h2>
                <p className="text-xs text-gray-500 font-medium mt-1">Some items lack sufficient stock to be fully recalled.</p>
              </div>
            </div>

            <div className="max-h-64 overflow-y-auto mb-6 pr-2">
              {stockValidation.issues.map((issue, i) => {
               return (   
                    <div key={i} className="mb-3 p-3 rounded-xl border border-gray-200 bg-gray-50 flex justify-between items-center">
                      <span className="font-bold text-sm text-gray-800" style={{ fontFamily: "Poppins" }}>{issue.name}</span>
                      <div className="flex flex-col items-end text-xs font-bold font-poppins shrink-0 pl-4">
                        <span className="text-gray-500">Ordered: {issue.requested}</span>
                        <span className={issue.available === 0 ? "text-red-500" : "text-orange-500"}>
                          Available: {issue.available}
                        </span>
                      </div>
                    </div>
                  )
                }
              )}
            </div>

            <div className="flex gap-3">
              <button onClick={() => setStockValidation(null)} className="flex-1 py-3.5 rounded-xl font-bold bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors">
                Cancel Recall
              </button>
              <button
                onClick={() => {
                  setStockValidation(null);
                  if (stockValidation.adjustedCart.length > 0) {
                    executeRecall(stockValidation.adjustedCart);
                  } else {
                    sileo.error({ title: "Recall Failed", description: "No items have stock available.", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" } });
                  }
                }}
                className="flex-1 py-3.5 rounded-xl font-bold text-white bg-orange-500 hover:bg-orange-600 transition-colors shadow-md"
              >
                Proceed ({stockValidation.adjustedCart.reduce((sum, item) => sum + item.qty, 0)} items)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}