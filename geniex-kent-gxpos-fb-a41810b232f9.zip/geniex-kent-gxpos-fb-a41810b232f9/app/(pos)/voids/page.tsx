/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';
import { useState, useMemo, useEffect } from "react";
import { useRouter } from "next/navigation";
import { FiCreditCard, FiSmartphone, FiGrid, FiList, FiPrinter, FiFileText } from 'react-icons/fi';
import { usePrinter } from '../../context/PrinterContext';

import { getCachedVoidReasons } from '../../../src/api/void-reason';
import { getWorkstationId } from "@/src/lib/workstation";
import { logEJournalEntry } from "@/src/lib/ejournal-client";

const glass = {
  card: {
    background: "rgba(255, 255, 255, 0.25)",
    backdropFilter: "blur(14px)",
    WebkitBackdropFilter: "blur(14px)",
    border: "1px solid rgba(255, 255, 255, 0.45)",
    boxShadow: "0 4px 20px rgba(0,0,0,0.10), inset 0 1px 0 rgba(255,255,255,0.6)",
  } as React.CSSProperties,

  modal: {
    background: "rgba(255, 255, 255, 0.85)",
    backdropFilter: "blur(32px)",
    WebkitBackdropFilter: "blur(32px)",
    border: "1.5px solid rgba(255, 255, 255, 0.95)",
    boxShadow: "0 32px 80px rgba(0,0,0,0.16), inset 0 1px 0 rgba(255,255,255,1), inset 0 -1px 0 rgba(0,0,0,0.03)",
  } as React.CSSProperties,
};

type Order = {
  _id?: string;
  dbId?: string;
  id: string;
  salesNumber: string;
  items: number;
  total: number;
  date: string;
  dateISO: string;
  paymentMethod: string;
  cardLast4: string | null;
  status: string;
  platform?: string;
  voidSeriesNo?: string;
  kioskNo?: string;
};

function PaymentBadge({ method, large = false }: { method: string; large?: boolean }) {
  const getPaymentIcon = (method: string) => {
    switch (method) {
      case 'Visa':
      case 'Mastercard':
      case 'Amex':
        return <FiCreditCard size={14} />;
      case 'Apple Pay':
        return <FiSmartphone size={14} />;
      case 'Cash':
        return null;
      default:
        return null;
    }
  };
  const map: Record<string, { color: string; bg: string; border: string }> = {
    Visa:        { color: "#1a1aff", bg: "rgba(26,26,255,0.07)",  border: "rgba(26,26,255,0.18)"  },
    Mastercard:  { color: "#c0000d", bg: "rgba(235,0,27,0.07)",   border: "rgba(235,0,27,0.18)"   },
    Amex:        { color: "#007bc1", bg: "rgba(0,123,193,0.07)",  border: "rgba(0,123,193,0.18)"  },
    "Apple Pay": { color: "#1a1a1a", bg: "rgba(0,0,0,0.05)",      border: "rgba(0,0,0,0.12)"      },
    Cash:        { color: "#16a34a", bg: "rgba(22,163,74,0.08)",  border: "rgba(22,163,74,0.22)"  },
  };
  const s = map[method] ?? { color: "#555", bg: "rgba(0,0,0,0.05)", border: "rgba(0,0,0,0.12)" };
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full font-bold"
      style={{
        background: s.bg,
        color: s.color,
        border: `1px solid ${s.border}`,
        padding: large ? "6px 14px" : "3px 10px",
        fontSize: large ? 13 : 11,
      }}
    >
      {getPaymentIcon(method) && <span>{getPaymentIcon(method)}</span>} {method}
    </span>
  );
}

function OrderCard({ order, onClick, index, isClosed }: { order: Order; onClick: () => void; index: number; isClosed?: boolean }) {
  const [hovered, setHovered] = useState(false);
  
  const getPlatformBadgeColor = (platform?: string) => {
    const p = String(platform || 'POS').toLowerCase();
    switch (p) {
      case 'grab': return { bg: 'rgba(34, 197, 94, 0.15)', color: '#22c55e', border: 'rgba(34, 197, 94, 0.35)' };
      case 'mobile': return { bg: 'rgba(6, 182, 212, 0.15)', color: '#06b6d4', border: 'rgba(6, 182, 212, 0.35)' };
      case 'sok': return { bg: 'rgba(249, 115, 22, 0.15)', color: '#f97316', border: 'rgba(249, 115, 22, 0.35)' };
      case 'pos': return { bg: 'rgba(168, 85, 247, 0.15)', color: '#a855f7', border: 'rgba(168, 85, 247, 0.35)' };
      default: return { bg: 'rgba(107, 114, 128, 0.15)', color: '#6b7280', border: 'rgba(107, 114, 128, 0.35)' };
    }
  };
  
  const platformColor = getPlatformBadgeColor(order.platform);
  
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="flex flex-col rounded-2xl p-5 text-left w-full focus:outline-none relative animate-slide-up"
      style={{
        animationDelay: `${index * 0.04}s`,
        opacity: 0,
        animationFillMode: "forwards",
        fontFamily: "Poppins",
        textTransform: "uppercase",
        ...glass.card,
        transition: "all 0.2s ease",
        ...(hovered ? {
          background: "rgba(255,255,255,0.42)",
          border: "1px solid rgba(75,85,99,0.50)",
          boxShadow: "0 8px 28px rgba(75,85,99,0.16), inset 0 1px 0 rgba(255,255,255,0.8)",
          transform: "translateY(-3px)",
        } : {}),
      }}
    >
      {isClosed && (
        <div style={{
          position: 'absolute', top: 8, left: 8, padding: '4px 10px', borderRadius: '12px',
          fontSize: 9, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5,
          background: 'rgba(107,114,128,0.15)', color: '#4b5563', border: '1px solid rgba(107,114,128,0.35)'
        }}>
          Closed Transaction
        </div>
      )}

      {order.platform && (
        <div
          style={{
            position: 'absolute', top: 8, right: 8, padding: '4px 10px', borderRadius: '12px', fontSize: 10,
            fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5,
            background: platformColor.bg, color: platformColor.color, border: `1px solid ${platformColor.border}`,
          }}
        >
          {order.platform}
        </div>
      )}
      
      <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 17, fontWeight: 900, color: "#1a1a1a", letterSpacing: 0.5, marginBottom: 4, textAlign: "center" }}>
        Ord# {order.id}
      </p>
      {order.voidSeriesNo && (
        <p style={{ fontFamily: "Poppins", fontSize: 9, fontWeight: 700, color: "#aaa", letterSpacing: 0.8, textAlign: "center", textTransform: "uppercase", marginBottom: 2 }}>
          Void# {order.voidSeriesNo}
        </p>
      )}
      <p style={{ fontFamily: "Poppins", fontSize: 9, fontWeight: 700, color: "#a78bfa", letterSpacing: 0.8, textAlign: "center", textTransform: "uppercase", marginBottom: 10 }}>
        T{order.kioskNo ?? '???'}
      </p>
      <p style={{ fontSize: 13, color: "#4b5563", fontWeight: 900, marginBottom: 10, textAlign: "center" }}>
        {order.total.toFixed(2)}
      </p>
      <p style={{ fontSize: 12, color: "#777", marginBottom: 12, textAlign: "center" }}>{order.date}</p>
      <p style={{ fontSize: 13, color: "#1a1a1a", fontWeight: 700, textAlign: "center" }}>
        {order.items} Item{order.items !== 1 ? "s" : ""}
      </p>
    </button>
  );
}

// ── FIX 1: Added onVoidProcessed callback prop (mirrors onRefundProcessed in refunds page) ──
function OrderDetailModal({
  order,
  onClose,
  transactionData,
  onVoidProcessed,
  selectedDay
}: {
  order: Order;
  onClose: () => void;
  transactionData?: any;
  onVoidProcessed?: (salesNumber: string) => void;
  selectedDay: string;
}) {
  const txType = transactionData?.transactionType || 'REGULAR';
  const { printDirect } = usePrinter();
  const [fiscal, setFiscal] = useState<any>(null);

  useEffect(() => {
    const WORKSTATION_ID = getWorkstationId() || '001';
    fetch(`/api/settings?workstationId=${WORKSTATION_ID}`)
      .then(r => r.json())
      .then(data => setFiscal(data))
      .catch(console.warn);
  }, []);

  // ── Parse items (same logic as refunds page) ──────────────────────────────
  let items: any[] = [];
  try {
    if (transactionData) {
      if (transactionData.orderDetailJSON) {
        const detailJSON = typeof transactionData.orderDetailJSON === 'string'
          ? JSON.parse(transactionData.orderDetailJSON)
          : transactionData.orderDetailJSON;
        if (detailJSON.items) items = detailJSON.items;
      }
      if (!items.length && Array.isArray(transactionData.items)) items = transactionData.items;
    }
  } catch (e) { console.warn('Error parsing items:', e); }

  const handlePrintReceipt = async () => {
    try {
      const { buildReceiptText, normalizeTransactionForReceipt } = await import("@/src/libs/ReceiptPrinting");

      let storeData = JSON.parse(localStorage.getItem("store_data") || "null") || {
        name: "Store", address: "", receiptFormats: [],
      };
      try {
        const res = await fetch("/api/store");
        if (res.ok) {
          const dbData = await res.json();
          storeData = dbData?.payload;
          localStorage.setItem("store_data", JSON.stringify(storeData));
        }
      } catch (fetchErr) {
        console.warn("Failed to fetch store data during print fallback:", fetchErr);
      }
      const receiptFormats   = storeData?.receiptFormats || [];
      const selectedFormatId = '3';
      const receiptFormat    = receiptFormats.find((f: any) => String(f.id) === selectedFormatId)
        || receiptFormats[0]
        || { header: storeData.name || '', footer: 'Thank you!' };

      const receiptData = await normalizeTransactionForReceipt(transactionData, { isVoided: true });
      const text = buildReceiptText({ storeData, receiptFormat, data: receiptData, fiscal });
      if (text && selectedDay) {
        logEJournalEntry({
          businessDayId: selectedDay,
          workstationId: getWorkstationId() || '001',
          entryType: 'REPRINT',
          text,
          transactionId: order.dbId,
        });
      }
      printDirect(text, false);
    } catch (err) {
      console.warn("[PrintReceipt] error:", err);
    }
  };

  return (
    <div
      className="fixed inset-0 flex items-center justify-center z-50 overflow-y-auto animate-fade-in"
      style={{ background: "rgba(160, 150, 145, 0.30)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)" }}
      onClick={onClose}
    >
      <div
        className="rounded-3xl w-full max-w-md mx-4 relative overflow-hidden my-8 shadow-2xl animate-scale-in"
        style={{ ...glass.modal, animationDelay: "0.05s", opacity: 0, animationFillMode: "forwards" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ height: 6, background: "linear-gradient(90deg, #6b7280 0%, #4b5563 60%, #9ca3af 100%)" }} />

        <div className="p-7 max-h-[80vh] overflow-y-auto">
          <button
            onClick={onClose}
            className="absolute top-8 right-7 w-8 h-8 rounded-full flex items-center justify-center font-bold text-base transition-all hover:bg-black/5"
            style={{ background: "rgba(0,0,0,0.05)", color: "#bbb", border: "1px solid rgba(0,0,0,0.07)" }}
          >
            ✕
          </button>

          {/* ── Header ── */}
          <div className="flex items-center gap-4 mb-6">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0"
              style={{
                background: "linear-gradient(135deg, #f3f4f6, #e5e7eb)",
                border: "1.5px solid rgba(107,114,128,0.18)",
                boxShadow: "0 2px 10px rgba(107,114,128,0.10)",
              }}
            >
              <FiFileText size={28} color="#4b5563" />
            </div>
            <div>
              <p style={{ fontSize: 11, color: "#ccc", fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 2 }}>
                Transaction
              </p>
              <h2 style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 26, fontWeight: 900, color: "#1a1a1a", lineHeight: 1 }}>
                Order <span style={{ color: "#4b5563" }}>#{order.id}</span>
              </h2>
              {order.voidSeriesNo && (
                <p style={{ fontFamily: "Poppins", fontSize: 10, fontWeight: 700, color: "#bbb", marginTop: 3, letterSpacing: 0.5 }}>
                  Void# {order.voidSeriesNo}
                </p>
              )}
              <p style={{ fontFamily: "Poppins", fontSize: 10, fontWeight: 700, color: "#a78bfa", marginTop: 2, letterSpacing: 0.5 }}>
                T{order.kioskNo ?? '???'}
              </p>
              <p style={{ fontSize: 12, color: "#bbb", marginTop: 2 }}>{order.date}</p>
            </div>
          </div>

          {/* ── Items ── */}
          <div
            className="rounded-2xl p-4 mb-4"
            style={{ fontFamily: "Poppins", background: "rgba(255,255,255,0.60)", border: "1px solid rgba(0,0,0,0.055)", boxShadow: "0 1px 4px rgba(0,0,0,0.04)" }}
          >
            <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 10, color: "#ccc", marginBottom: 10, letterSpacing: 1.1, fontWeight: 700 }}>
              Items Ordered
            </p>
            {items.length > 0 ? (
              <div className="space-y-3">
                {items.map((item: any, idx: number) => {
                  // ── FIX 2: Use same centavos-based price logic as refunds page ──
                  const rawPrice   = (Number(item.price) || 0) / 100;
                  const qty        = item.quantity || 1;
                  const grossPrice = rawPrice * qty;

                  let itemDiscount = 0;
                  if (item.itemDiscount) {
                    // Per-item discount stored directly (PWD, SC, SRC, etc.)
                    itemDiscount = Number(item.itemDiscount) / 100;
                  } else {
                    // Only spread tx-level discountAmount proportionally when NO item in the
                    // transaction has a per-item itemDiscount. If any item has itemDiscount,
                    // this is a targeted SC/PWD/SRC discount — items without it get 0.
                    const allItems: any[] = transactionData?.items || [];
                    const anyItemHasDiscount = allItems.some(
                      (it: any) => it.itemDiscount != null && Number(it.itemDiscount) > 0
                    );
                    if (!anyItemHasDiscount) {
                      const txDiscountPesos = (transactionData?.discountAmount || 0) / 100;
                      if (txDiscountPesos > 0) {
                        const totalGross = allItems.reduce((sum: number, it: any) => {
                          return sum + ((Number(it.price) || 0) / 100) * (it.quantity || 1);
                        }, 0);
                        const proportion = totalGross > 0 ? grossPrice / totalGross : 0;
                        itemDiscount = txDiscountPesos * proportion;
                      }
                    }
                  }

                  const netPrice = grossPrice - itemDiscount;

                  return (
                    <div
                      key={idx}
                      className="flex justify-between items-start gap-2"
                      style={{ paddingBottom: 10, borderBottom: idx < items.length - 1 ? "1px solid rgba(0,0,0,0.07)" : "none" }}
                    >
                      <div className="flex-1">
                        <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 13, fontWeight: 700, color: "#1a1a1a", marginBottom: 3 }}>
                          {item.itemName || item.name || 'Unknown Item'}
                        </p>
                        {item.modifiers && Object.keys(item.modifiers).length > 0 && (
                          <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 11, color: "#999", marginBottom: 2 }}>
                            {Object.values(item.modifiers).join(", ")}
                          </p>
                        )}
                        <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 12, color: "#4b5563", fontWeight: 600 }}>
                          {itemDiscount > 0.005 ? (
                            <>
                              <span style={{ textDecoration: "line-through", color: "#aaa", marginRight: 6 }}>
                                {grossPrice.toFixed(2)}
                              </span>
                              {netPrice.toFixed(2)}
                            </>
                          ) : (
                            `${grossPrice.toFixed(2)}`
                          )}
                        </p>
                        {itemDiscount > 0.005 && (
                          <p style={{ fontFamily: "Poppins", fontSize: 11, color: "#16a34a", fontWeight: 700, marginTop: 2 }}>
                            − {itemDiscount.toFixed(2)} discount
                          </p>
                        )}
                        {itemDiscount > 0.005 && transactionData?.discountInfo?.label && (
                          <p style={{ fontFamily: "Poppins", fontSize: 10, color: "#9ca3af", fontWeight: 600, marginTop: 1 }}>
                            {transactionData.discountInfo.label}
                            {item.discountID ? ` (${item.discountID}%)` : ''}
                          </p>
                        )}
                      </div>
                      <div
                        className="px-3 py-1 rounded-lg text-center flex-shrink-0"
                        style={{ background: "rgba(107,114,128,0.10)", border: "1px solid rgba(107,114,128,0.20)", minWidth: 50 }}
                      >
                        <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 12, fontWeight: 700, color: "#4b5563" }}>
                          x{qty}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 12, color: "#4b5563", fontWeight: 600, textAlign: "center" }}>
                {order.items} item{order.items !== 1 ? "s" : ""} ordered
              </p>
            )}
          </div>

          {/* ── Payment Details ── */}
          <div
            className="rounded-2xl p-4 mb-4"
            style={{ background: "rgba(255,255,255,0.60)", border: "1px solid rgba(0,0,0,0.055)", boxShadow: "0 1px 4px rgba(0,0,0,0.04)" }}
          >
            <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 10, color: "#ccc", marginBottom: 10, letterSpacing: 1.1, fontWeight: 700 }}>
              Payment Details
            </p>
            <div className="flex items-center justify-between flex-wrap gap-2">
              <PaymentBadge method={order.paymentMethod} large />
              <span
                className="px-3 py-1 rounded-full text-xs font-bold"
                style={{ background: "rgba(107,114,128,0.10)", color: "#4b5563", border: "1px solid rgba(107,114,128,0.20)" }}
              >
                Voided ✕
              </span>
            </div>
          </div>

          {/* ── Order Total ── */}
          <div
            className="rounded-2xl px-5 py-4 mb-6 flex items-center justify-between"
            style={{ background: "linear-gradient(135deg, rgba(107,114,128,0.07) 0%, rgba(156,163,175,0.09) 100%)", border: "1.5px solid rgba(107,114,128,0.16)" }}
          >
            <div>
              <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 10, color: "#4b5563", fontWeight: 700, letterSpacing: 1, opacity: 0.7 }}>
                Order Total
              </p>
              <p style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 12, color: "#aaa", marginTop: 1 }}>
                {order.items} item{order.items !== 1 ? "s" : ""} · {order.paymentMethod}
              </p>
            </div>
            <span style={{ fontFamily: "Impact, Arial Black, sans-serif", fontSize: 30, fontWeight: 900, color: "#4b5563", letterSpacing: 0.5, textDecoration: "line-through" }}>
              {order.total.toFixed(2)}
            </span>
          </div>

          {/* ── Actions ── */}
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="flex-1 rounded-full py-3 text-sm font-bold transition-all hover:brightness-95"
              style={{ fontFamily: "Poppins", textTransform: "uppercase", background: "rgba(0,0,0,0.05)", color: "#888", border: "1px solid rgba(0,0,0,0.08)" }}
            >
              Close
            </button>
            <button
              onClick={handlePrintReceipt}
              className="flex-1 rounded-full py-3 text-sm font-bold text-white transition-all hover:brightness-110 active:scale-95 flex items-center justify-center gap-2"
              style={{ fontFamily: "Poppins", textTransform: "uppercase", background: "linear-gradient(135deg, #f97316 0%, #ea580c 100%)", border: "1px solid rgba(255,255,255,0.25)", boxShadow: "0 4px 18px rgba(75,85,99,0.35)" }}
            >
              <FiPrinter size={16} /> Print Receipt
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

async function syncPendingVoids() {
  if (!navigator.onLine) return;
  const pendingVoids = JSON.parse(localStorage.getItem('pendingVoids') || '[]');
  if (pendingVoids.length === 0) return;
  
  const updatedVoids = [...pendingVoids];
  const toRemove: number[] = [];
  
  for (let i = 0; i < updatedVoids.length; i++) {
    const voidData = updatedVoids[i];
    if (voidData.retryCount >= 3) continue;
    try {
      const apiUrl = `${process.env.NEXT_PUBLIC_API_URL}/transactions/${voidData.transactionId}`;
      const response = await fetch(apiUrl, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'POS-API-KEY': process.env.NEXT_PUBLIC_KEY || '' },
        body: JSON.stringify({ transactionType: voidData.transactionType, remarks: voidData.remarks }),
      });
      if (response.ok) {
        const data = await response.json();
        if (data.status === 'success') {
          try {
            await fetch('/api/transactions', {
              method: 'PATCH',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ id: voidData.transactionId, status: 'voided', voidStatus: 'voided', orderState: 'VOIDED', voidRemarks: voidData.remarks }),
            });
            try {
              await fetch('/api/order-transactions', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: voidData.transactionId, status: 'voided', orderState: 'VOIDED', voidRemarks: voidData.remarks }),
              });
            } catch (cmsErr) {}
          } catch (updateErr) {}
          toRemove.push(i);
        } else { voidData.retryCount++; }
      } else { voidData.retryCount++; }
    } catch (error) { voidData.retryCount++; }
  }
  for (let i = toRemove.length - 1; i >= 0; i--) updatedVoids.splice(toRemove[i], 1);
  localStorage.setItem('pendingVoids', JSON.stringify(updatedVoids));
}

export default function VoidsPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [transactionDataMap, setTransactionDataMap] = useState<Record<string, any>>({});
  const [search, setSearch] = useState("");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'card' | 'table'>('card');
  const [currentShiftOpenedAt, setCurrentShiftOpenedAt] = useState<string | undefined>(undefined);
  type SortMode = 'order_desc' | 'order_asc' | 'series_desc' | 'series_asc';
  const [sortMode, setSortMode] = useState<SortMode>('order_desc');
  const [terminalFilter, setTerminalFilter] = useState<'All' | 'ThisTerminal'>('ThisTerminal');
  const [selectedDate, setSelectedDate] = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  });

  useEffect(() => {
    fetch('/api/cashier-session')
      .then((r) => r.json())
      .then((data) => {
        if (data.active && data.session?.openedAt) {
          setCurrentShiftOpenedAt(data.session.openedAt);
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    fetch('/api/business-day')
      .then(r => r.json())
      .then(d => {
        const bd = d.businessDay;
        if (bd?.date) setSelectedDate(bd.date);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    const savedPref = localStorage.getItem('void_show_type');
    if (savedPref === 'card' || savedPref === 'table') {
      setViewMode(savedPref);
    }
  }, []);

  const handleViewModeChange = (mode: 'card' | 'table') => {
    setViewMode(mode);
    localStorage.setItem('void_show_type', mode);
  };

  useEffect(() => {
      let isMounted = true;
      let abortController = new AbortController();

      const fetchOrders = async () => {
        try {
          if (abortController.signal.aborted) abortController = new AbortController();

          // ── Step 1: get today's business day ─────────────────────────────────
          // Voids page always shows today — no date picker needed.
          let businessDayId: string | null = null;

          try {
            const bdRes = await fetch(`/api/business-day?date=${selectedDate}`, {
              signal: abortController.signal,
            });
            if (bdRes.ok) {
              const bdData = await bdRes.json();
              const bd = bdData?.businessDay;
              if (bd?.businessDayId) {
                businessDayId = bd.businessDayId;
              }
            }
          } catch (e) {
            console.warn('[Voids] business-day fetch error:', e);
          }

          // ── Step 2: get all session IDs under this business day ───────────────
          let allSessionIds: string[] = [];

          if (businessDayId) {
            try {
              const [closedRes, openRes] = await Promise.all([
                fetch(`/api/cashier-session?status=closed&businessDayId=${businessDayId}`, {
                  signal: abortController.signal,
                }),
                fetch(`/api/cashier-session?status=all_open`, {
                  signal: abortController.signal,
                }),
              ]);

              const closedSessions: any[] = closedRes.ok
                ? (await closedRes.json()).sessions || []
                : [];

              const openJson = openRes.ok ? await openRes.json() : {};
              const openSessions: any[] = (openJson.sessions || []).filter(
                (s: any) => s.businessDayId === businessDayId
              );

              const allSessions = [...closedSessions, ...openSessions];
              allSessionIds = allSessions.map((s: any) => s.sessionId).filter(Boolean);
            } catch (e) {
              console.warn('[Voids] session fetch error:', e);
            }
          }

          // ── Step 3: fetch voided transactions scoped to these sessions ─────────
          let allTransactions: any[] = [];

          if (allSessionIds.length > 0) {
            try {
              const sessionParam = encodeURIComponent(allSessionIds.join(','));
              const res = await fetch(
                `/api/transactions?limit=1000&sessionIds=${sessionParam}`,
                { signal: abortController.signal }
              );
              if (res.ok) {
                const data = await res.json();
                const txList: any[] = Array.isArray(data.transactions)
                  ? data.transactions
                  : Array.isArray(data)
                  ? data
                  : [];

                const sessionSet = new Set(allSessionIds);
                allTransactions = txList
                  .filter(
                    (tx: any) =>
                      sessionSet.has(tx.sessionId) &&
                      (tx.status === 'voided' || tx.voidStatus === 'voided')
                  )
                  .map((tx: any) => ({ ...tx, platform: 'POS' }));
              }
            } catch (e) {
              if (e instanceof Error && e.name !== 'AbortError') console.warn(e);
            }
          }

          // Also pull voided non-POS orders (Grab, Mobile, SOK) — these don't
          // have sessionIds so we keep their existing fetch as-is
          try {
            const orderRes = await fetch(
              `/api/order-transactions?limit=500&offset=0`,
              { signal: abortController.signal }
            );
            if (orderRes.ok) {
              const orderData = await orderRes.json();
              const txList: any[] = Array.isArray(orderData.transactions)
                ? orderData.transactions
                : Array.isArray(orderData)
                ? orderData
                : [];
              const voided = txList
                .filter((tx: any) => {
                  if (!(tx.status === 'voided' || tx.voidStatus === 'voided')) return false;
                  // scope to today PHT
                  try {
                    const d = new Date(tx.created_at || tx.createdAt || tx.orderTime || new Date());
                    return d.toLocaleDateString('en-CA', { timeZone: 'Asia/Manila' }) === selectedDate;
                  } catch { return false; }
                })
                .map((tx: any) => ({ ...tx, platform: tx.order_from || 'POS' }));
              allTransactions = allTransactions.concat(voided);
            }
          } catch (e) {
            if (e instanceof Error && e.name !== 'AbortError') console.warn(e);
          }

          if (!isMounted) return;

          if (allTransactions.length === 0) {
            setOrders([]);
            setTransactionDataMap({});
            setLoading(false);
            return;
          }

          // ── Step 4: transform ─────────────────────────────────────────────────
          const transformedOrders: Order[] = allTransactions.map((tx: any) => {
            const itemsCount = Array.isArray(tx.items)
              ? tx.items.reduce((sum: number, item: any) => sum + (Number(item.quantity) || 1), 0)
              : 0;

            let totalAmount = 0;
            if (tx.total_amount) {
              totalAmount = Number(tx.total_amount) || 0;
            } else if (Array.isArray(tx.payment) && tx.payment.length > 0) {
              const paySum = tx.payment.reduce(
                (s: number, p: any) => s + (Number(p.Amount || p.amount) || 0),
                0
              );
              totalAmount = paySum > 0 ? paySum : (tx.price?.eaterPayment || 0);
            } else if (typeof tx.price?.eaterPayment === 'number') {
              totalAmount = tx.price.eaterPayment;
            } else if (typeof tx.totalAmount === 'number') {
              totalAmount = tx.totalAmount;
            } else if (typeof tx.total === 'number') {
              totalAmount = tx.total * 100;
            }

            const dateObj = new Date(tx.created_at || tx.createdAt || tx.orderTime || new Date());
            const dateStr =
              dateObj.toLocaleDateString('en-PH', {
                timeZone: 'Asia/Manila',
                year: 'numeric',
                month: 'short',
                day: 'numeric',
              }) +
              ' ' +
              dateObj.toLocaleTimeString('en-PH', {
                timeZone: 'Asia/Manila',
                hour: '2-digit',
                minute: '2-digit',
              });

            const orderId = String(
              tx.order_number || tx.OrderNo || tx.orderNumber || tx.id || 'UNK'
            ).padStart(4, '0');

            const salesNumber = tx.salesNumber || tx.specialID || String(tx._id || tx.id);
            const voidSeriesNo = tx.voidSeriesNo || tx.voidSeriesNumber || undefined;

            return {
              _id:           String(tx._id || tx.id),
              dbId:          String(tx._id || tx.id),
              id:            orderId,
              salesNumber,
              voidSeriesNo,
              items:         itemsCount,
              total:         totalAmount / 100,
              date:          dateStr,
              dateISO:       dateObj.toISOString(),
              paymentMethod: tx.payment_type || tx.paymentMethod || 'Cash',
              cardLast4:     null,
              status:        'Voided',
              platform:      tx.platform || tx.order_from || 'POS',
              kioskNo:       String(tx.KioskNo || tx.terminalId || tx.workstationId || '???'),
            };
          });

          // ── Step 5: sort + deduplicate ────────────────────────────────────────
          transformedOrders.sort(
            (a, b) => new Date(b.dateISO).getTime() - new Date(a.dateISO).getTime()
          );

          const uniqueOrders: Order[] = [];
          const seenIds = new Set<string>();
          for (const o of transformedOrders) {
            const dedupeKey = `${o.kioskNo ?? ''}::${o.salesNumber}`;
            if (!seenIds.has(dedupeKey)) {
              seenIds.add(dedupeKey);
              uniqueOrders.push(o);
            }
          }

          // ── Step 6: build data map ────────────────────────────────────────────
          const dataMap: Record<string, any> = {};
          allTransactions.forEach((tx: any) => {
            const kioskNo = String(tx.KioskNo || tx.terminalId || tx.workstationId || '???');
            const sn = tx.salesNumber || tx.specialID || String(tx._id || tx.id);
            dataMap[`${kioskNo}::${sn}`] = tx;
          });

          if (isMounted) {
            setOrders(uniqueOrders);
            setTransactionDataMap(dataMap);
            setLoading(false);
          }
        } catch (error) {
          if (error instanceof Error && error.name === 'AbortError') return;
          console.warn('[Voids] unexpected error:', error);
          if (isMounted) setLoading(false);
        }
      };

      setLoading(true);
      fetchOrders();
      const interval = setInterval(fetchOrders, 30000);

      return () => {
        isMounted = false;
        abortController.abort();
        clearInterval(interval);
      };
    }, [selectedDate]);

  useEffect(() => {
    if (navigator.onLine) syncPendingVoids();
    const handleOnline = () => syncPendingVoids();
    window.addEventListener('online', handleOnline);
    const syncInterval = setInterval(() => syncPendingVoids(), 5000);
    return () => { window.removeEventListener('online', handleOnline); clearInterval(syncInterval); };
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const currentTerminalId = getWorkstationId() || '001';

    // No more isToday check — fetchOrders already scopes to today's business day
    const target = orders.filter((o) => {
      try {
        if (terminalFilter === 'ThisTerminal') {
          const txData = transactionDataMap[`${o.kioskNo ?? '???'}::${o.salesNumber}`];
          const txTerminal = txData?.KioskNo || txData?.terminalId || txData?.workstationId;
          if (txTerminal && String(txTerminal) !== String(currentTerminalId)) return false;
        }
        return true;
      } catch { return false; }
    });

    const searched = !q
      ? target
      : target.filter((o) =>
          o.id.toLowerCase().includes(q) ||
          o.date.toLowerCase().includes(q) ||
          o.paymentMethod.toLowerCase().includes(q) ||
          String(o.total).includes(q) ||
          (o.voidSeriesNo || '').toLowerCase().includes(q)
        );

    return [...searched].sort((a, b) => {
      switch (sortMode) {
        case 'order_asc':  return a.id.localeCompare(b.id, undefined, { numeric: true });
        case 'order_desc': return b.id.localeCompare(a.id, undefined, { numeric: true });
        case 'series_asc': return (a.voidSeriesNo || '').localeCompare(b.voidSeriesNo || '', undefined, { numeric: true });
        case 'series_desc': return (b.voidSeriesNo || '').localeCompare(a.voidSeriesNo || '', undefined, { numeric: true });
        default: return 0;
      }
    });
  }, [search, orders, sortMode, terminalFilter, transactionDataMap]);

  return (
    <div
      className="flex flex-col w-full h-full overflow-hidden select-none p-6 animate-fade-in"
      style={{ fontFamily: "'Poppins', Impact, Arial, sans-serif" }}
    >
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes slideUpFade {
          from { opacity: 0; transform: translateY(15px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.97); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-slide-up { animation: slideUpFade 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        .animate-fade-in { animation: fadeIn 0.3s ease-out forwards; }
        .animate-scale-in { animation: scaleIn 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
      `}} />

      <div className="flex flex-col xl:flex-row items-start xl:items-center justify-between gap-4 mb-6 flex-shrink-0 animate-slide-up" style={{ animationDelay: '0.05s', opacity: 0, animationFillMode: "forwards" }}>
        
        <div className="flex items-center gap-4">
          <h1 style={{ fontFamily: "Poppins", textTransform: "uppercase", fontSize: 32, fontWeight: 900, color: "#1a1a1a", letterSpacing: 1.5, textShadow: "0 2px 4px rgba(255,255,255,0.5)", lineHeight: 1 }}>
            Voided Transactions
          </h1>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/60 border border-white/40 shadow-sm" style={{ backdropFilter: "blur(10px)" }}>
            <span className="flex items-center justify-center min-w-[24px] h-6 px-1.5 rounded-full bg-gray-100 text-gray-600 text-xs font-black border border-gray-200">
              {filtered.length}
            </span>
            <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Records</span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">

          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/60 border border-white/50 shadow-sm backdrop-blur-md">
            <select
              value={terminalFilter}
              onChange={(e) => setTerminalFilter(e.target.value as 'All' | 'ThisTerminal')}
              className="bg-transparent outline-none text-sm font-bold cursor-pointer"
              style={{ fontFamily: "Poppins", color: "#4b5563" }}
            >
              <option value="All">All Terminals</option>
              <option value="ThisTerminal">This Terminal Only</option>
            </select>
          </div>

          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/60 border border-white/50 shadow-sm backdrop-blur-md transition-all focus-within:bg-white focus-within:border-gray-300">
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent outline-none text-sm font-bold text-gray-700"
              style={{ fontFamily: "Poppins", color: "#4b5563" }}
            />
          </div>

          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/60 border border-white/50 shadow-sm backdrop-blur-md">
            <select
              value={sortMode}
              onChange={(e) => setSortMode(e.target.value as SortMode)}
              className="bg-transparent outline-none text-sm font-bold cursor-pointer"
              style={{ fontFamily: "Poppins", color: "#4b5563" }}
            >
              <option value="order_desc">Sort By Order No ↓</option>
              <option value="order_asc">Sort By Order No ↑</option>
              <option value="series_desc">Sort By Void Series No ↓</option>
              <option value="series_asc">Sort By Void Series No ↑</option>
            </select>
          </div>

          <div className="flex items-center gap-2 px-4 py-2 rounded-full w-full sm:w-64 bg-white/60 border border-white/50 shadow-sm backdrop-blur-md transition-all focus-within:w-80 focus-within:bg-white focus-within:border-gray-300">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#aaa" strokeWidth="2.5">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
            </svg>
            <input
              type="text"
              placeholder="Search Order #, Date..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-1 bg-transparent outline-none text-sm font-medium text-gray-700 placeholder-gray-400"
            />
            {search && <button onClick={() => setSearch("")} className="text-gray-400 hover:text-gray-700 transition-colors">✕</button>}
          </div>

          <div className="flex items-center p-1 rounded-full bg-white/50 border border-white/40 shadow-sm backdrop-blur-md">
            <button
              onClick={() => handleViewModeChange('card')}
              className="flex items-center justify-center w-10 h-8 rounded-full transition-all"
              style={{
                background: viewMode === 'card' ? "#4b5563" : "transparent",
                color: viewMode === 'card' ? "#fff" : "#64748b",
                boxShadow: viewMode === 'card' ? "0 2px 8px rgba(75,85,99,0.3)" : "none"
              }}
            >
              <FiGrid size={16} />
            </button>
            <button
              onClick={() => handleViewModeChange('table')}
              className="flex items-center justify-center w-10 h-8 rounded-full transition-all"
              style={{
                background: viewMode === 'table' ? "#4b5563" : "transparent",
                color: viewMode === 'table' ? "#fff" : "#64748b",
                boxShadow: viewMode === 'table' ? "0 2px 8px rgba(75,85,99,0.3)" : "none"
              }}
            >
              <FiList size={16} />
            </button>
          </div>

        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto pr-2" style={{ scrollbarWidth: "thin" }}>
          
          {loading ? (
            <div className="flex flex-col items-center justify-center h-64 gap-4 animate-fade-in">
               <div className="w-10 h-10 border-4 border-gray-200 border-t-gray-500 rounded-full animate-spin" />
               <p className="text-gray-500 font-bold text-xs tracking-widest uppercase">Syncing Transactions...</p>
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 gap-4 animate-fade-in">
              <span style={{ fontSize: 32, opacity: 0.5 }}>🔍</span>
              <p className="text-gray-500 font-bold text-sm tracking-wide uppercase">
                No voids found{search ? ` for "${search}"` : ""}
              </p>
            </div>
          ) : viewMode === 'card' ? (
            <div className="grid gap-4 pb-4" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", alignContent: "start" }}>
              {filtered.map((order, idx) => {
                const isClosed = currentShiftOpenedAt
                  ? new Date(order.dateISO).getTime() < new Date(currentShiftOpenedAt).getTime()
                  : false;
                return (
                  // ── FIX 5: Consistent composite key for React key prop ──
                  <OrderCard key={order.kioskNo + order.salesNumber} order={order} index={idx} isClosed={isClosed} onClick={() => setSelectedOrder(order)} />
                );
              })}
            </div>
          ) : (
            <div className="w-full pb-4">
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr className="animate-slide-up" style={{ borderBottom: "2px solid rgba(75,85,99,0.3)", opacity: 0, animationFillMode: "forwards" }}>
                    {["Order #", "Void Series", "Terminal", "Platform", "Items", "Total", "Date", "Payment", "Action"].map((h, i) => (
                      <th key={i} style={{ fontFamily: "Poppins", textTransform: "uppercase", padding: "12px 8px", textAlign: i >= 8 ? "center" : "left", fontWeight: 900, color: "#4b5563", fontSize: 13 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((order, idx) => {
                    const pc = (() => {
                      const p = String(order.platform || 'POS').toLowerCase();
                      switch (p) {
                        case 'grab':   return { bg: 'rgba(34,197,94,0.15)',   color: '#22c55e', border: 'rgba(34,197,94,0.35)'   };
                        case 'mobile': return { bg: 'rgba(6,182,212,0.15)',   color: '#06b6d4', border: 'rgba(6,182,212,0.35)'   };
                        case 'sok':    return { bg: 'rgba(249,115,22,0.15)',   color: '#f97316', border: 'rgba(249,115,22,0.35)'  };
                        case 'pos':    return { bg: 'rgba(168,85,247,0.15)',   color: '#a855f7', border: 'rgba(168,85,247,0.35)'  };
                        default:       return { bg: 'rgba(107,114,128,0.15)', color: '#6b7280', border: 'rgba(107,114,128,0.35)' };
                      }
                    })();
                    return (
                      // ── FIX 6: Consistent composite key for table rows ──
                      <tr
                        key={order.kioskNo + order.salesNumber}
                        className="animate-slide-up"
                        style={{
                          animationDelay: `${idx * 0.03}s`,
                          opacity: 0,
                          animationFillMode: "forwards",
                          borderBottom: "1px solid rgba(0,0,0,0.07)",
                          background: idx % 2 === 0 ? "rgba(255,255,255,0.05)" : "transparent",
                          transition: "background 0.2s"
                        }}
                        onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(75,85,99,0.1)")}
                        onMouseLeave={(e) => (e.currentTarget.style.background = idx % 2 === 0 ? "rgba(255,255,255,0.05)" : "transparent")}
                      >
                        <td style={{ padding: "12px 8px", fontWeight: 700, color: "#1a1a1a", fontSize: 13 }}>#{order.id}</td>
                        <td style={{ padding: "12px 8px", fontSize: 11, color: "#aaa", fontWeight: 600, fontFamily: "Poppins" }}>
                          {order.voidSeriesNo || '—'}
                        </td>
                        <td style={{ padding: "12px 8px" }}>
                          <span style={{ display: 'inline-block', padding: '4px 10px', borderRadius: '6px', fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, background: 'rgba(167,139,250,0.12)', color: '#a78bfa', border: '1px solid rgba(167,139,250,0.28)' }}>
                            T{order.kioskNo ?? '???'}
                          </span>
                        </td>
                        <td style={{ padding: "12px 8px", fontSize: 12 }}>
                          {order.platform && (
                            <span style={{ display: 'inline-block', padding: '4px 10px', borderRadius: '6px', fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, background: pc.bg, color: pc.color, border: `1px solid ${pc.border}` }}>
                              {order.platform}
                            </span>
                          )}
                        </td>
                        <td style={{ padding: "12px 8px", color: "#666", fontSize: 13 }}>{order.items} item{order.items !== 1 ? "s" : ""}</td>
                        <td style={{ padding: "12px 8px", fontWeight: 700, color: "#4b5563", fontSize: 13, textDecoration: "line-through" }}>{order.total.toFixed(2)}</td>
                        <td style={{ padding: "12px 8px", color: "#666", fontSize: 13 }}>{order.date}</td>
                        <td style={{ padding: "12px 8px", fontSize: 12 }}><PaymentBadge method={order.paymentMethod} /></td>
                        <td style={{ padding: "12px 8px", textAlign: "center" }}>
                          <button
                            onClick={() => setSelectedOrder(order)}
                            style={{ padding: "6px 12px", borderRadius: "6px", background: "rgba(75,85,99,0.1)", color: "#4b5563", border: "1px solid rgba(75,85,99,0.3)", fontSize: 12, fontWeight: 600, cursor: "pointer", transition: "all 0.2s" }}
                            onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(75,85,99,0.2)"; }}
                            onMouseLeave={(e) => { e.currentTarget.style.background = "rgba(75,85,99,0.1)"; }}
                          >
                            View
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {selectedOrder && (
        <OrderDetailModal
          order={selectedOrder}
          onClose={() => setSelectedOrder(null)}
          // ── FIX 7: Use compound key `kioskNo::salesNumber` — matches how dataMap was built ──
          transactionData={transactionDataMap[`${selectedOrder.kioskNo ?? '???'}::${selectedOrder.salesNumber}`]}
          onVoidProcessed={(salesNumber) => {
            setOrders(orders.map(o => o.salesNumber === salesNumber ? { ...o, status: 'Voided' } : o));
          }}
          selectedDay={selectedDate}
        />
      )}
    </div>
  );
}