"use client";
import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { getCachedAssociates, type Associate } from "@/src/api/associates";
import { Delete } from "lucide-react";
import { Avatar } from "../(pos)/layout";
import { getWorkstationId } from "@/src/lib/workstation";
import { sileo, Toaster } from "sileo";
import { KeyboardInput } from "../components/KeyboardInput";

const PinBtn = ({ onClick, className = "", children, danger = false, success = false }: any) => (
  <button
    onClick={onClick}
    className={`rounded-2xl backdrop-blur-md border text-2xl font-bold flex items-center justify-center transition-all duration-200 active:scale-95 hover:brightness-110 shadow-sm
      ${danger ? "bg-white/30 border-white/40 text-red-500" : success ? "bg-green-500/90 border-green-400 text-white" : "bg-white/40 border-white/50 text-black"} ${className}`}
  >
    {children}
  </button>
);

// Fades + slides its children in whenever `key` changes on it, used to
// animate the swap between the PIN pad and the email/password form.
const FadeIn = ({ children }: { children: React.ReactNode }) => {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const raf = requestAnimationFrame(() => setVisible(true));
    return () => cancelAnimationFrame(raf);
  }, []);
  return (
    <div
      className="w-full transition-all duration-300 ease-out"
      style={{ opacity: visible ? 1 : 0, transform: visible ? "translateY(0px)" : "translateY(10px)" }}
    >
      {children}
    </div>
  );
};

// Stable DOM id so we can imperatively re-focus the email field after the
// on-screen keyboard portal (rendered outside this input) steals native focus.
const EMAIL_INPUT_ID = "login-email-input";
const PASSWORD_INPUT_ID = "login-password-input";

export default function UserSelect() {
  
  const SLOT = 110;
  const router = useRouter();
  const [associates, setAssociates] = useState<Associate[]>([]);
  const [allAssociates, setAllAssociates] = useState<Associate[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [showPinPad, setShowPinPad] = useState(false);
  const [pin, setPin] = useState("");
  const [pinError, setPinError] = useState("");
  
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Which login field is logically "active" — drives a manual focus ring and
  // lets us re-assert real focus, independent of the on-screen keyboard
  // occasionally stealing native DOM focus while the user types.
  const [activeField, setActiveField] = useState<"email" | "password" | null>(null);

  // Mirrors selectedId === -1 but only flips *after* selectedId changes, so we
  // can key a FadeIn wrapper on it and get a transition between the PIN pad
  // and the email/password form instead of an instant swap.
  const [mode, setMode] = useState<"pin" | "others">(selectedId === -1 ? "others" : "pin");

  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [storeData, setStoreData] = useState<any>(null);
  const [businessDayDate, setBusinessDayDate] = useState<string | null>(null);
  const [isOnline, setIsOnline] = useState(true);
  const [completedTerminals, setCompletedTerminals] = useState<string[]>([]);
  const [zReadingType, setZReadingType] = useState<"Consolidated" | "Per Terminal" | "Both">("Consolidated");

  const currentTerminal = getWorkstationId() || '001';
  const isTerminalCompleted = completedTerminals.includes(currentTerminal);

  // ── Drag state ────────────────────────────────────────────────────────────
  const [dragOffset, setDragOffset]   = useState(0);       // live px offset while finger is down
  const [isDragging, setIsDragging]   = useState(false);
  const dragStartY                    = useRef<number | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);

  const logoClickCount = useRef(0);
  const logoClickTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleLogoClick = () => {
    logoClickCount.current += 1;
    if (logoClickTimer.current) clearTimeout(logoClickTimer.current);
    logoClickTimer.current = setTimeout(() => { logoClickCount.current = 0; }, 600);
    if (logoClickCount.current >= 3) {
      logoClickCount.current = 0;
      router.push("/settings");
    }
  };

  useEffect(() => {
    localStorage.removeItem("managerBypass");
    localStorage.removeItem("currentUser");
    localStorage.removeItem("sessionToken");

    (async () => {
      try {
        const data = await getCachedAssociates();
        if (data && data.length > 0) {
          setAllAssociates(data);
          
          const visibleAssociates = data.filter((a: Associate) => a.user.role !== 1);
          const othersDummy = {
            id: -1, user_id: -1, store_id: 1, created_at: "", updated_at: "",
            user: { id: -1, name: "Others", email: "", pin: "", avatar: "", role: 0, created_at: "", updated_at: "" }
          } as Associate;
          
          setAssociates([...visibleAssociates, othersDummy]);

          try {
            const lastLogin = JSON.parse(localStorage.getItem("lastLogin") || "{}");
            if (lastLogin?.user_id && visibleAssociates.some((a: Associate) => a.user_id === lastLogin.user_id)) {
              setSelectedId(lastLogin.user_id);
              setShowPinPad(true);
            }
          } catch {}
        }
        try {
          const res = await fetch("/api/store");
          if (res.ok) {
            const dbData = await res.json();
            setStoreData(dbData?.payload);
            localStorage.setItem("store_data", JSON.stringify(dbData?.payload));
          }
        } catch {}
        try {
          const res = await fetch("/api/cashier-session?status=all_open");
          if (res.ok) {
            const d = await res.json();
            setBusinessDayDate(d.businessDayDate ?? null);
            setCompletedTerminals(d.completedTerminals || []);
          }
        } catch {}
        try {
          const res = await fetch(`/api/settings?workstationId=${getWorkstationId() || '001'}`);
          if (res.ok) {
            const d = await res.json();
            if (d.zReadingType) setZReadingType(d.zReadingType);
          }
        } catch {}
      } catch (e) {
        console.error("Error loading associates:", e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent | TouchEvent) => {
      const target = e.target as Element;
      // Prevent closing if clicking on the GlobalKeyboard portal
      if (target.closest('#global-keyboard-wrapper') || target.closest('.hg-theme-default')) {
        return;
      }
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowPinPad(false);
        setPin("");
        setPinError("");
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("touchstart", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("touchstart", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    const poll = async () => {
      try {
        const res = await fetch("/api/cashier-session?status=all_open");
        if (res.ok) {
          const d = await res.json();
          setBusinessDayDate(d.businessDayDate ?? null);
          setCompletedTerminals(d.completedTerminals || []);
        }
      } catch {}
    };
    const interval = setInterval(poll, 5000);
    return () => clearInterval(interval);
  }, []);

  // Keep `mode` in sync with selectedId, so the FadeIn wrapper below only
  // remounts (and therefore animates) when we actually cross between the
  // PIN pad and the "Others" email/password form.
  useEffect(() => {
    setMode(selectedId === -1 ? "others" : "pin");
  }, [selectedId]);

  // Clear the manual focus-ring state whenever we leave the email/password
  // form, so it doesn't linger stale when the PIN pad is shown again.
  useEffect(() => {
    if (mode === "pin") setActiveField(null);
  }, [mode]);

  // Re-assert real focus on the email field after every keystroke coming
  // from the on-screen keyboard, since tapping its (portal-rendered) keys
  // can otherwise blur the underlying <input>.
  useEffect(() => {
    if (activeField !== "email") return;
    const el = document.getElementById(EMAIL_INPUT_ID) as HTMLInputElement | null;
    if (el && document.activeElement !== el) el.focus({ preventScroll: true });
  }, [email, activeField]);

  const activeIdx = selectedId !== null
    ? associates.findIndex((a) => a.user_id === selectedId)
    : associates.length > 0 ? Math.floor(associates.length / 2) : 0;

  const selectedAssociate = associates[activeIdx] ?? null;
  const virtualCenter = isDragging ? activeIdx - dragOffset / SLOT : activeIdx;


  // ── During drag, compute which slot the finger is hovering over ───────────
  const dragSteps      = isDragging ? Math.round(-dragOffset / SLOT) : 0;
  const visualActiveIdx = Math.max(0, Math.min(associates.length - 1, activeIdx + dragSteps));

  // ── Touch handlers ────────────────────────────────────────────────────────
  const handleTouchStart = (e: React.TouchEvent) => {
    dragStartY.current = e.targetTouches[0].clientY;
    setIsDragging(true);
    setDragOffset(0);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (dragStartY.current === null) return;
    const raw = e.targetTouches[0].clientY - dragStartY.current;

    // Soft-clamp at list boundaries so it doesn't scroll into blank space
    const maxDrag =  activeIdx * SLOT;
    const minDrag = -(associates.length - 1 - activeIdx) * SLOT;
    const clamped  = Math.max(minDrag, Math.min(maxDrag, raw));
    setDragOffset(clamped);
  };

  const handleTouchEnd = () => {
    if (dragStartY.current === null) return;

    const steps  = Math.round(-dragOffset / SLOT);
    const newIdx = Math.max(0, Math.min(associates.length - 1, activeIdx + steps));

    setSelectedId(associates[newIdx].user_id);
    setShowPinPad(true);
    setPin("");
    setEmail("");
    setPassword("");
    setPinError("");
    setActiveField(null);

    // Reset drag — transition re-enables automatically (isDragging → false)
    setDragOffset(0);
    setIsDragging(false);
    dragStartY.current = null;
  };

  const handleEmailLogin = async () => {
    if (isLoggingIn) return;
    setPinError("");


    if (!email || !password) return setPinError("Fill all fields");

    const accUser = allAssociates.find((a: Associate) => a.user.role === 1 && a.user.email.toLowerCase() === email.toLowerCase());

    if (!accUser || accUser.user.pin !== password) {
       setPinError("Invalid credentials");
       return;
    }

    if (isTerminalCompleted && accUser.user.role !== 2) {
      setPinError("EOD COMPLETED");
      return;
    }

    setIsLoggingIn(true);
    try {
      const res = await fetch("/api/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: String(accUser.user_id),
          name: accUser.user.name,
          email: accUser.user.email,
          role: accUser.user.role,
          avatar: accUser.user.avatar,
          terminalId: getWorkstationId() || '001',
        }),
      });
      if (!res.ok) {
        const errData = await res.json();
        if (res.status === 409 && errData.code === 'CROSS_TERMINAL_SESSION') {
          sileo.error({
            title: "CROSS_TERMINAL_SESSION",
            description: `Register open on terminal ${errData.existingSession?.terminalId || 'another terminal'}. Close it first.`,
            fill: "#171717",
            styles: { title: "text-white! font-[Poppins]!", description: "text-white/75! font-[Poppins]!" }
          });
          return;
        }
        setPinError("API Error");
        return;
      }
      const sessionData = await res.json();
      localStorage.setItem("sessionToken", sessionData.sessionToken);
      const userData = {
        id: accUser.user_id,
        user_id: accUser.user_id,
        name: accUser.user.name,
        email: accUser.user.email,
        role: accUser.user.role,
        avatar: accUser.user.avatar,
        loginTime: new Date().toISOString(),
      };
      localStorage.setItem("lastLogin", JSON.stringify(userData));
      localStorage.setItem("currentUser", JSON.stringify(userData));
      localStorage.setItem("managerBypass", "true");
      
      setEmail(""); setPassword(""); setPinError(""); setShowPinPad(false); setActiveField(null);
      router.push("/dashboard");
    } catch {
      setPinError("Network Error");
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handlePinInput = async (val: string) => {
    if (isLoggingIn) return;
    setPinError("");
    if (val === "del") return setPin((p) => p.slice(0, -1));
    if (val !== "enter" && pin.length < 4) return setPin((p) => p + val);
    if (val === "enter") {
      
      
      if (!selectedAssociate) return setPinError("No user selected");
      if (pin !== selectedAssociate.user.pin) {
        setPinError("Incorrect PIN");
        return setPin("");
      }

      
      if (isTerminalCompleted && selectedAssociate.user.role !== 2) {
        setPinError("EOD COMPLETED");
        setPin("");
        return;
      }
      setIsLoggingIn(true);
      try {
        const res = await fetch("/api/sessions", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            userId: String(selectedAssociate.user_id),
            name: selectedAssociate.user.name,
            email: selectedAssociate.user.email,
            role: selectedAssociate.user.role,
            avatar: selectedAssociate.user.avatar,
            terminalId: getWorkstationId() || '001',
          }),
        });
        if (!res.ok) {
          const errData = await res.json();
          if (res.status === 409 && errData.code === 'CROSS_TERMINAL_SESSION') {
            sileo.error({
              title: "CROSS_TERMINAL_SESSION",
              description: `Register open on terminal ${errData.existingSession?.terminalId || 'another terminal'}. Close it first.`,
              fill: "#171717",
              styles: {
                title: "text-white! font-[Poppins]!",
                description: "text-white/75! font-[Poppins]!",
              }
            });
            setPin("");
            return;
          }
          setPinError("API Error");
          setPin("");
          return;
        }
        const sessionData = await res.json();
        localStorage.setItem("sessionToken", sessionData.sessionToken);
        const userData = {
          id: selectedAssociate.user_id,
          user_id: selectedAssociate.user_id,
          name: selectedAssociate.user.name,
          email: selectedAssociate.user.email,
          role: selectedAssociate.user.role,
          avatar: selectedAssociate.user.avatar,
          loginTime: new Date().toISOString(),
        };
        localStorage.setItem("lastLogin", JSON.stringify(userData));
        localStorage.setItem("currentUser", JSON.stringify(userData));
        setPin(""); setPinError(""); setShowPinPad(false);
        router.push("/dashboard");
      } catch {
        setPinError("Network Error"); setPin("");
      } finally {
        setIsLoggingIn(false);
      }
    }
  };

  if (loading) {
    return (
      <div className="relative flex items-center justify-center w-screen h-screen overflow-hidden">
        <img src="/images/logbg.jpg" alt="bg" className="absolute inset-0 w-full h-full object-cover blur-sm brightness-90" />
        <div className="relative z-10 text-white text-xl font-bold tracking-widest uppercase animate-pulse">Loading...</div>
      </div>
    );
  }


  return (
    <>
      <Toaster position="top-center" />
      <div className="relative flex w-screen h-screen overflow-hidden select-none" style={{ fontFamily: "Poppins, sans-serif" }}>

        <img src="/images/logbg.jpg" alt="background" className="absolute inset-0 w-full h-full object-cover blur-[2px] brightness-[0.95]" />

        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-20 cursor-pointer" onClick={handleLogoClick}>
          <img src="/images/logo.svg" alt="Logo" className="h-12 object-contain drop-shadow-md" />
        </div>

        <div ref={containerRef} className="relative z-10 flex items-center justify-center w-full h-full gap-16">

          {/* ── Avatar drum-roll ─────────────────────────────────────────── */}
          <div
            className="relative flex flex-col items-center overflow-visible cursor-grab active:cursor-grabbing"
            style={{ width: 220, height: `${SLOT * 5}px` }}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            {associates.map((assoc, idx) => {
              const offset         = idx - activeIdx;

              // Continuous distance from the live drag position (float, not snapped)
              const dist           = Math.abs(idx - virtualCenter);

              // Scale lerps 1.0 → 1.5 as dist approaches 0
              const continuousScale   = 1 + Math.max(0, 1 - dist) * 0.5;

              // Opacity fades out gradually with distance
              const continuousOpacity = Math.max(0.15, 1 - dist * 0.4);

              // Only snap the orange ring highlight (single pixel, barely noticeable mid-drag)
              const isHighlighted  = idx === Math.round(virtualCenter);
              const isVisible      = dist <= 2.5;

              return (
                <div
                  key={assoc.user_id}
                  className="absolute flex flex-row items-center gap-4 justify-start"
                  style={{
                    top:        "50%",
                    willChange: "transform, opacity",   // hint GPU layer
                    // Disable transition while finger is down → silky 1:1 tracking
                    // Re-enable on release → spring snap feels natural
                    transition: isDragging
                      ? "none"
                      : "transform 500ms cubic-bezier(0.25,1,0.5,1), opacity 500ms ease",
                    transform:     `translateY(calc(-50% + ${offset * SLOT + dragOffset}px)) scale(${continuousScale})`,
                    zIndex:        10 - Math.round(dist),
                    opacity:       isVisible ? continuousOpacity : 0,
                    pointerEvents: isVisible ? "auto" : "none",
                  }}
                >
                  <button
                    onClick={() => {
                      if (selectedId === assoc.user_id && showPinPad) {
                        setShowPinPad(false);
                      } else {
                        setSelectedId(assoc.user_id);
                        setShowPinPad(true);
                      }
                      setPin("");
                      setEmail("");
                      setPassword("");
                      setPinError("");
                      setActiveField(null);
                    }}
                    className={`rounded-full overflow-hidden shadow-lg flex-shrink-0
                      ${isHighlighted
                        ? "border-[3px] border-[#f97316] shadow-xl"
                        : "border-[3px] border-gray-400 opacity-90 hover:opacity-100 hover:border-gray-300"}`}
                    style={{ width: 64, height: 64 }}
                  >
                    <Avatar src={assoc.user.avatar} alt={assoc.user.name} className="w-full h-full object-cover" />
                  </button>
                  <span className={`text-[11px] font-bold tracking-wide whitespace-nowrap drop-shadow-md
                    ${isHighlighted ? "text-[#f97316]" : "text-black opacity-90"}`}>
                    {assoc.user.name.split(" ")[0]}
                  </span>
                </div>
              );
            })}
          </div>

          {/* ── PIN pad / login form ─────────────────────────────────────── */}
          <div
            className="flex flex-col items-center gap-5 transition-all duration-500 ease-[cubic-bezier(0.25,1,0.5,1)] overflow-hidden"
            style={{
              width: showPinPad ? 310 : 0,
              opacity: showPinPad ? 1 : 0,
              pointerEvents: showPinPad ? "auto" : "none",
            }}
          >
            {/* Keying FadeIn on `mode` makes it remount (and therefore
                fade + slide in) whenever we cross between the PIN pad and
                the "Others" email/password form. */}
            <FadeIn key={mode}>
              {mode === "others" ? (
                <div className="flex flex-col items-center gap-3 w-[310px]">
                  <div className={`w-full h-[60px] flex items-center justify-center rounded-2xl backdrop-blur-xl font-black tracking-[0.1em] text-lg transition-colors shadow-sm mb-2
                    ${pinError ? "bg-red-100/90 border-2 border-red-400 text-red-600" : "bg-white/50 border border-white/60 text-black"}`}>
                    {isLoggingIn ? "VERIFYING" : pinError ? pinError.toUpperCase() : "ACCOUNTING LOGIN"}
                  </div>
                  <KeyboardInput
                    id={EMAIL_INPUT_ID}
                    type="email"
                    keyboardLayout="email"
                    placeholder="Email Address"
                    value={email}
                    onChange={setEmail}
                    onFocus={() => setActiveField("email")}
                    className={`w-full h-[60px] px-4 rounded-2xl bg-white/50 border text-black outline-none font-bold text-center placeholder-gray-500 shadow-sm shrink-0 transition-all duration-200
                      ${activeField === "email" ? "border-[#f97316] ring-4 ring-[#f97316]/30" : "border-white/60"}`}
                    style={{ fontFamily: "Poppins" }}
                  />
                  <KeyboardInput
                    id={PASSWORD_INPUT_ID}
                    type="password"
                    keyboardLayout="default"
                    placeholder="Password"
                    value={password}
                    onChange={setPassword}
                    onFocus={() => setActiveField("password")}
                    className={`w-full h-[60px] px-4 rounded-2xl bg-white/50 border text-black outline-none font-bold text-center placeholder-gray-500 shadow-sm shrink-0 transition-all duration-200
                      ${activeField === "password" ? "border-[#f97316] ring-4 ring-[#f97316]/30" : "border-white/60"}`}
                    style={{ fontFamily: "Poppins" }}
                  />
                  <div className="flex gap-3 w-full mt-2">
                    <button
                      onClick={() => { setShowPinPad(false); setEmail(""); setPassword(""); setPinError(""); setActiveField(null); }}
                      className="flex-1 h-[65px] rounded-2xl bg-white/40 backdrop-blur-md text-black font-bold text-sm hover:bg-white/60 active:scale-95 transition-all border border-white/50 shadow-sm uppercase tracking-wider"
                    >
                      Back
                    </button>
                    <button
                      onClick={handleEmailLogin}
                      disabled={isLoggingIn}
                      className="flex-1 h-[65px] rounded-2xl bg-green-500/90 text-white font-bold text-sm hover:brightness-110 active:scale-95 transition-all border border-green-400 shadow-sm uppercase tracking-wider disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Login
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-5">
                  <div className={`w-[310px] h-[60px] flex items-center justify-center rounded-2xl backdrop-blur-xl font-black tracking-[0.25em] text-2xl transition-colors shadow-sm
                    ${pinError ? "bg-red-100/90 border-2 border-red-400 text-red-600" : "bg-white/50 border border-white/60 text-black"}`}>
                    {isLoggingIn ? "VERIFYING" : pinError ? pinError.toUpperCase() : pin.length ? "•".repeat(pin.length) : "ENTER PIN"}
                  </div>

                  <div className="flex gap-3">
                    <div className="grid grid-cols-3 gap-3">
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                        <PinBtn key={num} onClick={() => handlePinInput(String(num))} className="w-[65px] h-[65px]">{num}</PinBtn>
                      ))}
                      <PinBtn onClick={() => handlePinInput("0")} className="col-span-2 h-[65px]">0</PinBtn>
                      <PinBtn onClick={() => handlePinInput("del")} danger className="w-[65px] h-[65px]"><Delete size={22} /></PinBtn>
                    </div>
                    <div className="flex flex-col gap-3">
                      <PinBtn onClick={() => handlePinInput("enter")} success className="w-[65px] h-[142px] text-3xl">✓</PinBtn>
                      <button
                        onClick={() => { setShowPinPad(false); setPin(""); setPinError(""); }}
                        className="w-[65px] h-[65px] rounded-2xl bg-white/40 backdrop-blur-md text-black font-bold text-xs hover:bg-white/60 active:scale-95 transition-all border border-white/50 shadow-sm uppercase tracking-wider"
                      >
                        Back
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </FadeIn>
          </div>

        </div>

        {/* ── Store info bar (unchanged) ───────────────────────────────────── */}
        <div className="absolute bottom-5 left-5 z-20">
          <span className="text-[13px] font-black tracking-wide text-black leading-none">
            {storeData?.data.name ?? "—"}
          </span>
          <div className="flex flex-col gap-0.5 mt-0.5">
            <span className="text-[10px] font-medium text-black/60">
              {storeData?.data.store_id ?? "—"} · T{getWorkstationId() ?? "?"}
            </span>
            <span className="text-[10px] font-medium text-black/50 truncate">
              {storeData?.data.address ?? "—"}
            </span>
          </div>
          <div className="flex items-center gap-2 pt-1 border-t border-black/10 mt-1">
            <span className={`w-2 h-2 rounded-full flex-shrink-0 ${businessDayDate ? "bg-green-500 shadow-[0_0_5px_rgba(34,197,94,0.7)]" : "bg-red-400 shadow-[0_0_5px_rgba(239,68,68,0.6)]"}`} />
            <span className="text-[10px] font-bold tracking-wider text-black/70 uppercase">
              {businessDayDate
                ? new Date(businessDayDate).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" }).toUpperCase()
                : "No Active Business Day"}
            </span>
          </div>
          {zReadingType === 'Per Terminal' && (
            <div className="flex items-center gap-2 pt-1 border-t border-black/10 mt-1">
              <span className={`w-2 h-2 rounded-full flex-shrink-0 transition-colors duration-500
                ${!isTerminalCompleted ? "bg-green-500 shadow-[0_0_5px_rgba(34,197,94,0.7)]" : "bg-red-400 shadow-[0_0_5px_rgba(239,68,68,0.6)]"}`} />
              <span className="text-[10px] font-bold tracking-wider text-black/70 uppercase">
                {!isTerminalCompleted ? "Terminal Active" : "Terminal Inactive (EOD Completed)"}
              </span>
            </div>
          )}
          <div className="flex items-center gap-2 pt-1">
            <span className={`w-2 h-2 rounded-full flex-shrink-0 transition-colors duration-500
              ${isOnline ? "bg-green-500 shadow-[0_0_5px_rgba(34,197,94,0.7)]" : "bg-red-400 shadow-[0_0_5px_rgba(239,68,68,0.6)]"}`} />
            <span className="text-[10px] font-bold tracking-wider text-black/70 uppercase">
              {isOnline ? "Online" : "Offline"}
            </span>
          </div>
        </div>

      </div>
    </>
  );
}