'use client';
import { getWorkstationId } from '@/src/lib/workstation';
import { useEffect, useState, useMemo, useRef, useCallback } from 'react';
import { FiClock, FiCheck, FiArrowLeft, FiX, FiRotateCcw, FiShoppingBag, FiInbox, FiSettings, FiPrinter } from 'react-icons/fi';
import { sileo, Toaster } from 'sileo';
import { usePrinter } from '@/app/context/PrinterContext';

const C = {
  orange:      '#FF6700',
  orangeHover: '#E55C00',
  orangeSoft:  'rgba(255, 103, 0, 0.1)',
  orangeBorder:'rgba(255, 103, 0, 0.2)',
  amber:       '#DA1884', 
  amberSoft:   'rgba(218, 24, 132, 0.1)',
  green:       '#22c55e',
  greenDark:   '#16a34a',
  bg:          '#E5E3DE',
  surface:     'rgba(252, 252, 252, 0.8)',
  border:      'rgba(0, 0, 0, 0.05)',
  cardShadow:  '0 6px 20px rgba(0, 0, 0, 0.04)',
  text:        '#2b2b2b',
  textSub:     '#5c5c5c',
  textFaint:   '#9ca3af',
  white:       '#FFFFFF',
};

// ── Types ────────────────────────────────────────────────────────────────────

type OrderModifier = {
  id: string;
  name: string;
  price?: number;
  quantity?: number;
  kitchenState?: 'PREPARING' | 'READY' | 'SERVED';
};

type OrderItem = {
  id: string;
  itemName: string;
  quantity: number;
  modifiers?: OrderModifier[];
  kitchenState?: 'PREPARING' | 'READY' | 'SERVED';
  notes?: string;
};

type FilterNode = {
  id: string;
  name: string;
  type: 'category' | 'subcategory' | 'bundle';
  itemIds: string[];
  children?: FilterNode[];
};

type AuditEvent = {
  type:
    | 'ORDER_RECEIVED'
    | 'ITEM_DONE'
    | 'ITEM_REVERTED'
    | 'ORDER_READY'
    | 'ORDER_BACK_TO_PREPARING'
    | 'ORDER_SERVED'
    | 'ORDER_RECALLED';
  timestamp: string;
  itemName?: string;
};

type Order = {
  _id: string;
  OrderNo: string;
  salesNumber?: string;
  orderTime: string;
  kitchenState: 'PREPARING' | 'READY' | 'SERVED';
  items: OrderItem[];
  featureFlags?: { orderType?: string };
  transactionType?: string;
  updatedAt?: string;
  sessionId?: string; 
  shiftNo?: string;   
};

// ── Helpers ──────────────────────────────────────────────────────────────────

const isBundleMod = (mod: OrderModifier) => mod.id?.startsWith('MD-');
const isComboItem = (item: OrderItem) => (item.modifiers || []).some(isBundleMod);

const resolveItemState = (item: OrderItem): 'PREPARING' | 'READY' | 'SERVED' => {
  if (item.kitchenState === 'SERVED') return 'SERVED';
  if (item.kitchenState === 'READY') return 'READY';
  if (!isComboItem(item)) return item.kitchenState ?? 'PREPARING';
  const bundleMods = (item.modifiers || []).filter(isBundleMod);
  const allDone = bundleMods.every(m => m.kitchenState === 'READY' || m.kitchenState === 'SERVED');
  return allDone ? 'READY' : 'PREPARING';
};

// ── Notification sound ────────────────────────────────────────────────────────

const playNotificationSound = () => {
  try {
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(880, audioCtx.currentTime);
    oscillator.frequency.setValueAtTime(1108.73, audioCtx.currentTime + 0.1);
    gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.5);
    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    oscillator.start();
    oscillator.stop(audioCtx.currentTime + 0.5);
  } catch (e) {
    console.error('Audio playback failed', e);
  }
};
// ── ConfirmModal ──────────────────────────────────────────────────────────────

function ConfirmModal({ isOpen, onClose, onConfirm, title, message }: {
  isOpen: boolean; onClose: () => void; onConfirm: () => void; title: string; message: string;
}) {
  if (!isOpen) return null;
  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(15, 23, 42, 0.6)', backdropFilter: 'blur(4px)' }} onClick={onClose}>
      <div style={{ width: '80%', background: '#fff', borderRadius: 24, padding: 24, boxShadow: '0 20px 40px rgba(0,0,0,0.2)', animation: 'popIn 0.3s cubic-bezier(0.16, 1, 0.3, 1)' }} onClick={e => e.stopPropagation()}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
          <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'rgba(239, 68, 68, 0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#ef4444' }}>
            <span style={{ fontSize: 20, fontWeight: 900 }}>!</span>
          </div>
          <h3 style={{ margin: 0, fontSize: 18, fontWeight: 900, color: '#2b2b2b', fontFamily: 'Poppins' }}>{title}</h3>
        </div>
        <p style={{ margin: '0 0 24px 0', fontSize: 14, color: '#5c5c5c', fontFamily: 'Poppins', lineHeight: 1.5 }}>{message}</p>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
          <button onClick={onClose} style={{ padding: '10px 20px', borderRadius: 12, background: 'rgba(0,0,0,0.05)', border: 'none', color: '#5c5c5c', fontSize: 13, fontWeight: 800, fontFamily: 'Poppins', cursor: 'pointer', transition: 'background 0.2s' }}>Cancel</button>
          <button onClick={() => { onConfirm(); onClose(); }} style={{ padding: '10px 20px', borderRadius: 12, background: '#ef4444', border: 'none', color: '#fff', fontSize: 13, fontWeight: 800, fontFamily: 'Poppins', cursor: 'pointer', boxShadow: '0 4px 12px rgba(239, 68, 68, 0.3)', transition: 'transform 0.15s, filter 0.15s' }}>Proceed</button>
        </div>
      </div>
    </div>
  );
}

// ── OrderTimer ────────────────────────────────────────────────────────────────

function OrderTimer({ elapsed, accent, isDanger, stopped = false }: {
  elapsed: string; accent: string; isDanger: boolean; stopped?: boolean;
}) {
  if (stopped) {
    return (
      <span style={{ color: C.textFaint, fontSize: 11, fontWeight: 700, letterSpacing: 0.8, fontFamily: 'Poppins' }}>
        Served {elapsed}
      </span>
    );
  }
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      background: C.white, border: `1px solid ${accent}40`, boxShadow: `0 2px 8px ${accent}20`,
      borderRadius: 8, padding: '4px 10px',
      animation: isDanger ? 'pulse 1.5s ease-in-out infinite' : undefined, flexShrink: 0,
    }}>
      <FiClock size={12} color={accent} />
      <span style={{ color: accent, fontSize: 12, fontWeight: 900, letterSpacing: 1.2, fontFamily: 'Poppins' }}>
        {elapsed}
      </span>
    </div>
  );
}

// ── OrderCard ─────────────────────────────────────────────────────────────────

function OrderCard({
  order, onAction, onItemAction, onModifierAction, onPrint,
  filterItemIds, idx, warningMins, dangerMins, serverTimeOffsetMs,
}: {
  order: Order;
  onAction: (id: string, state: string, targetIndices?: number[]) => void;
  onItemAction: (orderId: string, itemIdx: number, state: string) => void;
  onModifierAction: (orderId: string, itemIdx: number, modifierIdx: number, state: string) => void;
  onPrint: (order: Order) => void;
  filterItemIds: Set<string> | null;
  idx: number;
  warningMins: number;
  dangerMins: number;
  serverTimeOffsetMs: number;
}) {
  const isPreparing = order.kitchenState === 'PREPARING';
  const isDineIn    = order.featureFlags?.orderType === 'DineIn';
  const [mins, setMins] = useState(0);
  const [elapsed, setElapsed] = useState('');
  const [confirmDialog, setConfirmDialog] = useState<{ isOpen: boolean; pendingAction: (() => void) | null }>({ isOpen: false, pendingAction: null });

  useEffect(() => {
    if (order.kitchenState === 'SERVED') {
      const t = order.updatedAt || order.orderTime;
      const dateObj = new Date(t);
      setElapsed(isNaN(dateObj.getTime()) ? '00:00' : dateObj.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }));
      return;
    }
    let start = new Date(order.orderTime).getTime();
    if (isNaN(start) || start > Date.now()) start = Date.now();
    const tick = () => {
      // FIX 3: Use server-corrected time so timers match the server clock
      const serverNow = Date.now() + serverTimeOffsetMs;
      const diff = Math.max(0, serverNow - start);
      const m = Math.floor(diff / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setMins(m);
      setElapsed(`${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [order.orderTime, order.kitchenState, order.updatedAt, serverTimeOffsetMs]);

  const isDanger = isPreparing && mins >= dangerMins;
  const isWarn   = isPreparing && mins >= warningMins && mins < dangerMins;

  let accent   = isPreparing ? C.orange : C.amber;
  let headerBg = isPreparing
    ? `linear-gradient(135deg, ${C.orangeHover} 0%, ${C.orange} 100%)`
    : `linear-gradient(135deg, #C21473 0%, ${C.amber} 100%)`;
  let cardBg     = 'rgba(255, 255, 255, 0.8)';
  let cardBorder = C.border;

  if (isDanger) {
    accent = '#ef4444'; headerBg = `linear-gradient(135deg, #b91c1c 0%, #ef4444 100%)`;
    cardBg = 'rgba(254, 226, 226, 0.95)'; cardBorder = 'rgba(239, 68, 68, 0.3)';
  } else if (isWarn) {
    accent = '#eab308'; headerBg = `linear-gradient(135deg, #ca8a04 0%, #eab308 100%)`;
    cardBg = 'rgba(254, 249, 195, 0.95)'; cardBorder = 'rgba(234, 179, 8, 0.3)';
  }

  return (
    <div className="kds-card animate-pop" style={{
      borderRadius: 24, background: cardBg, backdropFilter: 'blur(16px)',
      border: `1px solid ${cardBorder}`, boxShadow: C.cardShadow,
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
      animationDelay: `${idx * 0.04}s`,
      transition: 'transform 0.2s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.2s ease, background-color 0.5s ease',
    }}>
      {/* Header */}
      <div style={{ background: headerBg, padding: '14px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, transition: 'background 0.5s ease' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 26, fontWeight: 900, color: '#fff', fontFamily: 'Poppins', lineHeight: 1 }}>#{order.OrderNo}</span>
          <span style={{ background: 'rgba(0,0,0,0.15)', padding: '4px 8px', borderRadius: 8, fontSize: 10, fontWeight: 800, color: '#fff', letterSpacing: 1.2, textTransform: 'uppercase', fontFamily: 'Poppins' }}>
            {isDineIn ? '🍽 Dine In' : '🛍 Take Out'}
          </span>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <button onClick={(e) => { e.stopPropagation(); onPrint(order); }} className="kds-btn-ghost"
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.15)', border: 'none', borderRadius: 8, width: 28, height: 28, color: '#fff', cursor: 'pointer', transition: 'background 0.2s' }} title="Print Order Slip">
            <FiPrinter size={14} />
          </button>
          <OrderTimer elapsed={elapsed} accent={accent} isDanger={isDanger} stopped={order.kitchenState === 'SERVED'} />
        </div>
      </div>

      {/* Items */}
      <div style={{ padding: '16px', flex: 1, display: 'flex', flexDirection: 'column', gap: 12 }}>
        {order.items.map((item, i) => {
          const inFilter    = !filterItemIds || filterItemIds.has(item.id);
          // const canInteract = isPreparing && inFilter;
          const isReadyView = order.kitchenState === 'READY';
          const canInteract = (isPreparing || isReadyView) && inFilter;
          const isCombo     = isComboItem(item);

          if (isCombo) {
            const bundleComponents   = (item.modifiers || []).filter(isBundleMod);
            const regularMods        = (item.modifiers || []).filter(m => !isBundleMod(m));
            const allComponentsDone  = bundleComponents.every(m => m.kitchenState === 'READY' || m.kitchenState === 'SERVED');
            const someComponentsDone = bundleComponents.some(m => m.kitchenState === 'READY' || m.kitchenState === 'SERVED');
            
            const isItemServed       = item.kitchenState === 'SERVED';
            const effectiveItemReady = allComponentsDone || item.kitchenState === 'READY' || isItemServed;
            
            const isDoneInView   = isPreparing ? effectiveItemReady : isItemServed;
            const nextComboState = isPreparing ? (effectiveItemReady ? 'PREPARING' : 'READY') : (isItemServed ? 'READY' : 'SERVED');
            const doneBg         = isPreparing ? C.green : '#8b5cf6';
            const doneBorder     = isPreparing ? C.greenDark : '#7c3aed';
            const doneLightBg    = isPreparing ? 'rgba(34, 197, 94, 0.04)' : 'rgba(139, 92, 246, 0.04)';

            return (
              <div key={i} style={{
                opacity: (!inFilter && isPreparing) ? 0.32 : isDoneInView ? 0.6 : 1, transition: 'opacity 0.2s ease',
                borderRadius: 12,
                border: `1px solid ${isDoneInView ? doneBorder : `${accent}18`}`,
                background: isDoneInView ? doneLightBg : someComponentsDone && isPreparing ? `${accent}05` : 'transparent',
                overflow: 'hidden', pointerEvents: (!inFilter && isPreparing) ? 'none' : 'auto',
              }}>
                <div 
                  onClick={() => canInteract && onItemAction(order._id, i, nextComboState)}
                  style={{ display: 'flex', gap: 10, alignItems: 'center', padding: '8px 10px', borderBottom: `1px solid ${accent}12`, cursor: canInteract ? 'pointer' : 'default' }}>
                  <span style={{ minWidth: 28, height: 28, borderRadius: 7, background: isDoneInView ? doneBg : `${accent}15`, border: isDoneInView ? `1px solid ${doneBorder}` : `1px solid ${accent}30`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 900, color: isDoneInView ? '#fff' : accent, fontFamily: 'Poppins', flexShrink: 0, transition: 'all 0.2s ease' }}>
                    {isDoneInView ? <FiCheck size={14} /> : item.quantity}
                  </span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ margin: 0, fontSize: 14, fontWeight: 900, color: C.text, textTransform: 'uppercase', letterSpacing: 0.5, fontFamily: 'Poppins', textDecoration: effectiveItemReady && isPreparing ? 'line-through' : 'none' }}>
                      {item.itemName}
                    </p>
                    {item.notes && (
                      <p style={{ margin: '6px 0 0', fontSize: 11, fontWeight: 700, color: '#b91c1c', fontFamily: 'Poppins', display: 'flex', gap: 6, background: '#fef2f2', padding: '6px 10px', borderRadius: 8, border: '1px solid #fca5a5' }}>
                        <span style={{ color: '#ef4444' }}>📝</span>
                        <span>{item.notes}</span>
                      </p>
                    )}
                  </div>
                  <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: 0.8, textTransform: 'uppercase', color: C.amber, background: `${C.amber}15`, padding: '3px 7px', borderRadius: 999, fontFamily: 'Poppins', flexShrink: 0 }}>COMBO</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
                  {bundleComponents.map((mod, mi) => {
                    const isModReady = mod.kitchenState === 'READY' || mod.kitchenState === 'SERVED' || item.kitchenState === 'READY' || item.kitchenState === 'SERVED';
                    const actualModIdx = (() => {
                      let count = -1;
                      for (let k = 0; k < (item.modifiers || []).length; k++) {
                        if (isBundleMod(item.modifiers![k])) count++;
                        if (count === mi) return k;
                      }
                      return -1;
                    })();
                    return (
                      <div key={mi} onClick={() => canInteract && actualModIdx >= 0 && onModifierAction(order._id, i, actualModIdx, isModReady ? 'PREPARING' : 'READY')}
                        style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', cursor: canInteract ? 'pointer' : 'default', background: isModReady && isPreparing ? 'rgba(34,197,94,0.06)' : 'transparent', borderBottom: mi < bundleComponents.length - 1 ? `1px solid ${accent}08` : 'none', transition: 'background 0.15s ease' }}
                        className="kds-mod-row">
                        <div style={{ width: 2, height: 26, borderRadius: 1, background: isModReady && isPreparing ? C.green : `${accent}30`, flexShrink: 0, marginLeft: 4 }} />
                        <span style={{ minWidth: 24, height: 24, borderRadius: 6, background: isModReady && isPreparing ? C.green : 'transparent', border: `1.5px solid ${isModReady && isPreparing ? C.greenDark : `${accent}40`}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'all 0.2s ease' }}>
                          {isModReady && isPreparing ? <FiCheck size={13} color="#fff" strokeWidth={3} /> : mod.quantity && mod.quantity > 1 ? <span style={{ fontSize: 11, fontWeight: 800, color: accent, fontFamily: 'Poppins' }}>{mod.quantity}</span> : null}
                        </span>
                        <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: isModReady && isPreparing ? C.textFaint : C.textSub, fontFamily: 'Poppins', flex: 1, lineHeight: 1.3, textDecoration: isModReady && isPreparing ? 'line-through' : 'none', transition: 'color 0.2s ease' }}>
                          {mod.name}
                        </p>
                        {isModReady && isPreparing && <span style={{ fontSize: 9, fontWeight: 800, color: C.green, letterSpacing: 0.5, fontFamily: 'Poppins', flexShrink: 0 }}>DONE</span>}
                      </div>
                    );
                  })}
                </div>
                {regularMods.length > 0 && (
                  <div style={{ padding: '6px 10px 8px', borderTop: `1px dashed ${accent}12` }}>
                    {regularMods.map((mod, mi) => (
                      <p key={mi} style={{ margin: '2px 0 0', fontSize: 11, fontWeight: 600, color: C.textFaint, fontFamily: 'Poppins', display: 'flex', gap: 6 }}>
                        <span style={{ color: C.textFaint }}>↳</span>
                        <span>{mod.quantity && mod.quantity > 1 ? `${mod.quantity}x ` : ''}{mod.name}</span>
                      </p>
                    ))}
                  </div>
                )}
              </div>
            );
          }

          const isItemReady  = item.kitchenState === 'READY' || item.kitchenState === 'SERVED';
          const isItemServed = item.kitchenState === 'SERVED';
          const isDoneInView = isPreparing ? isItemReady : isItemServed;
          const nextState    = isPreparing ? (isItemReady ? 'PREPARING' : 'READY') : (isItemServed ? 'READY' : 'SERVED');

          const doneBg       = isPreparing ? C.green : '#8b5cf6';
          const doneBorder   = isPreparing ? C.greenDark : '#7c3aed';
          const doneLightBg  = isPreparing ? 'rgba(34, 197, 94, 0.05)' : 'rgba(139, 92, 246, 0.05)';

          return (
            <div key={i} onClick={() => canInteract && onItemAction(order._id, i, nextState)}
              style={{ display: 'flex', gap: 12, alignItems: 'flex-start', cursor: canInteract ? 'pointer' : 'default', opacity: (!inFilter && isPreparing) ? 0.32 : isDoneInView ? 0.55 : 1, transition: 'opacity 0.2s ease', padding: '4px', borderRadius: '8px', backgroundColor: isDoneInView ? doneLightBg : 'transparent', pointerEvents: (!inFilter && isPreparing) ? 'none' : 'auto' }}>
              <span style={{ minWidth: 30, height: 30, borderRadius: 8, background: isDoneInView ? doneBg : `${accent}15`, border: isDoneInView ? `1px solid ${doneBorder}` : `1px solid ${accent}30`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 900, color: isDoneInView ? '#fff' : accent, fontFamily: 'Poppins', flexShrink: 0, transition: 'all 0.2s ease' }}>
                {isDoneInView ? <FiCheck size={16} /> : item.quantity}
              </span>
              <div style={{ flex: 1, minWidth: 0, paddingTop: 4 }}>
                <p style={{ margin: 0, fontSize: 15, fontWeight: 800, color: C.text, textTransform: 'uppercase', letterSpacing: 0.5, fontFamily: 'Poppins', lineHeight: 1.3, wordBreak: 'break-word', textDecoration: (isItemReady && isPreparing) ? 'line-through' : 'none' }}>
                  {item.itemName}
                </p>
                {item.notes && (
                  <p style={{ margin: '6px 0 0', fontSize: 11, fontWeight: 700, color: '#b91c1c', fontFamily: 'Poppins', display: 'flex', gap: 6, background: '#fef2f2', padding: '6px 10px', borderRadius: 8, border: '1px solid #fca5a5' }}>
                    <span style={{ color: '#ef4444' }}>📝</span>
                    <span>{item.notes}</span>
                  </p>
                )}
                {item.modifiers?.map((mod, mi) => (
                  <p key={mi} style={{ margin: '4px 0 0', fontSize: 12, fontWeight: 600, color: C.textSub, fontFamily: 'Poppins', display: 'flex', gap: 6, textDecoration: isDoneInView ? 'line-through' : 'none' }}>
                    <span style={{ color: C.textFaint }}>↳</span>
                    <span>{mod.quantity && mod.quantity > 1 ? `${mod.quantity}x ` : ''}{mod.name}</span>
                  </p>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <div style={{ height: 1, background: 'rgba(0,0,0,0.06)', margin: '0 16px' }} />

      {/* Action buttons */}
      <div style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: 8, background: 'rgba(255,255,255,0.5)' }}>
        {(() => {
          const getTargetIndices = (targetState: 'PREPARING' | 'READY' | 'SERVED') => {
            const indices: number[] = [];
            order.items.forEach((item, idx) => {
              if (filterItemIds && !filterItemIds.has(item.id)) return;
              const currentState = resolveItemState(item);
              if (targetState === 'READY' && currentState === 'PREPARING') indices.push(idx);
              if (targetState === 'SERVED' && (currentState === 'READY' || currentState === 'PREPARING')) indices.push(idx);
              if (targetState === 'PREPARING' && (currentState === 'READY' || currentState === 'SERVED')) indices.push(idx);
            });
            return indices;
          };

          const handleActionClick = (targetState: 'PREPARING' | 'READY' | 'SERVED') => {
            const executeAction = () => {
              if (!filterItemIds) {
                onAction(order._id, targetState);
              } else {
                const indices = getTargetIndices(targetState);
                if (indices.length > 0) onAction(order._id, targetState, indices);
              }
            };

            if (targetState === 'READY' || targetState === 'SERVED') {
              const pendingOtherItems = order.items.filter((item) => {
                const isItemPending = resolveItemState(item) === 'PREPARING';
                return filterItemIds ? (isItemPending && !filterItemIds.has(item.id)) : isItemPending;
              });

              if (pendingOtherItems.length > 0) {
                setConfirmDialog({ isOpen: true, pendingAction: executeAction });
                return;
              }
            }

            executeAction();
          };

          if (isPreparing) {
            return (
              <button onClick={() => handleActionClick('READY')} className="kds-btn-primary"
                style={{ width: '100%', padding: '12px 0', borderRadius: 12, background: `linear-gradient(135deg, ${accent}, ${isDanger ? '#dc2626' : isWarn ? '#ca8a04' : C.orangeHover})`, boxShadow: `0 4px 12px ${accent}40`, border: 'none', color: '#fff', fontSize: 12, fontWeight: 900, fontFamily: 'Poppins', letterSpacing: 1.5, textTransform: 'uppercase', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, transition: 'all 0.5s ease' }}>
                <FiCheck size={16} /> Ready
              </button>
            );
          } else {
            return (
              <>
                <button onClick={() => handleActionClick('SERVED')} className="kds-btn-success"
                  style={{ width: '100%', padding: '12px 0', borderRadius: 12, background: `linear-gradient(135deg, ${C.green}, ${C.greenDark})`, boxShadow: `0 4px 12px rgba(34, 197, 94, 0.35)`, border: 'none', color: '#fff', fontSize: 12, fontWeight: 900, fontFamily: 'Poppins', letterSpacing: 1.5, textTransform: 'uppercase', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                  <FiCheck size={16} strokeWidth={3} /> Served
                </button>
                <button onClick={() => handleActionClick('PREPARING')} className="kds-btn-ghost"
                  style={{ width: '100%', padding: '8px 0', borderRadius: 10, background: 'rgba(255,255,255,0.8)', border: `1px solid rgba(0,0,0,0.1)`, color: C.textSub, fontSize: 10, fontWeight: 800, fontFamily: 'Poppins', letterSpacing: 1, textTransform: 'uppercase', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                  <FiArrowLeft size={12} /> Back to Preparing
                </button>
              </>
            );
          }
        })()}
      </div>
      <ConfirmModal
        isOpen={confirmDialog.isOpen}
        onClose={() => setConfirmDialog({ isOpen: false, pendingAction: null })}
        onConfirm={() => {
          if (confirmDialog.pendingAction) confirmDialog.pendingAction();
        }}
        title="Pending Items"
        message="There are still items pending from other stations. Are you sure you want to proceed?"
      />
    </div>
  );
}

// ── OrderSection ──────────────────────────────────────────────────────────────

function OrderSection({
  label, orders, onAction, onItemAction, onModifierAction, onPrint,
  filterItemIds, accent, emptyIcon, kdsTimers, serverTimeOffsetMs,
}: {
  label: string; orders: Order[];
  onAction: (id: string, state: string, targetIndices?: number[]) => void;
  onItemAction: (orderId: string, itemIdx: number, state: string) => void;
  onModifierAction: (orderId: string, itemIdx: number, modifierIdx: number, state: string) => void;
  onPrint: (order: Order) => void;
  filterItemIds: Set<string> | null; accent: string; emptyIcon: React.ReactNode;
  kdsTimers: { warning: number; danger: number }; serverTimeOffsetMs: number;
}) {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: C.surface, borderRadius: 32, border: `1px solid ${C.border}`, overflow: 'hidden', boxShadow: C.cardShadow, backdropFilter: 'blur(24px)' }}>
      <div style={{ padding: '20px 24px', borderBottom: `1px solid rgba(0,0,0,0.06)`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'rgba(255,255,255,0.4)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 14, height: 14, borderRadius: '50%', background: accent, boxShadow: `0 0 12px ${accent}80` }} />
          <h2 style={{ margin: 0, fontSize: 22, fontWeight: 900, color: C.text, fontFamily: 'Poppins', letterSpacing: -0.5 }}>{label}</h2>
        </div>
        <div style={{ background: 'rgba(0,0,0,0.05)', color: C.textSub, padding: '6px 14px', borderRadius: 999, fontSize: 13, fontWeight: 800, fontFamily: 'Poppins' }}>
          {orders.length} ORDER{orders.length !== 1 && 'S'}
        </div>
      </div>
      <div className="hide-scroll" style={{ flex: 1, overflowY: 'auto', padding: 24, display: orders.length === 0 ? 'flex' : 'block', columnWidth: 320, columnGap: 24 }}>
        {orders.length === 0 ? (
          <div style={{ margin: 'auto', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: C.textFaint, opacity: 0.5 }}>
            {emptyIcon}
            <p style={{ marginTop: 16, fontSize: 14, fontWeight: 800, fontFamily: 'Poppins', textTransform: 'uppercase', letterSpacing: 1.5 }}>No orders {label.toLowerCase()}</p>
          </div>
        ) : (
          orders.map((o, idx) => (
            <div key={o._id} style={{ breakInside: 'avoid', marginBottom: 24, transform: 'translateZ(0)' }}>
              <OrderCard order={o} onAction={onAction} onItemAction={onItemAction} onModifierAction={onModifierAction} onPrint={onPrint} filterItemIds={filterItemIds} idx={idx} warningMins={kdsTimers.warning} dangerMins={kdsTimers.danger} serverTimeOffsetMs={serverTimeOffsetMs} />
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// ── AuditTimeline ─────────────────────────────────────────────────────────────

const EVENT_META: Record<AuditEvent['type'], { label: string; color: string; symbol: string }> = {
  ORDER_RECEIVED:          { label: 'Order received',         color: '#3b82f6', symbol: '●' },
  ITEM_DONE:               { label: 'done',                   color: '#22c55e', symbol: '●' },
  ITEM_REVERTED:           { label: 'reverted to preparing',  color: '#eab308', symbol: '●' },
  ORDER_READY:             { label: 'Order ready',            color: '#16a34a', symbol: '●' },
  ORDER_BACK_TO_PREPARING: { label: 'Sent back to preparing', color: '#f97316', symbol: '●' },
  ORDER_SERVED:            { label: 'Order served',           color: '#8b5cf6', symbol: '●' },
  ORDER_RECALLED:          { label: 'Recalled from history',  color: '#DA1884', symbol: '●' },
};

function AuditTimeline({ events }: { events: AuditEvent[] }) {
  if (!events || events.length === 0) {
    return <p style={{ fontSize: 11, color: '#bbb', fontFamily: 'Poppins', fontWeight: 600, fontStyle: 'italic', marginTop: 8 }}>No audit trail recorded</p>;
  }
  return (
    <div style={{ marginTop: 12, position: 'relative' }}>
      <p style={{ fontSize: 9, fontWeight: 800, color: '#ccc', fontFamily: 'Poppins', textTransform: 'uppercase', letterSpacing: 1.5, marginBottom: 8 }}>Audit Trail</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
        {events.map((ev, i) => {
          const meta  = EVENT_META[ev.type] || { label: ev.type, color: '#999', symbol: '●' };
          const time  = new Date(ev.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
          const isLast = i === events.length - 1;
          const label = (ev.type === 'ITEM_DONE' || ev.type === 'ITEM_REVERTED') && ev.itemName ? `${ev.itemName} ${meta.label}` : meta.label;
          return (
            <div key={i} style={{ display: 'flex', gap: 0, alignItems: 'stretch' }}>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: 20, flexShrink: 0 }}>
                <div style={{ width: 10, height: 10, borderRadius: '50%', flexShrink: 0, background: meta.color, marginTop: 4, boxShadow: `0 0 6px ${meta.color}60` }} />
                {!isLast && <div style={{ width: 2, flex: 1, background: `${meta.color}30`, minHeight: 14, borderRadius: 1 }} />}
              </div>
              <div style={{ paddingLeft: 10, paddingBottom: isLast ? 0 : 10, flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 8 }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: '#2b2b2b', fontFamily: 'Poppins', lineHeight: 1.3, wordBreak: 'break-word' }}>{label}</span>
                  <span style={{ fontSize: 10, fontWeight: 700, color: '#aaa', fontFamily: 'Poppins', flexShrink: 0, letterSpacing: 0.3 }}>{time}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── HistoryPanel ──────────────────────────────────────────────────────────────

function HistoryPanel({ orders, onClose, onRecall, loading, auditTrails, viewMode }: {
  orders: Order[]; onClose: () => void;
  onRecall: (id: string, state: string) => void;
  loading: boolean; auditTrails: Record<string, AuditEvent[]>;
  viewMode: 'PREPARING' | 'READY';
}) {
  const isPrepMode = viewMode === 'PREPARING';
  const [expandedId, setExpandedId] = useState<string | null>(null);

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 200, display: 'flex', justifyContent: 'flex-end', background: 'rgba(15, 23, 42, 0.4)', backdropFilter: 'blur(8px)' }} onClick={onClose}>
      <div style={{ width: 450, height: '100%', background: '#F8F9FA', borderLeft: `1px solid rgba(0,0,0,0.05)`, display: 'flex', flexDirection: 'column', boxShadow: '-12px 0 40px rgba(0,0,0,0.15)', animation: 'slideInRight 0.3s cubic-bezier(0.16,1,0.3,1)' }} onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '24px', background: '#fff', borderBottom: `1px solid rgba(0,0,0,0.05)`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', boxShadow: '0 2px 10px rgba(0,0,0,0.02)' }}>
          <div>
            <h2 style={{ margin: 0, fontSize: 22, fontWeight: 900, color: '#2b2b2b', fontFamily: 'Poppins' }}>
              {isPrepMode ? 'Ready Orders' : 'Delivered Orders'}
            </h2>
            <p style={{ margin: 0, fontSize: 11, color: '#5c5c5c', fontFamily: 'Poppins', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 1, marginTop: 4 }}>
              {isPrepMode ? 'Ready — tap to revert back' : 'Recently completed'}
            </p>
          </div>
          <button onClick={onClose} style={{ width: 40, height: 40, borderRadius: 20, background: 'rgba(0,0,0,0.05)', border: 'none', color: '#5c5c5c', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <FiX size={20} />
          </button>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: 24, display: 'flex', flexDirection: 'column', gap: 16 }} className="hide-scroll">
          {loading ? (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
              <div className="spinner" style={{ width: 36, height: 36, border: `4px solid rgba(0,0,0,0.1)`, borderTopColor: '#FF6700', borderRadius: '50%' }} />
            </div>
          ) : orders.length === 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: 16, opacity: 0.4 }}>
              <FiRotateCcw size={48} color="#5c5c5c" />
              <p style={{ margin: 0, color: '#5c5c5c', fontFamily: 'Poppins', fontWeight: 800, fontSize: 13, letterSpacing: 1.5, textTransform: 'uppercase' }}>
                {isPrepMode ? 'No ready orders' : 'No history today'}
              </p>
            </div>
          ) : (
            orders.map((order) => {
              const isExpanded = expandedId === order._id;
              const trails = auditTrails[order._id] || [];
              const latestTrail = trails.length > 0 ? trails[trails.length - 1] : null;

              return (
                <div key={order._id} style={{ background: '#fff', border: `1px solid rgba(0,0,0,0.06)`, borderRadius: 20, padding: 20, boxShadow: '0 4px 15px rgba(0,0,0,0.03)', cursor: 'pointer', transition: 'all 0.2s ease' }} onClick={() => setExpandedId(isExpanded ? null : order._id)}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: isExpanded ? 12 : 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <p style={{ margin: 0, fontSize: 20, fontWeight: 900, color: '#2b2b2b', fontFamily: 'Poppins' }}>#{order.OrderNo}</p>
                      <span style={{ fontSize: 10, fontWeight: 800, letterSpacing: 0.8, textTransform: 'uppercase', color: isPrepMode ? C.amber : '#8b5cf6', background: isPrepMode ? `${C.amber}15` : 'rgba(139,92,246,0.1)', padding: '3px 8px', borderRadius: 999, fontFamily: 'Poppins' }}>
                        {isPrepMode ? 'Ready' : 'Served'}
                      </span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <p style={{ margin: 0, fontSize: 11, fontWeight: 700, color: '#9ca3af', fontFamily: 'Poppins', textTransform: 'uppercase' }}>
                        {order.updatedAt ? new Date(order.updatedAt).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) : '—'}
                      </p>
                      <span style={{ color: '#ccc', transform: isExpanded ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s', display: 'flex' }}>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
                      </span>
                    </div>
                  </div>

                  {!isExpanded && latestTrail && (
                    <div style={{ fontSize: 11, color: '#aaa', marginTop: 8, fontStyle: 'italic', fontFamily: 'Poppins', fontWeight: 600 }}>
                      Latest: {latestTrail.type.replace(/_/g, ' ')} {latestTrail.itemName ? `— ${latestTrail.itemName}` : ''}
                    </div>
                  )}

                  {isExpanded && (
                    <div onClick={e => e.stopPropagation()} style={{ cursor: 'default' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 12, marginTop: 12 }}>
                        {order.items.map((item, idx) => (
                          <div key={idx} style={{ fontSize: 13, color: '#5c5c5c', fontWeight: 600, fontFamily: 'Poppins' }}>
                            <span style={{ fontWeight: 800, color: '#2b2b2b', marginRight: 8 }}>{item.quantity}x</span>{item.itemName}
                            {item.notes && (
                              <div style={{ paddingLeft: 20, fontSize: 11, color: '#ef4444', fontStyle: 'italic', marginTop: 2 }}>📝 {item.notes}</div>
                            )}
                            {isComboItem(item) && (item.modifiers || []).filter(isBundleMod).map((mod, mi) => (
                              <div key={mi} style={{ paddingLeft: 20, fontSize: 11, color: '#9ca3af' }}>↳ {mod.name}</div>
                            ))}
                          </div>
                        ))}
                      </div>
                      <div style={{ height: 1, background: 'rgba(0,0,0,0.05)', margin: '12px 0' }} />
                      <AuditTimeline events={trails} />
                      <div style={{ height: 1, background: 'rgba(0,0,0,0.05)', margin: '12px 0' }} />
                      <button
                        onClick={(e) => { e.stopPropagation(); onRecall(order._id, 'PREPARING'); onClose(); }}
                        className="kds-recall-btn"
                        style={{ width: '100%', padding: '12px 0', borderRadius: 12, background: isPrepMode ? `${C.orange}10` : 'rgba(0,0,0,0.03)', border: `1px solid ${isPrepMode ? `${C.orange}30` : 'rgba(0,0,0,0.05)'}`, color: isPrepMode ? C.orange : '#5c5c5c', fontSize: 12, fontWeight: 800, fontFamily: 'Poppins', letterSpacing: 1, textTransform: 'uppercase', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, transition: 'all 0.2s' }}>
                        <FiArrowLeft size={14} /> Revert to Preparing
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

// ── LiveClock ─────────────────────────────────────────────────────────────────

// FIX 3: Clock now uses server-corrected time
function LiveClock({ serverTimeOffsetMs }: { serverTimeOffsetMs: number }) {
  const [time, setTime] = useState('');
  useEffect(() => {
    const tick = () => {
      const serverNow = new Date(Date.now() + serverTimeOffsetMs);
      setTime(serverNow.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [serverTimeOffsetMs]);
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, fontSize: 14, fontWeight: 800, color: C.textSub, fontFamily: 'Poppins', letterSpacing: 1, background: 'rgba(0,0,0,0.03)', padding: '8px 16px', borderRadius: 12 }}>
      <FiClock size={16} />
      <span>{time}</span>
    </div>
  );
}

// ── Audit logger ──────────────────────────────────────────────────────────────

async function logAuditEvent(orderId: string, orderNo: string, event: AuditEvent) {
  try {
    await fetch('/api/kds-audit', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orderId, orderNo, event }),
    });
  } catch (err) { console.error('Failed to log audit event:', err); }
}

// ── KDSPage ───────────────────────────────────────────────────────────────────

export default function KDSPage() {
  const [activeOrders,   setActiveOrders]   = useState<Order[]>([]);
  const [historyOrders,  setHistoryOrders]  = useState<Order[]>([]);
  const [loading,        setLoading]        = useState(true);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [auditTrails,    setAuditTrails]    = useState<Record<string, AuditEvent[]>>({});
  const [showHistory,    setShowHistory]    = useState(false);
  const [showSettings,   setShowSettings]   = useState(false);
  const [viewMode,       setViewMode]       = useState<'PREPARING' | 'READY'>('PREPARING');

  // ── FIX 3: Server time sync ───────────────────────────────────────────────
  // Compute offset between server clock and local device clock once on mount,
  // then re-sync every 5 min to handle drift. All timers use (Date.now() + offset).
  const [serverTimeOffsetMs, setServerTimeOffsetMs] = useState(0);

  useEffect(() => {
    const syncServerTime = async () => {
      try {
        const before   = Date.now();
        const res      = await fetch('/api/time'); // expects { now: <ISO or epoch ms> }
        const after    = Date.now();
        if (!res.ok) return;
        const data     = await res.json();
        const serverMs = typeof data.now === 'number' ? data.now : new Date(data.now).getTime();
        if (isNaN(serverMs)) return;
        // Round-trip midpoint to compensate for network latency
        const localMid = Math.round((before + after) / 2);
        setServerTimeOffsetMs(serverMs - localMid);
      } catch (err) {
        console.warn('Could not sync server time, using device time:', err);
      }
    };
    syncServerTime();
    const id = setInterval(syncServerTime, 5 * 60 * 1000);
    return () => clearInterval(id);
  }, []);

  const [kdsTimers,       setKdsTimers]       = useState({ warning: 5, danger: 10 });
  const [menuFilterTree,  setMenuFilterTree]  = useState<FilterNode[]>([]);
  const [categoryFilter,  setCategoryFilter]  = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem('kds_category_filter');
      if (saved) { const arr = JSON.parse(saved); if (Array.isArray(arr)) return new Set<string>(arr); }
    } catch {}
    return new Set<string>();
  });
  const [itemAncestorMap, setItemAncestorMap] = useState<Map<string, string[]>>(new Map());

  // ── FIX 2: Customizable display title ────────────────────────────────────
  const [displayTitle, setDisplayTitle] = useState<string>(() => {
    try { return localStorage.getItem('kds_display_title') || ''; } catch { return ''; }
  });
  const [editingTitle, setEditingTitle] = useState(false);
  const [titleDraft,   setTitleDraft]   = useState('');

  const resolvedTitle = displayTitle.trim()
    ? displayTitle.trim()
    : viewMode === 'READY' ? 'Dispatch Display' : 'Kitchen Display';

  const { printDirect } = usePrinter();

  const handlePrintOrder = async (order: Order) => {
    try {
      const { buildKdsPrintText } = await import("@/src/libs/ReceiptPrinting");
      const storeData = JSON.parse(localStorage.getItem("store_data") || "{}");
      const text = buildKdsPrintText({ storeData, order });
      printDirect(text, false);
      sileo.success({ title: "Order Printed", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }, duration: 1000 });
    } catch (err) {
      console.error("Print KDS failed", err);
      sileo.error({ title: "Print Failed", fill: "#171717", styles: { title: "text-white!" } });
    }
  };

  const filterItemIds = useMemo((): Set<string> | null => {
    if (categoryFilter.size === 0) return null;
    const allowed = new Set<string>();
    itemAncestorMap.forEach((ancestors, itemId) => {
      if (ancestors.some(aid => categoryFilter.has(aid))) allowed.add(itemId);
    });
    return allowed;
  }, [categoryFilter, itemAncestorMap]);

  const prevOrdersRef     = useRef<string[]>([]);
  const loggedReceivedRef = useRef(new Set<string>());
  const modifierStatesRef = useRef<Map<string, 'PREPARING' | 'READY'>>(new Map());

  // ── URL-preset KDS mode ──────────────────────────────────────────────────

  useEffect(() => {
    const params  = new URLSearchParams(window.location.search);
    const kdsMode = params.get("kds");
    if (!kdsMode) return;
    if (kdsMode === "3") { handleChangeViewMode("READY"); return; }
    if (menuFilterTree.length === 0) return;

    const beverageNames = ["beverage", "beverages", "drinks", "drink"];
    if (kdsMode === "1") {
      const allIds = new Set<string>();
      menuFilterTree.forEach(cat => {
        if (!beverageNames.some(b => cat.name.toLowerCase().includes(b))) {
          allIds.add(cat.id);
          (cat.children || []).forEach(c => { allIds.add(c.id); (c.children || []).forEach(gc => allIds.add(gc.id)); });
        }
      });
      setCategoryFilter(allIds);
      handleChangeViewMode("PREPARING");
    } else if (kdsMode === "2") {
      const bevIds = new Set<string>();
      menuFilterTree.forEach(cat => {
        if (beverageNames.some(b => cat.name.toLowerCase().includes(b))) {
          bevIds.add(cat.id);
          (cat.children || []).forEach(c => { bevIds.add(c.id); (c.children || []).forEach(gc => bevIds.add(gc.id)); });
        }
      });
      setCategoryFilter(bevIds);
      handleChangeViewMode("PREPARING");
    }
  }, [menuFilterTree]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("kds")) return;
    try { localStorage.setItem('kds_category_filter', JSON.stringify([...categoryFilter])); } catch {}
  }, [categoryFilter]);

  useEffect(() => {
    const savedMode = localStorage.getItem('kdsViewMode');
    if (savedMode === 'PREPARING' || savedMode === 'READY') setViewMode(savedMode);
  }, []);

  // ── Settings sync ─────────────────────────────────────────────────────────

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const localData = localStorage.getItem('store_data');
        if (localData) {
          const parsed = JSON.parse(localData);
          if (parsed.kdsWarningMinutes !== undefined && parsed.kdsDangerMinutes !== undefined)
            setKdsTimers({ warning: Number(parsed.kdsWarningMinutes), danger: Number(parsed.kdsDangerMinutes) });
        }
      } catch (e) {}
      try {
        const WORKSTATION_ID = getWorkstationId() || '001';
        const res = await fetch(`/api/settings?workstationId=${WORKSTATION_ID}`);
        if (res.ok) {
          const data    = await res.json();
          const warning = Number(data.kdsWarningMinutes) || 5;
          const danger  = Number(data.kdsDangerMinutes)  || 10;
          setKdsTimers({ warning, danger });
          const existing = JSON.parse(localStorage.getItem('store_data') || '{}');
          existing.kdsWarningMinutes = warning;
          existing.kdsDangerMinutes  = danger;
          localStorage.setItem('store_data', JSON.stringify(existing));
        }
      } catch (err) { console.error('Failed to sync KDS timers from API', err); }
    };
    fetchSettings();
    const id = setInterval(fetchSettings, 30000);
    return () => clearInterval(id);
  }, []);

  // ── Menu / filter tree ────────────────────────────────────────────────────

  useEffect(() => {
    const loadMenu = async () => {
      try {
        const res = await fetch('/api/menu');
        if (!res.ok) return;
        const menuRecord   = await res.json();
        const categories   = menuRecord.payload.categories || menuRecord.payload.data?.categories || [];
        const tree: FilterNode[]          = [];
        const ancestorMap  = new Map<string, string[]>();

        const isBundle = (item: any) =>
          (item.modifierGroups || []).some((mg: any) =>
            (mg.modifiers || []).some((mod: any) => mod.id.startsWith('MD-'))
          );
        const registerItem = (itemId: string, ancestorIds: string[]) => {
          const existing = ancestorMap.get(itemId) || [];
          ancestorMap.set(itemId, [...new Set([...existing, ...ancestorIds])]);
        };

        categories.forEach((cat: any) => {
          const catNode: FilterNode = { id: cat.id, name: cat.name, type: 'category', itemIds: [], children: [] };
          const subs: any[] = cat.subcategories || [];
          if (subs.length > 0) {
            subs.forEach((sub: any) => {
              const subNode: FilterNode = { id: sub.id, name: sub.name, type: 'subcategory', itemIds: [], children: [] };
              (sub.items || []).forEach((item: any) => {
                subNode.itemIds.push(item.id); catNode.itemIds.push(item.id);
                const ancestors = [cat.id, sub.id];
                if (isBundle(item)) { subNode.children!.push({ id: item.id, name: item.name, type: 'bundle', itemIds: [item.id] }); ancestors.push(item.id); }
                registerItem(item.id, ancestors);
              });
              catNode.children!.push(subNode);
            });
          } else {
            (cat.items || []).forEach((item: any) => {
              catNode.itemIds.push(item.id);
              const ancestors = [cat.id];
              if (isBundle(item)) { catNode.children!.push({ id: item.id, name: item.name, type: 'bundle', itemIds: [item.id] }); ancestors.push(item.id); }
              registerItem(item.id, ancestors);
            });
          }
          tree.push(catNode);
        });
        setMenuFilterTree(tree);
        setItemAncestorMap(ancestorMap);
      } catch (err) { console.error('Failed to load menu for filter:', err); }
    };
    loadMenu();
  }, []);

  // ── Notification / audit on new orders ───────────────────────────────────

  useEffect(() => {
    if (activeOrders.length === 0) { prevOrdersRef.current = []; return; }
    const currentIds = activeOrders.map(o => o._id);
    const unseen = activeOrders.filter(o => !loggedReceivedRef.current.has(o._id));
    unseen.forEach(order => {
      loggedReceivedRef.current.add(order._id);
      logAuditEvent(order._id, order.OrderNo, { type: 'ORDER_RECEIVED', timestamp: new Date().toISOString() });
    });
    if (prevOrdersRef.current.length > 0) {
      const hasNew = currentIds.some(id => !prevOrdersRef.current.includes(id));
      if (hasNew) playNotificationSound();
    }
    prevOrdersRef.current = currentIds;
  }, [activeOrders]);

  const handleChangeViewMode = (mode: 'PREPARING' | 'READY') => {
    setViewMode(mode);
    localStorage.setItem('kdsViewMode', mode);
  };

  // ── Fetch active orders ───────────────────────────────────────────────────

  const fetchActiveOrders = async () => {
    try {
      const res  = await fetch('/api/kds');
      const data = await res.json();
      if (data.success) {
        setActiveOrders(data.orders.map((order: Order) => ({
          ...order,
          items: order.items.map((item: OrderItem, itemIdx: number) => ({
            ...item,
            modifiers: (item.modifiers || []).map((mod: OrderModifier, modIdx: number) => {
              const saved = modifierStatesRef.current.get(`${order._id}:${itemIdx}:${modIdx}`);
              return saved ? { ...mod, kitchenState: saved } : mod;
            }),
          })),
        })));
      }
    } catch (err) { console.error('Failed to fetch KDS orders:', err); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    fetchActiveOrders();
    const id = setInterval(fetchActiveOrders, 3000);
    return () => clearInterval(id);
  }, []);

  // ── History panel ─────────────────────────────────────────────────────────
  // FIX 1: PREPARING view → show READY active orders (accidental ready-marks to revert)
  //        READY view     → show SERVED completed transactions (as before)

  const openHistory = async () => {
    setShowHistory(true);
    setHistoryLoading(true);
    try {
      if (viewMode === 'PREPARING') {
        // Pull currently-READY orders from in-memory active list
        const readyOrders = activeOrders.filter(o => o.kitchenState === 'READY');
        setHistoryOrders(readyOrders);
        if (readyOrders.length > 0) {
          try {
            const ids      = readyOrders.map(o => o._id).join(',');
            const auditRes = await fetch(`/api/kds-audit?orderIds=${ids}`);
            if (auditRes.ok) {
              const auditData: { orderId: string; events: AuditEvent[] }[] = await auditRes.json();
              const trailMap: Record<string, AuditEvent[]> = {};
              auditData.forEach(t => { trailMap[t.orderId] = t.events || []; });
              setAuditTrails(prev => ({ ...prev, ...trailMap }));
            }
          } catch {}
        }
        setHistoryLoading(false);
      } else {
        // READY view: fetch served transactions
        const res  = await fetch(`/api/transactions?limit=200`);
        const data = await res.json();
        if (data.transactions) {
          const served = data.transactions
            .filter((tx: any) => tx.kitchenState === 'SERVED' && tx.status !== 'voided' && tx.status !== 'refunded')
            .sort((a: any, b: any) => new Date(b.updatedAt || b.createdAt).getTime() - new Date(a.updatedAt || a.createdAt).getTime());
          const normalized: Order[] = served.map((tx: any) => ({
            _id: tx._id, OrderNo: tx.OrderNo || tx.orderNumber || tx.id,
            orderTime: tx.orderTime || tx.createdAt, kitchenState: 'SERVED' as const,
            featureFlags: tx.featureFlags, updatedAt: tx.updatedAt || tx.orderTime || tx.createdAt,
            sessionId: tx.sessionId, shiftNo: tx.shiftNo,
            items: tx.items ? tx.items.map((item: any) => ({
              id: item.id || '', itemName: item.itemName || item.name || 'Item',
              quantity: item.quantity || item.qty || 1,
              modifiers: Array.isArray(item.modifiers) ? item.modifiers : Object.values(item.modifiers || {}),
            })) : [],
          }));
          setHistoryOrders(normalized);
          if (normalized.length > 0) {
            const ids      = normalized.map(o => o._id).join(',');
            const auditRes = await fetch(`/api/kds-audit?orderIds=${ids}`);
            if (auditRes.ok) {
              const auditData: { orderId: string; events: AuditEvent[] }[] = await auditRes.json();
              const trailMap: Record<string, AuditEvent[]> = {};
              auditData.forEach(t => { trailMap[t.orderId] = t.events || []; });
              setAuditTrails(trailMap);
            }
          }
        }
        setHistoryLoading(false);
      }
    } catch (err) {
      console.error('Failed to fetch history:', err);
      setHistoryLoading(false);
    }
  };

  // ── State update handlers ─────────────────────────────────────────────────

  const handleUpdateState = async (transactionId: string, newState: string, targetItemIndices?: number[]) => {
    let shouldAutoBumpOrder = false;
    let finalOrderState = '';

    setActiveOrders((prev) => prev.map((order) => {
      if (order._id !== transactionId) return order;
      
      const newItems = [...order.items];
      if (targetItemIndices) {
        targetItemIndices.forEach(idx => {
          if (newItems[idx]) newItems[idx] = { ...newItems[idx], kitchenState: newState as 'PREPARING'|'READY'|'SERVED' };
        });
      } else {
        newItems.forEach((item, idx) => {
          newItems[idx] = { ...item, kitchenState: newState as 'PREPARING'|'READY'|'SERVED' };
        });
      }

      let nextOrderState = order.kitchenState;

      if (newState === 'READY') {
        const allReady = newItems.every(item => resolveItemState(item) === 'READY' || resolveItemState(item) === 'SERVED');
        if (allReady && order.kitchenState === 'PREPARING') {
          nextOrderState = 'READY';
          shouldAutoBumpOrder = true;
          finalOrderState = 'READY';
        }
      } else if (newState === 'SERVED') {
        const allServed = newItems.every(item => resolveItemState(item) === 'SERVED');
        if (allServed && order.kitchenState !== 'SERVED') {
          nextOrderState = 'SERVED';
          shouldAutoBumpOrder = true;
          finalOrderState = 'SERVED';
        }
      } else if (newState === 'PREPARING') {
         if (order.kitchenState === 'READY') {
           nextOrderState = 'PREPARING';
           shouldAutoBumpOrder = true;
           finalOrderState = 'PREPARING';
         }
      }
      
      return { ...order, items: newItems, kitchenState: nextOrderState };
    }).filter(o => o.kitchenState !== 'SERVED'));

    const order = activeOrders.find(o => o._id === transactionId);
    if (order) {
      const indicesToLog = targetItemIndices || order.items.map((_, i) => i);
      indicesToLog.forEach(idx => {
        if (newState !== 'SERVED') {
          logAuditEvent(transactionId, order.OrderNo, {
            type: newState === 'READY' ? 'ITEM_DONE' : 'ITEM_REVERTED',
            timestamp: new Date().toISOString(), itemName: order.items[idx]?.itemName,
          });
        }
      });
    }

    try {
      const bodyPayload: any = { transactionId, newState };
      if (targetItemIndices) bodyPayload.itemIndices = targetItemIndices;

      const res = await fetch('/api/kds', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(bodyPayload) });
      if (!res.ok) throw new Error();
      
      if (shouldAutoBumpOrder && finalOrderState && order) {
        await fetch('/api/kds', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ transactionId, newState: finalOrderState }) });
        await logAuditEvent(transactionId, order.OrderNo, { type: finalOrderState === 'READY' ? 'ORDER_READY' : (finalOrderState === 'SERVED' ? 'ORDER_SERVED' : 'ORDER_BACK_TO_PREPARING'), timestamp: new Date().toISOString() });
      }
      fetchActiveOrders();
    } catch {
      sileo.error({ title: 'Sync Error', description: 'Failed to update order state.' });
      fetchActiveOrders();
    }
  };

  const handleUpdateItemState = async (transactionId: string, itemIdx: number, newState: string) => {
    let shouldAutoBumpOrder = false;
    let finalOrderState = '';

    setActiveOrders((prev) => prev.map((order) => {
      if (order._id !== transactionId) return order;
      const newItems = [...order.items];
      newItems[itemIdx] = { ...newItems[itemIdx], kitchenState: newState as 'PREPARING' | 'READY' | 'SERVED' };
      
      let nextOrderState = order.kitchenState;

      if (newState === 'READY') {
        const allReady = newItems.every(item => resolveItemState(item) === 'READY' || resolveItemState(item) === 'SERVED');
        if (allReady && order.kitchenState === 'PREPARING') {
          nextOrderState = 'READY';
          shouldAutoBumpOrder = true;
          finalOrderState = 'READY';
        }
      } else if (newState === 'SERVED') {
        const allServed = newItems.every(item => resolveItemState(item) === 'SERVED');
        if (allServed && order.kitchenState !== 'SERVED') {
          nextOrderState = 'SERVED';
          shouldAutoBumpOrder = true;
          finalOrderState = 'SERVED';
        }
      }
      return { ...order, items: newItems, kitchenState: nextOrderState };
    }).filter(o => o.kitchenState !== 'SERVED'));

    const order = activeOrders.find(o => o._id === transactionId);
    if (order) {
      if (newState !== 'SERVED') {
        logAuditEvent(transactionId, order.OrderNo, {
          type: newState === 'READY' ? 'ITEM_DONE' : 'ITEM_REVERTED',
          timestamp: new Date().toISOString(), itemName: order.items[itemIdx]?.itemName,
        });
      }
    }

    try {
      const res = await fetch('/api/kds', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ transactionId, newState, itemIndex: itemIdx }) });
      if (!res.ok) throw new Error();
      
      if (shouldAutoBumpOrder && finalOrderState && order) {
        await fetch('/api/kds', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ transactionId, newState: finalOrderState }) });
        await logAuditEvent(transactionId, order.OrderNo, { type: finalOrderState === 'READY' ? 'ORDER_READY' : 'ORDER_SERVED', timestamp: new Date().toISOString() });
      }
      fetchActiveOrders();
    } catch {
      sileo.error({ title: 'Sync Error', description: 'Failed to update item.' });
      fetchActiveOrders();
    }
  };

  const handleUpdateModifierState = async (transactionId: string, itemIdx: number, modifierIdx: number, newState: string) => {
    const modKey = `${transactionId}:${itemIdx}:${modifierIdx}`;
    modifierStatesRef.current.set(modKey, newState as 'PREPARING' | 'READY');

    const order       = activeOrders.find(o => o._id === transactionId);
    const item        = order?.items[itemIdx];
    const bundleMods  = (item?.modifiers || []).filter(isBundleMod);
    const allModsDone = bundleMods.length > 0 && bundleMods.every((_, mi) => {
      const actualIdx = (() => {
        let count = -1;
        for (let k = 0; k < (item!.modifiers || []).length; k++) {
          if (isBundleMod(item!.modifiers![k])) count++;
          if (count === mi) return k;
        }
        return -1;
      })();
      const saved   = modifierStatesRef.current.get(`${transactionId}:${itemIdx}:${actualIdx}`);
      const current = item!.modifiers![actualIdx]?.kitchenState;
      return (saved ?? current) === 'READY';
    });

    let shouldAutoReadyOrder = false;
    setActiveOrders((prev) => prev.map((o) => {
      if (o._id !== transactionId) return o;
      const newItems = o.items.map((it, i) => {
        if (i !== itemIdx) return it;
        const newModifiers = (it.modifiers || []).map((mod, mi) => mi === modifierIdx ? { ...mod, kitchenState: newState as 'PREPARING' | 'READY' } : mod);
        return { ...it, modifiers: newModifiers, kitchenState: allModsDone ? 'READY' as const : 'PREPARING' as const };
      });
      const allReady = newItems.every(it => resolveItemState(it) === 'READY');
      if (allReady) shouldAutoReadyOrder = true;
      return { ...o, items: newItems, kitchenState: allReady ? 'READY' : o.kitchenState };
    }));

    if (order && item) {
      logAuditEvent(transactionId, order.OrderNo, {
        type: newState === 'READY' ? 'ITEM_DONE' : 'ITEM_REVERTED',
        timestamp: new Date().toISOString(), itemName: item.modifiers?.[modifierIdx]?.name,
      });
    }

    if (!allModsDone) {
      if (item?.kitchenState === 'READY') {
        try { await fetch('/api/kds', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ transactionId, newState: 'PREPARING', itemIndex: itemIdx }) }); }
        catch (err) { console.error('Failed to revert item state:', err); }
      }
      return;
    }

    try {
      bundleMods.forEach((_, mi) => {
        const actualIdx = (() => { let count = -1; for (let k = 0; k < (item!.modifiers || []).length; k++) { if (isBundleMod(item!.modifiers![k])) count++; if (count === mi) return k; } return -1; })();
        modifierStatesRef.current.delete(`${transactionId}:${itemIdx}:${actualIdx}`);
      });
      await fetch('/api/kds', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ transactionId, newState: 'READY', itemIndex: itemIdx }) });
      if (shouldAutoReadyOrder && order) {
        await fetch('/api/kds', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ transactionId, newState: 'READY' }) });
        await logAuditEvent(transactionId, order.OrderNo, { type: 'ORDER_READY', timestamp: new Date().toISOString() });
      }
      fetchActiveOrders();
    } catch {
      sileo.error({ title: 'Sync Error', description: 'Failed to update combo component.' });
      fetchActiveOrders();
    }
  };

  const handleRecall = async (transactionId: string, newState: string) => {
    const order = historyOrders.find(o => o._id === transactionId);
    setHistoryOrders((prev) => prev.filter((o) => o._id !== transactionId));
    
    if (order) {
      // Log ITEM_REVERTED for each individual item instead of ORDER_RECALLED
      order.items.forEach(item => {
        logAuditEvent(transactionId, order.OrderNo, { 
          type: 'ITEM_REVERTED', 
          timestamp: new Date().toISOString(), 
          itemName: item.itemName || item.name 
        });
      });
    }

    try {
      await fetch('/api/kds', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ transactionId, newState }) });
      fetchActiveOrders();
    } catch { sileo.error({ title: 'Sync Error', description: 'Failed to recall order.' }); }
  };

  // ── Derived lists ─────────────────────────────────────────────────────────

  const getOrderStateForFilter = useCallback((order: Order, filter: Set<string> | null): 'PREPARING' | 'READY' | 'SERVED' | 'NONE' => {
    if (!filter) return order.kitchenState; 
    
    const matchingItems = order.items.filter(item => filter.has(item.id));
    if (matchingItems.length === 0) return 'NONE';

    const allServed = matchingItems.every(item => resolveItemState(item) === 'SERVED');
    if (allServed) return 'SERVED';

    const allReadyOrServed = matchingItems.every(item => resolveItemState(item) === 'READY' || resolveItemState(item) === 'SERVED');
    if (allReadyOrServed) return 'READY';

    return 'PREPARING';
  }, []);

  const filteredPreparingOrders = useMemo(() => activeOrders.filter(o => getOrderStateForFilter(o, filterItemIds) === 'PREPARING'), [activeOrders, filterItemIds, getOrderStateForFilter]);
  const filteredReadyOrders     = useMemo(() => activeOrders.filter(o => getOrderStateForFilter(o, filterItemIds) === 'READY'), [activeOrders, filterItemIds, getOrderStateForFilter]);

  // ── Loading screen ────────────────────────────────────────────────────────

  if (loading && activeOrders.length === 0) {
    return (
      <div style={{ minHeight: '100vh', background: C.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 16 }}>
        <div className="spinner" style={{ width: 48, height: 48, border: `4px solid rgba(0,0,0,0.1)`, borderTopColor: C.orange, borderRadius: '50%' }} />
        <p style={{ color: C.textSub, fontFamily: 'Poppins', fontWeight: 800, letterSpacing: 4, textTransform: 'uppercase', fontSize: 13 }}>Loading Kitchen Display...</p>
      </div>
    );
  }

  // ── Render ────────────────────────────────────────────────────────────────

  return (
    <>
      <div className='z-10000'>
        <Toaster position='top-center' />
      </div>
      <style dangerouslySetInnerHTML={{ __html: `
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800;900&display=swap');
        *, *::before, *::after { box-sizing: border-box; }
        body { margin: 0; background: ${C.bg}; }
        @keyframes popIn { 0% { opacity:0; transform:scale(0.92) translateY(10px); } 65% { opacity:1; transform:scale(1.02) translateY(-3px); } 100% { opacity:1; transform:scale(1) translateY(0); } }
        @keyframes slideInRight { from { transform:translateX(100%); } to { transform:translateX(0); } }
        @keyframes spin  { to { transform:rotate(360deg); } }
        @keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.55; } }
        .animate-pop { animation: popIn 0.35s cubic-bezier(0.175,0.885,0.32,1.275) both; opacity:0; }
        .spinner { animation: spin 0.8s linear infinite; }
        .hide-scroll::-webkit-scrollbar { display:none; }
        .hide-scroll { -ms-overflow-style:none; scrollbar-width:none; }
        .kds-card:hover { box-shadow:0 12px 40px rgba(0,0,0,0.08) !important; transform:translateY(-4px); }
        .kds-btn-primary { transition:filter 0.15s,transform 0.15s,box-shadow 0.15s; }
        .kds-btn-primary:hover { filter:brightness(1.1); transform:translateY(-2px); box-shadow:0 6px 16px rgba(255,103,0,0.4) !important; }
        .kds-btn-primary:active { transform:scale(0.97); }
        .kds-btn-success { transition:filter 0.15s,transform 0.15s,box-shadow 0.15s; }
        .kds-btn-success:hover { filter:brightness(1.1); transform:translateY(-2px); box-shadow:0 6px 16px rgba(34,197,94,0.4) !important; }
        .kds-btn-success:active { transform:scale(0.97); }
        .kds-btn-ghost:hover { background:rgba(0,0,0,0.04) !important; color:#1C1108 !important; }
        .kds-recall-btn:hover { background:rgba(0,0,0,0.06) !important; color:#1C1108 !important; }
        .kds-mod-row:hover { background:rgba(255,103,0,0.04) !important; }
        .kds-title-edit-btn { opacity:0; transition:opacity 0.2s; }
        .kds-title-wrap:hover .kds-title-edit-btn { opacity:1; }
      ` }} />

      <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden', userSelect: 'none', fontFamily: 'Poppins, sans-serif', background: C.bg }}>

        {/* ── Header ── */}
        <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 28px', background: 'rgba(255,255,255,0.8)', backdropFilter: 'blur(20px)', borderBottom: `1px solid ${C.border}`, flexShrink: 0, gap: 16, zIndex: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <img src="/images/logo.svg" alt="Brand Logo" style={{ height: 50, width: 'auto', objectFit: 'contain' }} />
            <div style={{ width: 2, height: 32, background: 'rgba(0,0,0,0.1)', borderRadius: 1 }} />

            {/* FIX 2: Inline-editable display title */}
            {editingTitle ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <input
                  autoFocus
                  value={titleDraft}
                  onChange={e => setTitleDraft(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') { const v = titleDraft.trim(); setDisplayTitle(v); try { localStorage.setItem('kds_display_title', v); } catch {} setEditingTitle(false); }
                    if (e.key === 'Escape') setEditingTitle(false);
                  }}
                  placeholder={viewMode === 'READY' ? 'Dispatch Display' : 'Kitchen Display'}
                  disabled
                  style={{ fontSize: 18, fontWeight: 900, color: C.textSub, fontFamily: 'Poppins', letterSpacing: 2, textTransform: 'uppercase', border: 'none', borderBottom: `2px solid ${C.orange}`, background: 'transparent', outline: 'none', padding: '2px 4px', width: 260 }}
                />
                {/* <button onClick={() => { const v = titleDraft.trim(); setDisplayTitle(v); try { localStorage.setItem('kds_display_title', v); } catch {} setEditingTitle(false); }}
                  style={{ background: C.orange, border: 'none', color: '#fff', borderRadius: 8, padding: '4px 12px', fontFamily: 'Poppins', fontSize: 11, fontWeight: 800, cursor: 'pointer', letterSpacing: 1 }}>
                  Save
                </button> */}
                {/* <button onClick={() => setEditingTitle(false)}
                  style={{ background: 'rgba(0,0,0,0.05)', border: 'none', color: C.textSub, borderRadius: 8, padding: '4px 10px', fontFamily: 'Poppins', fontSize: 11, fontWeight: 800, cursor: 'pointer' }}>
                  Cancel
                </button> */}
              </div>
            ) : (
              <div className="kds-title-wrap" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 18, fontWeight: 900, color: C.textSub, letterSpacing: 2, textTransform: 'uppercase', fontFamily: 'Poppins', marginTop: 2 }}>
                  {resolvedTitle}
                </span>
              </div>
            )}
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <LiveClock serverTimeOffsetMs={serverTimeOffsetMs} />
            <button onClick={() => setShowSettings(true)} className="kds-btn-ghost"
              style={{ padding: '10px 20px', borderRadius: 12, background: C.white, border: `1px solid rgba(0,0,0,0.1)`, color: C.textSub, fontSize: 12, fontWeight: 800, fontFamily: 'Poppins', letterSpacing: 1.5, textTransform: 'uppercase', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, boxShadow: '0 2px 8px rgba(0,0,0,0.02)', transition: 'all 0.2s' }}>
              <FiSettings size={15} /> Settings
            </button>
            <button onClick={openHistory} className="kds-btn-ghost"
              style={{ padding: '10px 20px', borderRadius: 12, background: C.white, border: `1px solid rgba(0,0,0,0.1)`, color: C.textSub, fontSize: 12, fontWeight: 800, fontFamily: 'Poppins', letterSpacing: 1.5, textTransform: 'uppercase', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, boxShadow: '0 2px 8px rgba(0,0,0,0.02)', transition: 'all 0.2s' }}>
              <FiRotateCcw size={15} /> History
            </button>
          </div>
        </header>

        {/* ── Main ── */}
        <div style={{ flex: 1, display: 'flex', overflow: 'hidden', padding: 24 }}>
          {viewMode === 'PREPARING' ? (
            <OrderSection label="Preparing" orders={filteredPreparingOrders} onAction={handleUpdateState} onItemAction={handleUpdateItemState} onModifierAction={handleUpdateModifierState} onPrint={handlePrintOrder} filterItemIds={filterItemIds} accent={C.orange} emptyIcon={<FiShoppingBag size={56} color="rgba(0,0,0,0.1)" />} kdsTimers={kdsTimers} serverTimeOffsetMs={serverTimeOffsetMs} />
          ) : (
            <OrderSection label="Ready" orders={filteredReadyOrders} onAction={handleUpdateState} onItemAction={handleUpdateItemState} onModifierAction={() => {}} onPrint={handlePrintOrder} filterItemIds={null} accent={C.amber} emptyIcon={<FiInbox size={56} color="rgba(0,0,0,0.1)" />} kdsTimers={kdsTimers} serverTimeOffsetMs={serverTimeOffsetMs} />
          )}
        </div>

        {/* ── History panel ── */}
        {showHistory && (
          <HistoryPanel orders={historyOrders} onClose={() => setShowHistory(false)} onRecall={handleRecall} loading={historyLoading} auditTrails={auditTrails} viewMode={viewMode} />
        )}

        {/* ── Settings panel ── */}
        {showSettings && (
          <div style={{ position: 'fixed', inset: 0, zIndex: 200, display: 'flex', justifyContent: 'flex-end', background: 'rgba(15, 23, 42, 0.4)', backdropFilter: 'blur(8px)' }} onClick={() => setShowSettings(false)}>
            <div style={{ width: 450, height: '100%', background: '#F8F9FA', borderLeft: `1px solid ${C.border}`, display: 'flex', flexDirection: 'column', boxShadow: '-12px 0 40px rgba(0,0,0,0.15)', animation: 'slideInRight 0.3s cubic-bezier(0.16,1,0.3,1)' }} onClick={(e) => e.stopPropagation()}>
              <div style={{ padding: '24px', background: C.white, borderBottom: `1px solid rgba(0,0,0,0.05)`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', boxShadow: '0 2px 10px rgba(0,0,0,0.02)' }}>
                <div>
                  <h2 style={{ margin: 0, fontSize: 22, fontWeight: 900, color: C.text, fontFamily: 'Poppins' }}>Settings</h2>
                  <p style={{ margin: 0, fontSize: 11, color: C.textSub, fontFamily: 'Poppins', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 1, marginTop: 4 }}>Configure Display</p>
                </div>
                <button onClick={() => setShowSettings(false)} style={{ width: 40, height: 40, borderRadius: 20, background: 'rgba(0,0,0,0.05)', border: 'none', color: C.textSub, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <FiX size={20} />
                </button>
              </div>

              <div style={{ flex: 1, overflowY: 'auto', padding: 24, display: 'flex', flexDirection: 'column', gap: 24 }} className="hide-scroll">

                {/* FIX 2: Display Title setting */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <label style={{ fontSize: 13, fontWeight: 700, color: C.textSub, fontFamily: 'Poppins', textTransform: 'uppercase', letterSpacing: 1 }}>Display Title</label>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <input
                      value={editingTitle ? titleDraft : displayTitle}
                      onChange={e => { setTitleDraft(e.target.value); if (!editingTitle) setEditingTitle(true); }}
                      onFocus={() => { if (!editingTitle) { setTitleDraft(displayTitle); setEditingTitle(true); } }}
                      onKeyDown={e => {
                        if (e.key === 'Enter') { const v = titleDraft.trim(); setDisplayTitle(v); try { localStorage.setItem('kds_display_title', v); } catch {} setEditingTitle(false); }
                        if (e.key === 'Escape') setEditingTitle(false);
                      }}
                      placeholder={viewMode === 'READY' ? 'Dispatch Display' : 'Kitchen Display'}
                      style={{ flex: 1, padding: '10px 14px', borderRadius: 12, fontFamily: 'Poppins', fontSize: 13, fontWeight: 700, border: `1.5px solid rgba(0,0,0,0.1)`, background: C.white, color: C.text, outline: 'none' }}
                    />
                    <button onClick={() => { 
                        const v = (editingTitle ? titleDraft : displayTitle).trim(); 
                        setDisplayTitle(v); 
                        try { 
                          localStorage.setItem('kds_display_title', v);
                          sileo.success({title: "KDS Title Saved Successfully!", fill: "#171717", styles: { title: "text-white!", description: "text-white/75!" }, duration: 1000 });
                        } catch {}
                        setEditingTitle(false); 
                      }}
                      style={{ padding: '10px 16px', borderRadius: 12, background: C.orange, border: 'none', color: '#fff', fontFamily: 'Poppins', fontSize: 12, fontWeight: 800, cursor: 'pointer', whiteSpace: 'nowrap' }}>
                      Save
                    </button>
                  </div>
                  {displayTitle.trim() && (
                    <button onClick={() => { setDisplayTitle(''); setTitleDraft(''); setEditingTitle(false); try { localStorage.removeItem('kds_display_title'); } catch {} }}
                      style={{ alignSelf: 'flex-start', background: 'none', border: 'none', fontSize: 11, fontWeight: 700, color: C.textFaint, fontFamily: 'Poppins', cursor: 'pointer', padding: 0 }}>
                      Reset to default
                    </button>
                  )}
                  <p style={{ margin: 0, fontSize: 11, color: C.textFaint, fontFamily: 'Poppins', fontWeight: 600 }}>
                    Default: &ldquo;{viewMode === 'READY' ? 'Dispatch Display' : 'Kitchen Display'}&rdquo;
                  </p>
                </div>

                <div style={{ height: 1, background: 'rgba(0,0,0,0.06)' }} />

                {/* View mode toggle */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  <label style={{ fontSize: 13, fontWeight: 700, color: C.textSub, fontFamily: 'Poppins', textTransform: 'uppercase', letterSpacing: 1 }}>Active Screen View</label>
                  <div style={{ display: 'flex', gap: 12 }}>
                    {(['PREPARING', 'READY'] as const).map(mode => (
                      <button key={mode} onClick={() => handleChangeViewMode(mode)}
                        style={{ flex: 1, padding: '16px', borderRadius: 16, cursor: 'pointer', fontFamily: 'Poppins', fontSize: 14, fontWeight: 800, transition: 'all 0.2s', background: viewMode === mode ? (mode === 'PREPARING' ? C.orange : C.amber) : C.white, color: viewMode === mode ? C.white : C.textSub, border: `2px solid ${viewMode === mode ? (mode === 'PREPARING' ? C.orange : C.amber) : 'rgba(0,0,0,0.05)'}`, boxShadow: viewMode === mode ? `0 4px 12px ${mode === 'PREPARING' ? C.orange : C.amber}40` : 'none' }}>
                        {mode === 'PREPARING' ? 'Preparing' : 'Ready'}
                      </button>
                    ))}
                  </div>
                </div>

                <div style={{ height: 1, background: 'rgba(0,0,0,0.06)' }} />

                {/* Category filter */}
                {viewMode === 'PREPARING' && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <label style={{ fontSize: 13, fontWeight: 700, color: C.textSub, fontFamily: 'Poppins', textTransform: 'uppercase', letterSpacing: 1 }}>Category Filter</label>
                      {categoryFilter.size > 0 && (
                        <button onClick={() => setCategoryFilter(new Set())} style={{ fontSize: 11, fontWeight: 800, color: C.orange, fontFamily: 'Poppins', background: 'none', border: 'none', cursor: 'pointer', letterSpacing: 0.5 }}>Show All</button>
                      )}
                    </div>
                    {categoryFilter.size === 0 && (
                      <div style={{ padding: '10px 14px', borderRadius: 12, background: 'rgba(0,0,0,0.03)', border: '1px solid rgba(0,0,0,0.05)', fontSize: 12, fontWeight: 600, color: C.textFaint, fontFamily: 'Poppins' }}>
                        All orders shown — tap a category to filter
                      </div>
                    )}
                    {menuFilterTree.length === 0 ? (
                      <div style={{ fontSize: 12, color: C.textFaint, fontFamily: 'Poppins', fontWeight: 600 }}>Loading menu…</div>
                    ) : (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                        {menuFilterTree.map(cat => {
                          const catChecked       = categoryFilter.has(cat.id);
                          const someChildChecked = (cat.children || []).some(c => categoryFilter.has(c.id));
                          const isIndeterminate  = !catChecked && someChildChecked;
                          const toggleCat = () => setCategoryFilter(prev => {
                            const next = new Set(prev);
                            if (catChecked) { next.delete(cat.id); (cat.children || []).forEach(c => { next.delete(c.id); (c.children || []).forEach(gc => next.delete(gc.id)); }); }
                            else            { next.add(cat.id);    (cat.children || []).forEach(c => { next.add(c.id);    (c.children || []).forEach(gc => next.add(gc.id));    }); }
                            return next;
                          });
                          return (
                            <div key={cat.id} style={{ borderRadius: 14, overflow: 'hidden', border: '1px solid rgba(0,0,0,0.06)', background: C.white }}>
                              <button onClick={toggleCat} style={{ width: '100%', padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10, background: catChecked ? `${C.orange}10` : 'transparent', border: 'none', cursor: 'pointer', fontFamily: 'Poppins', transition: 'background 0.2s' }}>
                                <span style={{ width: 18, height: 18, borderRadius: 5, flexShrink: 0, border: `2px solid ${catChecked || isIndeterminate ? C.orange : 'rgba(0,0,0,0.2)'}`, background: catChecked ? C.orange : isIndeterminate ? `${C.orange}30` : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.15s' }}>
                                  {catChecked && <FiCheck size={11} color="#fff" strokeWidth={3} />}
                                  {isIndeterminate && <span style={{ width: 8, height: 2, background: C.orange, borderRadius: 1, display: 'block' }} />}
                                </span>
                                <span style={{ fontSize: 13, fontWeight: 800, color: C.text, textAlign: 'left', flex: 1 }}>{cat.name}</span>
                                <span style={{ fontSize: 10, fontWeight: 700, color: C.textFaint, background: 'rgba(0,0,0,0.04)', padding: '2px 8px', borderRadius: 999 }}>{cat.itemIds.length}</span>
                              </button>
                              {(cat.children || []).length > 0 && (
                                <div style={{ borderTop: '1px solid rgba(0,0,0,0.05)', padding: '6px 0' }}>
                                  {(cat.children || []).map(child => {
                                    const childChecked       = categoryFilter.has(child.id) || catChecked;
                                    const someGrandchild     = (child.children || []).some(gc => categoryFilter.has(gc.id));
                                    const childIndeterminate = !childChecked && !catChecked && someGrandchild;
                                    const toggleChild = (e: React.MouseEvent) => {
                                      e.stopPropagation();
                                      setCategoryFilter(prev => {
                                        const next = new Set(prev);
                                        if (catChecked) { next.delete(cat.id); (cat.children || []).forEach(c => { next.add(c.id); (c.children || []).forEach(gc => next.add(gc.id)); }); next.delete(child.id); (child.children || []).forEach(gc => next.delete(gc.id)); }
                                        else if (childChecked) { next.delete(child.id); (child.children || []).forEach(gc => next.delete(gc.id)); }
                                        else { next.add(child.id); (child.children || []).forEach(gc => next.add(gc.id)); }
                                        return next;
                                      });
                                    };
                                    return (
                                      <div key={child.id}>
                                        <button onClick={toggleChild} style={{ width: '100%', padding: '9px 16px 9px 36px', display: 'flex', alignItems: 'center', gap: 10, background: childChecked ? `${child.type === 'bundle' ? C.amber : C.orange}08` : 'transparent', border: 'none', cursor: 'pointer', fontFamily: 'Poppins', transition: 'background 0.2s' }}>
                                          <span style={{ width: 15, height: 15, borderRadius: 4, flexShrink: 0, border: `2px solid ${childChecked || childIndeterminate ? (child.type === 'bundle' ? C.amber : C.orange) : 'rgba(0,0,0,0.15)'}`, background: childChecked ? (child.type === 'bundle' ? C.amber : C.orange) : childIndeterminate ? `${C.orange}30` : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.15s' }}>
                                            {childChecked && <FiCheck size={9} color="#fff" strokeWidth={3} />}
                                            {childIndeterminate && <span style={{ width: 6, height: 2, background: C.orange, borderRadius: 1, display: 'block' }} />}
                                          </span>
                                          <span style={{ fontSize: 12, fontWeight: 700, color: C.textSub, textAlign: 'left', flex: 1 }}>{child.name}</span>
                                          {child.type === 'bundle' && <span style={{ fontSize: 9, fontWeight: 800, color: C.amber, background: `${C.amber}15`, padding: '2px 6px', borderRadius: 999, letterSpacing: 0.5 }}>BUNDLE</span>}
                                        </button>
                                        {(child.children || []).length > 0 && (childChecked || childIndeterminate) && (
                                          <div style={{ paddingLeft: 52, paddingBottom: 4 }}>
                                            {(child.children || []).map(gc => {
                                              const gcChecked = categoryFilter.has(gc.id) || childChecked || catChecked;
                                              const toggleGc  = (e: React.MouseEvent) => {
                                                e.stopPropagation();
                                                setCategoryFilter(prev => {
                                                  const next = new Set(prev);
                                                  if (childChecked || catChecked) {
                                                    if (catChecked)   { next.delete(cat.id);   (cat.children   || []).forEach(c  => { next.add(c.id);  (c.children  || []).forEach(ggc => next.add(ggc.id)); }); }
                                                    if (childChecked) { next.delete(child.id); (child.children || []).forEach(ggc => next.add(ggc.id)); }
                                                    next.delete(gc.id);
                                                  } else if (gcChecked) { next.delete(gc.id); }
                                                  else { next.add(gc.id); }
                                                  return next;
                                                });
                                              };
                                              return (
                                                <button key={gc.id} onClick={toggleGc} style={{ width: '100%', padding: '7px 12px', display: 'flex', alignItems: 'center', gap: 8, background: 'transparent', border: 'none', cursor: 'pointer', fontFamily: 'Poppins' }}>
                                                  <span style={{ width: 13, height: 13, borderRadius: 3, flexShrink: 0, border: `2px solid ${gcChecked ? C.amber : 'rgba(0,0,0,0.12)'}`, background: gcChecked ? C.amber : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.15s' }}>
                                                    {gcChecked && <FiCheck size={8} color="#fff" strokeWidth={3} />}
                                                  </span>
                                                  <span style={{ fontSize: 11, fontWeight: 700, color: C.textSub, textAlign: 'left', flex: 1 }}>{gc.name}</span>
                                                  <span style={{ fontSize: 9, fontWeight: 800, color: C.amber, background: `${C.amber}15`, padding: '2px 6px', borderRadius: 999, letterSpacing: 0.5 }}>BUNDLE</span>
                                                </button>
                                              );
                                            })}
                                          </div>
                                        )}
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}