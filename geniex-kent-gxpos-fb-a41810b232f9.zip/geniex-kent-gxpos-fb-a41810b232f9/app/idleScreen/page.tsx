"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import { useRouter } from "next/navigation";

const COLORS = [
  "#f97316", "#3b82f6", "#22c55e", "#ec4899", "#a855f7",
  "#14b8a6", "#f59e0b", "#ef4444", "#06b6d4", "#84cc16",
];

export default function IdleScreen() {
  const router = useRouter();
  const screenRef = useRef<HTMLDivElement>(null);
  const logoRef   = useRef<HTMLDivElement>(null);
  const rafRef    = useRef<number>(0);

  const stateRef = useRef({
    x: 100, y: 100,
    vx: 1.8, vy: 1.6,
    colorIdx: 0,
    W: 0, H: 0, lW: 0, lH: 0,
  });

  const [color, setColor]       = useState(COLORS[0]);
  const [pos, setPos]           = useState({ x: 100, y: 100 });
  const [clock, setClock]       = useState("");
  const [flash, setFlash]       = useState(false);
  const [flashPos, setFlashPos] = useState({ x: 0, y: 0 });
  const [imgError, setImgError] = useState(false);

  // ── Clock ──────────────────────────────────────────────────────────────────
  useEffect(() => {
    const tick = () => {
      const n = new Date();
      const t = n.toLocaleTimeString("en-PH", {
        hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
      });
      const d = n.toLocaleDateString("en-PH", {
        weekday: "long", year: "numeric", month: "long", day: "numeric",
      });
      setClock(`${t}   ·   ${d}`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  // ── Bounce loop ────────────────────────────────────────────────────────────
  const bounce = useCallback(() => {
    const s = stateRef.current;
    if (!s.W || !s.lW) return;

    s.x += s.vx;
    s.y += s.vy;

    let hit = false;

    if (s.x <= 0)            { s.x = 0;            s.vx =  Math.abs(s.vx); hit = true; }
    if (s.x >= s.W - s.lW)  { s.x = s.W - s.lW;   s.vx = -Math.abs(s.vx); hit = true; }
    if (s.y <= 0)            { s.y = 0;             s.vy =  Math.abs(s.vy); hit = true; }
    if (s.y >= s.H - s.lH)  { s.y = s.H - s.lH;   s.vy = -Math.abs(s.vy); hit = true; }

    if (hit) {
      s.colorIdx = (s.colorIdx + 1) % COLORS.length;
      setColor(COLORS[s.colorIdx]);
      setFlashPos({ x: s.x + s.lW / 2, y: s.y + s.lH / 2 });
      setFlash(true);
      setTimeout(() => setFlash(false), 180);
    }

    setPos({ x: Math.round(s.x), y: Math.round(s.y) });
    rafRef.current = requestAnimationFrame(bounce);
  }, []);

  // ── Init ───────────────────────────────────────────────────────────────────
  useEffect(() => {
    const init = () => {
      const sc = screenRef.current;
      const lg = logoRef.current;
      if (!sc || !lg) return;

      const s    = stateRef.current;
      s.W  = sc.offsetWidth;
      s.H  = sc.offsetHeight;
      s.lW = lg.offsetWidth  || 280;
      s.lH = lg.offsetHeight || 280;

      const angle = Math.random() * Math.PI * 2;
      s.x  = Math.random() * Math.max(1, s.W - s.lW);
      s.y  = Math.random() * Math.max(1, s.H - s.lH);
      s.vx = Math.cos(angle) * 1.8;
      s.vy = Math.sin(angle) * 1.6;

      setPos({ x: Math.round(s.x), y: Math.round(s.y) });
      rafRef.current = requestAnimationFrame(bounce);
    };

    const t = setTimeout(init, 100);

    const ro = new ResizeObserver(() => {
      if (screenRef.current) {
        stateRef.current.W = screenRef.current.offsetWidth;
        stateRef.current.H = screenRef.current.offsetHeight;
      }
    });
    if (screenRef.current) ro.observe(screenRef.current);

    return () => {
      clearTimeout(t);
      cancelAnimationFrame(rafRef.current);
      ro.disconnect();
    };
  }, [bounce]);

  // ── Any interaction → back to login ───────────────────────────────────────
  const handleInteraction = () => router.push("/logs");

  return (
    <div
      ref={screenRef}
      onClick={handleInteraction}
      onKeyDown={handleInteraction}
      tabIndex={0}
      style={{
        width: "100vw",
        height: "100vh",
        background: "#000",
        overflow: "hidden",
        position: "relative",
        cursor: "none",
        outline: "none",
      }}
    >
      {/* ── Bouncing Logo ── */}
      <div
        ref={logoRef}
        style={{
          position: "absolute",
          left: pos.x,
          top: pos.y,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 8,
          color,
          transition: "color 0.2s",
          userSelect: "none",
          pointerEvents: "none",
        }}
      >
        {/* Logo image — falls back to text badge if missing */}
        {!imgError ? (
          <img
            src="/images/menux_white.png"
            alt="MenuX Logo"
            onError={() => setImgError(true)}
            style={{
              width: 240,
              height: 240,
              objectFit: "contain",
              filter: `drop-shadow(0 0 14px ${color}) drop-shadow(0 0 4px ${color})`,
              transition: "filter 0.2s",
            }}
          />
        ) : (
          /* Fallback badge when image not found */
          <div
            style={{
              width: 240,
              height: 240,
              borderRadius: 18,
              border: `4px solid ${color}`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: `0 0 24px ${color}55`,
              transition: "border-color 0.2s, box-shadow 0.2s",
            }}
          >
            <span
              style={{
                fontFamily: "Impact, 'Arial Black', sans-serif",
                fontSize: 72,
                fontWeight: 900,
                color,
                lineHeight: 1,
              }}
            >
              MX
            </span>
          </div>
        )}
      </div>

      {/* ── Corner flash on bounce ── */}
      {flash && (
        <div
          style={{
            position: "absolute",
            left: flashPos.x - 120,
            top: flashPos.y - 120,
            width: 240,
            height: 240,
            borderRadius: "50%",
            background: `radial-gradient(circle, ${color}66 0%, transparent 70%)`,
            pointerEvents: "none",
            animation: "none",
          }}
        />
      )}

      {/* ── Clock ── */}
      <div
        style={{
          position: "absolute",
          bottom: 36,
          left: "50%",
          transform: "translateX(-50%)",
          fontFamily: "'Courier New', Courier, monospace",
          fontSize: 13,
          fontWeight: 600,
          color: "rgba(255,255,255,0.18)",
          letterSpacing: 2,
          whiteSpace: "nowrap",
          pointerEvents: "none",
        }}
      >
        {clock}
      </div>

      {/* ── Tap hint ── */}
      <div
        style={{
          position: "absolute",
          bottom: 16,
          left: "50%",
          transform: "translateX(-50%)",
          fontFamily: "Impact, 'Arial Black', sans-serif",
          fontSize: 9,
          fontWeight: 700,
          color: "rgba(255,255,255,0.10)",
          letterSpacing: 3,
          textTransform: "uppercase",
          whiteSpace: "nowrap",
          pointerEvents: "none",
        }}
      >
        TAP ANYWHERE TO RESUME
      </div>
    </div>
  );
}