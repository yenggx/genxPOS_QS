'use client';
import { resolveMenuImageUrl } from '@/src/utils/menuImages';
import { useEffect, useState, useMemo } from 'react';
import { DonutPlaceholder } from '../components/pos/ProductCard';

const DISSOLVE_STYLE = `
  @keyframes cfdFadeIn {
    from { opacity: 0; }
    to   { opacity: 1; }
  }
  .cfd-media-fade {
    animation: cfdFadeIn 0.55s ease-in-out;
    will-change: opacity;
  }
`;

function CartItemImage({ src }: { src?: string }) {
  const [loaded, setLoaded] = useState(false);
  const [error, setError]   = useState(false);
  const resolved = resolveMenuImageUrl(src || '');
  if (!resolved || error) return <DonutPlaceholder />;
  return (
    <div className="w-full h-full relative">
      {!loaded && <div className="absolute inset-0"><DonutPlaceholder /></div>}
      <img
        src={resolved}
        alt=""
        className="w-full h-full object-contain"
        style={{ opacity: loaded ? 1 : 0, transition: 'opacity .25s ease' }}
        onLoad={() => setLoaded(true)}
        onError={() => setError(true)}
      />
    </div>
  );
}

export default function CustomerFacingDisplay() {
  const [cartData, setCartData]   = useState<{ cart: any[]; total: number; subtotal: number; tax: number; discountAmt?: number } | null>(null);
  const [cfdConfig, setCfdConfig] = useState<any>(null);

  // ── Media playback state ──────────────────────────────────────────────────
  //
  // THREE counters, each with exactly one job:
  //
  //   mediaIndex  — which clip is active (0…N-1)
  //   renderKey   — forces a full <img>/<video> remount on every tick.
  //                 Remounting is what restarts a GIF from frame 0.
  //                 NEVER goes into effect deps — it's output-only.
  //   generation  — lets the timer effect re-run when mediaIndex didn't change
  //                 (single-clip loop). Only bumped in that one case.
  //
  // Previously a single `cycleKey` served all three roles. Bumping it for img
  // remount also re-ran the effect, which cleared the pending timer and
  // restarted it. Two mount-time triggers (localStorage + isIdle reset)
  // competing could leave the carousel with no pending timer and no future
  // nudge — the "first GIF stuck" bug.
  //
  const [mediaIndex,  setMediaIndex]  = useState(0);
  const [renderKey,   setRenderKey]   = useState(0);
  const [generation,  setGeneration]  = useState(0);

  // ── Config ────────────────────────────────────────────────────────────────
  useEffect(() => {
    const config = JSON.parse(localStorage.getItem('cfd_config') || 'null');
    if (config) setCfdConfig(config);
  }, []);

  // ── BroadcastChannel ──────────────────────────────────────────────────────
  useEffect(() => {
    const channel = new BroadcastChannel('cfd_channel');
    channel.onmessage = ({ data }) => {
      if      (data.type === 'CART_UPDATE')        setCartData(data.payload);
      else if (data.type === 'CHECKOUT_COMPLETE')  setCartData(null);
      else if (data.type === 'CFD_CONFIG_UPDATE')  setCfdConfig(data.payload);
      else if (data.type === 'GO_FULLSCREEN') {
        if (!document.fullscreenElement)
          document.documentElement.requestFullscreen({ navigationUI: 'hide' }).catch(console.error);
      } else if (data.type === 'PING') {
        channel.postMessage({ type: 'CFD_READY' });
      }
    };
    channel.postMessage({ type: 'CFD_READY' });
    return () => channel.close();
  }, []);

  // ── Derived config ────────────────────────────────────────────────────────
  const isIdle = !cartData || cartData.cart.length === 0;

  // Memoised: object reference only changes when data changes, preventing
  // spurious timer-effect re-runs on unrelated re-renders.
  const currentConfig = useMemo(
    () => (isIdle ? cfdConfig?.idle : cfdConfig?.ongoing) ?? null,
    [cfdConfig, isIdle]
  );

  // ── Reset on config / idle-state switch ───────────────────────────────────
  useEffect(() => {
    setMediaIndex(0);
    setRenderKey((k) => k + 1);
    // generation not bumped: mediaIndex reset already re-triggers timer effect.
  }, [currentConfig]);

  // ── Timer / carousel ──────────────────────────────────────────────────────
  useEffect(() => {
    if (!currentConfig || currentConfig.items.length === 0) return;
    const item = currentConfig.items[mediaIndex];
    if (!item || item.type === 'video') return; // videos self-advance via onEnded

    const durationMs = Math.max(500, (item.duration || 5) * 1000);

    const timer = setTimeout(() => {
      const nextIndex = (mediaIndex + 1) % currentConfig.items.length;

      // Always bump renderKey → new elemKey → remount → GIF restarts frame 0.
      setRenderKey((k) => k + 1);
      setMediaIndex(nextIndex);

      if (nextIndex === mediaIndex) {
        // Single-clip: index won't change so deps won't change; bump generation
        // to force this effect to re-run and schedule the next tick.
        setGeneration((g) => g + 1);
      }
    }, durationMs);

    return () => clearTimeout(timer);
    // renderKey intentionally absent from deps — it's output-only in this effect.
  }, [currentConfig, mediaIndex, generation]);

  // ── Fullscreen ────────────────────────────────────────────────────────────
  useEffect(() => {
    const t = setTimeout(async () => {
      try {
        if (!document.fullscreenElement)
          await document.documentElement.requestFullscreen({ navigationUI: 'hide' });
      } catch { /* user gesture required — click handler covers this */ }
    }, 800);
    return () => clearTimeout(t);
  }, []);

  const forceFullscreen = () => {
    if (!document.fullscreenElement)
      document.documentElement.requestFullscreen().catch(() => {});
  };

  // ── Media renderer ────────────────────────────────────────────────────────
  const renderMedia = () => {
    if (!currentConfig || currentConfig.items.length === 0) {
      return (
        <div className="w-full h-full flex items-center justify-center bg-gray-100">
          <h1 className="text-4xl font-black text-gray-300" style={{ fontFamily: 'Poppins' }}>
            Dunkin'
          </h1>
        </div>
      );
    }

    const item = currentConfig.items[mediaIndex];

    // renderKey changes on every tick even when mediaIndex stays 0 (single clip).
    // React sees a new key → unmounts old element → mounts fresh one → GIF plays from start.
    const elemKey = `${item.id}-${mediaIndex}-${renderKey}`;

    if (item.type === 'video') {
      return (
        <video
          key={elemKey}
          src={item.url}
          autoPlay
          muted
          loop={currentConfig.mode === 'static'}
          className="cfd-media-fade w-full h-full object-contain bg-black"
          onEnded={() => {
            if (currentConfig.mode === 'carousel') {
              setRenderKey((k) => k + 1);
              setMediaIndex((prev) => (prev + 1) % currentConfig.items.length);
            }
          }}
        />
      );
    }

    return (
      <img
        key={elemKey}
        src={item.url}
        className="cfd-media-fade w-full h-full object-contain bg-black"
        alt="Ad"
      />
    );
  };

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: DISSOLVE_STYLE }} />
      <div
        onClick={forceFullscreen}
        className="w-screen h-screen overflow-hidden flex bg-white font-poppins text-gray-900 select-none cursor-none"
      >
        {isIdle ? (
          <div className="w-full h-full relative">{renderMedia()}</div>
        ) : (
          <div className="w-full h-full flex">

            {/* ── Left: order summary ────────────────────────────────── */}
            <div className="w-[40%] h-full flex flex-col bg-gray-50 border-r border-gray-200 shadow-2xl z-10">
              <div className="p-6 bg-orange-500 text-white shadow-md flex justify-between items-end">
                <h1 className="text-3xl font-black uppercase tracking-widest leading-none" style={{ fontFamily: 'Poppins' }}>
                  Order Summary
                </h1>
                <span className="text-sm font-bold bg-white/20 px-3 py-1 rounded-full leading-none" style={{ fontFamily: 'Poppins' }}>
                  {cartData!.cart.reduce((s, i) => s + i.qty, 0)} Items
                </span>
              </div>

              <style dangerouslySetInnerHTML={{ __html: `
                .hide-scroll::-webkit-scrollbar { display: none; }
                .hide-scroll { -ms-overflow-style: none; scrollbar-width: none; }
              `}} />

              <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-4 hide-scroll">
                {cartData!.cart.map((item: any, idx: number) => {
                  const grossPrice =
                    item.grossPrice !== undefined
                      ? item.grossPrice
                      : (() => {
                          const modsPrice = (item.modifiers || []).reduce(
                            (s: number, m: any) => s + ((m.price || 0) * (m.qty || 1)) / 100, 0
                          );
                          return (item.price + modsPrice) * item.qty;
                        })();
                  const discountAmount = item.itemDiscountAmount || 0;
                  const finalPrice = item.finalPrice !== undefined ? item.finalPrice : grossPrice;

                  return (
                    <div key={idx} className="flex justify-between items-center pb-4 border-b border-gray-200">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-white rounded-xl shadow-sm border border-gray-100 flex items-center justify-center p-1 shrink-0 overflow-hidden">
                          <CartItemImage src={item.imgReal} />
                        </div>
                        <div>
                          <p className="font-bold text-lg leading-tight uppercase text-gray-900" style={{ fontFamily: 'Poppins' }}>{item.name}</p>
                          <p className="text-sm font-bold text-gray-500" style={{ fontFamily: 'Poppins' }}>Qty: {item.qty}</p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end shrink-0">
                        {discountAmount > 0.005 ? (
                          <>
                            <p className="text-sm font-bold line-through text-gray-400" style={{ fontFamily: 'Poppins' }}>
                              {grossPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </p>
                            <p className="text-xl font-black text-orange-600" style={{ fontFamily: 'Poppins' }}>
                              {finalPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </p>
                          </>
                        ) : (
                          <p className="text-xl font-black text-orange-600" style={{ fontFamily: 'Poppins' }}>
                            {grossPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="p-6 bg-white border-t border-gray-200 shadow-[0_-10px_30px_rgba(0,0,0,0.05)]">
                {(() => {
                  const displaySubtotal = cartData!.cart.reduce((sum, item) => {
                    const gross =
                      item.grossPrice !== undefined
                        ? item.grossPrice
                        : (item.price + (item.modifiers || []).reduce(
                            (s: number, m: any) => s + ((m.price || 0) * (m.qty || 1)) / 100, 0
                          )) * item.qty;
                    return sum + gross;
                  }, 0);
                  return (
                    <>
                      <div className="flex justify-between text-gray-500 text-lg font-bold mb-2" style={{ fontFamily: 'Poppins' }}>
                        <span>Subtotal</span>
                        <span>{displaySubtotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                      </div>
                      {(cartData!.discountAmt ?? 0) > 0 && (
                        <div className="flex justify-between text-pink-600 text-lg font-bold mb-2" style={{ fontFamily: 'Poppins' }}>
                          <span>Discount</span>
                          <span>−{(cartData!.discountAmt ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                        </div>
                      )}
                    </>
                  );
                })()}
                <div className="flex justify-between text-4xl font-black mt-4" style={{ fontFamily: 'Poppins' }}>
                  <span className="text-gray-900">TOTAL</span>
                  <span className="text-orange-600">
                    {cartData!.total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </div>

            {/* ── Right: ads ─────────────────────────────────────────── */}
            <div className="w-[60%] h-full relative overflow-hidden">{renderMedia()}</div>
          </div>
        )}
      </div>
    </>
  );
}