export function extractImageUrls(menuPayload: any): string[] {
  const urls = new Set<string>();
  const add = (url?: string) => { if (url?.startsWith('http')) urls.add(url); };

  (menuPayload?.categories || []).forEach((cat: any) => {
    add(cat.image);
    (cat.items || []).forEach((item: any) => (item.photos || []).forEach(add));
    (cat.subcategories || []).forEach((sub: any) => {
      add(sub.image);
      (sub.items || []).forEach((item: any) => {
        (item.photos || []).forEach(add);
        (item.modifierGroups || []).forEach((mg: any) =>
          (mg.modifiers || []).forEach((mod: any) => add(mod.image))
        );
      });
    });
  });

  return [...urls];
}

// "https://.../storage/items/ABC123.png" → "/menu-cache/ABC123.png"
export function resolveMenuImageUrl(remoteUrl: string): string {
  if (!remoteUrl) return '';
  const filename = remoteUrl.split('/').pop();
  return `/menu-cache/${filename}`;
}