//associates
'use client';

import axios from 'axios';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL;
const API_KEY = process.env.NEXT_PUBLIC_KEY;
const STORE_CODE = process.env.NEXT_PUBLIC_STORE_CODE;

// Build storage URL by removing /api/v2/pos from the base URL
const getStorageBaseUrl = () => {
  if (!API_BASE_URL) return '';
  // Remove /api/v2/pos from the end
  const baseUrl = API_BASE_URL.replace(/\/api\/v2\/pos\/?$/, '');
  return `${baseUrl}/storage/`;
};

const STORAGE_BASE_URL = getStorageBaseUrl();

export interface AssociateUser {
  id: number;
  name: string;
  email: string;
  pin: string;
  avatar: string;
  email_verified_at: string | null;
  role: number;
  created_at: string;
  updated_at: string;
}

export interface Associate {
  id: number;
  user_id: number;
  store_id: number;
  created_at: string;
  updated_at: string;
  user: AssociateUser;
}

export interface AssociatesResponse {
  status: string;
  message: string;
  dateTime: string;
  data: Associate[];
}

/**
 * Save associates to MongoDB via API
 */
async function saveAssociatesToMongo(
  associates: Associate[]
): Promise<void> {
  try {
    await fetch('/api/db?collection=associates&action=insert', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        data: {
          id: 'store_associates',
          payload: associates,
          lastUpdated: new Date().toISOString(),
        },
      }),
    });
  } catch (error) {
    console.error('Error saving associates to MongoDB:', error);
  }
}

/**
 * Fetch store associates from API and save to MongoDB
 */
export async function fetchAndSaveStoreAssociates(): Promise<Associate[]> {
  try {
    if (!API_BASE_URL || !STORE_CODE || !API_KEY) {
      throw new Error(
        `Missing environment variables: API_BASE_URL=${API_BASE_URL}, STORE_CODE=${STORE_CODE}, API_KEY=${API_KEY}`
      );
    }

    const endpoint = `${API_BASE_URL}/associate/store/${STORE_CODE}`;
    console.log('Fetching associates from:', endpoint);

    const response = await axios.get<AssociatesResponse>(endpoint, {
      headers: {
        'POS-API-KEY': API_KEY,
        'Content-Type': 'application/json',
      },
    });

    const payload = response.data;

    if (payload.status !== 'success' || !payload.data) {
      throw new Error('Invalid response format from associates API');
    }

    // Process associates and add full avatar URLs
    const processedAssociates = payload.data.map((associate) => ({
      ...associate,
      user: {
        ...associate.user,
        avatar: associate.user.avatar
          ? `${STORAGE_BASE_URL}${associate.user.avatar}`
          : '',
      },
    }));

    // Save to MongoDB
    await saveAssociatesToMongo(processedAssociates);

    console.log(
      `✓ Saved ${processedAssociates.length} associates to MongoDB`
    );
    const avatarUrls = processedAssociates
      .map(a => a.user.avatar)
      .filter(Boolean);

    if (avatarUrls.length > 0) {
      fetch('/api/cache-menu-images', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ urls: avatarUrls }),
      }).catch(err => console.warn('[AVATAR CACHE] Non-fatal:', err.message));
    }

    return processedAssociates;
  } catch (error) {
    console.warn('Error fetching store associates:', error);
    // Return cached data if API fails
    try {
      const cached = await getCachedAssociates();
      if (cached) {
        console.log('Using cached associates data');
        return cached;
      }
    } catch (cacheError) {
      console.warn('Error retrieving cached associates:', cacheError);
    }
    throw error;
  }
}

/**
 * Get cached associates from MongoDB
 */
export async function getCachedAssociates(): Promise<Associate[] | null> {
  try {
    const response = await fetch(
      '/api/db?collection=associates&action=get',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: 'store_associates' }),
      }
    );

    if (!response.ok) return null;

    const record = await response.json();
    return record?.payload || null;
  } catch (error) {
    console.error('Error retrieving cached associates:', error);
    return null;
  }
}

/**
 * Get associates by role
 */
export async function getAssociatesByRole(role: number): Promise<Associate[]> {
  try {
    const associates = await getCachedAssociates();
    if (!associates) return [];
    return associates.filter((a) => a.user.role === role);
  } catch (error) {
    console.error('Error filtering associates by role:', error);
    return [];
  }
}

/**
 * Get associate by PIN
 */
export async function getAssociateByPin(pin: string): Promise<Associate | null> {
  try {
    const associates = await getCachedAssociates();
    if (!associates) return null;
    return associates.find((a) => a.user.pin === pin) || null;
  } catch (error) {
    console.error('Error finding associate by PIN:', error);
    return null;
  }
}

/**
 * Get associate by email
 */
export async function getAssociateByEmail(
  email: string
): Promise<Associate | null> {
  try {
    const associates = await getCachedAssociates();
    if (!associates) return null;
    return associates.find((a) => a.user.email === email) || null;
  } catch (error) {
    console.error('Error finding associate by email:', error);
    return null;
  }
}
