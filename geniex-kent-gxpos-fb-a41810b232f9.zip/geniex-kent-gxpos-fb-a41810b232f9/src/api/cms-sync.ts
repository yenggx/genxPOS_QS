// I think this is obsolete now that we have the CMS sync API route, but I'll keep it here for reference until we confirm it's not needed anymore

import axios from 'axios';

// Check internet connectivity
export const isOnline = (): boolean => {
  return navigator.onLine;
};

// Fetch latest transactions from CMS
export const fetchCMSTransactions = async () => {
  // Check internet connection first
  if (!navigator.onLine) {
    console.log('[CMS-SYNC] No internet connection. Skipping CMS fetch.');
    return {
      success: false,
      reason: 'No internet connection',
      fetched: 0,
    };
  }

  try {
    const storeCode = process.env.NEXT_PUBLIC_STORE_CODE || 'gXPOS-123';
    const cmsUrl = process.env.NEXT_PUBLIC_API_URL;
    const apiKey = process.env.NEXT_PUBLIC_KEY;

    if (!cmsUrl) {
      console.error('[CMS-SYNC] NEXT_PUBLIC_API_URL is not configured');
      return {
        success: false,
        reason: 'CMS URL not configured',
        fetched: 0,
      };
    }

    // Fetch latest transaction from CMS
    const response = await axios.get(
      `${cmsUrl}/transactions/latest/${storeCode}`,
      {
        headers: {
          'Content-Type': 'application/json',
          'POS-API-KEY': apiKey,
        },
        timeout: 8000, // 8 second timeout
      }
    );

    if (!response.data || !response.data.data) {
      console.log('[CMS-SYNC] Invalid response format from CMS');
      return {
        success: false,
        reason: 'Invalid CMS response',
        fetched: 0,
      };
    }

    const cmsTransaction = response.data.data;

    // Save transaction to local database
    try {
      const saveResponse = await axios.post(
        '/api/order-transactions',
        {
          ...cmsTransaction,
          isSyncedFromCMS: true,
          fetchedAt: new Date(),
        },
        { timeout: 5000 }
      );

      if (saveResponse.status === 200 || saveResponse.status === 201) {
        console.log(
          `[CMS-SYNC] ✓ Transaction #${cmsTransaction.order_number} fetched from CMS and saved locally`
        );
        return {
          success: true,
          reason: 'Transaction fetched and saved',
          fetched: 1,
          transaction: cmsTransaction,
        };
      }
    } catch (saveError) {
      console.error('[CMS-SYNC] Failed to save transaction locally:', saveError);
      return {
        success: false,
        reason: 'Failed to save locally',
        fetched: 0,
      };
    }
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    console.error('[CMS-SYNC] Error fetching from CMS:', errorMsg);
    return {
      success: false,
      reason: 'CMS fetch error',
      error: errorMsg,
      fetched: 0,
    };
  }
};
