'use client';

import axios from 'axios';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL;
const API_KEY = process.env.NEXT_PUBLIC_KEY;
const STORE_CODE = process.env.NEXT_PUBLIC_STORE_CODE;

// Build API URL by removing /api/v2/pos from the base URL
const getApiBaseUrl = () => {
  if (!API_BASE_URL) return '';
  return API_BASE_URL.replace(/\/api\/v2\/pos\/?$/, '');
};

const API_ROOT_URL = getApiBaseUrl();

// ─── INTERFACES ───────────────────────────────────────────────────────────
export interface GeneralSetting {
  id: number;
  key: string;
  value: string;
  created_at: string;
  updated_at: string;
}

export interface ReceiptFormat {
  id: number;
  name: string;
  header: string;
  footer: string;
  created_at: string;
  updated_at: string;
}

export interface StoreData {
  id: number;
  store_id: string;
  series_type: string | null;
  number_of_work_station: number;
  name: string;
  description: string;
  open_time: string;
  close_time: string;
  address: string;
  email: string;
  contact_number: string;
  pos_type: string;
  emp_code: string | null;
  emp_pin: string | null;
  store_url: string | null;
  longitude: string;
  latitude: string;
  merchant_id: string;
  merchant_code: string;
  partner_merchant_id: string;
  currency: string;
  code: string;
  exponent: string;
  services_charge: number;
  token_expiry: string | null;
  created_at: string;
  updated_at: string;
  undefinedvars: Record<string, unknown>[];
}

export interface StoreConnectionResponse {
  status: string;
  message: string;
  dateTime: string;
  generalSettings: GeneralSetting[];
  receiptFormats: ReceiptFormat[];
  data: StoreData;
}

/**
 * Save store data to MongoDB via API
 */
async function saveStoreToDB(data: StoreConnectionResponse): Promise<void> {
  try {
    await fetch('/api/db?collection=stores&action=insert', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        data: {
          id: 'store_data',
          payload: data,
          lastUpdated: new Date().toISOString(),
        },
      }),
    });
  } catch (error) {
    console.error('Error saving store data to MongoDB:', error);
  }
}

/**
 * Fetch store connection data from API and save to MongoDB
 */
export async function fetchAndSaveStoreData(): Promise<StoreConnectionResponse> {
  try {
    if (!API_ROOT_URL || !STORE_CODE || !API_KEY) {
      throw new Error(
        `Missing environment variables: API_ROOT_URL=${API_ROOT_URL}, STORE_CODE=${STORE_CODE}, API_KEY=${API_KEY}`
      );
    }

    const endpoint = `${API_ROOT_URL}/api/v2/pos/connection/check/${STORE_CODE}`;
    console.log('[STORES] Fetching store data from:', endpoint);

    const response = await axios.get<StoreConnectionResponse>(endpoint, {
      headers: {
        'POS-API-KEY': API_KEY,
        'Content-Type': 'application/json',
      },
      timeout: 1000000,
    });

    const payload = response.data;

    if (payload.status !== 'success' || !payload.data) {
      throw new Error('Invalid response format from store connection API');
    }

    // Save to MongoDB
    await saveStoreToDB(payload);

    console.log('[STORES] ✓ Saved store data to MongoDB');

    return payload;
  } catch (error: any) {
    console.warn('[STORES] ✗ Error fetching store data:', {
      message: error.message,
      code: error.code,
      status: error.response?.status,
      statusText: error.response?.statusText,
    });

    // Provide helpful debugging info
    if (error.response?.status === 500) {
      console.error('[STORES] ⚠️  CMS API returned 500 - server may be down');
    } else if (error.code === 'ECONNREFUSED') {
      console.error('[STORES] ⚠️  Connection refused - check API_URL and server status');
    } else if (error.code === 'ENOTFOUND') {
      console.error('[STORES] ⚠️  DNS resolution failed - verify API_URL domain');
    }

    // Return cached data if API fails
    try {
      const cached = await getCachedStoreData();
      if (cached) {
        console.log('[STORES] ⚠️  Using cached store data due to API failure');
        return cached;
      }
    } catch (cacheError) {
      console.warn('[STORES] ✗ Error retrieving cached store data:', cacheError);
    }
    
    throw error;
  }
}

/**
 * Get cached store data from MongoDB
 */
export async function getCachedStoreData(): Promise<StoreConnectionResponse | null> {
  try {
    const response = await fetch('/api/db?collection=stores&action=get', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: 'store_data' }),
    });

    if (!response.ok) return null;

    const record = await response.json();
    return record?.payload || null;
  } catch (error) {
    console.error('Error retrieving cached store data:', error);
    return null;
  }
}

/**
 * Get general settings by key
 */
export async function getGeneralSetting(key: string): Promise<string | null> {
  try {
    const storeData = await getCachedStoreData();
    if (!storeData) return null;

    const setting = storeData.generalSettings.find((s) => s.key === key);
    return setting?.value || null;
  } catch (error) {
    console.error(`Error getting setting '${key}':`, error);
    return null;
  }
}

/**
 * Get receipt format by name
 */
export async function getReceiptFormat(name: string): Promise<ReceiptFormat | null> {
  try {
    const storeData = await getCachedStoreData();
    if (!storeData) return null;

    const format = storeData.receiptFormats.find((f) => f.name === name);
    return format || null;
  } catch (error) {
    console.error(`Error getting receipt format '${name}':`, error);
    return null;
  }
}

/**
 * Get store information
 */
export async function getStoreInfo(): Promise<StoreData | null> {
  try {
    const storeData = await getCachedStoreData();
    return storeData?.data || null;
  } catch (error) {
    console.error('Error getting store info:', error);
    return null;
  }
}

/**
 * Get all receipt formats
 */
export async function getAllReceiptFormats(): Promise<ReceiptFormat[]> {
  try {
    const storeData = await getCachedStoreData();
    return storeData?.receiptFormats || [];
  } catch (error) {
    console.error('Error getting receipt formats:', error);
    return [];
  }
}
