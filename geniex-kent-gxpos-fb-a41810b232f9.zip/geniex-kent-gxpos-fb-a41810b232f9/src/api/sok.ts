// src/api/sok.ts
import axios from "axios";
import { getDatabase } from "@/src/lib/mongodb";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL;
const API_KEY = process.env.NEXT_PUBLIC_KEY;
const STORE_CODE = process.env.NEXT_PUBLIC_STORE_CODE;

export interface CmsOrder {
  [key: string]: any;
}

export interface CmsOrdersResponse {
  status: string;
  message: string;
  dateTime: string;
  data: CmsOrder[];
}

export async function fetchAndSaveCmsOrders(): Promise<CmsOrder[]> {
  try {
    if (!API_BASE_URL || !STORE_CODE || !API_KEY) {
      throw new Error('Missing environment variables');
    }

    const endpoint = `${API_BASE_URL}/get/cms/orders/${STORE_CODE}`;

    const response = await axios.get<CmsOrdersResponse>(endpoint, {
      headers: {
        'POS-API-KEY': API_KEY,
        'Content-Type': 'application/json',
      },
    });
  
    const payload = response.data;

    if (payload.status === 'success') {
      let ordersData: CmsOrder[] = [];
      if (Array.isArray(payload.data)) {
        ordersData = payload.data;
      } else if (payload.data && typeof payload.data === 'object') {
        ordersData = [payload.data];
      }

      if (ordersData.length > 0) {
        await saveCmsOrdersToMongo(ordersData);
      }
    }
  } catch (error) {
    console.warn('Error fetching CMS orders:', error);
  }

  try {
    const cached = await getCachedCmsOrders();
    return cached || [];
  } catch (cacheError) {
    console.warn('Error retrieving cached CMS orders:', cacheError);
    return [];
  }
}

async function saveCmsOrdersToMongo(orders: CmsOrder | CmsOrder[]): Promise<void> {
  try {
    const db = await getDatabase();
    const collection = db.collection('cms_orders');
    
    // Fetch the active business date directly from the DB
    let businessDate: string | undefined;
    try {
      const activeBd = await db.collection('businessDays').findOne({ $or: [{ status: 'open' }, { status: 'OPEN' }, { active: true }] });
      if (activeBd?.date) businessDate = activeBd.date;
      else if (activeBd?.businessDate) businessDate = activeBd.businessDate;
      
      if (!businessDate) {
        const activeSession = await db.collection('cashier_sessions').findOne({ $or: [{ status: 'open' }, { status: 'OPEN' }, { active: true }] });
        if (activeSession?.businessDayDate) businessDate = activeSession.businessDayDate;
        else if (activeSession?.businessDate) businessDate = activeSession.businessDate;
      }
    } catch (e) {
      console.warn("Failed to lookup business date:", e);
    }

    const newOrders = Array.isArray(orders) ? orders : [orders];
    
    const bulkOps = newOrders.map(o => {
      const updatePayload: any = { ...o, lastUpdated: new Date().toISOString() };
      
      // Inject the active business date into the order payload
      if (businessDate) {
        updatePayload.businessDate = businessDate;
      }

      return {
        updateOne: {
          filter: { order_id: o.order_id || o.id },
          update: { $set: updatePayload },
          upsert: true
        }
      };
    });

    if (bulkOps.length > 0) {
      await collection.bulkWrite(bulkOps);
    }
  } catch (error) {
    console.error('Error saving CMS orders to MongoDB:', error);
  }
}

export async function getCachedCmsOrders(): Promise<CmsOrder[] | null> {
  try {
    const db = await getDatabase();
    const collection = db.collection('cms_orders');
    
    const records = await collection.find({ id: { $ne: 'store_cms_orders' } }).toArray();
    
    return records.length > 0 ? records : null;
  } catch (error) {
    console.error('Error retrieving cached CMS orders:', error);
    return null;
  }
}

export async function updateCmsOrderToClosed(orderId: string, salesNumber: string): Promise<void> {
  try {
    const db = await getDatabase();
    const collection = db.collection('cms_orders');
    const result = await collection.updateOne(
      { order_id: orderId },
      { 
        $set: { 
          status: 'CLOSED', 
          salesNumber: salesNumber,
          lastUpdated: new Date().toISOString()
        } 
      }
    );
    console.log(`[CMS Update] Order: ${orderId}, Matched: ${result.matchedCount}, Modified: ${result.modifiedCount}`);
  } catch (error) {
    console.error('Error closing CMS order:', error);
  }
}

export async function updateCmsOrderStatusOnly(orderId: string): Promise<void> {
  try {
    const db = await getDatabase();
    const collection = db.collection('cms_orders');
    const result = await collection.updateOne(
      { order_id: orderId },
      { 
        $set: { 
          status: 'CANCELLED', 
          lastUpdated: new Date().toISOString()
        } 
      }
    );
    console.log(`[CMS Update Status Only] Order: ${orderId}, Matched: ${result.matchedCount}, Modified: ${result.modifiedCount}`);
  } catch (error) {
    console.error('Error closing CMS order status:', error);
  }
}