//api/transactions
import axios from 'axios';
import { getWorkstationId } from '../lib/workstation';

// Generate a unique guest token (can be improved with UUID)
const generateGuestToken = (): string => {
  return Math.random().toString(36).substring(2, 22);
};

// Map transaction type IDs to exact backend format requested
const mapTransactionType = (transactionTypeId: string): string => {
  const typeMap: Record<string, string> = {
    'regular': 'REGULAR',
    'pwd_sr': 'SRPWD',
    'athlete': 'ATHLETE',
    'vip': 'VIP',
    'diplomat': 'DIPLOMAT',
    'peza': 'PEZA',
    'REGULAR': 'REGULAR',
    'SRPWD': 'SRPWD',
    'ATHLETE': 'ATHLETE',
    'VIP': 'VIP',
    'DIPLOMAT': 'DIPLOMAT',
    'PEZA': 'PEZA'
  };
  return typeMap[transactionTypeId] || transactionTypeId || 'REGULAR';
};

// Map payment method to backend format
const mapPaymentMethod = (paymentMethod: string): string => {
  const methodMap: Record<string, string> = {
    'cash': 'CASH',
    'card': 'CARD',
    'card debit': 'CARD',
    'card credit': 'CARD',
    'ewallet': 'MAYA',
    'gcash': 'GCASH',
    'maya': 'MAYA',
    'voucher': 'VOUCHER',
    'bank_transfer': 'BANK_TRANSFER',
    'other': 'OTHER',
  };
  return methodMap[paymentMethod.toLowerCase()] || 'CASH';
};

// Get format counter values
export const getCounters = async (workstationId: string, seriesType: string) => {
  try {
    const res = await axios.post('/api/numbers?type=generateAll', {
      workstationId,
      seriesType
    });

    return {
      orderNumber: res.data.orderNumber,
      salesNumber: res.data.salesNumber,
      transactionNumber: res.data.transactionNumber,
    };
  } catch (error) {
    console.error('Error getting counters:', error);
    throw error;
  }
};

export const formatTransactionPayload = (data: {
  orderNumber: number | string;
  salesNumber: string;
  transactionNumber: string;
  cart: any[];
  payments: Array<{ method: string; amount: number; refCode?: string; tendered?: number }>;
  subtotal: number;
  tax: number;
  vatableSales?: number;
  vatExemptSales?: number;
  zeroRatedSales?: number;
  transactionType: string;
  appliedDiscount: any | null;
  discountInfo: any | null;
  discountAmount: number;
  staffId?: string;
  sessionId?: string;
  guests?: Array<{ guestName: string; GuestValidID: string }>;
  shiftNo?: number;
  cashierName?: string;
  kioskOrderId?: string;
}) => {
  const storeCode = process.env.NEXT_PUBLIC_STORE_CODE || 'gXPOS-123';
  const kioskNo = getWorkstationId() || '001';

  const items = data.cart.map((item) => ({
    id: String(item.id),
    itemName: item.name,
    staffID: data.staffId || '2',
    price: Math.round(item.price * 100),
    quantity: item.qty,
    tax: 0,
    notes: item.notes || null,
    modifiers: item.modifiers && Object.keys(item.modifiers).length > 0
      ? Object.values(item.modifiers).map((mod: any) => ({
          id: mod.id || '',
          name: mod.name || '',
          price: Math.round((mod.price || 0)),
          quantity: mod.qty || 1,
        }))
      : null,
    upSellItems: item.upSellItems || [],
  }));

  const payments = data.payments.map((payment, idx) => {
    const paymentObj: any = {
      id: idx + 1,
      PaymentMethod: mapPaymentMethod(payment.method),
      Amount: Math.round(payment.amount * 100),
      Tendered: Math.round((payment.tendered ?? payment.amount) * 100),
    };
    if (payment.refCode) {
      paymentObj.RefrenceNo = payment.refCode;
    }
    return paymentObj;
  });

  const orderType = 'DineIn';
  const orderTime = new Date().toISOString();
  const phTime = new Intl.DateTimeFormat('en-PH', {
    timeZone: 'Asia/Manila',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  }).format(new Date(orderTime));


  const payload = {
    sessionId: data.sessionId,
    shiftNo: data.shiftNo || data.sessionId,
    cashierName: data.cashierName || 'Unknown',
    GuestToken: generateGuestToken(),
    StoreID: storeCode,
    OrderNo: String(data.orderNumber),
    KioskNo: String(kioskNo),
    orderTime: new Date().toISOString(),
    TransactionType: '1',
    cutlery: false,
    guestNo: '1',
    tableNo: '5',
    salesNumber: data.salesNumber,
    transactionNumber: data.transactionNumber,
    transactionType: mapTransactionType(data.transactionType),
    price: {
      subtotal:   Math.round(data.subtotal * 100),
      tax:        Math.round(data.tax * 100),
      deliveryFee: 0,
      eaterPayment: Math.round((data.subtotal + data.tax - data.discountAmount) * 100),
      VATSale:    Math.round((data.vatableSales   || 0) * 100),
      VatAmount:  Math.round(data.tax              * 100),
      VatExSales: Math.round((data.vatExemptSales  || 0) * 100),
      ZeroRated:  Math.round((data.zeroRatedSales  || 0) * 100),
    },
    otherFee: {
      transactionFee: 0,
      Reason: '',
      Remarks: '',
    },
    featureFlags: {
      orderType: orderType,
    },
    guest: data.guests || [], 
    items,
    receiver: {
      userID: '20',
    },
    payment: payments,
    discountAmount: Math.round((data.discountAmount || 0) * 100),
    discountInfo:   { label: data.discountInfo?.label || null },
    orderState: 'DELIVERED',
    kitchenState: 'PREPARING',
    order_id: data.kioskOrderId || null
  };

  return payload;
};

// Save transaction to database
export const saveTransaction = async (transactionPayload: any) => {
  try {
    if(transactionPayload.transactionType === 'SC')  transactionPayload.transactionType = "SRC";
    const response = await axios.post('/api/transactions', transactionPayload);
    return response.data;
  } catch (error) {
    console.error('[saveTransaction] ✗ Error saving transaction:', error);
    throw error;
  }
};