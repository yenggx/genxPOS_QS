'use client';

export interface SimpleDiscount {
  id: number;
  campaign_name: string;
  discount_type: 'percentage' | 'fixed_amount';
  discount_value: string;
  discount_cap: number;
  platform: string[];
  startDateTime: string; 
  endDateTime: string;
  restrictions: {
    minAmountBasket: number;
    totalRedemptions: string;
    countPerUser: string;
    numberofItems: number;
  };
}

/**
 * Fetch discounts from the API and cache locally
 */
export async function getDiscountsFromCache(): Promise<SimpleDiscount[]> {
  try {
    console.log('[DISCOUNTS] 🔄 Fetching discounts from cache/API');
    const response = await fetch('/api/discounts', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      console.warn('[DISCOUNTS] ✗ Failed to fetch discounts:', response.status, response.statusText);
      return [];
    }

    const discountsData = await response.json();
    console.log('[DISCOUNTS] ✓ Loaded', Array.isArray(discountsData) ? discountsData.length : 0, 'discounts');
    console.log('[DISCOUNTS] Data type:', typeof discountsData);
    console.log('[DISCOUNTS] First item:', discountsData[0]);
    
    if (Array.isArray(discountsData)) {
      return discountsData;
    }
    return [];
  } catch (error) {
    console.warn('[DISCOUNTS] ✗ Error loading discounts:', error);
    return [];
  }
}

/**
 * Force refresh discounts from external API
 */
export async function refreshDiscountsFromAPI(): Promise<SimpleDiscount[]> {
  try {
    console.log('[DISCOUNTS] 🔄 Force refreshing discounts from external API');
    const response = await fetch('/api/discounts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      console.warn('[DISCOUNTS] ✗ Failed to refresh discounts:', response.status, response.statusText);
      const errorText = await response.text();
      console.warn('[DISCOUNTS] Error details:', errorText);
      return [];
    }

    const discountsData = await response.json();
    console.log('[DISCOUNTS] ✓ Refreshed', Array.isArray(discountsData) ? discountsData.length : 0, 'discounts');
    console.log('[DISCOUNTS] Data type:', typeof discountsData);
    console.log('[DISCOUNTS] Data structure:', JSON.stringify(discountsData).substring(0, 200));
    
    if (Array.isArray(discountsData)) {
      return discountsData;
    }
    
    // If data is wrapped in an object, try to extract it
    if (discountsData && typeof discountsData === 'object' && !Array.isArray(discountsData)) {
      const arr = Object.values(discountsData)[0];
      if (Array.isArray(arr)) {
        console.log('[DISCOUNTS] Found array in wrapped object');
        return arr;
      }
    }
    
    return [];
  } catch (error) {
    console.warn('[DISCOUNTS] ✗ Error refreshing discounts:', error);
    return [];
  }
}
