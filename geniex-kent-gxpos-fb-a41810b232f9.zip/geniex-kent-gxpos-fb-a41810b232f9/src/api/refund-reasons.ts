'use client';

import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL;
const API_KEY = process.env.NEXT_PUBLIC_KEY;

export interface RefundReason {
  id: number;
  reason: string;
  created_at: string;
  updated_at: string;
}

async function saveRefundReasonsToDB(reasons: RefundReason[]): Promise<void> {
  try {
    await fetch('/api/db?collection=refundReasons&action=insert', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        data: {
          id: 'refund_reasons',
          payload: reasons,
          lastUpdated: new Date().toISOString(),
        },
      }),
    });
  } catch (error) {
    console.error('[REFUND REASONS] Error saving to MongoDB:', error);
  }
}

export async function fetchAndSaveRefundReasons(): Promise<RefundReason[]> {
  if (!API_URL || !API_KEY) {
    throw new Error('[REFUND REASONS] Missing API configuration');
  }

  try {
    const response = await axios.get(`${API_URL}/refund/reason`, {
      headers: {
        'Content-Type': 'application/json',
        'POS-API-KEY': API_KEY,
      },
    });
    const raw = response.data;
    console.log(raw)
    const reasons: RefundReason[] = Array.isArray(raw)
    ? raw
    : Array.isArray(raw?.data)
    ? raw.data
    : Array.isArray(raw?.payload)
    ? raw.payload
    : [];

    await saveRefundReasonsToDB(reasons);
    console.log(`[REFUND REASONS] ✓ Saved ${reasons.length} reasons to MongoDB`);

    return reasons;
  } catch (error: any) {
    console.warn('[REFUND REASONS] ✗ Fetch failed:', {
      status: error.response?.status,
      message: error.message,
    });

    const cached = await getCachedRefundReasons();
    if (cached) {
      console.log('[REFUND REASONS] ⚠️  Using cached refund reasons');
      return cached;
    }

    throw error;
  }
}

export async function getCachedRefundReasons(): Promise<RefundReason[] | null> {
  try {
    const response = await fetch('/api/db?collection=refundReasons&action=get', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: 'refund_reasons' }),
    });

    if (!response.ok) return null;

    const record = await response.json();
    return record?.payload || null;
  } catch (error) {
    console.error('[REFUND REASONS] Error retrieving cache:', error);
    return null;
  }
}