'use client';

import axios from 'axios';

export interface CartItem {
  id: string | number;
  name: string;
  price: number;
  qty: number;
  [key: string]: any;
}

export interface CartData {
  workstationId?: string;
  sessionId?: string;
  items: CartItem[];
  appliedDiscount: 'SR_PWD' | 'VIP' | number | null;
  updatedAt?: string;
}

/**
 * Load cart from MongoDB for the current session
 */
export async function loadCartFromDatabase(workstationId: string): Promise<CartData | null> {
  try {
    console.log('[CART] Loading cart for workstationId:', workstationId);
    const response = await fetch(`/api/cart?workstationId=${encodeURIComponent(workstationId)}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      console.warn('[CART] Failed to load cart:', response.statusText);
      return null;
    }

    const cartData = await response.json();
    console.log('[CART] Loaded cart data:', cartData);
    return cartData;
  } catch (error) {
    console.error('[CART] Error loading cart from database:', error);
    return null;
  }
}

/**
 * Save cart to MongoDB for the current session
 */
export async function saveCartToDatabase(
  workstationId: string,
  items: CartItem[],
  appliedDiscount: 'SR_PWD' | 'VIP' | number | null = null
): Promise<boolean> {
  try {
    console.log('[CART] Saving cart for workstationId:', workstationId, 'items:', items.length);
    const response = await fetch(`/api/cart?workstationId=${encodeURIComponent(workstationId)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        items,
        appliedDiscount,
      }),
    });

    if (!response.ok) {
      console.warn('[CART] Failed to save cart:', response.statusText);
      return false;
    }

    const result = await response.json();
    console.log('[CART] Cart saved successfully:', result);
    return true;
  } catch (error) {
    console.error('[CART] Error saving cart to database:', error);
    return false;
  }
}

/**
 * Clear cart from MongoDB for the current session
 */
export async function clearCartFromDatabase(sessionId: string): Promise<boolean> {
  try {
    console.log('[CART] Clearing cart for workstationId:', sessionId);
    const response = await fetch(`/api/cart?workstationId=${encodeURIComponent(sessionId)}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      console.warn('[CART] Failed to clear cart:', response.statusText);
      return false;
    }

    console.log('[CART] Cart cleared successfully');
    return true;
  } catch (error) {
    console.error('[CART] Error clearing cart from database:', error);
    return false;
  }
}
