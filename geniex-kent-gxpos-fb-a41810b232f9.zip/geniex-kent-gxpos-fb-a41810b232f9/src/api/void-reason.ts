'use client';

import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL;
const API_KEY = process.env.NEXT_PUBLIC_KEY;

export interface VoidReason {
  id: number;
  reason: string;
  created_at: string;
  updated_at: string;
}

async function saveVoidReasonsToDB(reasons: VoidReason[]): Promise<void> {
  try {
    await fetch('/api/db?collection=voidReasons&action=insert', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        data: {
          id: 'void_reasons',
          payload: reasons,
          lastUpdated: new Date().toISOString(),
        },
      }),
    });
  } catch (error) {
    console.warn('[VOID REASONS] Error saving to MongoDB:', error);
  }
}

export async function fetchAndSaveVoidReasons(): Promise<VoidReason[]> {
  if (!API_URL || !API_KEY) {
    throw new Error('[VOID REASONS] Missing API configuration');
  }

  try {
    const response = await axios.get(`${API_URL}/void/reason`, {
      headers: {
        'Content-Type': 'application/json',
        'POS-API-KEY': API_KEY,
      },
    });
    
    const raw = response.data;
    const reasons: VoidReason[] = Array.isArray(raw)
      ? raw
      : Array.isArray(raw?.data)
      ? raw.data
      : Array.isArray(raw?.payload)
      ? raw.payload
      : [];

    await saveVoidReasonsToDB(reasons);
    console.log(`[VOID REASONS] ✓ Saved ${reasons.length} reasons to MongoDB`);

    return reasons;
  } catch (error: any) {
    console.warn('[VOID REASONS] ✗ Fetch failed:', {
      status: error.response?.status,
      message: error.message,
    });

    const cached = await getCachedVoidReasons();
    if (cached) {
      console.log('[VOID REASONS] ⚠️  Using cached void reasons');
      return cached;
    }

    throw error;
  }
}

export async function getCachedVoidReasons(): Promise<VoidReason[] | null> {
  try {
    const response = await fetch('/api/db?collection=voidReasons&action=get', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: 'void_reasons' }),
    });

    if (!response.ok) return null;

    const record = await response.json();
    return record?.payload || null;
  } catch (error) {
    console.warn('[VOID REASONS] Error retrieving cache:', error);
    return null;
  }
}