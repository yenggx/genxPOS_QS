'use client';
import { extractImageUrls } from '../utils/menuImages';

import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL;
const API_KEY = process.env.NEXT_PUBLIC_KEY;
const STORE_CODE = process.env.NEXT_PUBLIC_STORE_CODE;

export async function fetchAndStoreMenu() {
  if (!API_URL || !API_KEY || !STORE_CODE) {
    throw new Error('Missing API configuration');
  }

  try {
    const response = await fetch('/api/menu', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.warn('[MENU] POST failed:', {
        status: response.status,
        statusText: response.statusText,
        details: errorData,
      });
      throw new Error(`Failed to fetch menu: ${response.statusText}`);
    }

    const menuData = await response.json();
    console.log('[MENU] ✓ Menu stored in MongoDB');

    // Non-blocking — doesn't slow down init
    const payload = menuData?.payload || menuData;
    const urls = extractImageUrls(payload);
    if (urls.length > 0) {
      fetch('/api/cache-menu-images', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ urls }),
      }).then(() => console.log(`[IMAGE CACHE] Submitted ${urls.length} URLs`))
        .catch(err => console.warn('[IMAGE CACHE] Non-fatal:', err.message));
    }
    return menuData;
  } catch (error: any) {
    console.warn('[MENU] ✗ Failed to fetch or store menu:', {
      message: error.message,
      error: error,
    });
    throw error;
  }
}

export async function getMenuFromCache() {
  try {
    const response = await fetch('/api/menu', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      console.warn('[MENU] GET returned:', response.status, response.statusText);
      return null;
    }

    const menuData = await response.json();
    return menuData?.payload || null;
  } catch (error) {
    console.error('[MENU] Failed to get cached menu:', error);
    return null;
  }
}
