'use client';

export interface WorkstationSettings {
  workstationId:             string;
  vatNumber:                 string;
  tinNumber:                 string;
  minNumber:                 string;
  ptuNumber:                 string;
  snNumber:                  string;
  allowable_void_refund_hours: number;
  kdsWarningMinutes:         number;
  kdsDangerMinutes:          number;
  cashDropWarningAmount:     number;
  cashDropMaxAmount:         number;
  cashFundLimit:             number;
  soloParentLimit:           number;
  showStock:                 boolean;
  zReadingType:              'Consolidated' | 'Per Terminal' | 'Both';
  doublePrintTypes: {
    REGULAR:  boolean;
    SC:       boolean;
    PWD:      boolean;
    ATHLETE:  boolean;
    DIPLOMAT: boolean;
    PEZA:     boolean;
    SOLO:     boolean;
    MEDAL:    boolean;
  };
  updatedAt?: string;
}

const SETTINGS_STORAGE_KEY = 'workstation_settings';

const DEFAULT_SETTINGS: Omit<WorkstationSettings, 'workstationId' | 'updatedAt'> = {
  vatNumber:                   '',
  tinNumber:                   '',
  minNumber:                   '',
  ptuNumber:                   '',
  snNumber:                    '',
  allowable_void_refund_hours: 24,
  kdsWarningMinutes:           5,
  kdsDangerMinutes:            10,
  cashDropWarningAmount:       10000,
  cashDropMaxAmount:           20000,
  cashFundLimit:               1000,
  soloParentLimit:             2000,
  showStock:                   false,
  zReadingType:                'Consolidated',
  doublePrintTypes: {
    REGULAR:  false,
    SC:       false,
    PWD:      false,
    ATHLETE:  false,
    DIPLOMAT: false,
    PEZA:     false,
    SOLO:     false,
    MEDAL:    false,
  },
};

/**
 * Fetch settings from the API and cache to localStorage.
 *
 * Only writes defaults to the DB if no record exists yet — existing
 * settings are never overwritten by this function.
 */
export async function fetchAndSaveSettings(workstationId: string = '001'): Promise<WorkstationSettings> {
  const res = await fetch(`/api/settings?workstationId=${workstationId}`);

  if (!res.ok) {
    throw new Error(`[SETTINGS] Failed to fetch: ${res.status}`);
  }

  const data: WorkstationSettings = await res.json();

  // If the record has never been saved (all fiscal fields are blank and
  // updatedAt is absent), push defaults so the DB document exists.
  // This avoids clobbering any intentional edits the user already made.
  const isFirstRun = !data.updatedAt && !data.vatNumber && !data.tinNumber;

  if (isFirstRun) {
    console.log('[SETTINGS] First run — writing defaults to DB');
    await fetch('/api/settings', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...DEFAULT_SETTINGS,
        workstationId,
      }),
    });

    // Re-fetch so the returned object reflects what was just written
    const saved = await fetch(`/api/settings?workstationId=${workstationId}`);
    const savedData: WorkstationSettings = await saved.json();

    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(savedData));
    console.log('[SETTINGS] ✓ Defaults saved and cached');
    return savedData;
  }

  // Settings already exist — just cache what came back
  localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(data));
  console.log('[SETTINGS] ✓ Loaded and cached');
  return data;
}

/**
 * Return the last cached settings from localStorage, or null if not yet cached.
 */
export function getCachedSettings(): WorkstationSettings | null {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as WorkstationSettings;
  } catch {
    return null;
  }
}