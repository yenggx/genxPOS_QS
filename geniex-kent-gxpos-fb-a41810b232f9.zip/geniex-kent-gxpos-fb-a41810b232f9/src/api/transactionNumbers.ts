//src/api/transactionNumbers
'use client';

// ─── INTERFACES ───────────────────────────────────────────────────────────
export interface TransactionCounter {
  id: string;
  transactionNumber: number;
  salesInvoiceNumber: number;
  lastUpdated: string;
}

export interface OrderNumberCounter {
  id: string;
  orderNumber: number;
  date: string; // YYYY-MM-DD format
  lastUpdated: string;
}

/**
 * Initialize transaction counters in MongoDB
 */
export async function initializeTransactionCounters(): Promise<void> {
  try {
    await fetch('/api/numbers?type=init', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
    console.log('✓ Initialized transaction counters');
  } catch (error) {
    console.error('Error initializing transaction counters:', error);
    throw error;
  }
}

/**
 * Get next transaction number in format: 0000000001, 0000000002, etc.
 */
export async function getNextTransactionNumber(seriesType:string, workstationId:string): Promise<string> {
  try {
    const response = await fetch('/api/numbers?type=transaction', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({seriesType, workstationId})
    });

    if (!response.ok) {
      throw new Error('Failed to get next transaction number');
    }

    const data = await response.json();
    return data.number;
  } catch (error) {
    console.error('Error getting next transaction number:', error);
    throw error;
  }
}

/**
 * Get next sales invoice number in format: {WORKSTATION_ID}-{00000001}
 * Example: 001-00000001, 001-00000002, etc.
 */
export async function getNextSalesInvoiceNumber(): Promise<string> {
  try {
    const response = await fetch('/api/numbers?type=saleInvoice', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      throw new Error('Failed to get next sales invoice number');
    }

    const data = await response.json();
    return data.number;
  } catch (error) {
    console.error('Error getting next sales invoice number:', error);
    throw error;
  }
}

/**
 * Get current counters (for debugging/monitoring)
 */
export async function getCurrentCounters(): Promise<Record<string, unknown> | null> {
  try {
    const response = await fetch('/api/numbers?type=getAll', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) return null;

    return await response.json();
  } catch (error) {
    console.error('Error getting current counters:', error);
    return null;
  }
}

/**
 * Reset counters (use with caution - should not be used in production)
 */
export async function resetCounters(): Promise<void> {
  try {
    await fetch('/api/numbers?type=reset', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ counterType: 'transaction' }),
    });
    console.warn('⚠️  Transaction counters have been reset');
  } catch (error) {
    console.error('Error resetting counters:', error);
    throw error;
  }
}

// ─── ORDER NUMBER (Daily Reset) ────────────────────────────────────────────
/**
 * Initialize order number counter for today
 */
export async function initializeOrderNumber(): Promise<void> {
  try {
    await fetch('/api/numbers?type=init', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
    console.log('✓ Initialized order number counter');
  } catch (error) {
    console.error('Error initializing order number counter:', error);
    throw error;
  }
}

/**
 * Get next order number in format: 0001, 0002, etc. (resets daily)
 */
export async function getNextOrderNumber(): Promise<string> {
  try {
    const response = await fetch('/api/numbers?type=order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      throw new Error('Failed to get next order number');
    }

    const data = await response.json();
    return data.number;
  } catch (error) {
    console.error('Error getting next order number:', error);
    throw error;
  }
}

/**
 * Get current order number info (for debugging/monitoring)
 */
export async function getCurrentOrderNumber(): Promise<
  Record<string, unknown> | null
> {
  try {
    const response = await fetch('/api/numbers?type=getAll', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) return null;

    const counters = await response.json();
    // Find the order counter
    const orderCounter = Array.isArray(counters)
      ? counters.find((c) => c.type === 'order')
      : null;
    return orderCounter || null;
  } catch (error) {
    console.error('Error getting current order number:', error);
    return null;
  }
}
