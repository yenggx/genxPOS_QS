import axios from "axios";
import { StoreConnectionResponse } from "./stores";


const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL;
const API_KEY = process.env.NEXT_PUBLIC_KEY;
const STORE_CODE = process.env.NEXT_PUBLIC_STORE_CODE;

export async function checkConnection(): Promise<boolean> {
  try {
    if (!API_BASE_URL || !STORE_CODE || !API_KEY) {
      throw new Error(
        `Missing environment variables: API_BASE_URL=${API_BASE_URL}, STORE_CODE=${STORE_CODE}, API_KEY=${API_KEY}`
      );
    }

    const endpoint = `${API_BASE_URL}/connection/check/${STORE_CODE}`;
    console.log('[STORES] Fetching store data from:', endpoint);

    const response = await axios.get<StoreConnectionResponse>(endpoint, {
      headers: {
        'POS-API-KEY': API_KEY,
        'Content-Type': 'application/json',
      },
      timeout: 10000,
    });

    const payload = response.data;

    if (payload.status !== 'success' || !payload.data) {
      throw new Error('Invalid response format from store connection API');
    }

    return true;
  } catch (error: any) {
    console.warn('Is Offline')
    return false;
  }
}