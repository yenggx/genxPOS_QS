import axios from 'axios';

// Track if a sync is currently in progress
let isSyncInProgress = false;

// Check internet connectivity
export function isOnline(): boolean {
  console.log("navigator:", navigator.onLine)
  return navigator.onLine;
};

// Sync unsynchronized transactions to backend
export const syncTransactionsToBackend = async () => {
  // Prevent concurrent syncs
  if (isSyncInProgress) {
    return {
      success: false,
      reason: 'Sync already in progress',
      synced: 0,
    };
  }

  // Check internet connection first
  if (!navigator.onLine) {
    console.log('[SYNC] No internet connection. Skipping transaction sync.');
    return {
      success: false,
      reason: 'No internet connection',
      synced: 0,
    };
  }

  isSyncInProgress = true;

  try {
    // Get unsynchronized transactions from local database
    const response = await axios.get('/api/sync/transactions?pending=true', {
      timeout: 5000, // 5 second timeout
    });
    
    if (!response.data || !response.data.transactions) {
      console.log('[SYNC] Invalid response format from server');
      return {
        success: false,
        reason: 'Invalid server response',
        synced: 0,
      };
    }
    
    const pendingTransactions = response.data.transactions || [];

    if (pendingTransactions.length === 0) {
      console.log('[SYNC] No pending transactions to sync.');
      return {
        success: true,
        reason: 'No pending transactions',
        synced: 0,
      };
    }

    console.log(`[SYNC] Found ${pendingTransactions.length} pending transaction(s) to sync.`);

    let syncedCount = 0;
    const backendUrl = process.env.NEXT_PUBLIC_API_URL;
    const apiKey = process.env.NEXT_PUBLIC_KEY;

    if (!backendUrl) {
      console.error('[SYNC] NEXT_PUBLIC_API_URL is not configured');
      return {
        success: false,
        reason: 'Backend URL not configured',
        synced: 0,
      };
    }

    if (!apiKey) {
      console.warn('[SYNC] NEXT_PUBLIC_KEY is not configured - API requests may fail with 401');
    }

    // Send each transaction to backend
    for (const transaction of pendingTransactions) {
      try {
        // Send to backend API
        const syncResponse = await axios.post(
          `${backendUrl}/transactions/create`,
          transaction,
          {
            headers: {
              'Content-Type': 'application/json',
              'POS-API-KEY': apiKey,
            },
            timeout: 10000, // 10 second timeout
          }
        );

        if (syncResponse.status === 200 || syncResponse.status === 201) {
          // Mark transaction as synced in local database
          try {
            await axios.put(
              `/api/sync/transactions/${transaction._id}`,
              { isSynced: true },
              { timeout: 5000 }
            );

            syncedCount++;
            console.log(
              `[SYNC] ✓ Transaction #${transaction.OrderNo} synced successfully.`
            );
          } catch (updateError) {
            console.error(
              `[SYNC] Failed to mark transaction as synced:`,
              updateError instanceof Error ? updateError.message : String(updateError)
            );
          }
        }
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : String(error);
        console.error(
          `[SYNC] ✗ Failed to sync transaction #${transaction.OrderNo}: ${errorMsg}`
        );
        // Continue with next transaction instead of failing entirely
      }
    }

    return {
      success: true,
      reason: `Synced ${syncedCount}/${pendingTransactions.length} transactions`,
      synced: syncedCount,
      total: pendingTransactions.length,
    };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    console.error('[SYNC] Error during sync process:', errorMsg);
    return {
      success: false,
      reason: 'Sync process error',
      error: errorMsg,
      synced: 0,
    };
  } finally {
    isSyncInProgress = false;
  }
};
