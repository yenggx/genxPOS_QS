import { ObjectId } from 'mongodb';

// Menu Item
export interface MenuItem {
  _id?: ObjectId;
  id: string;
  payload: {
    id: string;
    name: string;
    category: string;
    subcategory: string;
    price: number;
    image?: string;
    description?: string;
    [key: string]: any;
  };
  updatedAt: Date;
}

// Associate/User
export interface Associate {
  _id?: ObjectId;
  id: string;
  user_id: string;
  name: string;
  email: string;
  pin: string;
  avatar: string;
  role: number; // 1 = staff, 2 = manager, etc.
  payload: any;
  lastUpdated: Date;
}

// Store Data
export interface StoreData {
  _id?: ObjectId;
  id: string;
  payload: {
    [key: string]: any;
  };
  lastUpdated: Date;
}

// Transaction/Order
export interface Transaction {
  _id?: ObjectId;
  localId?: number;
  items: Array<{
    id: string;
    name: string;
    quantity: number;
    price: number;
    subtotal: number;
  }>;
  total: number;
  discount?: number;
  discountType?: string;
  isSynced: boolean;
  date: Date;
  orderNumber?: string;
  paymentMethod?: string;
}

// Cart
export interface Cart {
  _id?: ObjectId;
  id: string;
  items: Array<{
    id: string;
    name: string;
    quantity: number;
    price: number;
    subtotal: number;
  }>;
  total: number;
  updatedAt: Date;
}

// User Session/Login
export interface UserSession {
  _id?: ObjectId;
  userId: string;
  name: string;
  email: string;
  role: number;
  avatar: string;
  loginTime: Date;
  lastActivity: Date;
  sessionToken: string;
}

// Transaction Counter
export interface TransactionCounter {
  _id?: ObjectId;
  type: 'transaction' | 'saleInvoice' | 'order'; // Type of counter
  value: number; // Current counter value
  lastUpdated: Date;
  date?: string; // For daily reset counters
}

// Sales Invoice
export interface SalesInvoice {
  _id?: ObjectId;
  id?: number;
  salesNumber: string;
  transactionRef: string;
  total: number;
  items: any[];
  updatedAt: Date;
}
