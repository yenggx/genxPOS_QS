export type EJournalEntryType = 'SALE' | 'VOID' | 'REFUND' | 'REPRINT' | 'X-READING' | 'Y-READING' | 'Z-READING';

export function logEJournalEntry(params: {
  businessDayId: string;
  workstationId: string;
  entryType: EJournalEntryType;
  text: string;
  transactionId?: string;
  sessionId?: string;
}): void {
  fetch('/api/ejournal-entry', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...params, timestamp: new Date().toISOString() }),
  }).catch(err => console.warn('[EJournal] Log failed (non-critical):', err));
}