import fs from 'fs';
import path from 'path';
import { getDatabase } from './mongodb';
import { COLLECTIONS } from './mongodb-utils';

// Helper functions
const center = (str: string, len: number) => {
  const pad = Math.max(0, len - str.length);
  const padL = Math.floor(pad / 2);
  return ' '.repeat(padL) + str + ' '.repeat(pad - padL);
};
const DIVIDER = ''.padEnd(40, '-');
const EQUALS_DIVIDER = ''.padEnd(40, '=');
const padRight = (str: string, len: number) => (str + ' '.repeat(len)).slice(0, len);
const padLeft = (str: string, len: number) => (' '.repeat(len) + str).slice(-len);

export async function generateAndSaveEJournal(dateStr: string, workstationId: string = "001") {
  
  try {
    const db = await getDatabase();

    // Find the businessDayId for this date + workstation
    const bizDay = await db.collection('businessDays').findOne(
      {
        date: dateStr,
        status: 'open',
      },
      {
        sort: { _id: -1 },
      }
    );
    const businessDayId = bizDay?.businessDayId?.toString();

    // Pull stored e-journal entries for this business day
    
    const entries = businessDayId
      ? await db.collection('ejournal_entries')
          .find({ businessDayId, workstationId })
          .sort({ timestamp: 1 })
          .toArray()
      : [];
    console.log("current business id:", businessDayId)
    let ejournalText = '';
    ejournalText += center("DUNKIN' PASALUBONG", 40) + '\n';
    ejournalText += center('ELECTRONIC JOURNAL', 40) + '\n';
    ejournalText += center(`DATE: ${dateStr}`, 40) + '\n';
    ejournalText += center(`TERMINAL: ${workstationId}`, 40) + '\n';
    ejournalText += EQUALS_DIVIDER + '\n\n';

    if (entries.length > 0) {
      // HAPPY PATH: use the stored receipt texts directly
      for (const entry of entries) {
        ejournalText += DIVIDER + '\n';
        ejournalText += center(`[${entry.entryType}]`, 40) + '\n';
        ejournalText += center(new Date(entry.timestamp).toLocaleString('en-PH'), 40) + '\n';
        ejournalText += DIVIDER + '\n';
        ejournalText += entry.text + '\n\n';
      }
      
    } else {
      // try {
      //   const db = await getDatabase();
        
      //   const startDate = new Date(`${dateStr}T00:00:00.000Z`);
      //   const endDate = new Date(`${dateStr}T23:59:59.999Z`);

      //   // 1. Fetch Transactions
      //   const txCollection = db.collection(COLLECTIONS.TRANSACTIONS || 'transactions');
      //   const transactions = await txCollection.find({
      //     $or: [
      //       { createdAt: { $gte: startDate.toISOString(), $lte: endDate.toISOString() } },
      //       { orderTime: { $gte: startDate.toISOString(), $lte: endDate.toISOString() } },
      //       { date: { $gte: startDate.toISOString(), $lte: endDate.toISOString() } }
      //     ]
      //   }).toArray();

      //   // 2. Fetch Sessions
      //   const sessionCollection = db.collection(COLLECTIONS.CASHIERS || 'cashier-session');
      //   const sessions = await sessionCollection.find({
      //     openedAt: { $gte: startDate.toISOString(), $lte: endDate.toISOString() }
      //   }).toArray();

      //   // 3. Fetch Reports (Z-Readings, etc)
      //   const reportsCollection = db.collection('reports');
      //   const reports = await reportsCollection.find({
      //     date: dateStr
      //   }).toArray();

      //   // 4. Combine everything into a single timeline
      //   let timeline: any[] = [];

      //   // Add Transactions
      //   transactions.forEach(tx => {
      //     timeline.push({
      //       type: tx.status === 'voided' ? 'VOID' : tx.status === 'refunded' ? 'REFUND' : 'SALE',
      //       timestamp: new Date(tx.createdAt || tx.orderTime || tx.date).getTime(),
      //       data: tx
      //     });
      //   });

      //   // Add Session Events
      //   sessions.forEach(session => {
      //     timeline.push({
      //       type: 'OPEN_REGISTER',
      //       timestamp: new Date(session.openedAt).getTime(),
      //       data: session
      //     });

      //     if (session.cashDrops && Array.isArray(session.cashDrops)) {
      //       session.cashDrops.forEach((drop: any) => {
      //         timeline.push({
      //           type: 'CASH_DROP',
      //           timestamp: new Date(drop.timestamp).getTime(),
      //           data: { ...drop, staffName: session.staffName }
      //         });
      //       });
      //     }

      //     if (session.closedAt) {
      //       timeline.push({
      //         type: 'CLOSE_REGISTER',
      //         timestamp: new Date(session.closedAt).getTime(),
      //         data: session
      //       });
      //     }
      //   });

      //   // Add Z-Readings
      //   reports.forEach(report => {
      //     timeline.push({
      //       type: report.reportType || 'Z_READING',
      //       timestamp: new Date(report.generatedAt).getTime(),
      //       data: report
      //     });
      //   });

      //   // Sort strictly by time
      //   timeline.sort((a, b) => a.timestamp - b.timestamp);

      //   // 5. Build the Text File
      //   let ejournalText = "";
      //   ejournalText += center("DUNKIN' PASALUBONG", 40) + "\n";
      //   ejournalText += center("ELECTRONIC JOURNAL", 40) + "\n";
      //   ejournalText += center(`DATE: ${dateStr}`, 40) + "\n";
      //   ejournalText += center(`TERMINAL: ${workstationId}`, 40) + "\n";
      //   ejournalText += EQUALS_DIVIDER + "\n\n";

      //   timeline.forEach(event => {
      //     const dateString = new Date(event.timestamp).toLocaleString('en-US');

      //     if (event.type === 'SALE' || event.type === 'VOID' || event.type === 'REFUND') {
      //       const tx = event.data;
            
      //       // If we saved the literal receipt text in the DB, USE IT!
      //       if (tx.receiptText) {
      //         if (event.type === 'VOID') ejournalText += center("*** VOIDED TRANSACTION ***", 40) + "\n";
      //         else if (event.type === 'REFUND') ejournalText += center("*** REFUNDED TRANSACTION ***", 40) + "\n";
              
      //         ejournalText += tx.receiptText + "\n\n";
      //       } 
      //       // Fallback for older transactions before we added receiptText
      //       else {
      //         ejournalText += DIVIDER + "\n";
      //         if (event.type === 'VOID') ejournalText += center("*** VOIDED TRANSACTION ***", 40) + "\n";
      //         else if (event.type === 'REFUND') ejournalText += center("*** REFUNDED TRANSACTION ***", 40) + "\n";
              
      //         ejournalText += `TXN #: ${tx.transactionNumber || tx.OrderNo || tx._id}\n`;
      //         ejournalText += `TYPE : ${tx.transactionType || 'REGULAR'} | ${tx.featureFlags?.orderType || 'TAKE OUT'}\n`;
      //         ejournalText += `DATE : ${dateString}\n`;
      //         ejournalText += `STAFF: ${tx.staffName || 'Cashier'}\n`;
      //         ejournalText += DIVIDER + "\n";
      //         ejournalText += padRight("SUBTOTAL:", 28) + padLeft(((tx.subtotal||0)).toFixed(2), 12) + "\n";
      //         ejournalText += padRight("TOTAL:", 28) + padLeft(((tx.total || tx.price?.eaterPayment || 0) / 100).toFixed(2), 12) + "\n";
      //         ejournalText += "\n";
      //       }
      //     }

      //     else if (event.type === 'OPEN_REGISTER') {
      //       ejournalText += EQUALS_DIVIDER + "\n";
      //       ejournalText += center("SHIFT OPEN", 40) + "\n";
      //       ejournalText += `DATE : ${dateString}\n`;
      //       ejournalText += `STAFF: ${event.data.staffName || 'Cashier'}\n`;
      //       ejournalText += padRight("STARTING CASH:", 28) + padLeft(parseFloat(event.data.startingCash || "0").toFixed(2), 12) + "\n";
      //       ejournalText += EQUALS_DIVIDER + "\n\n";
      //     }

      //     else if (event.type === 'CLOSE_REGISTER') {
      //       ejournalText += EQUALS_DIVIDER + "\n";
      //       ejournalText += center("SHIFT CLOSE / TURNOVER", 40) + "\n";
      //       ejournalText += `DATE : ${dateString}\n`;
      //       ejournalText += `STAFF: ${event.data.staffName || 'Cashier'}\n`;
      //       ejournalText += padRight("EXPECTED CASH:", 28) + padLeft(parseFloat(event.data.expectedCash || "0").toFixed(2), 12) + "\n";
      //       ejournalText += padRight("ACTUAL CASH:", 28) + padLeft(parseFloat(event.data.actualCash || "0").toFixed(2), 12) + "\n";
            
      //       const variance = parseFloat(event.data.variance || "0");
      //       if (Math.abs(variance) > 0.01) {
      //         const vType = variance > 0 ? "OVER:" : "SHORT:";
      //         ejournalText += padRight(`VARIANCE (${vType})`, 28) + padLeft(Math.abs(variance).toFixed(2), 12) + "\n";
      //         if (event.data.varianceReason) {
      //           ejournalText += `REASON: ${event.data.varianceReason}\n`;
      //         }
      //       }
      //       ejournalText += EQUALS_DIVIDER + "\n\n";
      //     }

      //     else if (event.type === 'CASH_DROP') {
      //       ejournalText += DIVIDER + "\n";
      //       ejournalText += center("CASH DROP", 40) + "\n";
      //       ejournalText += `DATE : ${dateString}\n`;
      //       ejournalText += `STAFF: ${event.data.staffName || 'Cashier'}\n`;
      //       ejournalText += padRight("AMOUNT DROPPED:", 28) + padLeft(parseFloat(event.data.amount || "0").toFixed(2), 12) + "\n";
      //       ejournalText += DIVIDER + "\n\n";
      //     }

      //     else if (event.type === 'Z-READING') {
      //       const r = event.data.totals || {};
      //       ejournalText += EQUALS_DIVIDER + "\n";
      //       ejournalText += center("Z-READING SUMMARY", 40) + "\n";
      //       ejournalText += `DATE : ${dateString}\n`;
      //       ejournalText += padRight("GROSS SALES:", 28) + padLeft((r.grossSales||0).toFixed(2), 12) + "\n";
      //       ejournalText += padRight("NET SALES:", 28) + padLeft((r.netSales||0).toFixed(2), 12) + "\n";
      //       ejournalText += padRight("DISCOUNTS:", 28) + padLeft((r.totalDiscounts||0).toFixed(2), 12) + "\n";
      //       ejournalText += padRight("TOTAL TXNS:", 28) + padLeft(String(r.transactionCount||0), 12) + "\n";
      //       ejournalText += EQUALS_DIVIDER + "\n\n";
      //     }
      //   });

      //   ejournalText += EQUALS_DIVIDER + "\n";
      //   ejournalText += center("END OF JOURNAL", 40) + "\n";
      //   ejournalText += EQUALS_DIVIDER + "\n";

      //   const dirPath = path.join(process.cwd(), 'POS_REPORTS');
      //   if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });

      //   const fileName = `EJ_${workstationId}_${dateStr.replace(/-/g, '')}.txt`;
      //   const filePath = path.join(dirPath, fileName);
        
      //   fs.writeFileSync(filePath, ejournalText, 'utf8');
        
      //   return { success: true, filePath, fileName };
      // } catch (error: any) {
      //   console.error("E-Journal Generation Error:", error);
      //   return { success: false, error: error.message };
      // }
    }

    ejournalText += EQUALS_DIVIDER + '\n';
    ejournalText += center('END OF JOURNAL', 40) + '\n';
    ejournalText += EQUALS_DIVIDER + '\n';

    const dirPath = path.join(process.cwd(), 'POS_REPORTS');
    if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });

    const fileName = `EJ_${workstationId}_${dateStr.replace(/-/g, '')}.txt`;
    const filePath = path.join(dirPath, fileName);
    fs.writeFileSync(filePath, ejournalText, 'utf8');

    return { success: true, filePath, fileName };
  } catch (error: any) {
    console.error('E-Journal Generation Error:', error);
    return { success: false, error: error.message };
  }
}

