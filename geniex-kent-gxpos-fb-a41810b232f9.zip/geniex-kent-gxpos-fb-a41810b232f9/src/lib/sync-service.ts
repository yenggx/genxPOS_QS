import axios from 'axios';
import { getDatabase } from '@/src/lib/mongodb';
import { COLLECTIONS } from '@/src/lib/mongodb-utils';
import { ObjectId } from 'mongodb';

export interface SyncResult {
  orderId: string | number;
  status: 'success' | 'failed' | 'skipped' | 'db_update_failed' | 'unexpected_status';
  cmsStatusCode?: number;
  cmsOrderID?: string;
  cmsSpecialID?: string;
  error?: string;
  errorType?: string;
  reason?: string;
}

export interface SyncSummary {
  synced: number;
  total: number;
  failed: number;
  results: SyncResult[];
}

export async function syncTransactions(transactions: any[]): Promise<SyncSummary> {
  const backendUrl = process.env.NEXT_PUBLIC_API_URL;
  const apiKey     = process.env.NEXT_PUBLIC_KEY;
  const db         = await getDatabase();
  const col        = db.collection(COLLECTIONS.TRANSACTIONS);

  let synced = 0;
  let failed = 0;
  const results: SyncResult[] = [];

  for (const transaction of transactions) {
    const orderId = transaction.OrderNo || transaction.orderNumber || 'UNKNOWN';

    if (!backendUrl) {
      failed++;
      results.push({ orderId, status: 'skipped', reason: 'No backend URL configured' });
      continue;
    }

    try {
      const cmsResponse = await axios.post(
        `${backendUrl}/transactions/create`,
        transaction,
        {
          headers: { 'Content-Type': 'application/json', 'POS-API-KEY': apiKey || '' },
          timeout: 10000,
        }
      );

      if (cmsResponse.status === 200 || cmsResponse.status === 201) {
        const cmsData     = cmsResponse.data || {};
        const cmsOrderID  = cmsData.OrderID  || cmsData.order_id;
        const cmsSpecialID = cmsData.specialID || cmsData.special_id;

        const updateResult = await col.updateOne(
          { _id: new ObjectId(transaction._id) },
          { $set: { isSynced: true, syncedAt: new Date(), syncedToCMS: true, cmsResponse: cmsResponse.data, cmsOrderID, cmsSpecialID, updatedAt: new Date() } }
        );

        if (updateResult.modifiedCount > 0) {
          synced++;
          results.push({ orderId, status: 'success', cmsStatusCode: cmsResponse.status, cmsOrderID, cmsSpecialID });
        } else {
          failed++;
          results.push({ orderId, status: 'db_update_failed' });
        }
      } else {
        failed++;
        results.push({ orderId, status: 'unexpected_status', cmsStatusCode: cmsResponse.status });
      }
    } catch (error) {
      failed++;
      const errorMsg = error instanceof Error ? error.message : String(error);
      let errorType  = 'unknown_error';
      if      (errorMsg.includes('ECONNREFUSED')) errorType = 'connection_refused';
      else if (errorMsg.includes('timeout'))      errorType = 'timeout';
      else if (errorMsg.includes('ENOTFOUND'))    errorType = 'dns_error';
      else if (axios.isAxiosError(error))         errorType = `http_error_${error.response?.status ?? 'unknown'}`;

      results.push({ orderId, status: 'failed', error: errorMsg, errorType });
    }
  }

  return { synced, total: transactions.length, failed, results };
}