// lib/workstation.ts
export function getWorkstationId(): string {
  if (typeof window === 'undefined') {
    return process.env.NEXT_PUBLIC_WORKSTATION_ID ?? '001';
  }
  return (
    localStorage.getItem('workstationId') ??
    process.env.NEXT_PUBLIC_WORKSTATION_ID ??
    '001'
  );
}