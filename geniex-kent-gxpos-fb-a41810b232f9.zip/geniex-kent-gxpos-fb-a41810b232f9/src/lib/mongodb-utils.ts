import { getDatabase } from './mongodb';
import { Collection } from 'mongodb';
import type {
  MenuItem,
  Associate,
  StoreData,
  Transaction,
  Cart,
  UserSession,
  TransactionCounter,
  SalesInvoice,
} from './mongodb-types';

// Collection names
export const COLLECTIONS = {
  MENU: 'menu',
  ASSOCIATES: 'associates',
  STORES: 'stores',
  TRANSACTIONS: 'transactions',
  CARTS: 'carts',
  USER_SESSIONS: 'userSessions',
  CASHIER_SESSIONS: 'cashierSessions',
  COUNTERS: 'counters',
  SALES_INVOICES: 'salesInvoices',
  DISCOUNTS: 'discounts',
  REFUND_REASONS: 'refundReasons',
  VOID_REASONS:   'voidReasons',
  Z_COUNTERS:        'zCounters',
  Z_READING_RECORDS: 'zReadingRecords'
};

// Initialize all collections with indexes
export async function initializeDatabase() {
  try {
    console.log('🔧 Initializing MongoDB database and collections...');
    const db = await getDatabase();

    // Create collections if they don't exist
    const collections = await db.listCollections().toArray();
    const collectionNames = collections.map((c) => c.name);

    console.log(`📊 Existing collections: ${collectionNames.join(', ') || 'none'}`);

    // Menu collection
    if (!collectionNames.includes(COLLECTIONS.MENU)) {
      await db.createCollection(COLLECTIONS.MENU);
      console.log(`  ✓ Created ${COLLECTIONS.MENU} collection`);
    }
    await db
      .collection(COLLECTIONS.MENU)
      .createIndex({ id: 1 }, { unique: true })
      .catch(() => {}); // Ignore if index already exists

    // Associates collection
    if (!collectionNames.includes(COLLECTIONS.ASSOCIATES)) {
      await db.createCollection(COLLECTIONS.ASSOCIATES);
      console.log(`  ✓ Created ${COLLECTIONS.ASSOCIATES} collection`);
    }
    await db
      .collection(COLLECTIONS.ASSOCIATES)
      .createIndex({ id: 1 }, { unique: true })
      .catch(() => {});
    await db
      .collection(COLLECTIONS.ASSOCIATES)
      .createIndex({ '$**': 1 }) // Text search index
      .catch(() => {});

    // Stores collection
    if (!collectionNames.includes(COLLECTIONS.STORES)) {
      await db.createCollection(COLLECTIONS.STORES);
      console.log(`  ✓ Created ${COLLECTIONS.STORES} collection`);
    }
    await db
      .collection(COLLECTIONS.STORES)
      .createIndex({ id: 1 }, { unique: true })
      .catch(() => {});

    // Transactions collection
    if (!collectionNames.includes(COLLECTIONS.TRANSACTIONS)) {
      await db.createCollection(COLLECTIONS.TRANSACTIONS);
      console.log(`  ✓ Created ${COLLECTIONS.TRANSACTIONS} collection`);
    }
    await db
      .collection(COLLECTIONS.TRANSACTIONS)
      .createIndex({ date: 1 })
      .catch(() => {});

    // Carts collection
    if (!collectionNames.includes(COLLECTIONS.CARTS)) {
      await db.createCollection(COLLECTIONS.CARTS);
      console.log(`  ✓ Created ${COLLECTIONS.CARTS} collection`);
    }
    await db
      .collection(COLLECTIONS.CARTS)
      .createIndex({ id: 1 }, { unique: true })
      .catch(() => {});

    // User Sessions collection
    if (!collectionNames.includes(COLLECTIONS.USER_SESSIONS)) {
      await db.createCollection(COLLECTIONS.USER_SESSIONS);
      console.log(`  ✓ Created ${COLLECTIONS.USER_SESSIONS} collection`);
    }
    await db
      .collection(COLLECTIONS.USER_SESSIONS)
      .createIndex({ sessionToken: 1 }, { unique: true })
      .catch(() => {});
    await db
      .collection(COLLECTIONS.USER_SESSIONS)
      .createIndex({ lastActivity: 1 }, { expireAfterSeconds: 86400 }) // 24 hour expiry
      .catch(() => {});

    // Counters collection (for transaction numbers, order numbers, etc.)
    if (!collectionNames.includes(COLLECTIONS.COUNTERS)) {
      await db.createCollection(COLLECTIONS.COUNTERS);
      console.log(`  ✓ Created ${COLLECTIONS.COUNTERS} collection`);
    }
    await db
      .collection(COLLECTIONS.COUNTERS)
      .createIndex({ type: 1 }, { unique: false })
      .catch(() => {});

    // Sales Invoices collection
    if (!collectionNames.includes(COLLECTIONS.SALES_INVOICES)) {
      await db.createCollection(COLLECTIONS.SALES_INVOICES);
      console.log(`  ✓ Created ${COLLECTIONS.SALES_INVOICES} collection`);
    }
    await db
      .collection(COLLECTIONS.SALES_INVOICES)
      .createIndex({ salesNumber: 1 }, { unique: true })
      .catch(() => {});

    // Discounts collection
    if (!collectionNames.includes(COLLECTIONS.DISCOUNTS)) {
      await db.createCollection(COLLECTIONS.DISCOUNTS);
      console.log(`  ✓ Created ${COLLECTIONS.DISCOUNTS} collection`);
    }
    await db
      .collection(COLLECTIONS.DISCOUNTS)
      .createIndex({ _id: 1 }, { unique: true })
      .catch(() => {});

    await db.collection('refundReasons').createIndex({ id: 1 }, { unique: true });
    await db.collection('voidReasons').createIndex({ id: 1 }, { unique: true });

    // ─── Z-Counters collection ─────────────────────────────────────────────
    // Tracks how many times a Z-Reading has been printed per workstation.
    // Each document: { workstationId, count, lastZDate, lastUpdated }
    if (!collectionNames.includes(COLLECTIONS.Z_COUNTERS)) {
      await db.createCollection(COLLECTIONS.Z_COUNTERS);
      console.log(`  ✓ Created ${COLLECTIONS.Z_COUNTERS} collection`);
    }
    await db
      .collection(COLLECTIONS.Z_COUNTERS)
      .createIndex({ workstationId: 1 }, { unique: true })
      .catch(() => {});

      // ─── Z-Reading Records (date-keyed, for accurate reprints) ────────────────
    if (!collectionNames.includes(COLLECTIONS.Z_READING_RECORDS)) {
      await db.createCollection(COLLECTIONS.Z_READING_RECORDS);
      console.log(`  ✓ Created ${COLLECTIONS.Z_READING_RECORDS} collection`);
    }
    await db
      .collection(COLLECTIONS.Z_READING_RECORDS)
      .createIndex({ workstationId: 1, date: 1 }, { unique: true })  // compound unique
      .catch(() => {});

    await db.collection('ejournal_entries').createIndex(
      { businessDayId: 1, workstationId: 1, timestamp: 1 }
    );

    console.log('✅ Database initialization complete');
  } catch (error) {
    console.error('❌ Error initializing database:', error);
    throw error;
  }
}

// Generic collection accessor
export async function getCollection(
  collectionName: string
): Promise<any> {
  const db = await getDatabase();
  return db.collection(collectionName);
}

// Helper: Get counter value and increment
export async function getNextCounterValue(
  counterType: string
): Promise<number> {
  const db = await getDatabase();
  const countersCollection = db.collection<TransactionCounter>(
    COLLECTIONS.COUNTERS
  );

  const result = await countersCollection.findOneAndUpdate(
    { type: counterType as any },
    { $inc: { value: 1 }, $set: { lastUpdated: new Date() } } as any,
    { upsert: true, returnDocument: 'after' }
  );

  return (result as any)?.value || 1;
}

// Helper: Reset daily counter if date changed
export async function getNextDailyCounterValue(
  counterType: string,
  currentDate: string
): Promise<number> {
  const db = await getDatabase();
  const countersCollection = db.collection<TransactionCounter>(
    COLLECTIONS.COUNTERS
  );

  // Check if date changed
  const counter = await countersCollection.findOne({ type: counterType as any });

  if (!counter || counter.date !== currentDate) {
    // Date changed or counter doesn't exist, reset to 1
    await countersCollection.updateOne(
      { type: counterType as any },
      {
        $set: { value: 1, date: currentDate, lastUpdated: new Date() },
      } as any,
      { upsert: true }
    );
    return 1;
  }

  // Same date, increment
  const result = await countersCollection.findOneAndUpdate(
    { type: counterType as any },
    { $inc: { value: 1 }, $set: { lastUpdated: new Date() } } as any,
    { returnDocument: 'after' }
  );

  return (result as any)?.value || 1;
}

export async function initCounterIfNotExists(
  counterType: string,
  startValue = 0
): Promise<void> {
  const db = await getDatabase();
  const countersCollection = db.collection<TransactionCounter>(COLLECTIONS.COUNTERS);

  await countersCollection.updateOne(
    { type: counterType as any },
    {
      $setOnInsert: { value: startValue, lastUpdated: new Date() },
    } as any,
    { upsert: true }
  );
}

// ─── Z-Counter Helpers ─────────────────────────────────────────────────────

/**
 * Increment the Z-Reading counter for a workstation and return the new value.
 * Call this ONCE per actual Z-Reading print (not reprints).
 */
export async function incrementZCounter(workstationId: string): Promise<number> {
  const db = await getDatabase();
  const todayDateStr = new Date().toISOString().split('T')[0];

  const result = await db.collection(COLLECTIONS.Z_COUNTERS).findOneAndUpdate(
    { workstationId },
    {
      $inc: { count: 1 },
      $set: { lastZDate: todayDateStr, lastUpdated: new Date() },
    },
    { upsert: true, returnDocument: 'after' }
  );

  return (result as any)?.count ?? 1;
}

/**
 * Get the current Z-Reading counter for a workstation WITHOUT incrementing.
 * Use for reprints or previewing the next expected value.
 */
export async function getZCounter(workstationId: string): Promise<number> {
  const db = await getDatabase();
  const doc = await db.collection(COLLECTIONS.Z_COUNTERS).findOne({ workstationId });
  return (doc as any)?.count ?? 0;
}