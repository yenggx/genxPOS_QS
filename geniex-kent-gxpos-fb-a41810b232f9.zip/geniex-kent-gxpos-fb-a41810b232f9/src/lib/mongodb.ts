import { MongoClient, Db } from 'mongodb';

let cachedClient: MongoClient | null = null;
let cachedDb: Db | null = null;

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://admin:admin123@localhost:27017/gXPOS';

if (!MONGODB_URI) {
  throw new Error('Please define the MONGODB_URI environment variable');
}

interface MongoConnection {
  client: MongoClient;
  db: Db;
}

export async function connectToDatabase(): Promise<MongoConnection> {
  // Return cached connection if available
  if (cachedClient && cachedDb) {
    console.log('✓ Using cached MongoDB connection');
    return { client: cachedClient, db: cachedDb };
  }

  try {
    console.log('🔗 Connecting to MongoDB at:', MONGODB_URI);
    const client = await MongoClient.connect(MONGODB_URI, {
      maxPoolSize: 10,
      minPoolSize: 2,
      serverSelectionTimeoutMS: 5000,
      connectTimeoutMS: 5000,
    });

    const db = client.db();

    // Verify connection
    await db.admin().ping();
    console.log('✅ Connected to MongoDB');

    // Cache the connection
    cachedClient = client;
    cachedDb = db;

    return { client, db };
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    // Clear cache on error
    cachedClient = null;
    cachedDb = null;
    throw error;
  }
}

export async function getDatabase(): Promise<Db> {
  if (!cachedDb) {
    const { db } = await connectToDatabase();
    return db;
  }
  return cachedDb;
}

export async function closeDatabase(): Promise<void> {
  if (cachedClient) {
    await cachedClient.close();
    cachedClient = null;
    cachedDb = null;
    console.log('MongoDB connection closed');
  }
}
