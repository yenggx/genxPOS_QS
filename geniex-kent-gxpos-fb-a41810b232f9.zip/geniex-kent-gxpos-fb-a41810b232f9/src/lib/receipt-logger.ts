import fs from 'fs';
import path from 'path';

export type ReceiptType =
  | 'SALE'
  | 'REFUND'
  | 'VOID'
  | 'X-READING'
  | 'Y-READING'
  | 'Z-READING'
  | 'E-SHIFT';

/**
 * Saves a receipt/reading text to POS_REPORTS/RECEIPTS/<date>/<timestamp>_<type>_<ref>.txt
 * Call this alongside every printDirect() so the folder always mirrors what was printed.
 *
 * @param text        The exact text sent to the printer
 * @param type        Receipt type label
 * @param ref         Transaction number, session ID, terminal ID, etc.
 * @param dateStr     Business date string (YYYY-MM-DD). Defaults to today.
 */
export function saveReceiptLog(
  text: string,
  type: ReceiptType,
  ref: string,
  dateStr?: string
): { success: boolean; filePath?: string; error?: string } {
  try {
    const date = dateStr ?? new Date().toISOString().split('T')[0];

    // POS_REPORTS/RECEIPTS/2025-01-15/
    const dirPath = path.join(process.cwd(), 'POS_REPORTS', 'RECEIPTS', date);
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }

    // 20250115_143022_SALE_TXN-00123.txt
    const timestamp = new Date()
      .toISOString()
      .replace(/[-:]/g, '')
      .replace('T', '_')
      .slice(0, 15); // YYYYMMdd_HHmmss

    const safeRef = ref.replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, 40);
    const fileName = `${timestamp}_${type}_${safeRef}.txt`;
    const filePath = path.join(dirPath, fileName);

    fs.writeFileSync(filePath, text, 'utf8');

    return { success: true, filePath };
  } catch (error: any) {
    console.error('[ReceiptLogger] Failed to save receipt:', error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Lists all saved receipt files for a given business date.
 * Returns them sorted chronologically (filename order = timestamp order).
 */
export function listReceiptLogs(dateStr: string): Array<{
  fileName: string;
  filePath: string;
  type: string;
  ref: string;
}> {
  try {
    const dirPath = path.join(process.cwd(), 'POS_REPORTS', 'RECEIPTS', dateStr);
    if (!fs.existsSync(dirPath)) return [];

    return fs.readdirSync(dirPath)
      .filter(f => f.endsWith('.txt'))
      .sort()
      .map(fileName => {
        // Parse: 20250115_143022_SALE_TXN-00123.txt
        const parts = fileName.replace('.txt', '').split('_');
        const type  = parts[2] ?? 'UNKNOWN';
        const ref   = parts.slice(3).join('_') || '-';
        return { fileName, filePath: path.join(dirPath, fileName), type, ref };
      });
  } catch {
    return [];
  }
}