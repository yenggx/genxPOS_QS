// src/lib/singleflight.ts

const inflight = new Map<string, Promise<any>>();

/**
 * Ensures only one execution of `fn` runs per `key` at a time.
 * Concurrent callers with the same key await the same in-flight
 * promise instead of triggering their own execution.
 */
export function singleFlight<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const existing = inflight.get(key);
  if (existing) {
    return existing as Promise<T>;
  }

  const promise = fn().finally(() => {
    // Only clear if this promise is still the current one for that key
    if (inflight.get(key) === promise) {
      inflight.delete(key);
    }
  });

  inflight.set(key, promise);
  return promise;
}