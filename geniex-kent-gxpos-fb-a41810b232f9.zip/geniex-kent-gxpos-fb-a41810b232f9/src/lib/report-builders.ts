// src/lib/report-builders.ts
export interface PaymentCounts {
  CARD: number; MAYA: number; GCASH: number; QRPH: number; LANDERS: number; VOUCHER: number;
}
export interface PaymentSums {
  CARD: number; MAYA: number; GCASH: number; QRPH: number; LANDERS: number; VOUCHER: number;
}

export interface DiscountCounts {
  SRC: number; PWD: number; ATHLETE: number; SOLO: number; MEDAL: number; CUSTOM: number;
}
export interface DiscountSums {
  SRC: number; PWD: number; ATHLETE: number; SOLO: number; MEDAL: number; CUSTOM: number;
}

export interface SiRange {
  minSi:        number;
  maxSi:        number;
  totalSi:      number;
  minVoidSi?:   number;
  maxVoidSi?:   number;
  minRefundSi?: number;
  maxRefundSi?: number;
}

export interface ReportStats {
  grossSales:          number;
  totalDiscount:       number;
  netSales:            number;
  totalTax:            number;
  totalCashSales:      number;
  totalNonCashSales:   number;
  totalVoided:         number;
  totalRefunded:       number;
  cashFund:            number;
  denominations:       any;
  actualCashCount:     any;
  expectedTotal:       number;
  totalDropped:        number;
  vatableSales:        number;
  vatExemptSales:      number;
  zeroRatedSales:      number;
  cashTxCount:         number;
  cashDrops:           any;
  nonCashTxCount:      number;
  encloseCashAmount?:  number;
  encloseCashCount?:   number;
  encloseNonCashAmount?: number;
  encloseNonCashCount?:  number;
  voidCount:           number;
  refundCount:         number;
  guestCount:          number;
  pCounts:             PaymentCounts;
  pSums:               PaymentSums;
  dCounts:             DiscountCounts;
  dSums:               DiscountSums;
  revenueByCategory:   Record<string, number>;
  txTypeSummary:       Record<string, { count: number; amount: number }>;
  si:                  SiRange;
  voidSeriesRange:     { min: string; max: string };
  refundSeriesRange:   { min: string; max: string };
}

export const padRight = (str: string, len: number) =>
  (str + ' '.repeat(len)).slice(0, len);

export const padLeft = (str: string, len: number) =>
  (' '.repeat(len) + str).slice(-len);

export const centerText = (str: string, len: number) => {
  const pad = Math.max(0, len - str.length);
  return ' '.repeat(Math.floor(pad / 2)) + str + ' '.repeat(pad - Math.floor(pad / 2));
};

export const divider = (width = 48) => '-'.repeat(width);

export const fmtAmt = (n: number) =>
  (n || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export const fmtSI = (val: number, pad = 15) =>
  val === Infinity || val === -Infinity || val == null
    ? '-'
    : String(val).padStart(pad, '0');

const replaceEnvVarsInline = (str: string, fiscal: any) => str
  .replace(/{{process\.env\.NEXT_PUBLIC_VAT}}/g,        fiscal?.vatNumber        || '')
  .replace(/{{process\.env\.NEXT_PUBLIC_TIN}}/g,        fiscal?.tinNumber        || '')
  .replace(/{{process\.env\.NEXT_PUBLIC_MIN}}/g,        fiscal?.minNumber        || '')
  .replace(/{{process\.env\.NEXT_PUBLIC_PTU}}/g,        fiscal?.ptuNumber        || '')
  .replace(/{{process\.env\.NEXT_PUBLIC_SERIALNO}}/g,   fiscal?.snNumber   || '');

export function formatHtmlToText(htmlStr: string, width: number): string {
  if (!htmlStr) return '';
  let text = htmlStr
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>|<\/div>|<\/h[1-6]>/gi, '\n')
    .replace(/<[^>]*>/gm, '');
  text = text
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');
  return (
    text
      .split('\n')
      .map(l => l.trim())
      .filter(Boolean)
      .map(l => centerText(l.slice(0, width), width))
      .join('\n') + '\n'
  );
}

export function contentToStats(content: any): ReportStats {
  const c   = content        || {};
  console.log(c);
  const at  = c.auditTrail   || {};
  const col = c.collections  || {};
  const tax = c.taxDetails   || {};
  const less = c.less        || {};

  const sc      = less.sc      ?? c.sales?.discounts?.src      ?? c.sales?.discounts?.srpwd   ?? 0;
  const pwd     = less.pwd     ?? c.sales?.discounts?.pwd      ?? 0;
  const athlete = less.athlete ?? c.sales?.discounts?.athlete  ?? 0;
  const solo    = less.solo    ?? c.sales?.discounts?.solo     ?? 0;
  const medal   = less.medal   ?? c.sales?.discounts?.medal    ?? 0;
  const custom  = less.custom  ?? c.sales?.discounts?.custom   ?? 0;

  const txTypeSummary: Record<string, { count: number; amount: number }> = c.txTypeSummary || {};

  if (Object.keys(txTypeSummary).length === 0) {
    const typeKeys = ['regular', 'sc', 'pwd', 'athlete', 'peza', 'diplomat', 'solo', 'medal', 'custom'] as const;
    for (const k of typeKeys) {
      const entry = at[k];
      if (entry) {
        const storeKey = k === 'sc' ? 'SRC' : k.toUpperCase();
        txTypeSummary[storeKey] = { count: entry.count || 0, amount: entry.amount || 0 };
      }
    }
  }

  return {
    grossSales:        c.grossSales              ?? c.sales?.grossSales    ?? 0,
    totalDiscount:     sc + pwd + athlete + solo + medal + custom,
    netSales:          c.netSales                ?? c.totals?.netSales     ?? 0,
    totalTax:          tax.vatAmount             ?? 0,
    totalCashSales:    col.cash?.amount          ?? 0,
    totalNonCashSales: col.onlinePayment?.amount ?? 0,
    encloseCashAmount: col.encloseCash?.amount   ?? 0,
    encloseCashCount:  col.encloseCash?.count    ?? 0,
    encloseNonCashAmount: col.encloseNonCash?.amount ?? 0,
    encloseNonCashCount:  col.encloseNonCash?.count  ?? 0,
    totalVoided:       at.voids?.amount          ?? 0,
    totalRefunded:     at.refunds?.amount        ?? 0,
    cashFund:
      c.cashierBankOut?.changeFund ??
      c.eShiftDetails?.cashFund    ?? 0,
    denominations:
      c.cashierBankOut?.denominations ??
      c.eShiftDetails?.denominations  ?? {},
    actualCashCount:
      c.cashierBankOut?.actualCount ??
      c.eShiftDetails?.actualCount  ?? 0,
    cashDrops:
      c.cashierBankOut?.cashDrops ??
      c.eShiftDetails?.cashDrops  ?? [],
    expectedTotal: 0,
    totalDropped:  c.eShiftDetails?.totalDropped ?? 0,
    vatableSales:  tax.vatableSales  ?? 0,
    vatExemptSales: tax.vatExemptSales ?? 0,
    zeroRatedSales: tax.zeroRatedSales ?? 0,
    cashTxCount:    col.cash?.count          ?? 0,
    nonCashTxCount: col.onlinePayment?.count ?? 0,
    voidCount:      at.voids?.count  ?? at.voidCount  ?? 0,
    refundCount:    at.refunds?.count ?? at.refundCount ?? 0,
    guestCount:     at.guests?.count  ?? 0,
    pCounts: c.pCounts || { CARD: 0, MAYA: 0, GCASH: 0, QRPH: 0, LANDERS: 0, VOUCHER: 0 },
    pSums:   c.pSums   || { CARD: 0, MAYA: 0, GCASH: 0, QRPH: 0, LANDERS: 0, VOUCHER: 0 },
    dCounts: { SRC: 0, PWD: 0, ATHLETE: 0, SOLO: 0, MEDAL: 0, CUSTOM: 0 },
    dSums:   { SRC: sc, PWD: pwd, ATHLETE: athlete, SOLO: solo, MEDAL: medal, CUSTOM: custom },
    revenueByCategory: c.revenueByCategory || {},
    txTypeSummary,
    si: {
      minSi:
        at.firstSalesInvoiceNo && at.firstSalesInvoiceNo !== '-'
          ? Number(at.firstSalesInvoiceNo) || Infinity
          : Infinity,
      maxSi:
        at.lastSalesInvoiceNo && at.lastSalesInvoiceNo !== '-'
          ? Number(at.lastSalesInvoiceNo) || -Infinity
          : -Infinity,
      totalSi: at.totalSI?.count ?? at.totalSi?.count ?? 0,
    },
    voidSeriesRange:   { min: '-', max: '-' },
    refundSeriesRange: {
      min: at.firstRefundSeriesNo || '-',
      max: at.lastRefundSeriesNo  || '-',
    },
  };
}

export function generateReportContentPayload(
  reportStats: ReportStats,
  extraData: Record<string, unknown> = {},
) {
  const vatFromExempt = (reportStats.vatExemptSales || 0) * 0.12;

  const less = {
    sc:      reportStats.dSums.SRC     || 0,
    pwd:     reportStats.dSums.PWD     || 0,
    athlete: reportStats.dSums.ATHLETE || 0,
    solo:    reportStats.dSums.SOLO    || 0,
    medal:   reportStats.dSums.MEDAL   || 0,
    custom:  reportStats.dSums.CUSTOM  || 0,
    vatFromExempt,
    total:
      (reportStats.dSums.SRC     || 0) +
      (reportStats.dSums.PWD     || 0) +
      (reportStats.dSums.ATHLETE || 0) +
      (reportStats.dSums.SOLO    || 0) +
      (reportStats.dSums.MEDAL   || 0) +
      (reportStats.dSums.CUSTOM  || 0) +
      vatFromExempt,
  };
  const salesForTheDay = (reportStats.grossSales || 0) - less.total;

  const totalColCount = (reportStats.cashTxCount || 0) + (reportStats.nonCashTxCount || 0) + (reportStats.encloseCashCount || 0) + (reportStats.encloseNonCashCount || 0);
  const totalColAmount = (reportStats.netSales || 0) + (reportStats.encloseCashAmount || 0) + (reportStats.encloseNonCashAmount || 0);
  
  const avgPerTx =
    (reportStats.si?.totalSi || 0) > 0
      ? reportStats.netSales / reportStats.si.totalSi
      : 0;

  const txTypes = reportStats.txTypeSummary || {};

  const vatTxCount = ['SRC', 'PWD', 'ATHLETE', 'PEZA', 'DIPLOMAT', 'SOLO', 'MEDAL', 'CUSTOM']
    .reduce((sum, t) => sum + (txTypes[t]?.count || 0), 0);

  const oldGT =
    (extraData?.accountability as any)?.oldGT ??
    (extraData?.yReadingDetails as any)?.oldGT ??
    0;
  const newGrandTTL = oldGT + (reportStats.netSales || 0);


  return {
    grossSales: reportStats.grossSales || 0,
    less,
    salesForTheDay,
    taxDetails: {
      vatableSales:   reportStats.vatableSales   || 0,
      vatAmount:      reportStats.totalTax       || 0,
      vatExemptSales: reportStats.vatExemptSales || 0,
      zeroRatedSales: reportStats.zeroRatedSales || 0,
    },
    netSales: reportStats.netSales || 0,
    collections: {
      cash:          { count: reportStats.cashTxCount    || 0, amount: reportStats.totalCashSales   || 0 },
      onlinePayment: { count: reportStats.nonCashTxCount || 0, amount: reportStats.totalNonCashSales || 0 },
      encloseCash:   { count: reportStats.encloseCashCount || 0, amount: reportStats.encloseCashAmount || 0 },
      encloseNonCash:{ count: reportStats.encloseNonCashCount || 0, amount: reportStats.encloseNonCashAmount || 0 },
      total:         { count: totalColCount,                   amount: totalColAmount },
    },
    revenueByCategory: reportStats.revenueByCategory || {},
    auditTrail: {
      regular:  txTypes.REGULAR  || { count: 0, amount: 0 },
      sc:       txTypes.SRC      || { count: 0, amount: 0 },
      pwd:      txTypes.PWD      || { count: 0, amount: 0 },
      athlete:  txTypes.ATHLETE  || { count: 0, amount: 0 },
      peza:     txTypes.PEZA     || { count: 0, amount: 0 },
      diplomat: txTypes.DIPLOMAT || { count: 0, amount: 0 },
      solo:     txTypes.SOLO     || { count: 0, amount: 0 },
      medal:    txTypes.MEDAL    || { count: 0, amount: 0 },
      custom:   txTypes.CUSTOM   || { count: 0, amount: 0 },
      vatFromEtcOthers:    { count: vatTxCount,                 amount: vatFromExempt                    },
      totalSI: {
        count: reportStats.si?.totalSi || 0,
        amount: reportStats.netSales || 0
      },
      voids:               { count: reportStats.voidCount    || 0, amount: reportStats.totalVoided     || 0 },
      refunds:             { count: reportStats.refundCount  || 0, amount: reportStats.totalRefunded   || 0 },
      guests:              { count: reportStats.guestCount   || 0                                          },
      averagePerTransaction: avgPerTx,
      firstSalesInvoiceNo:  reportStats.si?.minSi !== Infinity  ? reportStats.si.minSi  : '-',
      lastSalesInvoiceNo:   reportStats.si?.maxSi !== -Infinity ? reportStats.si.maxSi  : '-',
      firstRefundSeriesNo:  reportStats.refundSeriesRange?.min || '-',
      lastRefundSeriesNo:   reportStats.refundSeriesRange?.max || '-',
    },
    txTypeSummary: txTypes,
    grandTotals: {
      oldGT,
      currentTTL:  reportStats.netSales || 0,
      newGrandTTL: newGrandTTL,
    },
    rawStats: reportStats,
    ...extraData,
  };
}

export interface ZReadingOptions {
  type:           'Z' | 'Y';
  zCounter?:      string;
  resetCtr?:      string;       
  terminalId?:    string;
  termSessions?:  number;
  yTermSessions?: any[];
  readBy:         string;
  storeData:      any;
  oldGT?:         number;
  isReprint?:     boolean;
  transactionNumber?: string;
}

export function generateZOrYReadingText(
  stats:   ReportStats,
  options: ZReadingOptions,
  fiscal: any
): string {
  const {
    type,
    zCounter     = '0001',
    resetCtr     = '0000',
    terminalId   = '001',
    termSessions = 0,
    readBy,
    storeData,
    oldGT        = 0,
    isReprint    = false,
  } = options;

  const W     = 48;
  const valW  = 14;
  const lblW  = W - valW;
  const div   = divider(W) + '\n';
  const colLW = 20, colCW = 5, colAW = W - colLW - colCW - 3;

  const row = (lbl: string, val: string | number) =>
    padRight(lbl, lblW) + padLeft(typeof val === 'number' ? fmtAmt(val) : val, valW) + '\n';

  const colRow = (lbl: string, cnt: number | string, amt: number | string) =>
    padRight(lbl, colLW) +
    padLeft(String(cnt), colCW) + ' / ' +
    padLeft(typeof amt === 'number' ? fmtAmt(amt) : amt, colAW) + '\n';

  const txTypeSummary = stats.txTypeSummary     || {};
  const revByCat      = stats.revenueByCategory || {};
  const vatFromExempt = (stats.vatExemptSales   || 0) * 0.12;

  const discLines: Array<[string, number]> = [];
  if ((stats.dSums?.SRC     || 0) > 0) discLines.push(['   SC',      stats.dSums.SRC]);
  if ((stats.dSums?.PWD     || 0) > 0) discLines.push(['   PWD',     stats.dSums.PWD]);
  if ((stats.dSums?.ATHLETE || 0) > 0) discLines.push(['   NAAC',    stats.dSums.ATHLETE]);
  if ((stats.dSums?.SOLO    || 0) > 0) discLines.push(['   SOLO',    stats.dSums.SOLO]);
  if ((stats.dSums?.MEDAL   || 0) > 0) discLines.push(['   MEDAL',   stats.dSums.MEDAL]);
  if ((stats.dSums?.CUSTOM  || 0) > 0) discLines.push(['   CUSTOM',  stats.dSums.CUSTOM]);

  const totalLess      = discLines.reduce((s, [, a]) => s + a, 0) + vatFromExempt;
  const salesForTheDay = (stats.grossSales || 0) - totalLess;
  const totalColCount  = (stats.cashTxCount || 0) + (stats.nonCashTxCount || 0);
  const avgPerTx       = (stats.si?.totalSi || 0) > 0 ? stats.netSales / stats.si.totalSi : 0;

  const vatTxCount = Object.entries(txTypeSummary)
    .filter(([t]) => ['SRC', 'PWD', 'ATHLETE', 'PEZA', 'DIPLOMAT', 'SOLO', 'MEDAL', 'CUSTOM'].includes(t))
    .reduce((s, [, d]: any) => s + (d.count || 0), 0);

  const now     = new Date();
  const p2      = (n: number) => String(n).padStart(2, '0');
  const dateStr = `${p2(now.getMonth()+1)}/${p2(now.getDate())}/${now.getFullYear()}`;
  const timeStr = `${p2(now.getHours())}:${p2(now.getMinutes())}:${p2(now.getSeconds())}`;
  const dtStr   =
    `${p2(now.getMonth()+1)}/${p2(now.getDate())}/${String(now.getFullYear()).slice(-2)} ` +
    `${p2(now.getHours())}:${p2(now.getMinutes())}`;

  const shopName = storeData?.data?.name || storeData?.name || storeData?.merchant_code || '-';
  const format   =
    storeData?.receiptFormats?.find((f: any) => f.name === (type === 'Y' ? 'YRead' : 'ZRead')) ||
    storeData?.receiptFormats?.[0];

  let out = '';
  if (format?.header) out += formatHtmlToText(replaceEnvVarsInline(format.header, fiscal), W);
  else out += centerText(shopName, W) + '\n';

  out += '\n';
  const baseZTitle = `${type === 'Y' ? 'TERMINAL ACCOUNTABILITY' : 'END OF DAY'} (${type}-READING)`;
  const zTitle = isReprint ? `${baseZTitle} (REPRINT)` : baseZTitle;
  out += centerText(zTitle, W) + '\n';
  out += centerText(`DATE: ${dateStr} TIME: ${timeStr}`, W) + '\n\n';
  out += padRight('SHOP CODE :', 12) + padLeft(shopName, W - 12) + '\n';
  out += div;

  if (type === 'Z') {
    out += padRight('Z-Counter        :', 20) + padLeft(zCounter, W - 20) + '\n';
  } else {
    const trc = String(termSessions).padStart(4, '0');
    out += padRight('Terminal Read Count:', 20) + padLeft(trc,        W - 20) + '\n';
    out += padRight('Terminal No        :', 20) + padLeft(terminalId, W - 20) + '\n';
  }

  out += padRight('Transaction No   :', 20) + padLeft(options.transactionNumber || String(stats.si?.totalSi || 0), W - 20) + '\n';
  out += padRight('Printed on       :', 20) + padLeft(dtStr,  W - 20) + '\n';
  out += div;

  out += row('GROSS SALES', stats.grossSales || 0);
  out += padRight(' Less:', W) + '\n';
  discLines.forEach(([lbl, amt]) => out += row(lbl, amt));
  out += row(' VAT from SRPWD/OTHERS', vatFromExempt);
  out += '\n';
  out += row('SALES FOR THE DAY', salesForTheDay);

  out += '\n' + centerText('***Tax Details***', W) + '\n';
  out += row('VATable Sales',    stats.vatableSales   || 0);
  out += row('VAT Amount',       stats.totalTax       || 0);
  out += row('VAT Exempt Sales', stats.vatExemptSales || 0);
  out += row('Zero-rated Sales', stats.zeroRatedSales || 0);
  out += div;
  out += row('NET SALES', stats.netSales || 0);
  out += div;

  out += padRight('Collections:', colLW) + padLeft('Count', colCW) + ' / ' + padLeft('Amount', colAW) + '\n';
  out += colRow('CASH',           stats.cashTxCount    || 0, stats.totalCashSales    || 0);
  out += colRow('ONLINE PAYMENT', stats.nonCashTxCount || 0, stats.totalNonCashSales || 0);
  out += colRow('  CARD',         stats.pCounts?.CARD    || 0, stats.pSums?.CARD    || 0);
  out += colRow('  MAYA',         stats.pCounts?.MAYA    || 0, stats.pSums?.MAYA    || 0);
  out += colRow('  GCASH',        stats.pCounts?.GCASH   || 0, stats.pSums?.GCASH   || 0);
  out += colRow('  QRPH',         stats.pCounts?.QRPH    || 0, stats.pSums?.QRPH    || 0);
  out += colRow('  LANDERS',      stats.pCounts?.LANDERS || 0, stats.pSums?.LANDERS || 0);
  out += colRow('  VOUCHER',      stats.pCounts?.VOUCHER || 0, stats.pSums?.VOUCHER || 0);
  
  if ((stats.encloseCashAmount || 0) > 0 || (stats.encloseCashCount || 0) > 0) {
    out += colRow('ENCLOSE CASH', stats.encloseCashCount || 0, stats.encloseCashAmount || 0);
  }
  if ((stats.encloseNonCashAmount || 0) > 0 || (stats.encloseNonCashCount || 0) > 0) {
    out += colRow('ENCLOSE NON-CASH', stats.encloseNonCashCount || 0, stats.encloseNonCashAmount || 0);
  }

  out += div;
  const zTotalColCount = totalColCount + (stats.encloseCashCount || 0) + (stats.encloseNonCashCount || 0);
  const zTotalColAmt = (stats.netSales || 0) + (stats.encloseCashAmount || 0) + (stats.encloseNonCashAmount || 0);
  out += colRow('Total Collections', zTotalColCount, zTotalColAmt);
  out += div;

  if (type === 'Y' && Array.isArray(options.yTermSessions)) {
    let aggActualCash = 0;
    const aggDenoms: Record<string, number> = {
      '1000': 0, '500': 0, '200': 0, '100': 0, '50': 0,
      '20': 0, '10': 0, '5': 0, '1': 0, '0.25': 0,
    };

    options.yTermSessions.forEach((sess: any) => {
      aggActualCash += Number(sess.actualCash || 0);
      const bd = sess.closingBreakdown || {};
      Object.keys(aggDenoms).forEach(k => { aggDenoms[k] += Number(bd[k] || 0); });
    });

    out += padRight('TERMINAL BANK OUT:', lblW) + padLeft(fmtAmt(aggActualCash), valW) + '\n\n';
    out += 'FULL DEPOSIT DENOMINATION:\n';
    const denomW = 8, countW = 12, amtWd = W - denomW - countW;
    const denomRow = (label: string, count: number, amount: number) =>
      padLeft(label, denomW) + padLeft(String(count), countW) + padLeft(fmtAmt(amount), amtWd) + '\n';

    for (const d of [1000, 500, 200, 100, 50, 20, 10, 5]) {
      const cnt = aggDenoms[String(d)] || 0;
      out += denomRow(String(d), cnt, d * cnt);
    }
    const coinCount  = (aggDenoms['1'] || 0) + (aggDenoms['0.25'] || 0);
    const coinAmount = (aggDenoms['1'] || 0) + (aggDenoms['0.25'] || 0) * 0.25;
    out += denomRow('COINS', coinCount, coinAmount);
    out += padRight('', W - amtWd) + padLeft('-'.repeat(amtWd - 2), amtWd) + '\n';
    out += row('SUBTOTAL:', aggActualCash) + '\n';
    out += div;
  }

  out += 'REVENUE\n';
  const catEntries = Object.entries(revByCat).sort(([a], [b]) => a.localeCompare(b));
  if (catEntries.length > 0)
    catEntries.forEach(([cat, amt]) => out += row(` ${cat}`, amt as number));
  else
    out += padRight(' (no category data)', W) + '\n';
  out += row('GROSS SALES', stats.grossSales || 0);
  out += div;

  out += padRight('Audit Trail:', colLW) + padLeft('Count', colCW) + ' / ' + padLeft('Amount', colAW) + '\n';

  const TX_TYPES = ['REGULAR', 'SRC', 'PWD', 'ATHLETE', 'PEZA', 'DIPLOMAT', 'SOLO', 'MEDAL', 'CUSTOM'] as const;
  const mergedTypes = Array.from(new Set([...TX_TYPES, ...Object.keys(txTypeSummary)])).sort();

  mergedTypes.forEach(type => {
    const d = txTypeSummary[type] || { count: 0, amount: 0 };
    const displayType = type === 'SRC' ? 'SC' : type === 'ATHLETE' ? 'NAAC' : type;
    out += colRow(displayType, d.count, d.amount);
  });

  out += colRow('VAT from etc./others', vatTxCount,              vatFromExempt);
  out += colRow('Total no. of SI',
    stats.si?.totalSi || 0,
    stats.netSales || 0
  );
  
  out += colRow('Refund Count',      stats.refundCount  || 0, stats.totalRefunded || 0);
  out += colRow('Void Count',           stats.voidCount   || 0,  stats.totalVoided  || 0);
  out += colRow('Guest Count',          stats.si?.totalSi  || 0,  '-');
  out += '\n';
  if(type === 'Y') {
    out += row('AVERAGE/Transaction',      avgPerTx);
    out += row('FIRST SALES INVOICE No.',  fmtSI(stats.si?.minSi  ?? Infinity));
    out += row('LAST SALES INVOICE No.',   fmtSI(stats.si?.maxSi  ?? -Infinity));
    out += row('FIRST REFUND SERIES No.',  stats.refundSeriesRange?.min || '-');
    out += row('LAST REFUND SERIES No.',   stats.refundSeriesRange?.max || '-');
    out += '\n';
  }
  const newGrandTTL = (oldGT || 0) + (stats.netSales || 0);

  out += row('OLD GRAND TTL', oldGT);
  out += row('CURRENT TTL',   stats.netSales || 0);
  out += row('NEW GRAND TTL', newGrandTTL);
  out += row('Reset CTR', resetCtr);
  out += '\n';
  out += `READ BY: ${readBy || 'UNKNOWN'}\n`;
  out += div;

  if (format?.footer) out += formatHtmlToText(replaceEnvVarsInline(format.footer, fiscal), W);
  out += centerText('--- END OF REPORT ---', W) + '\n';

  return out;
}

export interface XReadingSession {
  staffName?:        string;
  shiftNumber?:      number | string;
  actualCash?:       number;
  cashDrops?:        Array<{ amount: number; timestamp?: string }>;
  closingBreakdown?: Record<string | number, number>;
}

export interface XReadingOptions {
  type:       'X_SHIFT' | 'TURNOVER';
  terminalId: string;
  readBy?:    string;
  storeData:  any;
  session:    XReadingSession;
  isReprint?: boolean;
  transactionNumber?: string;
}

export function generateXReadingText(
  stats:   ReportStats,
  options: XReadingOptions,
  fiscal: any
): string {

  const { type, terminalId, storeData, session, readBy, isReprint = true } = options;

  const W     = 48;
  const valW  = 14;
  const lblW  = W - valW;
  const div   = divider(W) + '\n';
  const eqDiv = '='.repeat(W) + '\n';
  const colLW = 20, colCW = 5, colAW = W - colLW - colCW - 3;

  const row = (lbl: string, val: string | number) =>
    padRight(lbl, lblW) + padLeft(typeof val === 'number' ? fmtAmt(val) : val, valW) + '\n';
  const colRow = (lbl: string, cnt: number | string, amt: number | string) =>
    padRight(lbl, colLW) +
    padLeft(String(cnt), colCW) + ' / ' +
    padLeft(typeof amt === 'number' ? fmtAmt(amt) : amt, colAW) + '\n';

  const txTypeSummary = stats.txTypeSummary     || {};
  const revByCat      = stats.revenueByCategory || {};
  const vatFromExempt = (stats.vatExemptSales   || 0) * 0.12;

  const discLines: Array<[string, number]> = [];
  if ((stats.dSums?.SRC     || 0) > 0) discLines.push(['   SC',      stats.dSums.SRC]);
  if ((stats.dSums?.PWD     || 0) > 0) discLines.push(['   PWD',     stats.dSums.PWD]);
  if ((stats.dSums?.ATHLETE || 0) > 0) discLines.push(['   NAAC',    stats.dSums.ATHLETE]);
  if ((stats.dSums?.SOLO    || 0) > 0) discLines.push(['   SOLO',    stats.dSums.SOLO]);
  if ((stats.dSums?.MEDAL   || 0) > 0) discLines.push(['   MEDAL',   stats.dSums.MEDAL]);
  if ((stats.dSums?.CUSTOM  || 0) > 0) discLines.push(['   CUSTOM',  stats.dSums.CUSTOM]);

  const totalLess      = discLines.reduce((s, [, a]) => s + a, 0) + vatFromExempt;
  const salesForTheDay = (stats.grossSales || 0) - totalLess;
  const totalColCount  = (stats.cashTxCount || 0) + (stats.nonCashTxCount || 0);
  const avgPerTx       = (stats.si?.totalSi || 0) > 0 ? stats.netSales / stats.si.totalSi : 0;
  const actualCash     = session.actualCash || 0;
  
  // Update expected cash to include the new Enclose Cash collections 
  const expectedCash   = (stats.cashFund || 0) + (stats.totalCashSales || 0) + (stats.encloseCashAmount || 0) - (stats.totalDropped || 0);
  const variance       = actualCash - expectedCash;

  const baseTitle = 'CASHIER COLLECTION (X-READING)';
  const title     = isReprint ? `${baseTitle} (REPRINT)` : baseTitle;

  const xFormat =
    storeData?.receiptFormats?.find((f: any) => f.name === 'XRead') ||
    storeData?.receiptFormats?.[0];

  const now     = new Date();
  const p2      = (n: number) => String(n).padStart(2, '0');
  const dateStr = `${p2(now.getMonth()+1)}/${p2(now.getDate())}/${now.getFullYear()}`;
  const timeStr = `${p2(now.getHours())}:${p2(now.getMinutes())}:${p2(now.getSeconds())}`;
  const shopName = storeData?.data?.name || storeData?.name || storeData?.merchant_code || '-';

  let out = '';
  if (xFormat?.header) out += formatHtmlToText(replaceEnvVarsInline(xFormat.header, fiscal), W);

  out += '\n';
  out += centerText(title, W) + '\n';
  out += centerText(`DATE: ${dateStr} TIME: ${timeStr}`, W) + '\n\n';
  out += padRight('SHOP CODE :', 12) + padLeft(shopName,                         W - 12) + '\n';
  out += padRight('TRANS NO  :', 12) + padLeft(options.transactionNumber || String(stats.si?.totalSi || 0), W - 12) + '\n';
  out += padRight('CASHIER   :', 12) + padLeft(session.staffName   || 'UNKNOWN', W - 12) + '\n';
  out += padRight('TERMINAL  :', 12) + padLeft(terminalId,                       W - 12) + '\n';
  out += div;

  out += row('GROSS SALES', stats.grossSales || 0);
  out += padRight(' Less:', W) + '\n';
  discLines.forEach(([lbl, amt]) => out += row(lbl, amt));
  out += row(' VAT from SRPWD/OTHERS', vatFromExempt);
  out += '\n';
  out += row('SALES FOR THE DAY', salesForTheDay);
  out += centerText('***TAX DETAILS***', W) + '\n';
  out += row('VATABLE SALES',    stats.vatableSales   || 0);
  out += row('VAT AMOUNT',       stats.totalTax       || 0);
  out += row('VAT EXEMPT SALES', stats.vatExemptSales || 0);
  out += row('ZERO RATED SALES', stats.zeroRatedSales || 0);
  out += div;
  out += row('NET SALES', stats.netSales || 0);
  out += div;

  out += padRight('Collections:', colLW) + padLeft('Count', colCW) + ' / ' + padLeft('Amount', colAW) + '\n';
  out += colRow('CASH',           stats.cashTxCount    || 0, stats.totalCashSales    || 0);
  out += colRow('ONLINE PAYMENT', stats.nonCashTxCount || 0, stats.totalNonCashSales || 0);
  out += colRow('  CARD',         stats.pCounts?.CARD    || 0, stats.pSums?.CARD    || 0);
  out += colRow('  MAYA',         stats.pCounts?.MAYA    || 0, stats.pSums?.MAYA    || 0);
  out += colRow('  GCASH',        stats.pCounts?.GCASH   || 0, stats.pSums?.GCASH   || 0);
  out += colRow('  QRPH',         stats.pCounts?.QRPH    || 0, stats.pSums?.QRPH    || 0);
  out += colRow('  LANDERS',      stats.pCounts?.LANDERS || 0, stats.pSums?.LANDERS || 0);
  out += colRow('  VOUCHER',      stats.pCounts?.VOUCHER || 0, stats.pSums?.VOUCHER || 0);
  
  if ((stats.encloseCashAmount || 0) > 0 || (stats.encloseCashCount || 0) > 0) {
    out += colRow('ENCLOSE CASH', stats.encloseCashCount || 0, stats.encloseCashAmount || 0);
  }
  if ((stats.encloseNonCashAmount || 0) > 0 || (stats.encloseNonCashCount || 0) > 0) {
    out += colRow('ENCLOSE NON-CASH', stats.encloseNonCashCount || 0, stats.encloseNonCashAmount || 0);
  }

  out += div;
  const xTotalColCount = totalColCount + (stats.encloseCashCount || 0) + (stats.encloseNonCashCount || 0);
  const xTotalColAmt = (stats.netSales || 0) + (stats.encloseCashAmount || 0) + (stats.encloseNonCashAmount || 0);
  out += colRow('TOTAL COLLECTIONS', xTotalColCount, xTotalColAmt);
  out += div;

  out += padRight('CASHIER BANK OUT:', lblW) + padLeft(fmtAmt(actualCash), valW) + '\n';
  const denomW = 8, countW = 12, amtWd = W - denomW - countW;
  const denomRow = (label: string, count: number, amount: number) =>
    padLeft(label, denomW) + padLeft(String(count), countW) + padLeft(fmtAmt(amount), amtWd) + '\n';

  const denominations = stats.denominations || {};
  for (const d of [1000, 500, 200, 100, 50, 20, 10, 5]) {
    const cnt = (denominations[d] || 0) as number;
    out += denomRow(String(d), cnt, d * cnt);
  }
  const coinCount  = ((denominations[1] || 0) as number) + ((denominations[0.25] || 0) as number);
  const coinAmount = ((denominations[1] || 0) as number) + ((denominations[0.25] || 0) as number) * 0.25;
  out += denomRow('COINS', coinCount, coinAmount);
  out += padRight('', W - amtWd) + padLeft('-'.repeat(amtWd - 2), amtWd) + '\n';
  out += row('SUBTOTAL:', actualCash) + '\n';

  out += padRight('LESS: CHANGE FUND', lblW) + padLeft(fmtAmt(stats.cashFund || 0), valW) + '\n';
  out += div;

  const overShortLabel = variance >= 0 ? 'CASH OVER' : 'CASH (SHORT)';
  const overShortVal   = variance >= 0
    ? fmtAmt(variance)
    : `-${fmtAmt(Math.abs(variance))}`;
  out += padRight(overShortLabel, lblW) + padLeft(overShortVal, valW) + '\n\n';

  out += 'REVENUE:\n';
  const catEntries = Object.entries(revByCat).sort(([a], [b]) => a.localeCompare(b));
  if (catEntries.length > 0)
    catEntries.forEach(([cat, amt]) => out += row(`    ${cat}`, amt as number));
  else
    out += padRight('    (no category data)', W) + '\n';
  out += row('GROSS SALES', stats.grossSales || 0);
  out += div;

  out += padRight('AUDIT TRAIL:', colLW) + padLeft('Count', colCW) + ' / ' + padLeft('Amount', colAW) + '\n';

  const TX_TYPES = ['REGULAR', 'SRC', 'PWD', 'ATHLETE', 'PEZA', 'DIPLOMAT', 'SOLO', 'MEDAL', 'CUSTOM'] as const;
  const mergedTypes = Array.from(new Set([...TX_TYPES, ...Object.keys(txTypeSummary)])).sort();

  mergedTypes.forEach(type => {
    const d = txTypeSummary[type] || { count: 0, amount: 0 };
    const displayType = type === 'SRC' ? 'SC' : type === 'ATHLETE' ? 'NAAC' : type;
    out += colRow(displayType, d.count, d.amount);
  });

  out += colRow('Total no. of SI',
    stats.si?.totalSi || 0,
    stats.netSales || 0
  );
  out += colRow('REFUND TXN',      stats.refundCount  || 0, stats.totalRefunded || 0);
  out += colRow('VOID COUNT',      stats.voidCount    || 0, stats.totalVoided   || 0);
  out += colRow('GUEST COUNT',     stats.si?.totalSi   || 0, '-');
  out += '\n';
  out += row('AVERAGE/TRANSACTIONS',    avgPerTx);
  out += row('FIRST SALES INVOICE No.', fmtSI(stats.si?.minSi  ?? Infinity));
  out += row('LAST SALES INVOICE No.',  fmtSI(stats.si?.maxSi  ?? -Infinity));
  out += row('FIRST REFUND SERIES No.', stats.refundSeriesRange?.min || '-');
  out += row('LAST REFUND SERIES No.',  stats.refundSeriesRange?.max || '-');
  out += eqDiv;

  out += 'BREAKDOWN OF CASH COUNT PREPARED BY:\n\n\n';
  out += centerText('________________________', W) + '\n';
  out += centerText('COUNTER CASHIER / EMPLOYEE NUMBER', W) + '\n';
  out += eqDiv;

  out += 'CASH SALES ACCEPTED RECEIVED AND DEPOSIT\nTO THE VAULT BY:\n\n\n';
  out += centerText('________________________', W) + '\n';
  out += centerText('STAFF ON DUTY / COUNTER CASHIER', W) + '\n';
  out += centerText('(signature over printed name)', W) + '\n';
  out += eqDiv;

  out += `READ BY: ${session.staffName || readBy || 'UNKNOWN'}\n`;
  if (xFormat?.footer) out += formatHtmlToText(replaceEnvVarsInline(xFormat.footer, fiscal), W);
  out += centerText('--- END OF REPORT ---', W) + '\n';

  return out;
}

export interface EShiftOptions {
  terminalId:    string;
  readBy:        string;
  storeData:     any;
  oldGT:         number;
  denominations: Record<number, number>;
  isReprint?:    boolean;
  transactionNumber?: string;
  session: {
    staffName?:   string;
    shiftNumber?: number | string;
    cashDrops?:   Array<{ amount: number; timestamp?: string }>;
  };
}

export function generateEShiftText(
  stats:   ReportStats,
  options: EShiftOptions,
  fiscal: any
): string {
  const { terminalId, readBy, storeData, oldGT, denominations, session, isReprint = false } = options;

  const W      = 48;
  const denomW = 8, countW = 12, amtW = W - denomW - countW;
  const valW   = 14, lblW = W - valW;
  const div    = divider(W) + '\n';
  const eqDiv  = '='.repeat(W) + '\n';

  const denomRow = (label: string, count: number, amount: number) =>
    padLeft(label, denomW) + padLeft(String(count), countW) + padLeft(fmtAmt(amount), amtW) + '\n';
  const amtLine  = () =>
    padRight('', W - amtW) + padLeft('-'.repeat(amtW - 2), amtW) + '\n';
  const row = (lbl: string, val: string | number) =>
    padRight(lbl, lblW) + padLeft(typeof val === 'number' ? fmtAmt(val) : val, valW) + '\n';

  const xFormat =
    storeData?.receiptFormats?.find((f: any) => f.name === 'XRead') ||
    storeData?.receiptFormats?.[0];

  const now     = new Date();
  const p2      = (n: number) => String(n).padStart(2, '0');
  const dateStr = `${p2(now.getMonth()+1)}/${p2(now.getDate())}/${now.getFullYear()}`;
  const timeStr = `${p2(now.getHours())}:${p2(now.getMinutes())}:${p2(now.getSeconds())}`;
  const shopName = storeData?.data?.name || storeData?.name || storeData?.merchant_code || '-';
  const shopCode = storeData?.merchant_code || storeData?.store_id || '-';
  const transNo = options.transactionNumber || String(stats.si?.totalSi || 0);

  let out = '';
  if (xFormat?.header) out += formatHtmlToText(replaceEnvVarsInline(xFormat.header, fiscal), W);

  out += '\n';
  const baseETitle = 'E-SHIFT CASH REPORT';
  const eTitle = isReprint ? `${baseETitle} (REPRINT)` : baseETitle;
  out += centerText(eTitle, W) + '\n';
  out += centerText(`DATE: ${dateStr} TIME: ${timeStr}`, W) + '\n\n';

  const halfW = Math.floor(W / 2);
  out += padRight('SHOP NAME:', 12) + padLeft(shopName, W - 12) + '\n';
  out += padRight('SHOP CODE:', 12) + padLeft(shopCode, W - 12) + '\n';
  out += padRight('TRANS NO :', 12) + padLeft(transNo,  W - 12) + '\n';
  out += padRight('E-SCR NO : 0', halfW)                            + padLeft(`TERMINAL: ${terminalId}`,         W - halfW) + '\n';
  out += padRight(`CASHIER  : ${session.staffName || '-'}`, halfW)  + padLeft(`SHIFT   : ${session.shiftNumber || '-'}`, W - halfW) + '\n';
  out += div;

  out += 'FULL DEPOSIT DENOMINATION:\n';
  let fullDepositSubtotal = 0;
  for (const d of [1000, 500, 200, 100, 50, 20, 10, 5]) {
    const cnt = denominations[d] || 0;
    const amt = d * cnt;
    fullDepositSubtotal += amt;
    out += denomRow(String(d), cnt, amt);
  }
  const coinCount  = (denominations[1] || 0) + (denominations[0.25] || 0);
  const coinAmount = (denominations[1] || 0) + (denominations[0.25] || 0) * 0.25;
  fullDepositSubtotal += coinAmount;
  out += denomRow('COINS', coinCount, coinAmount);
  out += amtLine();
  out += row('SUBTOTAL:', fullDepositSubtotal);

  const cashDrops    = session.cashDrops || [];
  const totalDropped = cashDrops.reduce((sum: number, d: any) => sum + parseFloat(String(d.amount || 0)), 0);

  if (cashDrops.length === 0) {
    out += centerText('** No Partial Deposit **', W) + '\n';
  } else {
    cashDrops.forEach((drop: any) => {
      const dropAmt  = parseFloat(String(drop.amount || 0));
      const dropTime = drop.timestamp
        ? new Date(drop.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        : '-';
      out += row(`  Cash Drop ${dropTime}`, dropAmt);
    });
  }
  out += amtLine();
  out += row('SUBTOTAL PARTIAL DEPOSIT:', totalDropped);

  const totalCashAccounted = fullDepositSubtotal + totalDropped;
  out += row('TOTAL CASH ACCOUNTED:', totalCashAccounted);
  out += '\n';
  out += row('TOTAL CASH COLLECTION:', totalCashAccounted);
  out += '\n';

  out += 'ADD: NON CASH TRANS:\n';
  const methods = ['CARD', 'MAYA', 'GCASH', 'QRPH', 'LANDERS', 'VOUCHER'] as const;
  for (const m of methods) {
    out += row(`  ${m}`, stats.pSums?.[m] || 0);
  }
  out += amtLine();
  out += row('TOTAL NON CASH',    stats.totalNonCashSales || 0);

  if ((stats.encloseCashAmount || 0) > 0 || (stats.encloseNonCashAmount || 0) > 0) {
    out += '\nADD: ENCLOSE TRANS:\n';
    if ((stats.encloseCashAmount || 0) > 0) out += row('  ENCLOSE CASH', stats.encloseCashAmount || 0);
    if ((stats.encloseNonCashAmount || 0) > 0) out += row('  ENCLOSE NON-CASH', stats.encloseNonCashAmount || 0);
    out += amtLine();
    out += row('TOTAL ENCLOSE', (stats.encloseCashAmount || 0) + (stats.encloseNonCashAmount || 0));
  }

  out += row('LESS CHANGE FUND:', stats.cashFund          || 0);

  const totalSalesCollection = totalCashAccounted + (stats.totalNonCashSales || 0) + (stats.encloseCashAmount || 0) + (stats.encloseNonCashAmount || 0) - (stats.cashFund || 0);
  out += row('TOTAL SALES COLLECTION:', totalSalesCollection);
  out += '\n';

  const newGT               = oldGT + (stats.netSales || 0);
  const salesAccountability = stats.netSales || 0; // The actual sales made during this shift
  out += row('TOTAL ACCOUNTABILITY:', '');
  out += row('NEW GT:', newGT);
  out += row('OLD GT:', oldGT);
  out += amtLine();
  out += row('SALES ACCOUNTABILITY:', salesAccountability);
  out += '\n';
  out += row('TOTAL SALES ACCOUNTABILITY:', salesAccountability);
  out += '\n';

  const cashOverShort = totalSalesCollection - salesAccountability;
  const overShortLabel = cashOverShort >= 0 ? 'CASH OVER' : 'CASH (SHORT)';
  const overShortVal   = cashOverShort >= 0
    ? fmtAmt(cashOverShort)
    : `-${fmtAmt(Math.abs(cashOverShort))}`;
  out += padRight(overShortLabel, lblW) + padLeft(overShortVal, valW) + '\n\n';

  out += eqDiv;

  out += row('SETTLED:', '______________');
  out += row('DEPOSIT:', '______________');
  out += eqDiv;

  const sigBlock = (title: string, name: string, note: string) => {
    let s = centerText(title, W) + '\n\n\n';
    s += centerText('__________________________', W) + '\n';
    s += centerText(name, W) + '\n';
    s += centerText(note, W) + '\n';
    return s + eqDiv;
  };

  out += sigBlock(
    'BREAKDOWN OF CASH COUNT PREPARED BY AND TURNED OVER BY:',
    'COUNTER CASHIER', '(Signature Over Printed Name)',
  );
  out += sigBlock(
    `${overShortLabel} ACKNOWLEDGED BY:`,
    'CASHIER / STAFF ON DUTY', '(Signature Over Printed Name)',
  );
  out += sigBlock(
    'CASH SALES ACCOUNTED, RECEIVED, AND DEPOSITED TO THE VAULT BY:',
    'STAFF ONLY', '(Signature Over Printed Name)',
  );

  out += centerText('CASH SALES DEPOSITED TO THE VAULT:', W) + '\n';
  out += centerText('AS WITNESSED BY:', W) + '\n\n\n';
  out += padRight('    ____________', halfW) + padLeft('_____________', W - halfW) + '\n';
  out += padRight('    STAFF ON DUTY', halfW) + padLeft('QUALIFIED WITNESS', W - halfW) + '\n';
  out += centerText('(Signature Over Printed Name)', W) + '\n';
  out += eqDiv;

  out += `READ BY : ${readBy || session.staffName || 'UNKNOWN'}\n`;
  out += centerText('--- END of REPORT ---', W) + '\n';

  return out;
}