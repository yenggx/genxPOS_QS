// src/libs/DetailedSalesSummaryGenerator.ts

export interface DetailedSalesRow {
  DATE: string;
  TERMINAL_NO: string;
  TRANSACTION_NO: string;
  REFUND_SERIES: string;
  GROSS: number | string;
  OTHER_CHARGES: number | string;
  DISCOUNTS: number | string;
  VAT_AMOUNT: number | string;
  VAT_EXEMPT_SALES: number | string;
  NET_SALES: number | string;
  STATUS: string;
}

const safePesos = (v: number) => (v || 0) / 100;
const formatAmt = (v: number) => parseFloat((v || 0).toFixed(2));

export function buildDetailedSalesSummary(
  transactions: Record<string, any>[],
  closedSessions: Record<string, any>[]
): DetailedSalesRow[] {
  const allRows: DetailedSalesRow[] = [];
  
  const sessionMap = new Map();
  closedSessions.forEach((s: any) => {
    sessionMap.set(s.sessionId, s);
  });

  // Identify all unique terminals
  const uniqueTids = new Set<string>();
  transactions.forEach((tx: any) => {
    uniqueTids.add(sessionMap.get(tx.sessionId)?.openedAtTerminal || tx.workstationId || tx.KioskNo || '001');
  });
  
  const terminals = Array.from(uniqueTids).sort();

  for (const terminal of terminals) {
    const terminalTx = transactions.filter(tx => {
      const tId = sessionMap.get(tx.sessionId)?.openedAtTerminal || tx.workstationId || tx.KioskNo || '001';
      return tId === terminal;
    });

    const salesRows: DetailedSalesRow[] = [];
    const refundRows: DetailedSalesRow[] = [];

    let tGross = 0;
    let tOther = 0;
    let tDisc = 0;
    let tVat = 0;
    let tExempt = 0;
    let tNet = 0;

    for (const tx of terminalTx) {
      const isVoid = tx.status === 'voided' || tx.orderState === 'VOIDED';
      if (isVoid) continue; // Skip voids completely per instructions

      const isRefund = tx.status === 'refunded' || tx.orderState === 'REFUNDED';
      
      const txDate = new Date(tx.createdAt || tx.date || Date.now());
      const p2 = (n: number) => String(n).padStart(2, '0');
      const dateStr = `${p2(txDate.getMonth() + 1)}/${p2(txDate.getDate())}/${txDate.getFullYear()}`;
      
      let gross = 0;
      let otherCharges = 0;

      for (const item of (tx.items || tx.cart || [])) {
        const qty = item.quantity || item.qty || 1;
        let itemGross = 0;
        let useUdf = false;

        // Apply UDF-1 if this specific item was targeted for the SC/PWD discount
        const hasItemDiscount = item.itemDiscount && Number(item.itemDiscount) > 0;

        if (hasItemDiscount && item.udfs && item.udfs['UDF-1'] && item.udfs['UDF-1'].value) {
          const udfVal = Number(item.udfs['UDF-1'].value);
          if (!isNaN(udfVal)) {
            itemGross = udfVal * qty;
            useUdf = true;
          }
        }

        // Standard gross calculation (base price + modifiers)
        if (!useUdf) {
          itemGross = safePesos(item.price || 0) * qty;
          for (const mod of (item.modifiers || item.selectedModifiers || [])) {
            let modPesos = 0;
            if (mod.price && mod.price >= 10000 && mod.price % 100 === 0) {
              modPesos = mod.price / 10000;
            } else {
              modPesos = safePesos(mod.price || 0);
            }
            const modQty = mod.quantity || mod.qty || 1;
            itemGross += modPesos * modQty; // Add modifiers directly to gross
          }
        }

        gross += itemGross;
      }

      const disc = safePesos(tx.discountAmount || 0);
      const vat = safePesos(tx.price?.VatAmount || tx.price?.tax || 0);
      const exempt = safePesos(tx.price?.VatExSales || 0);
      
      // Fix: Net sales = Gross - (Disc + vat)
      const net = gross - (disc + vat);

      // Top part: Record it as a sale (Even if it was later refunded)
      salesRows.push({
        DATE: dateStr,
        TERMINAL_NO: terminal,
        TRANSACTION_NO: tx.salesNumber || tx.transactionNumber || tx.OrderNo || '-',
        REFUND_SERIES: '',
        GROSS: formatAmt(gross),
        OTHER_CHARGES: formatAmt(otherCharges),
        DISCOUNTS: formatAmt(disc),
        VAT_AMOUNT: formatAmt(vat),
        VAT_EXEMPT_SALES: formatAmt(exempt),
        NET_SALES: formatAmt(net),
        STATUS: 'SALE'
      });

      tGross += gross;
      tOther += otherCharges;
      tDisc += disc;
      tVat += vat;
      tExempt += exempt;
      tNet += net;

      // Deduction part: If it was refunded, record it as a deduction (negative)
      if (isRefund) {
        refundRows.push({
          DATE: dateStr,
          TERMINAL_NO: terminal,
          TRANSACTION_NO: tx.salesNumber || tx.transactionNumber || tx.OrderNo || '-',
          REFUND_SERIES: tx.refundSeriesNo || '-',
          GROSS: formatAmt(-gross),
          OTHER_CHARGES: formatAmt(-otherCharges),
          DISCOUNTS: formatAmt(-disc),
          VAT_AMOUNT: formatAmt(-vat),
          VAT_EXEMPT_SALES: formatAmt(-exempt),
          NET_SALES: formatAmt(-net),
          STATUS: 'REFUNDED'
        });

        // Deduct from terminal net total
        tGross -= gross;
        tOther -= otherCharges;
        tDisc -= disc;
        tVat -= vat;
        tExempt -= exempt;
        tNet -= net;
      }
    }

    // Combine terminal rows
    allRows.push(...salesRows);
    allRows.push(...refundRows);

    // Append Net Row at the lowest line
    allRows.push({
      DATE: '',
      TERMINAL_NO: terminal,
      TRANSACTION_NO: 'NET',
      REFUND_SERIES: '',
      GROSS: formatAmt(tGross),
      OTHER_CHARGES: formatAmt(tOther),
      DISCOUNTS: formatAmt(tDisc),
      VAT_AMOUNT: formatAmt(tVat),
      VAT_EXEMPT_SALES: formatAmt(tExempt),
      NET_SALES: formatAmt(tNet),
      STATUS: ''
    });

    // Add empty row separator for the next terminal
    allRows.push({
      DATE: '', TERMINAL_NO: '', TRANSACTION_NO: '', REFUND_SERIES: '',
      GROSS: '', OTHER_CHARGES: '', DISCOUNTS: '', VAT_AMOUNT: '',
      VAT_EXEMPT_SALES: '', NET_SALES: '', STATUS: ''
    });
  }

  // Remove the trailing empty row at the very end
  if (allRows.length > 0 && allRows[allRows.length - 1].TERMINAL_NO === '') {
    allRows.pop();
  }

  return allRows;
}

export function detailedSalesSummaryToCsv(rows: DetailedSalesRow[]): string {
  const COLUMNS: (keyof DetailedSalesRow)[] = [
    'DATE', 'TERMINAL_NO', 'TRANSACTION_NO', 'REFUND_SERIES', 'GROSS', 
    'OTHER_CHARGES', 'DISCOUNTS', 'VAT_AMOUNT', 'VAT_EXEMPT_SALES', 'NET_SALES', 'STATUS'
  ];

  const headerRow = COLUMNS.join(',');
  if (rows.length === 0) return headerRow;

  const escape = (v: string | number) => {
    const s = String(v ?? '');
    return s.includes(',') || s.includes('"') || s.includes('\n')
      ? `"${s.replace(/"/g, '""')}"`
      : s;
  };

  const dataRows = rows.map(r => COLUMNS.map(c => escape(r[c])).join(',')).join('\r\n');

  return `${headerRow}\r\n${dataRows}`;
}