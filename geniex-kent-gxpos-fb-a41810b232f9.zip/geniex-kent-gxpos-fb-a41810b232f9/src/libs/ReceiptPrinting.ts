// this is the path of this file: src/libs/ReceiptPrinting.ts
import { StoreData, ReceiptFormat } from "../../app/(pos)/settings/page";
import { sileo } from "sileo";
import { getWorkstationId } from "../lib/workstation";
import { getNextTransactionNumber } from "../api/transactionNumbers";

/**
 * Utility for formatting and building receipts (Regular & Cash Drops)
 */

export interface PrintReceiptOptions {
  storeData: StoreData;
  receiptFormat: ReceiptFormat;
  data: Record<string, any>;
  fiscal: any;
}

export interface CashDropOptions {
  storeData: StoreData;
  cashierName: string;
  amount: number;
  date?: string;
  width?: number;
  breakdown?: Record<number, number>;
  receiptFormat?: any;
  fiscal?: any;
  transactionNumber?: string;
  controlNumber?: string;
}

function padRight(str: string, len: number) {
  return (str + ' '.repeat(len)).slice(0, len);
}
function padLeft(str: string, len: number) {
  return (' '.repeat(len) + str).slice(-len);
}

function centerText(str: string, len: number) {
  const pad = Math.max(0, len - str.length);
  const padL = Math.floor(pad / 2);
  return ' '.repeat(padL) + str + ' '.repeat(pad - padL);
}

function divider(width = 48) {
  return '-'.repeat(width);
}

function formatAmount(amount: number) {
  return amount.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatHtmlToTextLines(htmlStr: string, width: number): string {
  if (!htmlStr) return '';
  let text = htmlStr.replace(/<br\s*[\/]?>/gi, '\n');
  text = text.replace(/<\/p>|<\/div>|<\/h[1-6]>/gi, '\n');
  text = text.replace(/<[^>]*>?/gm, '');
  text = text.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');

  const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0);
  
  let out = '';
  for (const line of lines) {
    if (line.length > width) {
      out += centerText(line.substring(0, width), width) + '\n';
      out += centerText(line.substring(width, width * 2), width) + '\n';
    } else {
      out += centerText(line, width) + '\n';
    }
  }
  return out;
}

function getDiscountLineLabel(transactionType: string): string {
  switch (transactionType) {
    case 'SC':       return 'SC 20% DISCOUNT';
    case 'PWD':      return 'PWD 20% DISCOUNT'
    case 'ATHLETE':  return '20% NAAC DISC';
    case 'SOLO':     return 'SOLO PARENT DISC';
    case 'MEDAL':    return '20% MEDAL OF HONOR DISC';
    case 'DIPLOMAT': return 'DIPLOMAT EXT';
    case 'PEZA':     return 'PEZA EXT';
    case 'CUSTOM':   return 'CUSTOM DISC';
    default:         return 'DISCOUNT';
  }
}

const replaceEnvVarsInline = (str: string, fiscal: any) => str
  .replace(/{{process\.env\.NEXT_PUBLIC_VAT}}/g,        fiscal.vatNumber        || '')
  .replace(/{{process\.env\.NEXT_PUBLIC_TIN}}/g,        fiscal.tinNumber        || '')
  .replace(/{{process\.env\.NEXT_PUBLIC_MIN}}/g,        fiscal.minNumber        || '')
  .replace(/{{process\.env\.NEXT_PUBLIC_PTU}}/g,        fiscal.ptuNumber        || '')
  .replace(/{{process\.env\.NEXT_PUBLIC_SERIALNO}}/g,   fiscal.snNumber   || '');

/**
 * Sorts items so discounted/deducted items appear first.
 */
function sortItemsDiscountFirst(items: any[], txType: string): any[] {
  const discounted: any[] = [];
  const rest: any[] = [];
  for (const item of items) {
    if (item.itemDiscount != undefined && item.itemDiscount > 0) {
      discounted.push(item);
    } else {
      rest.push(item);
    }
  }
  return [...discounted, ...rest];
}

// ==========================================
// 1. REGULAR TRANSACTION RECEIPT BUILDERS
// ==========================================

export function buildReceiptHtml({ storeData, receiptFormat, data, fiscal }: PrintReceiptOptions): string {
  let header = receiptFormat.header || '';
  let footer = receiptFormat.footer || '';

  header = replaceEnvVarsInline(header, fiscal);
  footer = replaceEnvVarsInline(footer, fiscal);
  
  const style = `
    <style>
      * { margin: 0; padding: 0; box-sizing: border-box; }
      html { width: 80mm; height: 100%; }
      body { font-family: 'Courier New', Courier, monospace; background: #fff; width: 80mm; font-size: 11px; color: #000; line-height: 1.35; }
      @page { size: 80mm auto; margin: 0; }
      @media print { html, body { margin: 0; padding: 0; width: 80mm; background: white; } .receipt-container { margin: 0; padding: 0; width: 80mm; } }
      .receipt-container { width: 80mm; margin: 0; padding: 2mm 3mm; }
      .receipt-header { text-align: center; margin-bottom: 3px; font-size: 11px; line-height: 1.3; }
      .receipt-footer { text-align: center; margin-top: 3px; font-size: 11px; line-height: 1.3; }
      .divider { border: none; border-top: 1px dashed #000; margin: 6px 0; }
      .row { display: flex; justify-content: space-between; width: 100%; }
      .bold { font-weight: bold; }
      .center { text-align: center; }
      .item-name { margin: 3px 0 0 0; font-size: 11px; text-transform: uppercase; }
      .val-col { text-align: right; width: 75px; flex-shrink: 0; }
      .item-qty-row { display: flex; justify-content: space-between; padding-left: 12px; font-size: 11px; }
      .summary-grid-row { display: flex; justify-content: flex-end; margin: 1px 0; font-size: 12px; }
      .summary-grid-row .label-col { text-align: right; padding-right: 12px; }
      .customer-row { display: flex; margin: 1px 0; font-size: 11px; }
      .customer-label { width: 75px; }
    </style>
  `;

  const headerHtml = header ? `<div class="receipt-header">${header}</div>` : storeData?.name ? `<div class="receipt-header">${storeData.name}</div>` : '';
  const footerHtml = footer ? `<div class="receipt-footer">${footer}</div>` : '';

  const now = (data.orderTime || data.created_at) ? new Date(data.orderTime || data.created_at) : new Date();
  const pad2 = (n: number) => String(n).padStart(2, '0');
  const dateStr = `${pad2(now.getMonth() + 1)}/${pad2(now.getDate())}/${String(now.getFullYear()).slice(-2)} ${pad2(now.getHours())}:${pad2(now.getMinutes())}`;

  // Reverse sign multiplier for voids and refunds
  const isReversed = data.isVoided || data.isRefunded || data.transactionType === 'VOID' || data.transactionType === 'REFUND' || data.orderState === 'VOIDED' || data.orderState === 'REFUNDED' || data.status === 'voided' || data.status === 'refunded';
  const mult = isReversed ? -1 : 1;

  const salesNo     = data.salesNumber || '';
  const txnNo       = data.transactionNumber || '';
  const shiftNo     = data.shiftNo || data.shiftNumber || data.ShiftNo || '-';
  const refundNo    = data.refundSeriesNo || data.refundSeriesNumber || '';
  const cashierName = data.name || data.staffID || data.staffId || '-';
  const terminalNo  = data.terminalNo || data.KioskNo || data.terminalId || getWorkstationId() || '1';
  const orderType   = (data.orderType || 'DINE-IN').toUpperCase();
  const orderNumber = data.orderNumber || data.OrderNo || salesNo || txnNo || '';
  
  const total        = (data.total || data.grandTotal || 0) * mult || 0;
  const vatableSales = (data.vatableSales !== undefined ? data.vatableSales : (data.subtotal || 0)) * mult || 0;
  const vatAmount    = (data.tax || 0) * mult || 0;
  const vatExempt    = (data.vatExemptSales || 0) * mult || 0;
  const zeroRated    = (data.zeroRatedSales || 0) * mult || 0;
  const origDiscountAmount = data.discountAmount || 0;
  const discountAmount = origDiscountAmount * mult || 0;
  const txType       = data.transactionType || 'REGULAR';

  // ── Sort: discounted items first, everything else after ──
  const rawItems = data.items || data.cart || [];
  const itemsList = sortItemsDiscountFirst(rawItems, txType);

  let itemsHtml = '';
  let itemCount = 0;
  let grossSubTotal = 0;
  let aggregatedDiscountedGross = 0;

  for (const item of itemsList) {
    const qty       = item.quantity || item.qty || 1;
    const basePrice = ((item.price || 0) > 1000 ? (item.price / 100) : (item.price || 0)) * mult || 0;
    
    itemCount      += qty;

    let modsTotalPrice = 0;
    const mods = Array.isArray(item.modifiers) ? item.modifiers : Object.values(item.modifiers || {});
    for (const m of mods as any[]) {
      const mPrice = ((m.price || 0) / 100) * mult || 0;
      const mQty   = m.qty || m.quantity || 1;
      modsTotalPrice += mPrice * (mQty * qty);
    }
    const lineGrossAmount = (basePrice * qty) + modsTotalPrice;
    grossSubTotal += lineGrossAmount;   

    const origItemDiscount = item.itemDiscount || 0;
    const itemDiscount = origItemDiscount * mult || 0;

    if (origItemDiscount > 0 && ['SC', 'SRC', 'PWD', 'REGULAR', 'CUSTOM'].includes(txType)) {
      aggregatedDiscountedGross += lineGrossAmount;
    }

    // Apply (X) or (V) based on whether VAT is removed via discount
    let vatIndicator = '';
    if (txType === 'REGULAR') {
      if (item.taxable !== false) vatIndicator = ' (V)';
    } else {
      if (
        (origItemDiscount > 0 || txType === 'DIPLOMAT' || txType === 'PEZA') &&
        txType !== 'ATHLETE' && txType !== 'MEDAL' && txType !== 'SOLO' 
      ) {
        vatIndicator = ' (X)';
      } else {
        vatIndicator = ' (V)';
      }
    }

    const itemName  = (item.itemName || item.name || '') + vatIndicator;

    itemsHtml += `<div class="item-name">${itemName}</div>`;
    itemsHtml += `<div class="item-qty-row"><span class="label-col">${qty} @ ${formatAmount(basePrice)}</span><span class="val-col">${formatAmount(basePrice * qty)}</span></div>`;

    for (const m of mods as any[]) {
      const mPrice = ((m.price || 0) / 100) * mult || 0;
      const mQty   = m.qty || m.quantity || 1;
      const displayQty = mQty * qty;   // ← multiply by parent qty
      if (Math.abs(mPrice) > 0) {
        itemsHtml += `<div class="item-qty-row" style="padding-left:16px;"><span class="label-col">+ ${displayQty}x ${m.name}</span><span class="val-col">${formatAmount(mPrice * displayQty)}</span></div>`;
      } else {
        itemsHtml += `<div style="padding-left:16px;font-size:11px;">+ ${displayQty}x ${m.name}</div>`;
      }
    }

    if (origItemDiscount > 0) {
      const dashed = `style="border-top: 1px dashed #000; margin-top: 2px; padding-top: 2px;"`;

      if (['SC', 'SRC', 'PWD', 'REGULAR', 'CUSTOM', 'ATHLETE', 'SOLO', 'MEDAL', 'PEZA', 'DIPLOMAT'].includes(txType)) {
        const isLastDiscountedItem = !itemsList.slice(itemsList.indexOf(item) + 1).some((i:any) => (i.itemDiscount || 0) > 0);

        if (isLastDiscountedItem && ['SC', 'SRC', 'PWD', 'REGULAR', 'CUSTOM'].includes(txType)) {
          if (txType === 'REGULAR' || txType === 'CUSTOM') {
             const discLabel = txType === 'CUSTOM' ? 'CUSTOM DISC' : (data.discountInfo?.label ? data.discountInfo.label.substring(0, 15) : 'DISCOUNT');
             const discLess = (data.discountAmount || 0) * mult;
             const netSubTotal = (aggregatedDiscountedGross * mult) - discLess;
             itemsHtml += `<div class="item-qty-row"><span class="label-col">Less: ${discLabel}</span><span class="val-col">${formatAmount(discLess)}</span></div>`;
             itemsHtml += `<div class="item-qty-row"><span class="label-col"></span><span class="val-col" ${dashed}></span></div>`;
             itemsHtml += `<div class="item-qty-row"><span class="label-col">Sub-Total :</span><span class="val-col">${formatAmount(netSubTotal)}</span></div>`;
          } else {
             const discLabel = getDiscountLineLabel(txType);
             const vatLess = (aggregatedDiscountedGross - (aggregatedDiscountedGross / 1.12)) * mult;
             const discLess = ((aggregatedDiscountedGross / 1.12) * 0.20) * mult;
             const netSubTotal = ((aggregatedDiscountedGross / 1.12) * 0.80) * mult;
             itemsHtml += `<div class="item-qty-row"><span class="label-col">Less: 12% VAT</span><span class="val-col">${formatAmount(vatLess)}</span></div>`;
             itemsHtml += `<div class="item-qty-row"><span class="label-col">Less: ${discLabel}</span><span class="val-col">${formatAmount(discLess)}</span></div>`;
             itemsHtml += `<div class="item-qty-row"><span class="label-col"></span><span class="val-col" ${dashed}></span></div>`;
             itemsHtml += `<div class="item-qty-row"><span class="label-col">Sub-Total :</span><span class="val-col">${formatAmount(netSubTotal)}</span></div>`;
          }
        }
      } else {
         const discLabel = getDiscountLineLabel(txType);
         const subTotal = (lineGrossAmount * mult) - itemDiscount;
         itemsHtml += `<div class="item-qty-row"><span class="label-col">Less: ${discLabel}</span><span class="val-col">${formatAmount(itemDiscount)}</span></div>`;
         itemsHtml += `<div class="item-qty-row"><span class="label-col"></span><span class="val-col" ${dashed}></span></div>`;
         itemsHtml += `<div class="item-qty-row"><span class="label-col">Sub-Total :</span><span class="val-col">${formatAmount(subTotal)}</span></div>`;
      }
    }
  }

  let pezaDiplomatHtml = '';
  if (txType === 'PEZA' || txType === 'DIPLOMAT') {
    const vatRemoved = grossSubTotal - (grossSubTotal / 1.12);
    const extLabel   = txType === 'PEZA' ? 'PEZA' : 'DIPLOMAT';
    pezaDiplomatHtml = `
      <div class="summary-grid-row" style="border-top:1px dashed #000;margin-top:4px;padding-top:2px;">
        <div class="label-col">Sub-Total :</div><div class="val-col">${formatAmount(grossSubTotal)}</div>
      </div>
      <div class="summary-grid-row">
        <div class="label-col">${extLabel} Less: 12% VAT :</div><div class="val-col">${formatAmount(vatRemoved)}</div>
      </div>`;
  }

  let discountGridHtml = '';
  if (txType === 'REGULAR' && origDiscountAmount > 0 && aggregatedDiscountedGross === 0) {
    const dLabel = data.discountInfo?.label ? `Less: ${data.discountInfo.label}` : 'Less: DISCOUNT';
    discountGridHtml = `<div class="summary-grid-row"><div class="label-col">${dLabel} :</div><div class="val-col">${formatAmount(discountAmount)}</div></div>`;
  }
  if (txType === 'CUSTOM' && origDiscountAmount > 0 && aggregatedDiscountedGross === 0) {
    discountGridHtml = `<div class="summary-grid-row"><div class="label-col">Less: CUSTOM DISC :</div><div class="val-col">${formatAmount(discountAmount)}</div></div>`;
  }

  const payments = data.payments || [];
  let paymentsGridHtml = '';
  let totalPaid = 0;
  for (const p of payments) {
    const pAmt      = (p.amount || p.Amount || 0) * mult || 0;
    const rawMethod = (p.method || p.PaymentMethod || 'CASH').toUpperCase();
    totalPaid      += pAmt;

    const methodLabel = (() => {
      if (rawMethod === 'CASH')                          return 'CASH';
      if (rawMethod.includes('CARD DEBIT'))              return 'CARD DEBIT';
      if (rawMethod.includes('CARD CREDIT'))             return 'CARD CREDIT';
      if (rawMethod === 'CARD')                          return 'CARD';
      if (rawMethod.includes('MAYA'))                    return 'E-WALLET MAYA';
      if (rawMethod.includes('GCASH'))                   return 'E-WALLET GCASH';
      if (rawMethod.includes('QRPH'))                    return 'E-WALLET QRPH';
      if (rawMethod.includes('LANDERS'))                 return 'E-WALLET LANDERS';
      if (rawMethod.includes('VOUCHER'))                 return 'VOUCHER';
      return rawMethod;
    })();

    const refCode = p.refCode || p.RefrenceNo || p.referenceNo || '';

    paymentsGridHtml += `<div class="summary-grid-row"><div class="label-col">${methodLabel} :</div><div class="val-col">${formatAmount(pAmt)}</div></div>`;
    if (refCode) {
      paymentsGridHtml += `<div class="summary-grid-row" style="font-size:10px;color:#555;"><div class="label-col">TPO: ${refCode}</div><div class="val-col"></div></div>`;
    }
  }


  const change = isReversed ? Math.abs(totalPaid) : (data.change !== undefined ? data.change : Math.max(0, totalPaid - total));
  const changeGridHtml = `<div class="summary-grid-row"><div class="label-col">CHANGE DUE :</div><div class="val-col">${formatAmount(change)}</div></div>`;

  const guestListHtml = (() => {
    const guests = (data.guests && data.guests.length > 0)
      ? data.guests
      : [{ guestName: '', GuestValidID: '', tin: '', address: '' }];

    return guests.map((g: any) => `
      <hr class="divider">
      <div class="customer-row"><div class="customer-label">Sold To</div><div>: ${g.guestName || ''}</div></div>
      ${txType !== 'REGULAR' ? `<div class="customer-row"><div class="customer-label">ID Number</div><div>: ${g.GuestValidID || ''}</div></div>` : ''}
      <div class="customer-row"><div class="customer-label">TIN</div><div>: ${g.tin || ''}</div></div>
      <div class="customer-row"><div class="customer-label">Address</div><div>: ${g.address || ''}</div></div>
    `).join('');
  })();

  const statusBanner = (() => {
    const voided   = data.isVoided   || data.transactionType === 'VOID' || data.orderState === 'VOIDED' || data.status === 'voided';
    const refunded = data.isRefunded || data.transactionType === 'REFUND' || data.orderState === 'REFUNDED' || data.status === 'refunded';
    const reprint  = !!data.isReprint;
    if (voided   && reprint) return '*** VOIDED REPRINT ***';
    if (refunded && reprint) return '*** REFUNDED REPRINT ***';
    if (voided)              return '*** VOIDED ***';
    if (refunded)            return '*** REFUNDED ***';
    if (reprint)             return '*** REPRINT ***';
    return '';
  })();
  const statusBannerHtml = statusBanner ? `<div class="center bold" style="margin:4px 0;">${statusBanner}</div>` : '';
  const isRefundedStatus = data.isRefunded || data.transactionType === 'REFUND' || data.orderState === 'REFUNDED' || data.status === 'refunded';

  const repDate = new Date();
  const repDateStr = `${pad2(repDate.getMonth() + 1)}/${pad2(repDate.getDate())}/${repDate.getFullYear()}`;
  const repTimeStr = `${pad2(repDate.getHours())}:${pad2(repDate.getMinutes())}:${pad2(repDate.getSeconds())}`;
  const reprintHtml = data.isReprint ? `<div class="center" style="margin-top: 2px;">REPRINT DATE: ${repDateStr} TIME: ${repTimeStr}</div>` : '';

  return `<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Receipt</title>${style}</head>
<body>
<div class="receipt-container">
  ${headerHtml}
  ${!isReversed ? `<div class="center" style="margin-top: 6px;">THIS SERVES AS YOUR SALES INVOICE</div>` : ''}
  ${reprintHtml}
  ${statusBannerHtml}
  <br/>
  ${isRefundedStatus && refundNo ? `<div class="row"><span>REFUND SERIES</span><span>${refundNo}</span></div>` : ''}
  <div class="row"><span>${isRefundedStatus ? 'REFERENCE SALES INVOICE NO.' : 'SALES INVOICE NO.'}</span><span>${salesNo}</span></div>
  <div class="row"><span>TXN NUMBER</span><span>${txnNo}</span></div>
  <div class="row"><span>CASHIER: ${cashierName}</span><span>T${terminalNo} S${shiftNo} ${dateStr}</span></div>
  <div class="bold" style="font-size: 16px; margin: 6px 0; text-align: left;">${orderType}</div>
  <hr class="divider">
  <div class="center bold" style="font-size: 16px; margin: 4px 0;">ORDER SLIP NO.: ${orderNumber}</div>
  <hr class="divider">
  ${itemsHtml}
  ${pezaDiplomatHtml} 
  <div style="margin-top: 4px;">
    <div class="summary-grid-row bold"><div class="label-col">TOTAL :</div><div class="val-col">${formatAmount(total)}</div></div>
    ${discountGridHtml}
    ${paymentsGridHtml}
    ${changeGridHtml}
  </div>
  <div class="center" style="margin: 6px 0;">NO. OF ITEMS : ${itemCount}</div>
  <div class="row"><span>VATable Sales</span><span class="val-col">${formatAmount(vatableSales)}</span></div>
  <div class="row"><span>VAT Amount</span><span class="val-col">${formatAmount(vatAmount)}</span></div>
  <div class="row"><span>VAT Exempt Sales</span><span class="val-col">${formatAmount(vatExempt)}</span></div>
  <div class="row"><span>Zero-Rated Sales</span><span class="val-col">${formatAmount(zeroRated)}</span></div>
  ${txType !== 'REGULAR' ? 
    `<div class="center" style="margin-top: 14px;">
      <div style="border-top: 1px dashed #000; width: 80%; margin: 0 auto 2px auto;"></div>
      <div>CUSTOMER SIGNATURE</div>
    </div>` : ''
  }
  ${guestListHtml}
  <hr class="divider">
  ${footerHtml}
</div>
</body>
</html>`;
}

export function buildReceiptText({ storeData, receiptFormat, data, width = 48, copyType, fiscal }: { storeData: any; receiptFormat: any; data: any; width?: number; copyType?: 'customer' | 'accountant'; fiscal: any }): string {
  let out = '';
  const div    = divider(width) + '\n';
  const valW   = 12;
  const lblW   = width - valW;
  const txType = data.transactionType || 'REGULAR';
  const reprint  = !!data.isReprint;
  const voided   = data.isVoided   || data.transactionType === 'VOID' || data.orderState === 'VOIDED' || data.status === 'voided';
  const refunded = data.isRefunded || data.transactionType === 'REFUND' || data.orderState === 'REFUNDED' || data.status === 'refunded';

  // Reverse sign multiplier for voids and refunds
  const isReversed = data.isVoided || data.isRefunded || data.transactionType === 'VOID' || data.transactionType === 'REFUND' || data.orderState === 'VOIDED' || data.orderState === 'REFUNDED' || data.status === 'voided' || data.status === 'refunded';
  const isRefundedStatus = data.isRefunded || data.transactionType === 'REFUND' || data.orderState === 'REFUNDED' || data.status === 'refunded';
  const mult = isReversed ? -1 : 1;

  if (receiptFormat?.header) out += formatHtmlToTextLines(replaceEnvVarsInline(receiptFormat.header, fiscal), width);
  else if (storeData?.name) out += centerText(storeData.name, width) + '\n';

  if (!isReversed) out += '\n' + centerText("THIS SERVES AS YOUR SALES INVOICE", width) + '\n';
  else out += '\n';

  if (reprint) {
    const repDate = new Date();
    const pad2 = (n: number) => String(n).padStart(2, '0');
    const repDateStr = `${pad2(repDate.getMonth() + 1)}/${pad2(repDate.getDate())}/${repDate.getFullYear()}`;
    const repTimeStr = `${pad2(repDate.getHours())}:${pad2(repDate.getMinutes())}:${pad2(repDate.getSeconds())}`;
    out += centerText(`REPRINT DATE: ${repDateStr} TIME: ${repTimeStr}`, width) + '\n';
  }

  const statusBannerText = (() => {
    const voided   = data.isVoided   || data.transactionType === 'VOID' || data.orderState === 'VOIDED' || data.status === 'voided';
    const refunded = data.isRefunded || data.transactionType === 'REFUND' || data.orderState === 'REFUNDED' || data.status === 'refunded';
    const reprint  = !!data.isReprint;
    if (voided   && reprint) return '*** VOIDED REPRINT ***';
    if (refunded && reprint) return '*** REFUNDED REPRINT ***';
    if (voided)              return '*** VOIDED ***';
    if (refunded)            return '*** REFUNDED ***';
    if (reprint)             return '*** REPRINT ***';
    return '';
  })();
  if (statusBannerText) out += centerText(statusBannerText, width) + '\n';
  // if (copyType) {
  //   const banner = copyType === 'accountant'
  //     ? '*** ACCOUNTING COPY ***'
  //     : '*** CUSTOMER COPY ***';
  //   out += centerText(banner, width) + '\n';
  // }
  out += '\n';
  if (isRefundedStatus && (data.refundSeriesNo || data.refundSeriesNumber)) {
    out += padRight('REFUND SERIES', 20) + padLeft((data.refundSeriesNo || data.refundSeriesNumber), width - 20) + '\n';
  }
  out += padRight(isRefundedStatus ? 'REF. SALES INV. NO.' : 'SALES INVOICE NO.', 20) + padLeft(data.salesNumber || '', width - 20) + '\n';
  out += padRight('TXN NUMBER', 20)        + padLeft(data.transactionNumber || '', width - 20) + '\n';
  
  const now = (data.orderTime || data.created_at) ? new Date(data.orderTime || data.created_at) : new Date();

  const pad2 = (n: number) => String(n).padStart(2, '0');
  const dateStr = `${pad2(now.getMonth() + 1)}/${pad2(now.getDate())}/${String(now.getFullYear()).slice(-2)} ${pad2(now.getHours())}:${pad2(now.getMinutes())}`;

  const cashierName = data.staffName || data.staffId || '-';
  const terminalNo  = data.terminalNo || data.KioskNo || data.terminalId || getWorkstationId() || '1';

  out += padRight(`CASHIER: ${cashierName}`, 20) + padLeft(`T${terminalNo} S${String(data.shiftNo || data.shiftNumber || data.ShiftNo || '-')} ${dateStr}`, width - 20) + '\n';
  out += `${(data.orderType || 'DINE-IN').toUpperCase()}\n`;

  out += div;
  out += centerText(`ORDER SLIP NO.: ${data.orderNumber || ''}`, width) + '\n';
  out += div;

  let itemCount = 0;
  let grossSubTotal = 0;
  let aggregatedDiscountedGross = 0;

  // ── Sort: discounted items first, everything else after ──
  const rawItems = data.items || [];
  const items = sortItemsDiscountFirst(rawItems, txType);

  for (const item of items) {
    const qty       = item.quantity || item.qty || 1;
    const basePrice = ((item.price || 0) > 1000 ? (item.price / 100) : (item.price || 0)) * mult || 0;
    itemCount      += qty;

    let modsTotalPrice = 0;
    const mods = Array.isArray(item.modifiers) ? item.modifiers : Object.values(item.modifiers || {});
    for (const m of mods as any[]) {
      const mPrice = ((m.price || 0) / 100) * mult || 0;
      const mQty   = m.qty || m.quantity || 1;
      modsTotalPrice += mPrice * (mQty * qty);
    }
    const lineGrossAmount = (basePrice * qty) + modsTotalPrice;
    grossSubTotal += lineGrossAmount;

    const origItemDiscount = item.itemDiscount || 0;
    const itemDiscount = origItemDiscount * mult || 0;

    if (origItemDiscount > 0 && ['SC', 'SRC', 'PWD', 'REGULAR', 'CUSTOM'].includes(txType)) {
      aggregatedDiscountedGross += lineGrossAmount;
    }

    // Apply (X) or (V) based on whether VAT is removed via discount
    let vatIndicator = '';
    if (txType === 'REGULAR') {
      if (item.taxable !== false) vatIndicator = ' (V)';
    } else {
      if (
        (origItemDiscount > 0 || txType === 'DIPLOMAT' || txType === 'PEZA') &&
        txType !== 'ATHLETE' && txType !== 'MEDAL' && txType !== 'SOLO' 
      ) {
        vatIndicator = ' (X)';
      } else {
        vatIndicator = ' (V)';
      }
    }

    const itemName  = (item.itemName || item.name || '') + vatIndicator;

    out += `${itemName}\n`;
    out += padRight(`  ${qty} @ ${formatAmount(basePrice)}`, lblW) + padLeft(formatAmount(basePrice * qty), valW) + '\n';

    for (const m of mods as any[]) {
      const mQty        = m.qty || m.quantity || 1;
      const displayQty  = mQty * qty;   // ← multiply by parent qty
      const mPrice = ((m.price || 0) / 100) * mult || 0;
      let mName = `  + ${displayQty}x ${m.name}`;
      if (mName.length > 28) mName = mName.substring(0, 26) + '..';
      if (Math.abs(mPrice) > 0) {
        out += padRight(mName, lblW) + padLeft(formatAmount(mPrice * displayQty), valW) + '\n';
      } else {
        out += padRight(mName, width) + '\n';
      }
    }

    if (origItemDiscount > 0) {
      const dashedLine = padRight('', lblW) + padLeft('-'.repeat(valW), valW) + '\n';

      if (['SC', 'SRC', 'PWD', 'REGULAR', 'CUSTOM', 'ATHLETE', 'SOLO', 'MEDAL', 'PEZA', 'DIPLOMAT'].includes(txType)) {
        const isLastDiscountedItem = !items.slice(items.indexOf(item) + 1).some(i => (i.itemDiscount || 0) > 0);

        if (isLastDiscountedItem && ['SC', 'SRC', 'PWD', 'REGULAR', 'CUSTOM'].includes(txType)) {
          if (txType === 'REGULAR' || txType === 'CUSTOM') {
            const discLabel = txType === 'CUSTOM' ? 'CUSTOM DISC' : (data.discountInfo?.label ? data.discountInfo.label.substring(0, 15) : 'DISCOUNT');
            const discLess = (data.discountAmount || 0) * mult;
            const netSubTotal = (aggregatedDiscountedGross * mult) - discLess;

            out += padRight(`  Less: ${discLabel}`, lblW) + padLeft(formatAmount(discLess), valW) + '\n';
            out += dashedLine;
            out += padRight('  Sub-Total :', lblW)        + padLeft(formatAmount(netSubTotal), valW) + '\n';
            out += '\n';
          } else {
            const discLabel   = getDiscountLineLabel(txType);
            const vatLess     = (aggregatedDiscountedGross - (aggregatedDiscountedGross / 1.12)) * mult;
            const discLess    = ((aggregatedDiscountedGross / 1.12) * 0.20) * mult;
            const netSubTotal = ((aggregatedDiscountedGross / 1.12) * 0.80) * mult;

            out += padRight('  Less: 12% VAT', lblW)      + padLeft(formatAmount(vatLess),    valW) + '\n';
            out += padRight(`  Less: ${discLabel}`, lblW) + padLeft(formatAmount(discLess),   valW) + '\n';
            out += dashedLine;
            out += padRight('  Sub-Total :', lblW)        + padLeft(formatAmount(netSubTotal), valW) + '\n';
            out += '\n';
          }
        }
      } else {
         const discLabel = getDiscountLineLabel(txType);
         const subTotal = (lineGrossAmount * mult) - itemDiscount;
         out += padRight(`  Less: ${discLabel}`, lblW) + padLeft(formatAmount(itemDiscount), valW) + '\n';
         out += dashedLine;
         out += padRight('  Sub-Total :', lblW)        + padLeft(formatAmount(subTotal), valW) + '\n';
      }
    }
  }

  if (txType === 'PEZA' || txType === 'DIPLOMAT') {
    const vatRemoved  = grossSubTotal - (grossSubTotal / 1.12);
    const extLabel    = txType === 'PEZA' ? 'PEZA' : 'DIPLOMAT';
    const dashedLine  = padRight('', lblW) + padLeft('-'.repeat(valW), valW) + '\n';

    out += dashedLine;
    out += padRight('Sub-Total :', lblW)                      + padLeft(formatAmount(grossSubTotal), valW) + '\n';
    out += padRight(`${extLabel} Less: 12% VAT`, lblW)        + padLeft(formatAmount(vatRemoved),    valW) + '\n';
  }

  let totalPaid = 0;
  out += '\n';

  const origDiscountAmount = data.discountAmount || 0;
  const discountAmount = origDiscountAmount * mult || 0;
  const total = (data.total || data.grandTotal || 0) * mult || 0;

  // ATHLETE: single order-level discount line after items, before total
  if (txType === 'ATHLETE' && origDiscountAmount > 0) {
    out += padRight('Less: 20% NAAC DISC', lblW) + padLeft(formatAmount(discountAmount), valW) + '\n';
  }

  // SOLO / MEDAL
  if ((txType === 'SOLO' || txType === 'MEDAL') && origDiscountAmount > 0) {
    const discLabel = txType === 'SOLO' ? '20% SOLO PARENT DISC' : '20% MEDAL OF VALOR DISC';
    out += padRight(`Less: ${discLabel}`, lblW) + padLeft(formatAmount(discountAmount), valW) + '\n';
  }

  // CUSTOM (Fallback if not aggregated)
  if (txType === 'CUSTOM' && origDiscountAmount > 0 && aggregatedDiscountedGross === 0) {
    out += padRight(`Less: CUSTOM DISC`, lblW) + padLeft(formatAmount(discountAmount), valW) + '\n';
  }

  out += padLeft('TOTAL :', lblW) + padLeft(formatAmount(total), valW) + '\n';

  // REGULAR (Fallback if not aggregated)
  if (txType === 'REGULAR' && origDiscountAmount > 0 && aggregatedDiscountedGross === 0) {
    const discLabel = data.discountInfo?.label ? `Less: ${data.discountInfo.label.substring(0, 15)}` : 'Less: DISCOUNT';
    out += padLeft(`${discLabel} :`, lblW) + padLeft(formatAmount(discountAmount), valW) + '\n';
  }

  const payments = data.payments || [];
  for (const p of payments) {
    const pAmt      = (p.amount || 0) * mult || 0;
    const rawMethod = (p.method || p.PaymentMethod || 'CASH').toUpperCase();
    totalPaid      += pAmt;

    // Resolve display label
    const methodLabel = (() => {
      if (rawMethod === 'CASH')                          return 'CASH';
      if (rawMethod.includes('CARD DEBIT'))              return 'CARD DEBIT';
      if (rawMethod.includes('CARD CREDIT'))             return 'CARD CREDIT';
      if (rawMethod === 'CARD')                          return 'CARD';
      if (rawMethod.includes('MAYA'))                    return 'E-WALLET MAYA';
      if (rawMethod.includes('GCASH'))                   return 'E-WALLET GCASH';
      if (rawMethod.includes('QRPH'))                    return 'E-WALLET QRPH';
      if (rawMethod.includes('LANDERS'))                 return 'E-WALLET LANDERS';
      if (rawMethod.includes('VOUCHER'))                 return 'VOUCHER';
      return rawMethod;
    })();

    const refCode = p.refCode || p.RefrenceNo || p.referenceNo || '';

    out += padLeft(`${methodLabel} :`, lblW) + padLeft(formatAmount(pAmt), valW) + '\n';
    if (refCode) {
      out += padLeft(`TPO: ${refCode}`, lblW) + padLeft('', valW) + '\n';
    }
  }

  const change = isReversed ? Math.abs(totalPaid) : (data.change !== undefined ? data.change : Math.max(0, totalPaid - total));
  out += padLeft('CHANGE DUE :', lblW) + padLeft(formatAmount(change), valW) + '\n';

  out += '\n';
  out += centerText(`NO. OF ITEMS : ${itemCount}`, width) + '\n';
  
  const vatableSales = (data.vatableSales || 0) * mult || 0;
  const vatAmount    = (data.tax || 0) * mult || 0;
  const vatExempt    = (data.vatExemptSales || 0) * mult || 0;
  const zeroRated    = (data.zeroRatedSales || 0) * mult || 0;

  out += padRight('VATable Sales',     lblW) + padLeft(formatAmount(vatableSales), valW) + '\n';
  out += padRight('VAT Amount',        lblW) + padLeft(formatAmount(vatAmount), valW) + '\n';
  out += padRight('VAT Exempt Sales',  lblW) + padLeft(formatAmount(vatExempt), valW) + '\n';
  out += padRight('Zero-Rated Sales',  lblW) + padLeft(formatAmount(zeroRated), valW) + '\n';
  out += '\n';

  if (txType !== 'REGULAR') {
    const sigLine = '-'.repeat(Math.floor(width * 0.8));
    out += centerText(sigLine, width) + '\n';
    out += centerText("CUSTOMER SIGNATURE", width) + '\n';
    // const copyLabel = copyType === 'accountant'
    //   ? "(Accounting Copy)"
    //   : copyType === 'customer'
    //   ? "(Customer's Copy)"
    //   : (txType === 'PEZA' || txType === 'DIPLOMAT') ? "(Customer's Copy)" : "(Store's Copy)";
    // out += centerText(copyLabel, width) + '\n';
  }

  const guestList = (data.guests && data.guests.length > 0)
    ? data.guests
    : [{ guestName: '', GuestValidID: '', tin: '', address: '' }];

  for (const g of guestList) {
    out += div;
    out += `Sold To    : ${g.guestName || ''}\n`;
    if (txType !== 'REGULAR')
      out += `ID Number  : ${g.GuestValidID || ''}\n`;
    out += `TIN        : ${g.tin || ''}\n`;
    out += `Address    : ${g.address || ''}\n`;
  }
  out += div;

  if (receiptFormat?.footer) out += formatHtmlToTextLines(replaceEnvVarsInline(receiptFormat.footer, fiscal), width);

  return out;
}

// ==========================================
// 2. CASH DROP RECEIPT BUILDERS
// ==========================================

export function buildCashDropHtml({ storeData, cashierName, amount, date, breakdown = {}, receiptFormat, fiscal, transactionNumber, controlNumber }: CashDropOptions): string {
  const dropDate = date ? new Date(date) : new Date();
  
  const pad2 = (n: number) => String(n).padStart(2, '0');
  const dateStr = `${pad2(dropDate.getMonth() + 1)}/${pad2(dropDate.getDate())}/${dropDate.getFullYear()}`;
  const timeStr = `${pad2(dropDate.getHours())}:${pad2(dropDate.getMinutes())}:${pad2(dropDate.getSeconds())}`;

  let headerHtml = '';
  if (receiptFormat?.header) {
    headerHtml = `<div class="receipt-header">${replaceEnvVarsInline(receiptFormat.header, fiscal || {})}</div>`;
  } else if (storeData?.name) {
    headerHtml = `<div class="receipt-header">${storeData.name}</div>`;
  }

  let denomRows = '';
  const denomOrder = [1000, 500, 200, 100, 50];
  let hasBreakdown = false;
  for (const denom of denomOrder) {
    const count = breakdown[denom] || 0;
    if (count > 0) {
      hasBreakdown = true;
      denomRows += `<div class="col-3"><span>  ${denom.toFixed(2)}</span><span class="center">${count}</span><span>${formatAmount(denom * count)}</span></div>`;
    }
  }
  
  let coinsTotal = 0;
  const coinsDenoms = [20, 10, 5, 1, 0.25];
  for (const denom of coinsDenoms) {
    const count = breakdown[denom] || 0;
    coinsTotal += (denom * count);
  }
  if (!hasBreakdown && coinsTotal === 0 && amount > 0) coinsTotal = amount;

  if (coinsTotal > 0 || hasBreakdown) {
     denomRows += `<div class="col-3"><span>    Coins</span><span class="center">0</span><span>${formatAmount(coinsTotal)}</span></div>`;
  }

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Cash Drop</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html { width: 80mm; height: 100%; }
    body { font-family: 'Courier New', Courier, monospace; background: #fff; width: 80mm; font-size: 11px; color: #000; line-height: 1.4; }
    .receipt-container { width: 80mm; margin: 0; padding: 2mm 3mm; }
    .receipt-header { text-align: center; margin-bottom: 3px; font-size: 11px; line-height: 1.3; }
    .center { text-align: center; }
    .bold { font-weight: bold; }
    .row { display: flex; justify-content: space-between; margin: 2px 0; text-align: left; }
    .col-3 { display: flex; justify-content: space-between; margin: 2px 0; text-align: left; }
    .col-3 span { flex: 1; text-align: right; }
    .col-3 span:nth-child(2) { text-align: center; }
    .col-3 span:first-child { text-align: left; }
    .sig-line { border-top: 1px dashed #000; width: 60%; margin: 4px auto 2px; }
  </style>
</head>
<body>
<div class="receipt-container">
  ${headerHtml}
  <br/>
  <div class="center bold">&lt;&lt; PARTIAL DEPOSIT  &gt;&gt;</div>
  <div class="center">DATE: ${dateStr} TIME: ${timeStr}</div>
  <br/>
  <div class="row"><span>CONTROL NO.</span><span>: ${controlNumber || 'PD1'}</span></div>
  <div class="row"><span>TRANS. NO.</span><span>: ${transactionNumber || '1'}</span></div>
  <div class="row"><span>TAKEN FROM</span><span>: ${cashierName || 'Unknown'}</span></div>
  <div class="row"><span>RECEIVED BY</span><span>: MANAGER</span></div>
  <br/>
  <div class="col-3"><span>Bill Value</span><span class="center"># of Pcs. /</span><span>Bill Total</span></div>
  ${denomRows}
  <br/>
  <div class="row bold"><span>TOTAL AMOUNT:</span><span>${formatAmount(amount)}</span></div>
  <br/><br/>
  <div class="sig-line"></div>
  <div class="center">CASHIER: ${cashierName || 'Unknown'}</div>
  <br/>
  <div class="sig-line"></div>
  <div class="center">MANAGER: MANAGER</div>
  <br/>
  <div class="center">"THIS DOCUMENT IS NOT VALID FOR CLAIM<br/>OF INPUT TAX"</div>
</div>
</body>
</html>`;
}

export interface EncloseOptions {
  storeData: any;
  cashierName: string;
  amount: number;
  reason?: string;
  date?: string;
  width?: number;
  transactionNumber?: string;
}

export function buildEncloseHtml({ storeData, cashierName, amount, reason, date, transactionNumber }: EncloseOptions): string {
  const dateStr = date ? new Date(date).toLocaleDateString() : new Date().toLocaleDateString();
  const timeStr = date ? new Date(date).toLocaleTimeString() : new Date().toLocaleTimeString();

  return `
    <div class="receipt-container" style="font-family: monospace; width: 100%; max-width: 300px; margin: 0 auto; font-size: 12px;">
      <div class="center bold" style="text-align: center; font-weight: bold;">${storeData?.name || 'Store'}</div>
      <div class="center" style="text-align: center;">${storeData?.address || ''}</div>
      <br/>
      <div class="center bold" style="text-align: center; font-weight: bold;">&lt;&lt; PAID IN / ENCLOSE &gt;&gt;</div>
      <div class="center" style="text-align: center;">DATE: ${dateStr} TIME: ${timeStr}</div>
      <br/>
      <div class="row" style="display: flex; justify-content: space-between;"><span>TRANS. NO.</span><span>: ${transactionNumber || 'N/A'}</span></div>
      <div class="row" style="display: flex; justify-content: space-between;"><span>CASHIER</span><span>: ${cashierName || 'Unknown'}</span></div>
      <br/>
      <div class="row" style="display: flex; justify-content: space-between; font-weight: bold;"><span>AMOUNT</span><span>: ${(amount).toFixed(2)}</span></div>
      <div class="row" style="display: flex; justify-content: space-between;"><span>REASON</span><span>: ${reason || 'N/A'}</span></div>
      <br/>
      <div class="center" style="text-align: center;">--------------------------------</div>
      <br/><br/>
    </div>
  `;
}

export function buildEncloseText({ storeData, cashierName, amount, reason, date, width = 48, transactionNumber }: EncloseOptions): string {
  const padRight = (str: string, len: number) => (str + ' '.repeat(len)).substring(0, len);
  const centerText = (str: string, len: number) => {
    if (str.length >= len) return str;
    const pad = Math.floor((len - str.length) / 2);
    return ' '.repeat(pad) + str;
  };

  const dateStr = date ? new Date(date).toLocaleDateString() : new Date().toLocaleDateString();
  const timeStr = date ? new Date(date).toLocaleTimeString() : new Date().toLocaleTimeString();

  let out = '';
  out += centerText(storeData?.name || 'Store', width) + '\n';
  out += centerText(storeData?.address || '', width) + '\n\n';
  
  out += centerText('<< PAID IN / ENCLOSE >>', width) + '\n';
  out += centerText(`DATE: ${dateStr} TIME: ${timeStr}`, width) + '\n\n';

  out += padRight('TRANS. NO.', 15) + `: ${transactionNumber || 'N/A'}\n`;
  out += padRight('CASHIER', 15) + `: ${cashierName || 'Unknown'}\n\n`;
  
  out += padRight('AMOUNT', 15) + `: ${(amount).toFixed(2)}\n`;
  out += padRight('REASON', 15) + `: ${reason || 'N/A'}\n\n`;

  out += centerText('--------------------------------', width) + '\n\n\n\n\n';

  return out;
}

export function buildCashDropText({ storeData, cashierName, amount, date, width = 48, breakdown = {}, receiptFormat, fiscal, transactionNumber, controlNumber }: CashDropOptions): string {
  let out = '';
  const dropDate = date ? new Date(date) : new Date();
  const valW = 16;
  const lblW = width - valW;
  
  const pad2 = (n: number) => String(n).padStart(2, '0');
  const dateStr = `${pad2(dropDate.getMonth() + 1)}/${pad2(dropDate.getDate())}/${dropDate.getFullYear()}`;
  const timeStr = `${pad2(dropDate.getHours())}:${pad2(dropDate.getMinutes())}:${pad2(dropDate.getSeconds())}`;

  if (receiptFormat?.header) {
    out += formatHtmlToTextLines(replaceEnvVarsInline(receiptFormat.header, fiscal || {}), width);
  } else if (storeData?.name) {
    out += centerText(storeData.name, width) + '\n';
  }
  
  out += '\n';
  out += centerText('<< PARTIAL DEPOSIT  >>', width) + '\n';
  out += centerText(`DATE: ${dateStr} TIME: ${timeStr}`, width) + '\n\n';

  out += padRight('CONTROL NO.', 15) + `: ${controlNumber || 'PD1'}\n`;
  out += padRight('TRANS. NO.', 15) + `: ${transactionNumber || '1'}\n`;
  out += padRight('TAKEN FROM', 15) + `: ${cashierName || 'Unknown'}\n`;
  out += padRight('RECEIVED BY', 15) + `: MANAGER\n\n`;

  out += padRight('Bill Value', 16) + padLeft('# of Pcs. /', 14) + padLeft('Bill Total', 18) + '\n';
  
  const denomOrder = [1000, 500, 200, 100, 50];
  let hasBreakdown = false;

  for (const denom of denomOrder) {
    const count = breakdown[denom] || 0;
    if (count > 0) {
      hasBreakdown = true;
      out += padRight(`  ${denom.toFixed(2)}`, 16) + padLeft(String(count), 14) + padLeft(formatAmount(denom * count), 18) + '\n';
    }
  }

  // Coins sum
  let coinsTotal = 0;
  const coinsDenoms = [20, 10, 5, 1, 0.25];
  for (const denom of coinsDenoms) {
    const count = breakdown[denom] || 0;
    coinsTotal += (denom * count);
  }
  
  // If we didn't receive a breakdown at all, just put the total in Coins so it adds up
  if (!hasBreakdown && coinsTotal === 0 && amount > 0) {
    coinsTotal = amount;
  }

  if (coinsTotal > 0 || hasBreakdown) {
     out += padRight('    Coins', 16) + padLeft('0', 14) + padLeft(formatAmount(coinsTotal), 18) + '\n';
  }

  out += '\n';
  out += padRight('TOTAL AMOUNT:', 24) + padLeft(formatAmount(amount), 24) + '\n\n';

  const sigLine = '-'.repeat(32);
  out += centerText(sigLine, width) + '\n';
  out += centerText(`CASHIER: ${cashierName || 'Unknown'}`, width) + '\n';
  out += centerText(sigLine, width) + '\n';
  out += centerText(`MANAGER: MANAGER`, width) + '\n';
  out += centerText(sigLine, width) + '\n';
  out += centerText('"THIS DOCUMENT IS NOT VALID FOR CLAIM', width) + '\n';
  out += centerText('OF INPUT TAX"', width) + '\n';

  return out;
}

// ==========================================
// EXPORTS & HELPERS
// ==========================================

export interface OpenShiftOptions {
  storeData: StoreData;
  cashierName: string;
  shiftNumber: string | number;
  sessionId: string;
  amount: number;
  breakdown?: Record<number, number>;
  date?: string;
  width?: number;
  receiptFormat: any;
  fiscal: any;
  transactionNumber?: string;
}

// Add to ReceiptPrinting.ts
export async function normalizeTransactionForReceipt(
  transactionData: any,
  flags?: { isVoided?: boolean; isRefunded?: boolean; isReprint?: boolean },
  overrideTransactionNumber?: string  // ← add this
): Promise<Record<string, any>> {
  if (!transactionData) return {};
  const storeData = JSON.parse(localStorage.getItem("store_data") || "{}");
  const seriesType = storeData?.series_type || 'WS';
  
  const workstationId = getWorkstationId();
  
  if (flags?.isVoided || flags?.isRefunded || flags?.isReprint) {
    const newTransactionNumber = overrideTransactionNumber 
      ?? (await getNextTransactionNumber(seriesType, workstationId)).toString();
    transactionData.transactionNumber = newTransactionNumber;
  }

  // ── Items ──────────────────────────────────────────────
  let items: any[] = [];
  try {
    if (transactionData.orderDetailJSON) {
      const d = typeof transactionData.orderDetailJSON === 'string'
        ? JSON.parse(transactionData.orderDetailJSON)
        : transactionData.orderDetailJSON;
      if (d?.items) items = d.items;
    }
    if (!items.length && Array.isArray(transactionData.items)) items = transactionData.items;
  } catch {}

  // ── Amounts — our DB always stores in cents ─────────────
  // Use payment sum as the authoritative total
  const rawPayments = transactionData.payment || transactionData.payments || [];
  const paymentArr = Array.isArray(rawPayments) ? rawPayments : [];

  const payments = paymentArr.map((p: any) => ({
    method:   p.PaymentMethod || p.method || 'CASH',
    amount:   Number(p.Amount || p.amount || 0) / 100,
    refCode:  p.RefrenceNo   || p.referenceNo || p.refCode || '',
  }));

  const paidTotal = payments.reduce((s: number, p: any) => s + p.amount, 0);

  // Gross total = what was actually paid
  let total = paidTotal;
  if (!total) {
    // fallback: eaterPayment in cents
    const raw = transactionData.price?.eaterPayment || transactionData.price?.subtotal || 0;
    total = raw / 100;
  }

  // Tax and subtotal — divide by 100 unconditionally (always cents in our format)
  const taxCents    = transactionData.price?.tax      || transactionData.tax      || 0;
  const subCents    = transactionData.price?.subtotal || transactionData.subtotal || 0;
  const tax         = taxCents / 100;
  const subtotal    = subCents / 100;

  // VAT breakdown
  const txType = transactionData.transactionType || 'REGULAR';

  const storedVATSale    = transactionData.price?.VATSale    ?? null;
  const storedVatAmount  = transactionData.price?.VatAmount  ?? null;
  const storedVatExSales = transactionData.price?.VatExSales ?? null;
  const storedZeroRated  = transactionData.price?.ZeroRated  ?? null;

  const hasStoredVat = storedVATSale !== null || storedVatExSales !== null || storedZeroRated !== null;

  let vatableSales   = hasStoredVat ? (storedVATSale    ?? 0) / 100 : 0;
  let vatExemptSales = hasStoredVat ? (storedVatExSales ?? 0) / 100 : 0;
  let zeroRatedSales = hasStoredVat ? (storedZeroRated  ?? 0) / 100 : 0;

  // Fallback: recalculate only for older transactions that predate stored VAT fields
  if (!hasStoredVat) {
    if (txType === 'DIPLOMAT' || txType === 'PEZA') {
      zeroRatedSales = total;
    } else if (txType === 'SRC' || txType === 'PWD') {
      vatExemptSales = 0;
      vatableSales   = total - tax;
    } else {
      vatableSales = total - tax;
    }
  }


  const change = Math.max(0, paidTotal - total);

  // ── Field mapping ───────────────────────────────────────
  const cashierName = transactionData.cashierName
    || transactionData.staffName
    || transactionData.name
    || transactionData.staffId
    || '-';

  const orderType = transactionData.featureFlags?.orderType
    || transactionData.orderType
    || transactionData.order_type
    || 'DINE-IN';

  const orderNumber = transactionData.OrderNo
    || transactionData.orderNumber
    || transactionData.order_number
    || '';

  const terminalNo = transactionData.KioskNo 
    || transactionData.terminalId 
    || transactionData.workstationId 
    || getWorkstationId() 
    || '1';

  const shiftNo = transactionData.shiftNo
    || transactionData.shiftNumber
    || transactionData.ShiftNo
    || '-';

  // guest (singular in stored payload) → guests (plural for builder)
  const guests = Array.isArray(transactionData.guests)
    ? transactionData.guests
    : Array.isArray(transactionData.guest)
    ? transactionData.guest
    : transactionData.guest
    ? [transactionData.guest]
    : [];

  return {
    ...transactionData,
    isReprint: true,
    terminalNo,
    discountAmount: transactionData.discountAmount
      ? transactionData.discountAmount / 100
      : 0,
    discountInfo: transactionData.discountInfo || null,

    ...(flags?.isVoided   && { isVoided:   true }),
    ...(flags?.isRefunded && { isRefunded: true }),
    // corrected amounts
    items,
    total,
    grandTotal:    total,
    subtotal,
    tax,
    vatableSales,
    vatExemptSales,
    zeroRatedSales,
    change,
    // corrected payments
    payments,
    // corrected field names
    name:         cashierName,
    staffName:    cashierName,
    orderType,
    orderNumber,
    guests,
    shiftNo,
  };
}

const _previewQueue: string[] = [];
let _previewTimer: ReturnType<typeof setTimeout> | null = null;

export function previewReceiptText(text: string) {
  _previewQueue.push(text);

  if (_previewTimer) clearTimeout(_previewTimer);

  // Collect all texts that arrive in the same tick, then open one window.
  _previewTimer = setTimeout(() => {
    _previewTimer = null;
    const texts = _previewQueue.splice(0);

    const win = window.open('', '_blank', 'width=420,height=800,resizable=yes');
    if (!win) return;

    const receiptsHtml = texts
  .map((t) => `
    <div class="receipt-wrap">
      <div class="receipt">
        <pre>${t.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
      </div>
    </div>`)
  .join('');

win.document.write(`<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Receipt Preview</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: #e5e5e5;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 32px 16px 64px;
      min-height: 100vh;
      font-family: sans-serif;
    }
    .toolbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 16px;
      width: 100%;
      max-width: 900px;
    }
    .toolbar span {
      font-size: 11px; font-weight: 700; color: #888;
      text-transform: uppercase; letter-spacing: 1px;
    }
    .toolbar button {
      font-size: 11px; font-weight: 700; padding: 6px 14px;
      border-radius: 20px; border: none; background: #111;
      color: #fff; cursor: pointer;
    }
    .toolbar button:hover { background: #333; }

    /* ── side-by-side container ── */
    .receipts-row {
      display: flex;
      flex-direction: row;
      align-items: flex-start;
      gap: 24px;
      flex-wrap: wrap;
      justify-content: center;
    }

    .receipt-wrap {
      font-family: 'Courier New', Courier, monospace;
      font-size: 13px;
      width: calc(48ch + 80px);
      flex-shrink: 0;
    }
    .receipt-wrap::before {
      content: '';
      display: block; height: 14px;
      background:
        radial-gradient(circle at 7px 0, #e5e5e5 7px, transparent 7px),
        radial-gradient(circle at 7px 0, #e5e5e5 7px, transparent 7px);
      background-size: 14px 14px;
      background-position: 0 0, 7px 0;
      background-repeat: repeat-x;
    }
    .receipt-wrap::after {
      content: '';
      display: block; height: 14px;
      background:
        radial-gradient(circle at 7px 100%, #e5e5e5 7px, transparent 7px),
        radial-gradient(circle at 7px 100%, #e5e5e5 7px, transparent 7px);
      background-size: 14px 14px;
      background-position: 0 100%, 7px 100%;
      background-repeat: repeat-x;
    }
    .receipt {
      background: #fff;
      padding: 24px 40px 32px;
      box-shadow: 0 8px 40px rgba(0,0,0,0.18), 0 2px 8px rgba(0,0,0,0.10);
    }
    pre {
      font-family: 'Courier New', Courier, monospace;
      font-size: 13px; line-height: 1.45; color: #111;
      white-space: pre;
    }
  </style>
</head>
<body>
  <div class="toolbar">
    <span>📄 Receipt Preview (${texts.length} cop${texts.length > 1 ? 'ies' : 'y'})</span>
    <button onclick="window.print()">🖨 Print All</button>
  </div>
  <div class="receipts-row">
    ${receiptsHtml}
  </div>
</body>
</html>`);
    win.document.close();
  }, 50);
}


export function buildOpenShiftText({
  storeData,
  cashierName,
  shiftNumber,
  sessionId,
  receiptFormat,
  amount,
  breakdown = {},
  date,
  width = 48,
  fiscal,
  transactionNumber
}: OpenShiftOptions): string {
  let out = '';
  const storeName = storeData?.name || 'STORE NAME NOT SET';
  const openDate  = date ? new Date(date) : new Date();
  const valW = 14;
  const lblW = width - valW;

  const pad2  = (n: number) => String(n).padStart(2, '0');
  const dateStr = `${pad2(openDate.getMonth() + 1)}/${pad2(openDate.getDate())}/${openDate.getFullYear()}`;
  const timeStr = `${pad2(openDate.getHours())}:${pad2(openDate.getMinutes())}:${pad2(openDate.getSeconds())}`;

  if (receiptFormat?.header) out += formatHtmlToTextLines(replaceEnvVarsInline(receiptFormat.header, fiscal), width);
  else if (storeData?.name) out += centerText(storeData.name, width) + '\n';
  out += '\n';
  out += centerText('<< CHANGE FUND >>', width) + '\n';
  out += centerText(`DATE: ${dateStr} TIME:${timeStr}`, width) + '\n\n';

  out += padRight('CONTROL NO.', 16) + ': CF3\n';
  out += padRight('SHIFT NO.', 16) + `: ${shiftNumber || 0}\n`;
  out += padRight('TRANS. NO.', 16) + `: ${transactionNumber || 'N/A'}\n`;
  out += padRight('ISSUED TO', 16) + `: ${cashierName || 'Unknown'}\n`;
  out += padRight('ISSUED BY', 16) + ': Manager 1\n';
  out += padRight('AMOUNT ISSUED', 16) + `: ${formatAmount(amount)}\n\n`;

  const denomOrder = [1000, 500, 200, 100, 50, 20, 10, 5, 1, 0.25];
  const hasBreakdown = denomOrder.some((d) => (breakdown[d] || 0) > 0);

  if (hasBreakdown) {
    out += divider(width) + '\n';
    out += centerText('DENOMINATION BREAKDOWN', width) + '\n';
    out += divider(width) + '\n';
    for (const denom of denomOrder) {
      const count = breakdown[denom] || 0;
      if (count === 0) continue;
      const lineTotal = denom * count;
      const denomLabel = `  ${denom} x ${count}`;
      out += padRight(denomLabel, lblW) + padLeft(formatAmount(lineTotal), valW) + '\n';
    }
    out += divider(width) + '\n\n';
  }

  out += centerText('________________', width) + '\n';
  out += centerText(`CASHIER : ${cashierName || 'Unknown'}`, width) + '\n\n\n';
  
  out += centerText('________________', width) + '\n';
  out += centerText('MANAGER : Manager 1', width) + '\n';
  
  out += divider(width) + '\n';
  out += centerText('"THIS DOCUMENT IS NOT VALID', width) + '\n';
  out += centerText('FOR CLAIM OF INPUT TAX"', width) + '\n';

  return out;
}

const ReceiptPrinting = {
  buildReceiptHtml,
  buildReceiptText,
  buildCashDropHtml,
  buildCashDropText,
  print({ storeData, receiptFormat, data }: PrintReceiptOptions): Promise<void> {
    return new Promise(async (resolve) => {
      try {
        const workstationId = getWorkstationId() || '001';
        const html = buildReceiptHtml({ storeData, receiptFormat, data });
        const printResponse = await fetch('/api/print', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ html, workstationId }),
        });
        if (!printResponse.ok) throw new Error('Print failed');
        resolve();
      } catch (error) {
        console.error('[ReceiptPrinting] Print error:', error);
      }
    });
  },
};

export function printHtmlWithPreview(html: string) {
  if (!html || html.length === 0) {
    alert('Error: Receipt HTML is empty. Cannot print.');
    return;
  }
  const printWindow = window.open('', '_blank', 'width=400,height=auto,resizable=yes,scrollbars=no');
  if (!printWindow) {
    alert('Error: Unable to open print preview. Please allow popups in your browser.');
    return;
  }
  printWindow.document.open();
  printWindow.document.write(html);
  printWindow.document.close();
  setTimeout(() => {
    try {
      printWindow.focus();
      printWindow.addEventListener('afterprint', () => printWindow.close());
      printWindow.print();
    } catch (err) {
      alert('Error: Failed to open print dialog.');
    }
  }, 300);
}

export function buildKdsPrintText({ storeData, order, width = 48 }: { storeData: any; order: any; width?: number }): string {
  let out = '';
  const div = '-'.repeat(width) + '\n';
  const valW = 12;
  const lblW = width - valW;

  out += centerText('*** KITCHEN SLIP ***', width) + '\n';
  out += div;

  const pad2 = (n: number) => String(n).padStart(2, '0');
  const now = new Date(order.orderTime || new Date());
  const dateStr = `${pad2(now.getMonth() + 1)}/${pad2(now.getDate())}/${String(now.getFullYear()).slice(-2)} ${pad2(now.getHours())}:${pad2(now.getMinutes())}`;

  out += padRight('ORDER NO.', 15) + `: ${order.OrderNo || ''}\n`;
  out += padRight('SALES NO.', 15) + `: ${order.salesNumber || order._id || ''}\n`;
  out += padRight('DATE/TIME', 15) + `: ${dateStr}\n`;
  out += padRight('TYPE', 15) + `: ${order.featureFlags?.orderType === 'DineIn' ? 'DINE-IN' : 'TAKE-OUT'}\n`;
  out += div;

  for (const item of order.items || []) {
    const qty = item.quantity || item.qty || 1;
    out += padRight(` ${qty}x ${item.itemName || item.name || ''}`, width) + '\n';

    const mods = Array.isArray(item.modifiers) ? item.modifiers : Object.values(item.modifiers || {});
    for (const m of mods as any[]) {
      const mQty = m.qty || m.quantity || 1;
      let mName = `   ↳ ${mQty > 1 ? mQty + 'x ' : ''}${m.name}`;
      out += padRight(mName, width) + '\n';
    }
  }
  out += div;
  out += '\n\n\n\n\n';
  return out;
}

export default ReceiptPrinting;