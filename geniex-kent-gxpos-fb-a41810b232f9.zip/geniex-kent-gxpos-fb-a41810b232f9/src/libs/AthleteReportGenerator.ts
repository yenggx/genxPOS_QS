// src/libs/AthleteReportGenerator.ts

export interface AthleteReportRow {
  DATE: string;
  SALES_NUMBER: string;
  CUSTOMER_NAME: string;
  CUSTOMER_ID: string;
  GROSS: number;
  OTHER_CHARGES: number;
  DISCOUNTS: number;
  VAT_ADJ: number;
  NET_SALES: number;
  VAT_EXEMPT_SALES: number;
  CASH: number;
  CREDIT_CARD: number;
  OTHER: number;
  REMARKS: string;
}

const safePesos = (v: number) => (v || 0) / 100;
const formatAmt = (v: number) => parseFloat((v || 0).toFixed(2));

export function buildAthleteReportRows(transactions: Record<string, any>[]): AthleteReportRow[] {
  const rows: AthleteReportRow[] = [];

  for (const tx of transactions) {
    const txType = String(tx.transactionType || tx.TransactionType || '').toUpperCase();
    
    if (txType !== 'ATHLETE') {
      continue;
    }

    const txDate = new Date(tx.createdAt || tx.date || Date.now());
    const p2 = (n: number) => String(n).padStart(2, '0');
    const dateStr = `${p2(txDate.getMonth() + 1)}/${p2(txDate.getDate())}/${txDate.getFullYear()}`;

    const guests = tx.guest || tx.guests || [];
    const firstGuest = guests[0] || {};
    const customerName = firstGuest.guestName || firstGuest.name || firstGuest.customerName || '';
    const customerId = firstGuest.guestId || firstGuest.id || firstGuest.tin || firstGuest.athleteId || '';

    let gross = 0;
    let otherCharges = 0;

    for (const item of (tx.items || tx.cart || [])) {
      const qty = item.quantity || item.qty || 1;
      let itemGross = safePesos(item.price || 0) * qty;

      for (const mod of (item.modifiers || item.selectedModifiers || [])) {
        let modPesos = 0;
        if (mod.price && mod.price >= 10000 && mod.price % 100 === 0) {
          modPesos = mod.price / 10000;
        } else {
          modPesos = safePesos(mod.price || 0);
        }
        const modQty = mod.quantity || mod.qty || 1;
        itemGross += modPesos * modQty; // Add modifiers directly to gross
      }
      gross += itemGross;
    }

    let cash = 0;
    let creditCard = 0;
    let other = 0;

    const paymentsRaw = Array.isArray(tx.payment) && tx.payment.length > 0 
      ? tx.payment 
      : [{ method: tx.paymentMethod || tx.PaymentMethod || 'CASH', amount: tx.price?.eaterPayment || tx.price?.subtotal || 0 }];

    for (const p of paymentsRaw) {
      const method = String(p.PaymentMethod || p.method || '').toUpperCase();
      let amtRaw = Number(p.Amount ?? p.amount ?? 0);

      if (amtRaw > 1000 && amtRaw > (tx.price?.subtotal || 0) * 0.5) {
        amtRaw = amtRaw / 100;
      }

      if (method === 'CASH') {
        cash += amtRaw;
      } else if (method.includes('CARD') || method.includes('CREDIT') || method.includes('DEBIT')) {
        creditCard += amtRaw;
      } else {
        other += amtRaw;
      }
    }

    const discountAmt = safePesos(tx.discountAmount || 0);
    
    // Per NAAC instructions: "From gross remove vat, calc the discount and deduct then add the vat back"
    const grossVatExclusive = gross / 1.12;
    const vatAmount = gross - grossVatExclusive;
    const netSales = grossVatExclusive - discountAmt + vatAmount;

    // Athlete has no VAT Exemption
    const vatExemptSales = 0; 

    rows.push({
      DATE: dateStr,
      SALES_NUMBER: tx.salesNumber || tx.transactionNo || tx.OrderNo || '-',
      CUSTOMER_NAME: customerName,
      CUSTOMER_ID: customerId,
      GROSS: formatAmt(gross),
      OTHER_CHARGES: formatAmt(otherCharges), // Stays 0 as modifiers moved to GROSS
      DISCOUNTS: formatAmt(discountAmt),
      VAT_ADJ: formatAmt(vatAmount), // Reusing VAT_ADJ to display the actual VAT Amount for NAAC
      NET_SALES: formatAmt(netSales),
      VAT_EXEMPT_SALES: formatAmt(vatExemptSales),
      CASH: formatAmt(cash),
      CREDIT_CARD: formatAmt(creditCard),
      OTHER: formatAmt(other),
      REMARKS: tx.otherFee?.Remarks || tx.remarks || '',
    });
  }

  return rows;
}

export function athleteReportToCsv(rows: AthleteReportRow[]): string {
  const COLUMNS: (keyof AthleteReportRow)[] = [
    'DATE', 'SALES_NUMBER', 'CUSTOMER_NAME', 'CUSTOMER_ID', 'GROSS', 
    'OTHER_CHARGES', 'DISCOUNTS', 'VAT_ADJ', 'NET_SALES', 
    'VAT_EXEMPT_SALES', 'CASH', 'CREDIT_CARD', 'OTHER', 'REMARKS'
  ];

  const headerRow = COLUMNS.join(',');

  if (rows.length === 0) return headerRow;

  const escape = (v: string | number) => {
    const s = String(v ?? '');
    return s.includes(',') || s.includes('"') || s.includes('\n')
      ? `"${s.replace(/"/g, '""')}"`
      : s;
  };

  const dataRows = rows.map(r => COLUMNS.map(c => escape(r[c])).join(',')).join('\r\n');

  return `${headerRow}\r\n${dataRows}`;
}