/**
 * EsfGenerator.ts
 * Pure utility — no side effects, no imports from Next/React.
 * Builds a flat array of ESF rows from the same transactions + closedSessions
 * that are already loaded in the EOD page.
 *
 * === VAT / DISCOUNT RULES (BIR ESF spec) ===
 *
 * GROUP A — SC and PWD ONLY (true VAT-exempt discounts per BIR):
 * - item has itemDiscount > 0  →
 * DISCOUNT_W_VAT  = 0                                ← discount goes in WO_VAT, NOT W_VAT
 * DISCOUNT_WO_VAT = itemDiscPesos                    ← ex-VAT discount amount (price/1.12 × pct)
 * VAT_EXEMPT_AMT  = (lineGross / 1.12) × 0.12        ← VAT originally embedded in gross price
 * AMOUNT_DUE      = lineGross - DISCOUNT_WO_VAT - VAT_EXEMPT_AMT
 * = (lineGross / 1.12) × (1 - discountPct)
 * VAT_AMOUNT      = 0
 * NET_PRICE       = lineGross / 1.12                 ← ex-VAT selling price (before discount)
 * PCT_DISCOUNT    = discountID string (e.g. "20")
 * - item has NO itemDiscount on same tx →
 * normal VAT computation (proportional VAT_AMOUNT, NET_PRICE)
 * VAT_EXEMPT_AMT  = 0, DISCOUNT_W_VAT = 0, DISCOUNT_WO_VAT = 0
 * - DISCOUNT_TYPE shown ONLY on the first discounted item row; blank on all others
 * SRC → 'SC', PWD → 'PWD' (kept separate — not combined as SR/PWD)
 * - Discounted items sorted to TOP of that transaction's rows
 *
 * GROUP B — VAT-exempt NON-discount types (DIPLOMAT, PEZA):
 * - These are NOT discounts — they are VAT classification exemptions
 * - DISCOUNT_W_VAT  = 0  (always — not a discount)
 * - VAT_EXEMPT_AMT  = itemDiscPesos  (the VAT amount stripped from each item)
 * - VAT_AMOUNT      = 0
 * - NET_PRICE       = AMOUNT_DUE
 * - PCT_DISCOUNT    = ''  (not a discount percentage)
 * - DISCOUNT_TYPE   = DIPLOMAT / PEZA label (shown on first discounted item)
 *
 * GROUP C — All other discount types (ATHLETE, VIP, SOLO, MEDAL, NAAC, REGULAR, CUSTOM):
 * - These are VAT-inclusive discounts; VAT is still charged on the net amount
 * - DISCOUNT_W_VAT  = itemDiscPesos
 * - VAT_EXEMPT_AMT  = 0
 * - VAT_AMOUNT      computed proportionally from tx-level VatAmount
 * - NET_PRICE       = AMOUNT_DUE - VAT_AMOUNT
 * - PCT_DISCOUNT    = discountID string
 * - DISCOUNT_TYPE shown ONLY on the first discounted item; blank on rest
 * - Discounted items sorted to top
 *
 * GROUP D — No discount, normal transaction:
 * - All discount / exempt fields = 0
 * - VAT_AMOUNT and NET_PRICE computed normally (proportional)
 */

export interface EsfRow {
  TERMINAL_NO:       string;
  SHIFT_NO:          string | number;
  CASHIER_NAME:      string;
  ITEM_CODE:         string;
  ITEM_DESCRIPTION:  string;
  SELLING_PRICE:     number | string;
  QTY:               number | string;
  DISCOUNT_W_VAT:    number | string;
  DISCOUNT_WO_VAT:   number | string;
  PCT_DISCOUNT:      string;
  VAT_EXEMPT_AMT:    number | string;
  DELIVERY_CHARGE:   string;
  AMOUNT_DUE:        number | string;
  TRANSACTION_NO:    string;
  VAT_AMOUNT:        number | string;
  NET_PRICE:         number | string;
  TENDER_TYPE:       string;
  PAYMENT_INFO:      string;
  DATE_SOLD:         string;
  TIME_SOLD:         string;
  CATEGORY:          string;
  OUTLET_NAME:       string;
  TRANSACTION_COUNT: number;
  SALES_DATE:        string;
  MEAL_TYPE:         string;
  DISCOUNT_TYPE:     string;
  DELIVERY_TYPE:     string;
  ORDER_REF_NO:      string;
  WHTAX_RATE:        string;
  TENDERED_AMOUNT:   number | string;
  REF_NO:            string;
  CHARGE_TO:         string;
  CUSTOMER_NAME:     string;
  APPROVAL_NO:       string;
  MERCHANT_ID:       string;
  CARD_BANK:         string;
  CARD_NO:           string;
  CHECK_NO:          string;
  CHECK_DATE:        string;
}

// ─── Transaction type classification ─────────────────────────────────────────

const VAT_EXEMPT_DISCOUNT_TYPES = new Set([
  'SRPWD', 'SRC', 'PWD',
]);

const VAT_EXEMPT_NON_DISCOUNT_TYPES = new Set([
  'DIPLOMAT', 'PEZA',
]);

const DISCOUNT_TYPE_LABEL: Record<string, string> = {
  SRPWD:    'SR/PWD',
  SRC:      'SC',
  PWD:      'PWD',
  ATHLETE:  'ATHLETE',
  VIP:      'VIP',
  SOLO:     'SOLO PARENT',
  MEDAL:    'MEDAL OF VALOR',
  NAAC:     'NAAC',
  DIPLOMAT: 'DIPLOMAT',   
  PEZA:     'PEZA',       
  REGULAR:  '',
  CUSTOM:   'CUSTOM',
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
const safePesos = (v: number) => v / 100;

const formatAmt = (v: number) => v === 0 ? '' : parseFloat(v.toFixed(4));

function getItemUnitPricePesos(item: Record<string, any>): number {
  let totalPesos = safePesos(item.price || 0);
  const modifiers: Record<string, any>[] = item.modifiers || item.selectedModifiers || [];
  
  for (const mod of modifiers) {
    const modPesos = safePesos(mod.price || 0); // No guessing game, explicitly divide by 100
    const modQty = mod.quantity || mod.qty || 1;
    totalPesos += modPesos * modQty;
  }
  return totalPesos;
}

function normaliseTender(raw: string): string {
  const s = raw.toUpperCase().trim();
  if (s === 'CASH')                          return 'CASH';
  if (s.includes('MAYA'))                    return 'MAYA';
  if (s.includes('GCASH'))                   return 'GCASH';
  if (s.includes('QRPH'))                    return 'QRPH';
  if (s.includes('LANDERS'))                 return 'LANDERS';
  if (s.includes('CARD'))                    return 'CARD';
  if (s.includes('CHECK'))                   return 'CHECK';
  if (s.includes('VOUCHER'))                 return 'VOUCHER';
  if (
    s === 'ON_ACCOUNT' ||
    s === 'ON ACCOUNT' ||
    s === 'ONACCOUNT'  ||
    s === 'ACCOUNT'    ||
    s === 'OTHER'      ||
    s === 'BANK_TRANSFER'
  )                                          return 'ON ACCOUNT';
  return s;
}

function stripSubcategory(cat: string): string {
  if (!cat) return cat;
  const colonIdx = cat.indexOf(':');
  if (colonIdx === -1) return cat.trim();
  return cat.substring(0, colonIdx).trim();
}

function getDrinksSizeItemCode(item: Record<string, any>): string | null {
  const modifiers: Record<string, any>[] = item.modifiers || item.selectedModifiers || [];
  for (const mod of modifiers) {
    const modId: string = mod.id || mod.modifierId || '';
    if (modId.startsWith('CL-')) {
      const pipeIdx = modId.indexOf('|');
      if (pipeIdx !== -1) {
        return modId.substring(pipeIdx + 1); 
      }
    }
  }
  return null;
}

// ─── Session lookup ───────────────────────────────────────────────────────────

interface ClosedSession {
  sessionId?: string;
  staffId?: string;
  staffName?: string;
  shiftNumber?: number | string;
}

function sessionForTx(
  tx: Record<string, any>,
  closedSessions: ClosedSession[],
): ClosedSession | undefined {
  const txStaffId = tx.staffId || tx.cashierId;
  if (txStaffId) {
    const match = closedSessions.find(s => s.staffId === txStaffId);
    if (match) return match;
  }
  return closedSessions[0];
}

// ─── Main export ──────────────────────────────────────────────────────────────

function groupDonutsIntoBoxes(rawItems: Record<string, any>[], catMap: Record<string, string>): Record<string, any>[] {
  const newItems: Record<string, any>[] = [];
  
  const baseDefs = {
    CLASSIC: { codes: { 6: 'AA10000572', 3: 'AA10000571', 1: 'AA10000570' }, prefix: 'CLASSIC' },
    PREMIUM: { codes: { 6: 'AA247', 3: 'AA246', 1: 'AA245' }, prefix: 'PREM' },
    SUPREME: { codes: { 6: 'AA10000363', 3: 'AA10000362', 1: 'AA10000361' }, prefix: 'SUPREME' }
  };

  // Map to hold dynamic groups based on Category + Per-Unit Discount to prevent mixing
  const dynamicGroups: Record<string, { count: number, template: any, codes: any, prefix: string, perUnitDiscount: number }> = {};

  for (const item of rawItems) {
    let stockId = item.id || '';
    if (item.barcode && item.barcode !== 'GTIN') stockId = `IT-${item.barcode}`;
    const rawCat = catMap[stockId] || catMap[item.id] || item.category || '';
    const catUpper = rawCat.toUpperCase();
    
    // Only exclude items with actual modifiers (like combo additions)
    const hasMods = item.modifiers && item.modifiers.length > 0;
    
    let baseCat = null;

    if (!hasMods) {
      if (catUpper.includes('CLASSIC') || catUpper.includes(': CD')) baseCat = 'CLASSIC';
      else if (catUpper.includes('PREMIUM') || catUpper.includes(': PD')) baseCat = 'PREMIUM';
      else if (catUpper.includes('SUPREME') || catUpper.includes(': SD')) baseCat = 'SUPREME';
      // Fallback matching via itemCode prefixes
      else if (item.itemCode && String(item.itemCode).startsWith('CLASSIC-')) baseCat = 'CLASSIC';
      else if (item.itemCode && String(item.itemCode).startsWith('PREMIUM-')) baseCat = 'PREMIUM';
      else if (item.itemCode && String(item.itemCode).startsWith('S00')) baseCat = 'SUPREME';
    }

    item.resolvedCategory = rawCat; // Save original category for the ESF column

    if (baseCat) {
      const qty = item.quantity || item.qty || 1;
      
      // Calculate the discount applied to a SINGLE donut on this line
      const perUnitDiscountRaw = (item.itemDiscount || 0) / qty;
      const perUnitDiscountRounded = Math.round(perUnitDiscountRaw * 100) / 100;
      const discountId = item.discountID || '';
      
      // Group Key: e.g. "CLASSIC_8.93_20" (Ensures full price and diff discounts don't mix)
      const groupKey = `${baseCat}_${perUnitDiscountRounded}_${discountId}`;

      if (!dynamicGroups[groupKey]) {
        dynamicGroups[groupKey] = {
          count: 0,
          template: item,
          codes: baseDefs[baseCat as keyof typeof baseDefs].codes,
          prefix: baseDefs[baseCat as keyof typeof baseDefs].prefix,
          perUnitDiscount: perUnitDiscountRaw // Store precise unrounded value for total math
        };
      }

      dynamicGroups[groupKey].count += qty;
    } else {
      newItems.push(item);
    }
  }

  // Calculate box sizes mathematically for each dynamic group
  for (const group of Object.values(dynamicGroups)) {
    if (group.count === 0) continue;
    
    const template = group.template;
    const basePrice = template.price || 0;
    
    let remaining = group.count;
    const qty6 = Math.floor(remaining / 6);
    remaining %= 6;
    
    const qty3 = Math.floor(remaining / 3);
    remaining %= 3;
    
    const qty1 = remaining;

    const pDisc = group.perUnitDiscount;

    if (qty6 > 0) {
      newItems.push({ 
        ...template, 
        quantity: qty6, 
        qty: qty6, 
        itemName: `${group.prefix} 6`, 
        name: `${group.prefix} 6`, 
        id: group.codes[6], 
        barcode: 'GTIN', 
        price: basePrice * 6,
        itemDiscount: pDisc > 0 ? Math.round(pDisc * 6 * qty6) : undefined
      });
    }
    if (qty3 > 0) {
      newItems.push({ 
        ...template, 
        quantity: qty3, 
        qty: qty3, 
        itemName: `${group.prefix} 3`, 
        name: `${group.prefix} 3`, 
        id: group.codes[3], 
        barcode: 'GTIN', 
        price: basePrice * 3,
        itemDiscount: pDisc > 0 ? Math.round(pDisc * 3 * qty3) : undefined
      });
    }
    if (qty1 > 0) {
      newItems.push({ 
        ...template, 
        quantity: qty1, 
        qty: qty1, 
        itemName: `${group.prefix} 1`, 
        name: `${group.prefix} 1`, 
        id: group.codes[1], 
        barcode: 'GTIN', 
        price: basePrice * 1,
        itemDiscount: pDisc > 0 ? Math.round(pDisc * 1 * qty1) : undefined
      });
    }
  }

  return newItems;
}

export function buildEsfRows(
  transactions: Record<string, any>[],
  closedSessions: ClosedSession[],
  workstationId = '001',
  outletName    = '',
  catMap: Record<string, string> = {},
  businessDate  = '',
): EsfRow[] {
  const rows: EsfRow[] = [];
  const totalTransactions = transactions.length; 

  // Sort transactions: Terminal # ascending, then Transaction Number ascending
  const sortedTransactions = [...transactions].sort((a, b) => {
    const aTerm = String(a.KioskNo || a.workstationId || workstationId);
    const bTerm = String(b.KioskNo || b.workstationId || workstationId);
    
    if (aTerm < bTerm) return -1;
    if (aTerm > bTerm) return 1;

    const aSi = String(a.salesNumber || a.transactionNo || '0');
    const bSi = String(b.salesNumber || b.transactionNo || '0');
    
    // Extract purely the trailing numbers (e.g., 'WS1-00055' -> 55)
    const extractNum = (str: string) => {
      const match = str.match(/\d+$/);
      return match ? parseInt(match[0], 10) : 0;
    };

    return extractNum(aSi) - extractNum(bSi);
  });

  for (const tx of sortedTransactions) {

    const isVoid   = tx.status === 'voided'   || tx.orderState === 'VOIDED';
    const isRefund = tx.status === 'refunded' || tx.orderState === 'REFUNDED';

    const txTypeRaw = (tx.transactionType || 'REGULAR').toUpperCase();
    const txType    = txTypeRaw === 'SC' ? 'SRC' : txTypeRaw;

    const isGroupA = VAT_EXEMPT_DISCOUNT_TYPES.has(txType);
    const isGroupB = VAT_EXEMPT_NON_DISCOUNT_TYPES.has(txType);

    const session  = sessionForTx(tx, closedSessions);
    const terminal = tx.KioskNo || tx.workstationId || workstationId;
    const shiftNo  = session?.shiftNumber ?? tx.shiftNumber ?? tx.shiftNo ?? '-';
    const cashier  = tx.cashierName || session?.staffName || 'UNKNOWN';
    const siNo     = tx.salesNumber || tx.transactionNo || '-';

    const txDate   = new Date(tx.createdAt || tx.date || Date.now());
    const p2       = (n: number) => String(n).padStart(2, '0');
    
    let dateSold = `${p2(txDate.getMonth() + 1)}/${p2(txDate.getDate())}/${txDate.getFullYear()}`;
    
    // Override the transaction date with the business date if provided
    if (businessDate) {
      const parts = businessDate.split('T')[0].split('-');
      if (parts.length === 3) {
        // Format YYYY-MM-DD into MM/DD/YYYY
        dateSold = `${parts[1]}/${parts[2]}/${parts[0]}`;
      }
    }
    
    const timeSold = `${p2(txDate.getHours())}:${p2(txDate.getMinutes())}:${p2(txDate.getSeconds())}`;

    const txGrossCents = tx.price?.subtotal || 0;
    const txVat = safePesos(tx.price?.VatAmount || tx.price?.tax || 0);

    const mealType     = tx.featureFlags?.orderType || tx.orderType || tx.dineType || '';
    const deliveryType = tx.deliveryPlatform || tx.deliveryType || '';
    const orderRefNo   = tx.orderRefNo || tx.platformOrderId || '';
    const customerName = tx.guestName  || (tx.guest?.[0]?.guestName) || '';

    const paymentsRaw: Record<string, any>[] = Array.isArray(tx.payment) ? tx.payment : [];
    const payments = paymentsRaw.length > 0 ? paymentsRaw : [{
      method: tx.paymentMethod || tx.PaymentMethod || 'CASH',
      Amount: txGrossCents, // Force uppercase 'Amount' so it triggers the cents divider below
      referenceNo: tx.referenceNo || ''
    }];

    const collatedPayments: Record<string, any>[] = [];
    const paymentsByTender: Map<string, Record<string, any>> = new Map();
    for (const p of payments) {
      const methodRaw = String(p.PaymentMethod || p.method || '');
      const tender    = methodRaw ? normaliseTender(methodRaw) : '';
      
      // ESF MUST show the applied amount to balance the rows, NOT the voucher's face value.
      // Therefore, we strictly use 'Amount' (clamped to the balance) and ignore 'Tendered'.
      const rawAmt = p.Amount !== undefined ? Number(p.Amount) / 100 : Number(p.amount || 0);

      if (paymentsByTender.has(tender)) {
        const existing = paymentsByTender.get(tender)!;
        existing.amount = Number(existing.amount || 0) + rawAmt;
      } else {
        const clone = { ...p, amount: rawAmt };
        delete clone.Amount; 
        delete clone.Tendered;
        paymentsByTender.set(tender, clone);
        collatedPayments.push(clone);
      }
    }

    const unmappedItems: Record<string, any>[] = tx.items || tx.cart || [];
    const groupedItems = groupDonutsIntoBoxes(unmappedItems, catMap);
    
    const sortedItems = [...groupedItems].sort((a, b) => {
      const aDisc = a.itemDiscount ?? 0;
      const bDisc = b.itemDiscount ?? 0;
      if (bDisc > 0 && aDisc === 0) return 1;
      if (aDisc > 0 && bDisc === 0) return -1;
      return 0;
    });

    let itemsGrossTotalPesos = 0;
    for (const item of sortedItems) {
      const p = getItemUnitPricePesos(item);
      itemsGrossTotalPesos += p * (item.quantity || item.qty || 1);
    }

    const rowCount = Math.max(sortedItems.length, collatedPayments.length);

    for (let i = 0; i < rowCount; i++) {
      const item    = sortedItems[i]       || {};
      const payment = collatedPayments[i]  || {};
      const isItemData = i < sortedItems.length;
      const isCustomItem = isItemData && String(item.id || item.barcode || '').startsWith('CUSTOM');

      const payMethodRaw = String(payment.PaymentMethod || payment.method || '');
      const tenderType = payMethodRaw ? normaliseTender(payMethodRaw) : '';

      const refNo      = payment.RefrenceNo  || payment.referenceNo || payment.ref || '';
      const approvalNo = payment.approvalCode || payment.approval    || '';
      const merchantId = payment.merchantId   || payment.mid         || '';
      const cardBank   = payment.bankName     || payment.bank        || '';
      const cardNo     = payment.maskedPan    || payment.cardNo      || '';
      const checkNo    = payment.checkNo      || '';
      const checkDate  = payment.checkDate    || '';
      const chargeTo   = payment.chargeTo     || payment.swipeTo     || '';
      const paymentInfo = refNo || approvalNo || '';

      const tenderedRaw = Number(payment.amount ?? 0); // Already explicitly normalized to pesos above

      const itemPricePesos = isItemData ? getItemUnitPricePesos(item) : 0;
      const qty            = isItemData ? (item.quantity || item.qty || 1) : 0;
      const lineGross      = itemPricePesos * qty;

      let itemDiscPesos = isItemData && item.itemDiscount ? safePesos(item.itemDiscount) : 0;

      if (isItemData && itemDiscPesos === 0 && !isGroupA && !isGroupB && (tx.discountAmount ?? 0) > 0) {
        const txDiscPesos = safePesos(tx.discountAmount);
        const proportion  = itemsGrossTotalPesos > 0
          ? lineGross / itemsGrossTotalPesos
          : 0;
        itemDiscPesos = txDiscPesos * proportion;
      }

      const hasDiscount = itemDiscPesos > 0;
      const amountDueDefault = lineGross - itemDiscPesos;

      const proportion = itemsGrossTotalPesos > 0 && isItemData
        ? lineGross / itemsGrossTotalPesos
        : 0;

      let discountWVat:  number;
      let discountWoVat: number;
      let vatExemptAmt:  number;
      let amountDue:     number;
      let vatAmount:     number;
      let netPrice:      number;
      let pctDiscount:   string;
      let discountType:  string;

      if (isGroupB) {
        discountWVat  = 0;
        discountWoVat = 0;
        vatExemptAmt  = itemDiscPesos;
        amountDue     = amountDueDefault;
        vatAmount     = 0;
        netPrice      = amountDue;
        pctDiscount   = '0';
        if (isItemData) {
          discountType = DISCOUNT_TYPE_LABEL[txType] ?? txType;
        } else {
          discountType = '';
        }

      } else if (isGroupA && hasDiscount) {
        const vatEmbedded = (lineGross / 1.12) * 0.12;
        discountWVat  = 0;
        discountWoVat = itemDiscPesos;
        vatExemptAmt  = vatEmbedded;
        amountDue     = lineGross - itemDiscPesos - vatEmbedded;
        vatAmount     = 0;
        netPrice      = lineGross / 1.12;
        pctDiscount   = isItemData && item.discountID ? String(item.discountID) : '0';
        discountType  = DISCOUNT_TYPE_LABEL[txType] ?? txType;

      } else if (isGroupA && !hasDiscount) {
        discountWVat  = 0;
        discountWoVat = 0;
        vatExemptAmt  = 0;
        amountDue     = amountDueDefault;
        vatAmount     = txVat * proportion;
        netPrice      = amountDue - vatAmount;
        pctDiscount   = '0';
        discountType  = '';

      } else {
        discountWVat  = itemDiscPesos;
        discountWoVat = 0;
        vatExemptAmt  = 0;
        amountDue     = amountDueDefault;
        vatAmount     = txVat * proportion;
        netPrice      = amountDue - vatAmount;
        pctDiscount   = isItemData && item.discountID ? String(item.discountID) : '0';

        if (hasDiscount) {
          discountType = tx.discountInfo?.label || DISCOUNT_TYPE_LABEL[txType] || txType;
        } else {
          discountType = '';
        }
      }

      let stockId: string;
      if (isItemData) {
        const drinksSizeCode = getDrinksSizeItemCode(item);
        if (drinksSizeCode) {
          stockId = drinksSizeCode;
        } else if (isCustomItem) {
          stockId = 'OPEN ITEM';
        } else if (item.barcode && item.barcode !== 'GTIN') {
          stockId = `IT-${item.barcode}`;
        } else {
          stockId = item.id || '';
        }
      } else {
        stockId = '';
      }

      let rawCategory = '';
      if (isItemData) {
        if (isCustomItem) rawCategory = 'OPEN ITEM';
        else rawCategory = item.resolvedCategory || catMap[stockId] || catMap[item.id] || item.category || '';
      }
      const category = stripSubcategory(rawCategory);

      const itemDesc = isItemData ? (item.itemName || item.name || '') : '';

      let effectiveTxType = txType;
      if (isVoid)   effectiveTxType = 'VOID';
      if (isRefund) effectiveTxType = 'REFUND';

      rows.push({
        TERMINAL_NO:       String(terminal),
        SHIFT_NO:          shiftNo,
        CASHIER_NAME:      cashier,
        ITEM_CODE:         stockId,
        ITEM_DESCRIPTION:  itemDesc,
        SELLING_PRICE:     formatAmt(itemPricePesos),
        QTY:               qty === 0 ? '' : qty,
        DISCOUNT_W_VAT:    formatAmt(discountWVat),
        DISCOUNT_WO_VAT:   formatAmt(discountWoVat),
        PCT_DISCOUNT:      pctDiscount,
        VAT_EXEMPT_AMT:    formatAmt(vatExemptAmt),
        DELIVERY_CHARGE:   '',
        AMOUNT_DUE:        formatAmt(amountDue),
        TRANSACTION_NO:    siNo,
        VAT_AMOUNT:        formatAmt(vatAmount),
        NET_PRICE:         formatAmt(netPrice),
        TENDER_TYPE:       tenderType,
        PAYMENT_INFO:      paymentInfo,
        DATE_SOLD:         dateSold,
        TIME_SOLD:         timeSold,
        CATEGORY:          category,
        OUTLET_NAME:       outletName,
        TRANSACTION_COUNT: totalTransactions, 
        SALES_DATE:        dateSold,
        MEAL_TYPE:         mealType,
        DISCOUNT_TYPE:     discountType,
        DELIVERY_TYPE:     deliveryType,
        ORDER_REF_NO:      orderRefNo,
        WHTAX_RATE:        '',
        TENDERED_AMOUNT:   formatAmt(tenderedRaw),
        REF_NO:            refNo,
        CHARGE_TO:         chargeTo,
        CUSTOMER_NAME:     customerName,
        APPROVAL_NO:       approvalNo,
        MERCHANT_ID:       merchantId,
        CARD_BANK:         cardBank,
        CARD_NO:           cardNo,
        CHECK_NO:          checkNo,
        CHECK_DATE:        checkDate,
      });
    }
  }

  return rows;
}

export function esfRowsToCsv(rows: EsfRow[]): string {
  const COLUMNS: (keyof EsfRow)[] = [
    'TERMINAL_NO',
    'SHIFT_NO',
    'CASHIER_NAME',
    'ITEM_CODE',
    'ITEM_DESCRIPTION',
    'SELLING_PRICE',
    'QTY',
    'DISCOUNT_W_VAT',
    'DISCOUNT_WO_VAT',
    'PCT_DISCOUNT',
    'VAT_EXEMPT_AMT',
    'DELIVERY_CHARGE',
    'AMOUNT_DUE',
    'TRANSACTION_NO',
    'VAT_AMOUNT',
    'NET_PRICE',
    'MEAL_TYPE',
    'DISCOUNT_TYPE',
    'DELIVERY_TYPE',
    'ORDER_REF_NO',
    'TENDER_TYPE',
    'WHTAX_RATE',
    'TENDERED_AMOUNT',
    'REF_NO',
    'CHARGE_TO',
    'CUSTOMER_NAME',
    'APPROVAL_NO',
    'MERCHANT_ID',
    'CARD_BANK',
    'CARD_NO',
    'CHECK_NO',
    'CHECK_DATE',
    'DATE_SOLD',
    'TIME_SOLD',
    'CATEGORY',
    'OUTLET_NAME',
    'TRANSACTION_COUNT',
    'SALES_DATE',
  ];

  const escape = (v: string | number) => {
    const s = String(v ?? '');
    return s.includes(',') || s.includes('"') || s.includes('\n')
      ? `"${s.replace(/"/g, '""')}"`
      : s;
  };

  return rows.map(r => COLUMNS.map(c => escape(r[c])).join(',')).join('\r\n');
}